# PerformanceOptimization.psm1
# Dynamic performance optimization strategies

# Optimize performance based on current metrics
function Optimize-Performance {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration,
        
        [Parameter(Mandatory)]
        [hashtable]$Bottlenecks,
        
        [object]$CacheManager
    )
    
    Write-Verbose "[PerformanceOptimization] Optimizing performance based on current metrics"
    
    $optimizations = @()
    
    # Optimize based on identified bottlenecks
    if ($Bottlenecks.ContainsKey('QueueBacklog')) {
        $result = Optimize-BatchSize -Configuration $Configuration
        if ($result) { $optimizations += $result }
    }
    
    if ($Bottlenecks.ContainsKey('CacheEfficiency')) {
        $result = Optimize-CacheSettings -Configuration $Configuration -CacheManager $CacheManager
        if ($result) { $optimizations += $result }
    }
    
    if ($Bottlenecks.ContainsKey('MemoryPressure')) {
        $result = Optimize-MemoryUsage
        if ($result) { $optimizations += $result }
    }
    
    if ($Bottlenecks.ContainsKey('ThroughputDegradation')) {
        $result = Optimize-ThreadCount -Configuration $Configuration
        if ($result) { $optimizations += $result }
    }
    
    return $optimizations
}

# Increase batch size for better throughput
function Optimize-BatchSize {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration,
        
        [decimal]$IncreaseFactor = 1.5,
        [int]$MaxBatchSize = 200
    )
    
    $currentBatchSize = $Configuration.BatchSize
    $newBatchSize = [Math]::Min([int]($currentBatchSize * $IncreaseFactor), $MaxBatchSize)
    
    if ($newBatchSize -ne $currentBatchSize) {
        $Configuration.BatchSize = $newBatchSize
        Write-Information "[PerformanceOptimization] Increased batch size from $currentBatchSize to $newBatchSize"
        return "BatchSize increased to $newBatchSize"
    }
    
    return $null
}

# Optimize cache settings for better hit rate
function Optimize-CacheSettings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration,
        
        [object]$CacheManager,
        
        [decimal]$IncreaseFactor = 1.2,
        [int]$MaxCacheSize = 10000
    )
    
    if (-not $CacheManager) {
        Write-Warning "[PerformanceOptimization] CacheManager not available for optimization"
        return $null
    }
    
    $currentSize = $Configuration.CacheSize
    $newSize = [Math]::Min([int]($currentSize * $IncreaseFactor), $MaxCacheSize)
    
    if ($newSize -ne $currentSize) {
        $Configuration.CacheSize = $newSize
        
        # Apply new cache size if possible
        if ($CacheManager.SetMaxSize) {
            $CacheManager.SetMaxSize($newSize)
        }
        
        Write-Information "[PerformanceOptimization] Increased cache size from $currentSize to $newSize"
        return "CacheSize increased to $newSize"
    }
    
    return $null
}

# Reduce memory usage through cleanup
function Optimize-MemoryUsage {
    [CmdletBinding()]
    param()
    
    # Force garbage collection
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    
    $memoryBefore = [GC]::GetTotalMemory($false) / 1MB
    [GC]::Collect(2, [GCCollectionMode]::Forced, $true)
    $memoryAfter = [GC]::GetTotalMemory($false) / 1MB
    
    $memorySaved = [Math]::Round($memoryBefore - $memoryAfter, 2)
    
    Write-Information "[PerformanceOptimization] Memory cleanup performed, freed $memorySaved MB"
    return "Memory freed: $memorySaved MB"
}

# Clean completed queue items
function Clear-CompletedQueue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Collections.Concurrent.ConcurrentQueue[PSCustomObject]]$CompletedQueue,
        
        [int]$ItemsToKeep = 100
    )
    
    $currentCount = $CompletedQueue.Count
    if ($currentCount -le $ItemsToKeep) {
        return 0
    }
    
    $itemsToRemove = $currentCount - $ItemsToKeep
    $removed = 0
    
    for ($i = 0; $i -lt $itemsToRemove; $i++) {
        $result = $null
        if ($CompletedQueue.TryDequeue([ref]$result)) {
            $removed++
        }
        else {
            break
        }
    }
    
    Write-Debug "[PerformanceOptimization] Cleared $removed items from completed queue"
    return $removed
}

# Optimize thread count based on performance
function Optimize-ThreadCount {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration,
        
        [decimal]$IncreaseFactor = 1.25,
        [int]$MaxThreads = 64
    )
    
    $currentThreads = if ($Configuration.ContainsKey('ThreadCount')) {
        $Configuration.ThreadCount
    } else {
        [Environment]::ProcessorCount * 2
    }
    
    $newThreads = [Math]::Min([int]($currentThreads * $IncreaseFactor), $MaxThreads)
    
    if ($newThreads -ne $currentThreads) {
        $Configuration.ThreadCount = $newThreads
        Write-Information "[PerformanceOptimization] Increased thread count from $currentThreads to $newThreads"
        return "ThreadCount increased to $newThreads"
    }
    
    return $null
}

# Apply adaptive throttling based on system resources
function Get-AdaptiveThrottling {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Metrics,
        
        [int]$TargetQueueLength = 100,
        [decimal]$MemoryThresholdMB = 1000
    )
    
    $throttleSettings = @{
        ShouldThrottle = $false
        ThrottleDelayMs = 0
        Reason = ""
    }
    
    # Check queue length
    if ($Metrics.QueueLength -gt ($TargetQueueLength * 2)) {
        $throttleSettings.ShouldThrottle = $true
        $throttleSettings.ThrottleDelayMs = [Math]::Min(($Metrics.QueueLength - $TargetQueueLength) * 10, 1000)
        $throttleSettings.Reason = "Queue backlog"
    }
    
    # Check memory usage
    if ($Metrics.MemoryUsage -gt $MemoryThresholdMB) {
        $throttleSettings.ShouldThrottle = $true
        $memoryDelay = [Math]::Min((($Metrics.MemoryUsage - $MemoryThresholdMB) / 10), 500)
        $throttleSettings.ThrottleDelayMs = [Math]::Max($throttleSettings.ThrottleDelayMs, $memoryDelay)
        $throttleSettings.Reason = if ($throttleSettings.Reason) { "$($throttleSettings.Reason), Memory pressure" } else { "Memory pressure" }
    }
    
    return $throttleSettings
}

# Dynamic batch size adjustment
function Get-DynamicBatchSize {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Metrics,
        
        [int]$BaseBatchSize = 50,
        [int]$MinBatchSize = 10,
        [int]$MaxBatchSize = 200
    )
    
    $queueLength = $Metrics.QueueLength
    $throughput = $Metrics.FilesPerSecond
    
    # Adjust batch size based on queue length
    $batchSize = if ($queueLength -gt 500) {
        [Math]::Min($BaseBatchSize * 2, $MaxBatchSize)
    }
    elseif ($queueLength -gt 100) {
        [Math]::Min([int]($BaseBatchSize * 1.5), $MaxBatchSize)
    }
    elseif ($queueLength -lt 10) {
        [Math]::Max([int]($BaseBatchSize * 0.5), $MinBatchSize)
    }
    else {
        $BaseBatchSize
    }
    
    Write-Debug "[PerformanceOptimization] Dynamic batch size: $batchSize (queue: $queueLength)"
    return $batchSize
}

Export-ModuleMember -Function @(
    'Optimize-Performance',
    'Optimize-BatchSize',
    'Optimize-CacheSettings',
    'Optimize-MemoryUsage',
    'Clear-CompletedQueue',
    'Optimize-ThreadCount',
    'Get-AdaptiveThrottling',
    'Get-DynamicBatchSize'
)