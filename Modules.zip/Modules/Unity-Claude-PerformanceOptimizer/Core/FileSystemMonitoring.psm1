# FileSystemMonitoring.psm1
# File system monitoring and change detection components

using namespace System.IO
using namespace System.Collections.Concurrent

# Initialize file system watcher
function Initialize-FileSystemWatcher {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$BasePath,
        
        [string]$Filter = "*",
        [switch]$IncludeSubdirectories
    )
    
    Write-Verbose "[FileSystemMonitoring] Starting file system watcher for: $BasePath"
    
    $watcher = [FileSystemWatcher]::new($BasePath)
    $watcher.IncludeSubdirectories = $IncludeSubdirectories
    $watcher.Filter = $Filter
    $watcher.NotifyFilter = [NotifyFilters]::FileName -bor [NotifyFilters]::LastWrite
    
    Write-Verbose "[FileSystemMonitoring] File system watcher configured"
    return $watcher
}

# Register file change event handler
function Register-FileChangeHandler {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [FileSystemWatcher]$Watcher,
        
        [Parameter(Mandatory)]
        [scriptblock]$Handler,
        
        [object]$MessageData
    )
    
    Register-ObjectEvent -InputObject $Watcher -EventName Changed -Action $Handler -MessageData $MessageData | Out-Null
    Register-ObjectEvent -InputObject $Watcher -EventName Created -Action $Handler -MessageData $MessageData | Out-Null
    Register-ObjectEvent -InputObject $Watcher -EventName Renamed -Action $Handler -MessageData $MessageData | Out-Null
    
    Write-Verbose "[FileSystemMonitoring] File change handlers registered"
}

# Start file system monitoring
function Start-FileSystemMonitoring {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [FileSystemWatcher]$Watcher
    )
    
    $Watcher.EnableRaisingEvents = $true
    Write-Information "[FileSystemMonitoring] File system monitoring started"
}

# Stop file system monitoring
function Stop-FileSystemMonitoring {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [FileSystemWatcher]$Watcher
    )
    
    if ($Watcher) {
        $Watcher.EnableRaisingEvents = $false
        $Watcher.Dispose()
        Write-Information "[FileSystemMonitoring] File system monitoring stopped"
    }
}

# Process file change event
function New-FileChangeInfo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath,
        
        [Parameter(Mandatory)]
        [string]$ChangeType,
        
        [int]$Priority = 5
    )
    
    return [PSCustomObject]@{
        FilePath = $FilePath
        ChangeType = $ChangeType
        Timestamp = [datetime]::Now
        Priority = $Priority
        ProcessingStatus = 'Pending'
        RetryCount = 0
    }
}

# Get dependent files for incremental processing
function Get-DependentFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath,
        
        [object]$IncrementalProcessor
    )
    
    $dependentFiles = @()
    
    if ($IncrementalProcessor) {
        try {
            $dependentFiles = $IncrementalProcessor.GetDependentFiles($FilePath)
            Write-Debug "[FileSystemMonitoring] Found $($dependentFiles.Count) dependent files for $FilePath"
        }
        catch {
            Write-Warning "[FileSystemMonitoring] Failed to get dependent files for $FilePath : $_"
        }
    }
    
    return $dependentFiles
}

# Queue dependent files for processing
function Add-DependentFilesToQueue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SourceFilePath,
        
        [Parameter(Mandatory)]
        [System.Collections.Concurrent.ConcurrentQueue[PSCustomObject]]$ProcessingQueue,
        
        [object]$IncrementalProcessor
    )
    
    $dependentFiles = Get-DependentFiles -FilePath $SourceFilePath -IncrementalProcessor $IncrementalProcessor
    
    foreach ($dependentFile in $dependentFiles) {
        $changeInfo = New-FileChangeInfo -FilePath $dependentFile -ChangeType 'Dependent' -Priority 3
        $ProcessingQueue.Enqueue($changeInfo)
    }
    
    if ($dependentFiles.Count -gt 0) {
        Write-Debug "[FileSystemMonitoring] Queued $($dependentFiles.Count) dependent files for processing"
    }
}

# Monitor queue health
function Get-QueueHealth {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Collections.Concurrent.ConcurrentQueue[PSCustomObject]]$ProcessingQueue,
        
        [int]$WarningThreshold = 100,
        [int]$CriticalThreshold = 500
    )
    
    $queueLength = $ProcessingQueue.Count
    
    $health = [PSCustomObject]@{
        QueueLength = $queueLength
        Status = 'Healthy'
        Message = "Queue contains $queueLength items"
        Timestamp = [datetime]::Now
    }
    
    if ($queueLength -gt $CriticalThreshold) {
        $health.Status = 'Critical'
        $health.Message = "Queue critically overloaded with $queueLength items (threshold: $CriticalThreshold)"
    }
    elseif ($queueLength -gt $WarningThreshold) {
        $health.Status = 'Warning'
        $health.Message = "Queue backlog detected with $queueLength items (threshold: $WarningThreshold)"
    }
    
    return $health
}

Export-ModuleMember -Function @(
    'Initialize-FileSystemWatcher',
    'Register-FileChangeHandler',
    'Start-FileSystemMonitoring',
    'Stop-FileSystemMonitoring',
    'New-FileChangeInfo',
    'Get-DependentFiles',
    'Add-DependentFilesToQueue',
    'Get-QueueHealth'
)