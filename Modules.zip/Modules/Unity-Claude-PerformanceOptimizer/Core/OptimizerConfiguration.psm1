# OptimizerConfiguration.psm1
# Core configuration and initialization for Performance Optimizer

using namespace System.Collections.Concurrent
using namespace System.Threading

# Performance metrics tracking structure
function Initialize-PerformanceMetrics {
    [CmdletBinding()]
    param()
    
    return [hashtable]::Synchronized(@{
        TotalFilesProcessed = 0
        FilesPerSecond = 0.0
        AverageProcessingTime = 0.0
        CacheHitRate = 0.0
        QueueLength = 0
        ActiveThreads = 0
        MemoryUsage = 0
        LastUpdate = [datetime]::Now
        ProcessingErrors = 0
        ThroughputHistory = [System.Collections.Generic.List[double]]::new()
        BottleneckAnalysis = @{}
    })
}

# Calculate optimal thread count based on system resources
function Get-OptimalThreadCount {
    [CmdletBinding()]
    param(
        [decimal]$MemoryThresholdGB = 8
    )
    
    $cpuCores = [Environment]::ProcessorCount
    $optimalThreads = [Math]::Min($cpuCores * 4, 32)  # 4x CPU cores, max 32
    
    # Adjust based on available memory
    $availableMemoryGB = (Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory / 1GB
    if ($availableMemoryGB -lt $MemoryThresholdGB) {
        $optimalThreads = [Math]::Max($optimalThreads / 2, 4)
    }
    
    Write-Verbose "[OptimizerConfiguration] Calculated optimal thread count: $optimalThreads"
    return $optimalThreads
}

# Calculate file processing priority
function Get-FilePriority {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath
    )
    
    # Higher priority for critical files
    if ($FilePath -match '\.(ps1|psm1|psd1)$') { return 10 }
    if ($FilePath -match '\.(cs|py|js|ts)$') { return 8 }
    if ($FilePath -match '\.(md|txt)$') { return 3 }
    return 5  # default priority
}

# Initialize optimizer components
function Initialize-OptimizerComponents {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration,
        
        [Parameter(Mandatory)]
        [string]$BasePath
    )
    
    Write-Verbose "[OptimizerConfiguration] Initializing performance components"
    
    $components = @{}
    
    try {
        # Initialize cache manager with optimized settings
        $cacheConfig = @{
            MaxSize = $Configuration.CacheSize
            EnablePersistence = $true
            PersistencePath = Join-Path $BasePath ".cache"
        }
        $components.CacheManager = New-CacheManager @cacheConfig
        
        # Initialize incremental processor
        $incrementalConfig = @{
            BasePath = $BasePath
            ChangeDetectionInterval = $Configuration.IncrementalCheckInterval
        }
        $components.IncrementalProcessor = New-IncrementalProcessor @incrementalConfig
        
        # Initialize parallel processor with optimal thread count
        $optimalThreads = Get-OptimalThreadCount
        $parallelConfig = @{
            MaxThreads = $optimalThreads
            BatchSize = $Configuration.BatchSize
        }
        $components.ParallelProcessor = New-ParallelProcessor @parallelConfig
        
        Write-Verbose "[OptimizerConfiguration] Components initialized successfully"
        return $components
    }
    catch {
        Write-Error "[OptimizerConfiguration] Failed to initialize components: $_"
        throw
    }
}

# Create default configuration
function Get-DefaultOptimizerConfiguration {
    [CmdletBinding()]
    param()
    
    return @{
        TargetThroughput = 100
        CacheSize = 5000
        BatchSize = 50
        IncrementalCheckInterval = 500
        PerformanceReportingInterval = 30
        MaxQueueLength = 1000
        MemoryThresholdMB = 1000
        EnableAutoOptimization = $true
        EnableBottleneckAnalysis = $true
    }
}

# Validate configuration parameters
function Test-OptimizerConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration
    )
    
    $isValid = $true
    $errors = @()
    
    if ($Configuration.TargetThroughput -le 0) {
        $errors += "TargetThroughput must be greater than 0"
        $isValid = $false
    }
    
    if ($Configuration.CacheSize -le 0) {
        $errors += "CacheSize must be greater than 0"
        $isValid = $false
    }
    
    if ($Configuration.BatchSize -le 0 -or $Configuration.BatchSize -gt 500) {
        $errors += "BatchSize must be between 1 and 500"
        $isValid = $false
    }
    
    if ($errors.Count -gt 0) {
        Write-Warning "Configuration validation errors: $($errors -join '; ')"
    }
    
    return $isValid
}

Export-ModuleMember -Function @(
    'Initialize-PerformanceMetrics',
    'Get-OptimalThreadCount',
    'Get-FilePriority',
    'Initialize-OptimizerComponents',
    'Get-DefaultOptimizerConfiguration',
    'Test-OptimizerConfiguration'
)