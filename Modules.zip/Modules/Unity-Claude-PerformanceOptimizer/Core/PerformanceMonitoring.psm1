# PerformanceMonitoring.psm1
# Performance metrics monitoring and analysis

using namespace System.Threading
using namespace System.Collections.Generic

# Update performance metrics
function Update-PerformanceMetrics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Metrics,
        
        [Parameter(Mandatory)]
        [datetime]$StartTime,
        
        [Parameter(Mandatory)]
        [int]$FilesProcessed,
        
        [object]$CacheManager,
        
        [System.Collections.Concurrent.ConcurrentQueue[PSCustomObject]]$ProcessingQueue
    )
    
    $now = [datetime]::Now
    $elapsedMinutes = ($now - $StartTime).TotalMinutes
    
    # Calculate files per second
    $filesPerSecond = if ($elapsedMinutes -gt 0) { 
        $FilesProcessed / ($elapsedMinutes * 60) 
    } else { 0 }
    
    # Update metrics
    $Metrics.TotalFilesProcessed = $FilesProcessed
    $Metrics.FilesPerSecond = [Math]::Round($filesPerSecond, 2)
    $Metrics.QueueLength = if ($ProcessingQueue) { $ProcessingQueue.Count } else { 0 }
    $Metrics.LastUpdate = $now
    
    # Add to throughput history
    $Metrics.ThroughputHistory.Add($filesPerSecond)
    if ($Metrics.ThroughputHistory.Count -gt 100) {
        $Metrics.ThroughputHistory.RemoveAt(0)
    }
    
    # Update cache hit rate
    if ($CacheManager) {
        $cacheStats = $CacheManager.GetStatistics()
        $Metrics.CacheHitRate = if ($cacheStats.TotalGets -gt 0) {
            [Math]::Round(($cacheStats.Hits / $cacheStats.TotalGets) * 100, 2)
        } else { 0 }
    }
    
    # Update memory usage
    $Metrics.MemoryUsage = [Math]::Round([GC]::GetTotalMemory($false) / 1MB, 2)
    
    Write-Debug "[PerformanceMonitoring] Metrics updated: $filesPerSecond files/sec, Queue: $($Metrics.QueueLength)"
    
    return $filesPerSecond
}

# Analyze performance bottlenecks
function Get-PerformanceBottlenecks {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Metrics,
        
        [int]$QueueBacklogThreshold = 100,
        [int]$CacheHitRateThreshold = 70,
        [int]$MemoryThresholdMB = 1000
    )
    
    $bottlenecks = @{}
    
    # Analyze queue length
    if ($Metrics.QueueLength -gt $QueueBacklogThreshold) {
        $bottlenecks.QueueBacklog = "Processing queue has $($Metrics.QueueLength) items (threshold: $QueueBacklogThreshold)"
    }
    
    # Analyze cache performance
    if ($Metrics.CacheHitRate -lt $CacheHitRateThreshold) {
        $bottlenecks.CacheEfficiency = "Cache hit rate is $($Metrics.CacheHitRate)% (target >$CacheHitRateThreshold%)"
    }
    
    # Analyze memory usage
    if ($Metrics.MemoryUsage -gt $MemoryThresholdMB) {
        $bottlenecks.MemoryPressure = "Memory usage is $($Metrics.MemoryUsage) MB (threshold: $MemoryThresholdMB MB)"
    }
    
    # Analyze throughput trend
    if ($Metrics.ThroughputHistory.Count -ge 10) {
        $recentThroughput = $Metrics.ThroughputHistory[-10..-1]
        $avgRecent = ($recentThroughput | Measure-Object -Average).Average
        $avgOverall = ($Metrics.ThroughputHistory | Measure-Object -Average).Average
        
        if ($avgRecent -lt ($avgOverall * 0.8)) {
            $bottlenecks.ThroughputDegradation = "Recent throughput ($([Math]::Round($avgRecent, 2)) files/sec) is below average ($([Math]::Round($avgOverall, 2)) files/sec)"
        }
    }
    
    if ($bottlenecks.Count -gt 0) {
        Write-Warning "[PerformanceMonitoring] Bottlenecks detected: $($bottlenecks.Keys -join ', ')"
    }
    
    return $bottlenecks
}

# Create performance timer
function New-PerformanceTimer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$Callback,
        
        [Parameter(Mandatory)]
        [object]$State,
        
        [int]$IntervalSeconds = 30
    )
    
    $intervalMs = $IntervalSeconds * 1000
    
    $timer = [System.Threading.Timer]::new($Callback, $State, $intervalMs, $intervalMs)
    
    Write-Verbose "[PerformanceMonitoring] Performance timer created with interval: $IntervalSeconds seconds"
    return $timer
}

# Get throughput analysis report
function Get-ThroughputAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Metrics,
        
        [Parameter(Mandatory)]
        [int]$TargetThroughput,
        
        [Parameter(Mandatory)]
        [datetime]$StartTime
    )
    
    $history = $Metrics.ThroughputHistory
    
    $report = [PSCustomObject]@{
        CurrentThroughput = $Metrics.FilesPerSecond
        TargetThroughput = $TargetThroughput
        PerformanceRatio = if ($TargetThroughput -gt 0) { 
            [Math]::Round(($Metrics.FilesPerSecond / $TargetThroughput) * 100, 2) 
        } else { 0 }
        AverageThroughput = if ($history.Count -gt 0) { 
            [Math]::Round(($history | Measure-Object -Average).Average, 2) 
        } else { 0 }
        PeakThroughput = if ($history.Count -gt 0) { 
            [Math]::Round(($history | Measure-Object -Maximum).Maximum, 2) 
        } else { 0 }
        MinimumThroughput = if ($history.Count -gt 0) { 
            [Math]::Round(($history | Measure-Object -Minimum).Minimum, 2) 
        } else { 0 }
        TotalFilesProcessed = $Metrics.TotalFilesProcessed
        CacheHitRate = $Metrics.CacheHitRate
        ProcessingErrors = $Metrics.ProcessingErrors
        QueueLength = $Metrics.QueueLength
        MemoryUsageMB = $Metrics.MemoryUsage
        Bottlenecks = $Metrics.BottleneckAnalysis
        UpTime = [datetime]::Now - $StartTime
        MeetingTarget = ($Metrics.FilesPerSecond -ge $TargetThroughput)
    }
    
    return $report
}

# Check if performance optimization is needed
function Test-PerformanceOptimizationNeeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [decimal]$CurrentThroughput,
        
        [Parameter(Mandatory)]
        [int]$TargetThroughput,
        
        [decimal]$ThresholdPercentage = 0.8
    )
    
    $threshold = $TargetThroughput * $ThresholdPercentage
    $needsOptimization = $CurrentThroughput -lt $threshold
    
    if ($needsOptimization) {
        Write-Warning "[PerformanceMonitoring] Performance below threshold: $CurrentThroughput < $threshold files/sec"
    }
    
    return $needsOptimization
}

# Generate performance recommendations
function Get-PerformanceRecommendations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Bottlenecks,
        
        [Parameter(Mandatory)]
        [hashtable]$Metrics
    )
    
    $recommendations = @()
    
    if ($Bottlenecks.ContainsKey('QueueBacklog')) {
        $recommendations += "Increase batch size or add more worker threads to process queue backlog"
    }
    
    if ($Bottlenecks.ContainsKey('CacheEfficiency')) {
        $recommendations += "Increase cache size or optimize cache key strategy for better hit rate"
    }
    
    if ($Bottlenecks.ContainsKey('MemoryPressure')) {
        $recommendations += "Reduce batch size, clear completed queue more frequently, or add memory"
    }
    
    if ($Bottlenecks.ContainsKey('ThroughputDegradation')) {
        $recommendations += "Investigate recent changes, check for resource contention, or restart processing"
    }
    
    if ($recommendations.Count -eq 0 -and $Metrics.FilesPerSecond -gt 0) {
        $recommendations += "Performance is meeting expectations"
    }
    
    return $recommendations
}

Export-ModuleMember -Function @(
    'Update-PerformanceMetrics',
    'Get-PerformanceBottlenecks',
    'New-PerformanceTimer',
    'Get-ThroughputAnalysis',
    'Test-PerformanceOptimizationNeeded',
    'Get-PerformanceRecommendations'
)