# Unity-Claude-ScalabilityEnhancements - Progress Tracker Component
# Progress tracking, cancellation tokens, and callback management

using namespace System.Threading

#region Progress Tracking & Cancellation

class ProgressTracker {
    [string]$OperationName
    [long]$TotalItems
    [long]$CompletedItems
    [datetime]$StartTime
    [datetime]$LastUpdate
    [hashtable]$Statistics
    [System.Collections.Generic.List[scriptblock]]$ProgressCallbacks
    [System.Threading.CancellationTokenSource]$CancellationTokenSource
    
    ProgressTracker([string]$operationName, [long]$totalItems) {
        $this.OperationName = $operationName
        $this.TotalItems = $totalItems
        $this.CompletedItems = 0
        $this.StartTime = [datetime]::Now
        $this.LastUpdate = [datetime]::Now
        $this.Statistics = @{
            ItemsPerSecond = 0.0
            EstimatedTimeRemaining = [TimeSpan]::Zero
            PercentComplete = 0.0
        }
        $this.ProgressCallbacks = [System.Collections.Generic.List[scriptblock]]::new()
        $this.CancellationTokenSource = [System.Threading.CancellationTokenSource]::new()
    }
    
    [void] UpdateProgress([long]$completedItems) {
        $this.CompletedItems = $completedItems
        $this.LastUpdate = [datetime]::Now
        
        $elapsedTime = $this.LastUpdate - $this.StartTime
        $this.Statistics.PercentComplete = if ($this.TotalItems -gt 0) { ($this.CompletedItems / $this.TotalItems) * 100 } else { 0 }
        $this.Statistics.ItemsPerSecond = if ($elapsedTime.TotalSeconds -gt 0) { $this.CompletedItems / $elapsedTime.TotalSeconds } else { 0 }
        
        if ($this.Statistics.ItemsPerSecond -gt 0 -and $this.CompletedItems -lt $this.TotalItems) {
            $remainingItems = $this.TotalItems - $this.CompletedItems
            $remainingSeconds = $remainingItems / $this.Statistics.ItemsPerSecond
            $this.Statistics.EstimatedTimeRemaining = [TimeSpan]::FromSeconds($remainingSeconds)
        } else {
            $this.Statistics.EstimatedTimeRemaining = [TimeSpan]::Zero
        }
        
        # Invoke progress callbacks
        foreach ($callback in $this.ProgressCallbacks) {
            try {
                & $callback $this.GetProgressReport()
            }
            catch {
                # Continue processing even if callback fails
            }
        }
    }
    
    [hashtable] GetProgressReport() {
        return @{
            OperationName = $this.OperationName
            TotalItems = $this.TotalItems
            CompletedItems = $this.CompletedItems
            PercentComplete = [math]::Round($this.Statistics.PercentComplete, 2)
            ItemsPerSecond = [math]::Round($this.Statistics.ItemsPerSecond, 2)
            ElapsedTime = ([datetime]::Now - $this.StartTime)
            EstimatedTimeRemaining = $this.Statistics.EstimatedTimeRemaining
            LastUpdate = $this.LastUpdate
            IsCancellationRequested = $this.CancellationTokenSource.Token.IsCancellationRequested
        }
    }
    
    [void] RegisterCallback([scriptblock]$callback) {
        $this.ProgressCallbacks.Add($callback)
    }
    
    [void] Cancel() {
        $this.CancellationTokenSource.Cancel()
    }
    
    [bool] IsCancellationRequested() {
        return $this.CancellationTokenSource.Token.IsCancellationRequested
    }
}

function New-ProgressTracker {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$OperationName,
        
        [Parameter(Mandatory=$true)]
        [long]$TotalItems
    )
    
    try {
        $tracker = [ProgressTracker]::new($OperationName, $TotalItems)
        return $tracker
    }
    catch {
        Write-Error "Failed to create progress tracker: $_"
        return $null
    }
}

function Update-OperationProgress {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$ProgressTracker,
        
        [Parameter(Mandatory=$true)]
        [long]$CompletedItems
    )
    
    try {
        $ProgressTracker.UpdateProgress($CompletedItems)
        return @{ Success = $true }
    }
    catch {
        Write-Error "Failed to update progress: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Get-ProgressReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$ProgressTracker
    )
    
    try {
        return $ProgressTracker.GetProgressReport()
    }
    catch {
        Write-Error "Failed to get progress report: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function New-CancellationToken {
    [CmdletBinding()]
    param(
        [int]$TimeoutSeconds = 0
    )
    
    try {
        $tokenSource = if ($TimeoutSeconds -gt 0) {
            [System.Threading.CancellationTokenSource]::new([TimeSpan]::FromSeconds($TimeoutSeconds))
        } else {
            [System.Threading.CancellationTokenSource]::new()
        }
        
        return @{
            TokenSource = $tokenSource
            Token = $tokenSource.Token
            Success = $true
        }
    }
    catch {
        Write-Error "Failed to create cancellation token: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Test-CancellationRequested {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.Threading.CancellationToken]$CancellationToken
    )
    
    return $CancellationToken.IsCancellationRequested
}

function Cancel-Operation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$ProgressTracker
    )
    
    try {
        $ProgressTracker.Cancel()
        return @{ Success = $true; Message = "Operation cancelled" }
    }
    catch {
        Write-Error "Failed to cancel operation: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Register-ProgressCallback {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$ProgressTracker,
        
        [Parameter(Mandatory=$true)]
        [scriptblock]$Callback
    )
    
    try {
        $ProgressTracker.RegisterCallback($Callback)
        return @{ Success = $true }
    }
    catch {
        Write-Error "Failed to register progress callback: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'New-ProgressTracker',
    'Update-OperationProgress',
    'Get-ProgressReport',
    'New-CancellationToken',
    'Test-CancellationRequested',
    'Cancel-Operation',
    'Register-ProgressCallback'
)