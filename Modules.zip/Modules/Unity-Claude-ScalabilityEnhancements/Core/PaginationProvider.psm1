# Unity-Claude-ScalabilityEnhancements - Pagination Provider Component
# Result pagination and data navigation functionality

#region Pagination System

class PaginationProvider {
    [int]$PageSize
    [int]$CurrentPage
    [int]$TotalItems
    [int]$TotalPages
    [object[]]$DataSource
    [hashtable]$Cache
    
    PaginationProvider([object[]]$data, [int]$pageSize) {
        $this.DataSource = $data
        $this.PageSize = $pageSize
        $this.CurrentPage = 1
        $this.TotalItems = $data.Count
        $this.TotalPages = [math]::Ceiling($this.TotalItems / $this.PageSize)
        $this.Cache = @{}
    }
    
    [object[]] GetPage([int]$pageNumber) {
        if ($pageNumber -lt 1 -or $pageNumber -gt $this.TotalPages) {
            throw "Page number $pageNumber is out of range (1-$($this.TotalPages))"
        }
        
        $cacheKey = "page_$pageNumber"
        if ($this.Cache.ContainsKey($cacheKey)) {
            return $this.Cache[$cacheKey]
        }
        
        $startIndex = ($pageNumber - 1) * $this.PageSize
        $endIndex = [math]::Min($startIndex + $this.PageSize - 1, $this.TotalItems - 1)
        
        $page = $this.DataSource[$startIndex..$endIndex]
        $this.Cache[$cacheKey] = $page
        $this.CurrentPage = $pageNumber
        
        return $page
    }
    
    [hashtable] GetPageInfo() {
        return @{
            CurrentPage = $this.CurrentPage
            PageSize = $this.PageSize
            TotalPages = $this.TotalPages
            TotalItems = $this.TotalItems
            HasPrevious = $this.CurrentPage -gt 1
            HasNext = $this.CurrentPage -lt $this.TotalPages
        }
    }
    
    [object[]] GetNextPage() {
        if ($this.CurrentPage -lt $this.TotalPages) {
            return $this.GetPage($this.CurrentPage + 1)
        }
        return @()
    }
    
    [object[]] GetPreviousPage() {
        if ($this.CurrentPage -gt 1) {
            return $this.GetPage($this.CurrentPage - 1)
        }
        return @()
    }
}

function New-PaginationProvider {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object[]]$DataSource,
        
        [int]$PageSize = 100
    )
    
    if ($PageSize -le 0) {
        throw "PageSize must be greater than 0"
    }
    
    try {
        $provider = [PaginationProvider]::new($DataSource, $PageSize)
        return $provider
    }
    catch {
        Write-Error "Failed to create pagination provider: $_"
        return $null
    }
}

function Get-PaginatedResults {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$PaginationProvider,
        
        [int]$PageNumber = 1
    )
    
    try {
        $results = $PaginationProvider.GetPage($PageNumber)
        $pageInfo = $PaginationProvider.GetPageInfo()
        
        return @{
            Data = $results
            PageInfo = $pageInfo
            Success = $true
        }
    }
    catch {
        Write-Error "Failed to get paginated results: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Set-PageSize {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$PaginationProvider,
        
        [int]$NewPageSize
    )
    
    if ($NewPageSize -le 0) {
        throw "PageSize must be greater than 0"
    }
    
    $PaginationProvider.PageSize = $NewPageSize
    $PaginationProvider.TotalPages = [math]::Ceiling($PaginationProvider.TotalItems / $NewPageSize)
    $PaginationProvider.CurrentPage = 1
    $PaginationProvider.Cache.Clear()
    
    return @{
        NewPageSize = $NewPageSize
        TotalPages = $PaginationProvider.TotalPages
        Success = $true
    }
}

function Navigate-ResultPages {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$PaginationProvider,
        
        [ValidateSet('Next', 'Previous', 'First', 'Last')]
        [string]$Direction
    )
    
    switch ($Direction) {
        'Next' { $results = $PaginationProvider.GetNextPage() }
        'Previous' { $results = $PaginationProvider.GetPreviousPage() }
        'First' { $results = $PaginationProvider.GetPage(1) }
        'Last' { $results = $PaginationProvider.GetPage($PaginationProvider.TotalPages) }
    }
    
    $pageInfo = $PaginationProvider.GetPageInfo()
    
    return @{
        Data = $results
        PageInfo = $pageInfo
        Direction = $Direction
        Success = $true
    }
}

function Export-PagedData {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$PaginationProvider,
        
        [string]$OutputPath,
        
        [ValidateSet('JSON', 'CSV', 'XML')]
        [string]$Format = 'JSON',
        
        [int]$MaxPages = 0  # 0 = all pages
    )
    
    $allData = @()
    $pagesToProcess = if ($MaxPages -gt 0) { [math]::Min($MaxPages, $PaginationProvider.TotalPages) } else { $PaginationProvider.TotalPages }
    
    for ($i = 1; $i -le $pagesToProcess; $i++) {
        $pageData = $PaginationProvider.GetPage($i)
        $allData += $pageData
    }
    
    if ($OutputPath) {
        switch ($Format) {
            'JSON' { $allData | ConvertTo-Json -Depth 10 | Out-File -FilePath $OutputPath -Encoding UTF8 }
            'CSV' { $allData | Export-Csv -Path $OutputPath -NoTypeInformation }
            'XML' { $allData | ConvertTo-Xml | Out-File -FilePath $OutputPath -Encoding UTF8 }
        }
    }
    
    return @{
        TotalRecords = $allData.Count
        PagesProcessed = $pagesToProcess
        OutputPath = $OutputPath
        Format = $Format
        Success = $true
    }
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'New-PaginationProvider',
    'Get-PaginatedResults',
    'Set-PageSize',
    'Navigate-ResultPages',
    'Export-PagedData'
)