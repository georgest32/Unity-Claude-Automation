# Unity-Claude-ScalabilityEnhancements - Memory Manager Component
# Memory optimization, garbage collection, and pressure monitoring

#region Memory Management

class MemoryManager {
    [hashtable]$MemoryStatistics
    [double]$PressureThreshold
    [System.Collections.Generic.List[System.WeakReference]]$ManagedObjects
    
    MemoryManager([double]$pressureThreshold) {
        $this.PressureThreshold = $pressureThreshold
        $this.ManagedObjects = [System.Collections.Generic.List[System.WeakReference]]::new()
        $this.MemoryStatistics = @{
            InitialMemory = [GC]::GetTotalMemory($false)
            CurrentMemory = 0
            PeakMemory = 0
            GCCollections = @(0, 0, 0)
            LastOptimization = [datetime]::MinValue
        }
    }
    
    [void] StartMonitoring() {
        $this.UpdateMemoryStatistics()
        
        # Register for memory pressure notifications if available
        try {
            Register-ObjectEvent -InputObject ([AppDomain]::CurrentDomain) -EventName "UnhandledException" -Action {
                $this.HandleMemoryPressure()
            }
        }
        catch {
            # Memory pressure monitoring not available
        }
    }
    
    [void] UpdateMemoryStatistics() {
        $currentMemory = [GC]::GetTotalMemory($false)
        $this.MemoryStatistics.CurrentMemory = $currentMemory
        
        if ($currentMemory -gt $this.MemoryStatistics.PeakMemory) {
            $this.MemoryStatistics.PeakMemory = $currentMemory
        }
        
        for ($i = 0; $i -lt 3; $i++) {
            $this.MemoryStatistics.GCCollections[$i] = [GC]::CollectionCount($i)
        }
    }
    
    [hashtable] GetMemoryUsageReport() {
        $this.UpdateMemoryStatistics()
        
        $totalMemory = [GC]::GetTotalMemory($false)
        $workingSet = [System.Diagnostics.Process]::GetCurrentProcess().WorkingSet64
        $pressureRatio = $totalMemory / $workingSet
        
        return @{
            TotalManagedMemory = $totalMemory
            WorkingSet = $workingSet
            PeakMemory = $this.MemoryStatistics.PeakMemory
            GCCollections = $this.MemoryStatistics.GCCollections
            MemoryPressure = $pressureRatio
            IsUnderPressure = $pressureRatio -gt $this.PressureThreshold
            ManagedObjectsCount = $this.ManagedObjects.Count
            LastOptimization = $this.MemoryStatistics.LastOptimization
        }
    }
    
    [void] OptimizeMemory() {
        # Clean up weak references
        $aliveObjects = 0
        for ($i = $this.ManagedObjects.Count - 1; $i -ge 0; $i--) {
            if (-not $this.ManagedObjects[$i].IsAlive) {
                $this.ManagedObjects.RemoveAt($i)
            } else {
                $aliveObjects++
            }
        }
        
        # Force garbage collection
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
        [GC]::Collect()
        
        $this.MemoryStatistics.LastOptimization = [datetime]::Now
    }
    
    [void] HandleMemoryPressure() {
        if ($this.ShouldOptimize()) {
            $this.OptimizeMemory()
        }
    }
    
    [bool] ShouldOptimize() {
        $report = $this.GetMemoryUsageReport()
        $timeSinceLastOptimization = [datetime]::Now - $this.MemoryStatistics.LastOptimization
        
        return $report.IsUnderPressure -or $timeSinceLastOptimization.TotalMinutes -gt 30
    }
    
    [void] RegisterManagedObject([object]$obj) {
        $weakRef = [System.WeakReference]::new($obj)
        $this.ManagedObjects.Add($weakRef)
    }
}

function Start-MemoryOptimization {
    [CmdletBinding()]
    param(
        [double]$PressureThreshold = 0.85,
        [switch]$EnableMonitoring
    )
    
    try {
        $memoryManager = [MemoryManager]::new($PressureThreshold)
        
        if ($EnableMonitoring) {
            $memoryManager.StartMonitoring()
        }
        
        return $memoryManager
    }
    catch {
        Write-Error "Failed to start memory optimization: $_"
        return $null
    }
}

function Get-MemoryUsageReport {
    [CmdletBinding()]
    param(
        [object]$MemoryManager = $null
    )
    
    if ($MemoryManager) {
        return $MemoryManager.GetMemoryUsageReport()
    } else {
        # Basic memory report without manager
        return @{
            TotalManagedMemory = [GC]::GetTotalMemory($false)
            WorkingSet = [System.Diagnostics.Process]::GetCurrentProcess().WorkingSet64
            GCCollections = @([GC]::CollectionCount(0), [GC]::CollectionCount(1), [GC]::CollectionCount(2))
        }
    }
}

function Force-GarbageCollection {
    [CmdletBinding()]
    param(
        [int]$Generation = -1
    )
    
    $beforeMemory = [GC]::GetTotalMemory($false)
    
    if ($Generation -ge 0) {
        [GC]::Collect($Generation)
    } else {
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
        [GC]::Collect()
    }
    
    $afterMemory = [GC]::GetTotalMemory($true)
    
    return @{
        MemoryBefore = $beforeMemory
        MemoryAfter = $afterMemory
        MemoryFreed = $beforeMemory - $afterMemory
        Success = $true
    }
}

function Optimize-ObjectLifecycles {
    [CmdletBinding()]
    param(
        [object[]]$Objects
    )
    
    $optimized = 0
    
    foreach ($obj in $Objects) {
        if ($obj -is [System.IDisposable]) {
            try {
                $obj.Dispose()
                $optimized++
            }
            catch {
                # Continue processing even if disposal fails
            }
        }
    }
    
    return @{
        ObjectsProcessed = $Objects.Count
        ObjectsOptimized = $optimized
        Success = $true
    }
}

function Monitor-MemoryPressure {
    [CmdletBinding()]
    param(
        [int]$IntervalSeconds = 30,
        [scriptblock]$PressureCallback
    )
    
    $job = Start-Job -ScriptBlock {
        param($interval, $callback)
        
        while ($true) {
            $memUsage = [GC]::GetTotalMemory($false)
            $workingSet = [System.Diagnostics.Process]::GetCurrentProcess().WorkingSet64
            $pressure = $memUsage / $workingSet
            
            if ($pressure -gt 0.85 -and $callback) {
                & $callback @{ MemoryPressure = $pressure; TotalMemory = $memUsage }
            }
            
            Start-Sleep -Seconds $interval
        }
    } -ArgumentList $IntervalSeconds, $PressureCallback
    
    return @{
        MonitoringJob = $job
        IntervalSeconds = $IntervalSeconds
        Success = $true
    }
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'Start-MemoryOptimization',
    'Get-MemoryUsageReport',
    'Force-GarbageCollection',
    'Optimize-ObjectLifecycles',
    'Monitor-MemoryPressure'
)