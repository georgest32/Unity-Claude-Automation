# Unity-Claude-ScalabilityEnhancements - Background Job Queue Component
# Concurrent job queue management with prioritization and cancellation

using namespace System.Collections.Concurrent
using namespace System.Threading

#region Background Job Queue Management

class BackgroundJobQueue {
    [ConcurrentQueue[object]]$Queue
    [ConcurrentDictionary[string, object]]$Jobs
    [ConcurrentDictionary[string, object]]$Results
    [bool]$IsProcessing
    [int]$MaxConcurrentJobs
    [System.Threading.CancellationTokenSource]$CancellationTokenSource
    [System.Collections.Generic.List[System.Threading.Tasks.Task]]$RunningTasks
    
    BackgroundJobQueue([int]$maxConcurrentJobs) {
        $this.Queue = [ConcurrentQueue[object]]::new()
        $this.Jobs = [ConcurrentDictionary[string, object]]::new()
        $this.Results = [ConcurrentDictionary[string, object]]::new()
        $this.IsProcessing = $false
        $this.MaxConcurrentJobs = $maxConcurrentJobs
        $this.CancellationTokenSource = [System.Threading.CancellationTokenSource]::new()
        $this.RunningTasks = [System.Collections.Generic.List[System.Threading.Tasks.Task]]::new()
    }
    
    [string] AddJob([scriptblock]$jobScript, [hashtable]$parameters, [int]$priority) {
        $jobId = [guid]::NewGuid().ToString()
        $job = @{
            Id = $jobId
            Script = $jobScript
            Parameters = $parameters
            Priority = $priority
            Status = 'Queued'
            CreatedAt = [datetime]::Now
            StartedAt = $null
            CompletedAt = $null
        }
        
        $this.Jobs.TryAdd($jobId, $job) | Out-Null
        $this.Queue.Enqueue($job)
        
        return $jobId
    }
    
    [void] StartProcessing() {
        if ($this.IsProcessing) { return }
        
        $this.IsProcessing = $true
        $token = $this.CancellationTokenSource.Token
        
        $task = [System.Threading.Tasks.Task]::Run({
            while (-not $token.IsCancellationRequested -and $this.IsProcessing) {
                $this.ProcessJobs()
                Start-Sleep -Milliseconds 100
            }
        })
        
        $this.RunningTasks.Add($task)
    }
    
    [void] ProcessJobs() {
        $runningJobsCount = ($this.Jobs.Values | Where-Object { $_.Status -eq 'Running' }).Count
        
        while ($runningJobsCount -lt $this.MaxConcurrentJobs) {
            $job = $null
            if (-not $this.Queue.TryDequeue([ref]$job)) {
                break
            }
            
            $job.Status = 'Running'
            $job.StartedAt = [datetime]::Now
            $this.Jobs.TryUpdate($job.Id, $job, $job) | Out-Null
            
            $this.ExecuteJob($job)
            $runningJobsCount++
        }
    }
    
    [void] ExecuteJob([object]$job) {
        $jobTask = [System.Threading.Tasks.Task]::Run({
            try {
                $result = if ($job.Parameters) {
                    & $job.Script @($job.Parameters)
                } else {
                    & $job.Script
                }
                
                $jobResult = @{
                    JobId = $job.Id
                    Result = $result
                    Status = 'Completed'
                    CompletedAt = [datetime]::Now
                    Error = $null
                }
            }
            catch {
                $jobResult = @{
                    JobId = $job.Id
                    Result = $null
                    Status = 'Failed'
                    CompletedAt = [datetime]::Now
                    Error = $_.Exception.Message
                }
            }
            
            $this.Results.TryAdd($job.Id, $jobResult) | Out-Null
            $job.Status = $jobResult.Status
            $job.CompletedAt = $jobResult.CompletedAt
            $this.Jobs.TryUpdate($job.Id, $job, $job) | Out-Null
        })
        
        $this.RunningTasks.Add($jobTask)
    }
    
    [void] StopProcessing() {
        $this.IsProcessing = $false
        $this.CancellationTokenSource.Cancel()
        
        # Wait for all tasks to complete
        foreach ($task in $this.RunningTasks) {
            try {
                $task.Wait(5000)  # 5 second timeout
            }
            catch {
                # Task was cancelled or timed out
            }
        }
        
        $this.RunningTasks.Clear()
    }
    
    [hashtable] GetQueueStatus() {
        $queuedJobs = ($this.Jobs.Values | Where-Object { $_.Status -eq 'Queued' }).Count
        $runningJobs = ($this.Jobs.Values | Where-Object { $_.Status -eq 'Running' }).Count
        $completedJobs = ($this.Jobs.Values | Where-Object { $_.Status -eq 'Completed' }).Count
        $failedJobs = ($this.Jobs.Values | Where-Object { $_.Status -eq 'Failed' }).Count
        
        return @{
            QueuedJobs = $queuedJobs
            RunningJobs = $runningJobs
            CompletedJobs = $completedJobs
            FailedJobs = $failedJobs
            TotalJobs = $this.Jobs.Count
            IsProcessing = $this.IsProcessing
            MaxConcurrentJobs = $this.MaxConcurrentJobs
        }
    }
}

function New-BackgroundJobQueue {
    [CmdletBinding()]
    param(
        [int]$MaxConcurrentJobs = 10
    )
    
    try {
        $queue = [BackgroundJobQueue]::new($MaxConcurrentJobs)
        return $queue
    }
    catch {
        Write-Error "Failed to create background job queue: $_"
        return $null
    }
}

function Add-JobToQueue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue,
        
        [Parameter(Mandatory=$true)]
        [scriptblock]$JobScript,
        
        [hashtable]$Parameters = @{},
        
        [int]$Priority = 5
    )
    
    try {
        $jobId = $JobQueue.AddJob($JobScript, $Parameters, $Priority)
        
        return @{
            JobId = $jobId
            Status = 'Queued'
            Success = $true
        }
    }
    catch {
        Write-Error "Failed to add job to queue: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Start-QueueProcessor {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue
    )
    
    try {
        $JobQueue.StartProcessing()
        return @{ Success = $true; Message = "Queue processing started" }
    }
    catch {
        Write-Error "Failed to start queue processor: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Stop-QueueProcessor {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue
    )
    
    try {
        $JobQueue.StopProcessing()
        return @{ Success = $true; Message = "Queue processing stopped" }
    }
    catch {
        Write-Error "Failed to stop queue processor: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Get-QueueStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue
    )
    
    try {
        $status = $JobQueue.GetQueueStatus()
        return $status
    }
    catch {
        Write-Error "Failed to get queue status: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Get-JobResults {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue,
        
        [string]$JobId
    )
    
    try {
        if ($JobId) {
            $result = $null
            if ($JobQueue.Results.TryGetValue($JobId, [ref]$result)) {
                return $result
            } else {
                return @{ Success = $false; Error = "Job not found or not completed" }
            }
        } else {
            return $JobQueue.Results.Values
        }
    }
    catch {
        Write-Error "Failed to get job results: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Remove-CompletedJobs {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue,
        
        [switch]$KeepResults
    )
    
    $removedCount = 0
    $completedJobs = $JobQueue.Jobs.Values | Where-Object { $_.Status -eq 'Completed' -or $_.Status -eq 'Failed' }
    
    foreach ($job in $completedJobs) {
        $JobQueue.Jobs.TryRemove($job.Id, [ref]$null) | Out-Null
        if (-not $KeepResults) {
            $JobQueue.Results.TryRemove($job.Id, [ref]$null) | Out-Null
        }
        $removedCount++
    }
    
    return @{
        RemovedJobs = $removedCount
        ResultsKept = $KeepResults.IsPresent
        Success = $true
    }
}

function Invoke-JobPriorityUpdate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$JobQueue,
        
        [Parameter(Mandatory=$true)]
        [string]$JobId,
        
        [Parameter(Mandatory=$true)]
        [int]$NewPriority
    )
    
    $job = $null
    if ($JobQueue.Jobs.TryGetValue($JobId, [ref]$job)) {
        $job.Priority = $NewPriority
        $JobQueue.Jobs.TryUpdate($JobId, $job, $job) | Out-Null
        
        return @{
            JobId = $JobId
            NewPriority = $NewPriority
            Success = $true
        }
    } else {
        return @{ Success = $false; Error = "Job not found" }
    }
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'New-BackgroundJobQueue',
    'Add-JobToQueue',
    'Start-QueueProcessor',
    'Stop-QueueProcessor',
    'Get-QueueStatus',
    'Get-JobResults',
    'Remove-CompletedJobs',
    'Invoke-JobPriorityUpdate'
)