# Unity-Claude-ScalabilityEnhancements - Graph Optimizer Component
# Graph pruning, optimization, and compression functionality

using namespace System.Collections.Concurrent
using namespace System.Threading

#region Graph Pruning & Optimization

class GraphPruner {
    [hashtable]$PruningStats
    [hashtable]$Configuration
    [System.Collections.Generic.HashSet[string]]$PreservedNodes
    [datetime]$LastPruningTime
    
    GraphPruner([hashtable]$config) {
        $this.Configuration = $config
        $this.PruningStats = @{
            NodesRemoved = 0
            EdgesRemoved = 0
            MemorySaved = 0
            LastPruning = $null
            CompressionRatio = 0.0
        }
        $this.PreservedNodes = [System.Collections.Generic.HashSet[string]]::new()
        $this.LastPruningTime = [datetime]::MinValue
    }
    
    [hashtable] PruneGraph([object]$graph, [string[]]$preservePatterns) {
        $startMemory = [GC]::GetTotalMemory($false)
        $initialNodes = $graph.Nodes.Count
        $initialEdges = $graph.Edges.Count
        
        # Mark nodes to preserve based on patterns
        $this.MarkPreservedNodes($graph, $preservePatterns)
        
        # Remove unused nodes older than threshold
        $removedNodes = $this.RemoveUnusedNodes($graph)
        
        # Remove orphaned edges
        $removedEdges = $this.RemoveOrphanedEdges($graph)
        
        # Compress remaining data structures
        $compressionResult = $this.CompressGraphData($graph)
        
        $endMemory = [GC]::GetTotalMemory($true)
        $memorySaved = $startMemory - $endMemory
        
        # Update statistics
        $this.PruningStats.NodesRemoved += $removedNodes
        $this.PruningStats.EdgesRemoved += $removedEdges
        $this.PruningStats.MemorySaved += $memorySaved
        $this.PruningStats.LastPruning = [datetime]::Now
        $this.PruningStats.CompressionRatio = $compressionResult.Ratio
        $this.LastPruningTime = [datetime]::Now
        
        return @{
            NodesRemoved = $removedNodes
            EdgesRemoved = $removedEdges
            MemorySaved = $memorySaved
            CompressionRatio = $compressionResult.Ratio
            TimeElapsed = ([datetime]::Now - $this.LastPruningTime).TotalSeconds
            Success = $true
        }
    }
    
    [void] MarkPreservedNodes([object]$graph, [string[]]$patterns) {
        foreach ($nodeId in $graph.Nodes.Keys) {
            $node = $graph.Nodes[$nodeId]
            foreach ($pattern in $patterns) {
                if ($node.Name -like $pattern) {
                    $this.PreservedNodes.Add($nodeId) | Out-Null
                }
            }
        }
    }
    
    [int] RemoveUnusedNodes([object]$graph) {
        $removed = 0
        $threshold = [datetime]::Now.AddSeconds(-$this.Configuration.UnusedNodeAge)
        
        $nodesToRemove = @()
        foreach ($nodeId in $graph.Nodes.Keys) {
            if ($this.PreservedNodes.Contains($nodeId)) { continue }
            
            $node = $graph.Nodes[$nodeId]
            if ($node.LastAccessed -lt $threshold -and $node.ReferenceCount -eq 0) {
                $nodesToRemove += $nodeId
            }
        }
        
        foreach ($nodeId in $nodesToRemove) {
            $graph.Nodes.Remove($nodeId)
            $removed++
        }
        
        return $removed
    }
    
    [int] RemoveOrphanedEdges([object]$graph) {
        $removed = 0
        $edgesToRemove = @()
        
        foreach ($edge in $graph.Edges) {
            if (-not $graph.Nodes.ContainsKey($edge.From) -or -not $graph.Nodes.ContainsKey($edge.To)) {
                $edgesToRemove += $edge
            }
        }
        
        foreach ($edge in $edgesToRemove) {
            $graph.Edges.Remove($edge)
            $removed++
        }
        
        return $removed
    }
    
    [hashtable] CompressGraphData([object]$graph) {
        $originalSize = $this.CalculateGraphSize($graph)
        
        # Compress node properties by removing redundant data
        foreach ($node in $graph.Nodes.Values) {
            if ($node.Properties -and $node.Properties.Count -gt 0) {
                $compressedProps = @{}
                foreach ($key in $node.Properties.Keys) {
                    if ($node.Properties[$key] -and $node.Properties[$key] -ne "" -and $node.Properties[$key] -ne $null) {
                        $compressedProps[$key] = $node.Properties[$key]
                    }
                }
                $node.Properties = $compressedProps
            }
        }
        
        $compressedSize = $this.CalculateGraphSize($graph)
        $ratio = if ($originalSize -gt 0) { $compressedSize / $originalSize } else { 1.0 }
        
        return @{
            OriginalSize = $originalSize
            CompressedSize = $compressedSize
            Ratio = $ratio
            Success = $true
        }
    }
    
    [long] CalculateGraphSize([object]$graph) {
        $size = 0
        $size += $graph.Nodes.Count * 100  # Approximate node size
        $size += $graph.Edges.Count * 50   # Approximate edge size
        return $size
    }
}

function Start-GraphPruning {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$Graph,
        
        [string[]]$PreservePatterns = @("*Main*", "*Entry*", "*Public*"),
        
        [hashtable]$Configuration = @{
            UnusedNodeAge = 3600
            MinGraphSize = 1000
            CompressionRatio = 0.75
        }
    )
    
    try {
        $pruner = [GraphPruner]::new($Configuration)
        $result = $pruner.PruneGraph($Graph, $PreservePatterns)
        
        Write-Information "Graph pruning completed: $($result.NodesRemoved) nodes removed, $([math]::Round($result.MemorySaved / 1MB, 2)) MB saved"
        
        return $result
    }
    catch {
        Write-Error "Graph pruning failed: $_"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Remove-UnusedNodes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$Graph,
        
        [int]$AgeThresholdSeconds = 3600
    )
    
    $removed = 0
    $threshold = [datetime]::Now.AddSeconds(-$AgeThresholdSeconds)
    $nodesToRemove = @()
    
    foreach ($nodeId in $Graph.Nodes.Keys) {
        $node = $Graph.Nodes[$nodeId]
        if ($node.LastAccessed -lt $threshold -and $node.ReferenceCount -eq 0) {
            $nodesToRemove += $nodeId
        }
    }
    
    foreach ($nodeId in $nodesToRemove) {
        $Graph.Nodes.Remove($nodeId)
        $removed++
    }
    
    return @{
        NodesRemoved = $removed
        RemainingNodes = $Graph.Nodes.Count
        Success = $true
    }
}

function Optimize-GraphStructure {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$Graph
    )
    
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $optimizations = @()
    
    # Optimization 1: Remove duplicate edges
    $originalEdgeCount = $Graph.Edges.Count
    $uniqueEdges = $Graph.Edges | Sort-Object From, To, Type -Unique
    $Graph.Edges = $uniqueEdges
    $optimizations += "Removed $($originalEdgeCount - $uniqueEdges.Count) duplicate edges"
    
    # Optimization 2: Merge similar nodes
    $mergedCount = $this.MergeSimilarNodes($Graph)
    if ($mergedCount -gt 0) {
        $optimizations += "Merged $mergedCount similar nodes"
    }
    
    # Optimization 3: Optimize node properties
    foreach ($node in $Graph.Nodes.Values) {
        if ($node.Properties.Count -gt 10) {
            $essentialProps = @{}
            foreach ($key in @('Name', 'Type', 'Signature', 'Location')) {
                if ($node.Properties.ContainsKey($key)) {
                    $essentialProps[$key] = $node.Properties[$key]
                }
            }
            $node.Properties = $essentialProps
        }
    }
    
    $stopwatch.Stop()
    
    return @{
        OptimizationsApplied = $optimizations
        TimeElapsed = $stopwatch.Elapsed.TotalSeconds
        Success = $true
    }
}

function Compress-GraphData {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [object]$Graph,
        
        [double]$CompressionRatio = 0.75
    )
    
    $originalMemory = [GC]::GetTotalMemory($false)
    
    # Compress string properties
    foreach ($node in $Graph.Nodes.Values) {
        if ($node.Properties -and $node.Properties.ContainsKey('Source')) {
            $source = $node.Properties['Source']
            if ($source.Length -gt 1000) {
                $node.Properties['Source'] = $source.Substring(0, 997) + "..."
            }
        }
    }
    
    # Force garbage collection
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    
    $finalMemory = [GC]::GetTotalMemory($false)
    $actualRatio = $finalMemory / $originalMemory
    
    return @{
        OriginalMemory = $originalMemory
        CompressedMemory = $finalMemory
        ActualCompressionRatio = $actualRatio
        MemorySaved = $originalMemory - $finalMemory
        Success = $actualRatio -le $CompressionRatio
    }
}

function Get-PruningReport {
    [CmdletBinding()]
    param(
        [object]$PruningResults
    )
    
    $report = @{
        Summary = "Graph pruning operations summary"
        NodesRemoved = $PruningResults.NodesRemoved
        EdgesRemoved = $PruningResults.EdgesRemoved
        MemorySaved = "$([math]::Round($PruningResults.MemorySaved / 1MB, 2)) MB"
        CompressionRatio = "$([math]::Round($PruningResults.CompressionRatio * 100, 1))%"
        TimeElapsed = "$([math]::Round($PruningResults.TimeElapsed, 2)) seconds"
        Timestamp = [datetime]::Now
    }
    
    return $report
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'Start-GraphPruning',
    'Remove-UnusedNodes', 
    'Optimize-GraphStructure',
    'Compress-GraphData',
    'Get-PruningReport'
)