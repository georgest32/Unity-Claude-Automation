#Requires -Version 5.1
<#
.SYNOPSIS
    Core utilities and configuration for Unity parallelization module.

.DESCRIPTION
    Provides logging, dependency management, and shared configuration
    for Unity parallel monitoring operations.

.NOTES
    Part of Unity-Claude-UnityParallelization refactored architecture
    Originally from Unity-Claude-UnityParallelization.psm1 (lines 1-119)
    Refactoring Date: 2025-08-25
#>

$ErrorActionPreference = "Stop"

#region Module Configuration

# Module-level variables for Unity project management
$script:RegisteredUnityProjects = @{}
$script:ActiveUnityMonitors = @{}
$script:UnityParallelizationConfig = @{
    UnityExecutablePath = ""
    DefaultLogPath = "$env:LOCALAPPDATA\Unity\Editor"
    ErrorPatterns = @{
        CompilationError = '^.*\(\d+,\d+\): error.*$'
        CS0246 = 'CS0246.*could not be found'
        CS0103 = 'CS0103.*does not exist'
        CS1061 = 'CS1061.*does not contain'
        CS0029 = 'CS0029.*cannot implicitly convert'
    }
    MonitoringInterval = 1000  # 1 second
    CompilationTimeout = 300   # 5 minutes
    ErrorDetectionLatency = 500 # 500ms target
}

# Module availability tracking
$script:RequiredModulesAvailable = @{}
$script:WriteModuleLogAvailable = $false

#endregion

#region Dependency Management

function Test-ModuleDependencyAvailability {
    <#
    .SYNOPSIS
    Tests availability of required module dependencies
    .DESCRIPTION
    Validates that required modules are available for the parallelization module
    .PARAMETER RequiredModules
    Array of required module names
    .PARAMETER ModuleName
    Name of the module being checked
    #>
    param(
        [string[]]$RequiredModules,
        [string]$ModuleName = "Unknown"
    )
    
    $missingModules = @()
    foreach ($reqModule in $RequiredModules) {
        $module = Get-Module $reqModule -ErrorAction SilentlyContinue
        if (-not $module) {
            $missingModules += $reqModule
        }
    }
    
    if ($missingModules.Count -gt 0) {
        Write-Warning "[$ModuleName] Missing required modules: $($missingModules -join ', '). Import them explicitly before using this module."
        return $false
    }
    
    return $true
}

# Initialize module dependencies
function Initialize-ModuleDependencies {
    <#
    .SYNOPSIS
    Initializes required module dependencies
    .DESCRIPTION
    Attempts to load required modules and tracks their availability
    #>
    
    # Try to load Unity-Claude-RunspaceManagement
    try {
        if (-not (Get-Module Unity-Claude-RunspaceManagement -ErrorAction SilentlyContinue)) {
            Import-Module Unity-Claude-RunspaceManagement -ErrorAction Stop
            Write-Host "[DEBUG] [StatePreservation] Loaded Unity-Claude-RunspaceManagement module" -ForegroundColor Gray
        } else {
            Write-Host "[DEBUG] [StatePreservation] Unity-Claude-RunspaceManagement already loaded, preserving state" -ForegroundColor Gray
        }
        $script:RequiredModulesAvailable['RunspaceManagement'] = $true
        $script:WriteModuleLogAvailable = $true
    } catch {
        Write-Warning "Failed to import Unity-Claude-RunspaceManagement: $($_.Exception.Message)"
        $script:RequiredModulesAvailable['RunspaceManagement'] = $false
    }
    
    # Try to load Unity-Claude-ParallelProcessing
    try {
        if (-not (Get-Module Unity-Claude-ParallelProcessing -ErrorAction SilentlyContinue)) {
            Import-Module Unity-Claude-ParallelProcessing -ErrorAction Stop
            Write-Host "[DEBUG] [StatePreservation] Loaded Unity-Claude-ParallelProcessing module" -ForegroundColor Gray
        } else {
            Write-Host "[DEBUG] [StatePreservation] Unity-Claude-ParallelProcessing already loaded, preserving state" -ForegroundColor Gray
        }
        $script:RequiredModulesAvailable['ParallelProcessing'] = $true
    } catch {
        Write-Warning "Failed to import Unity-Claude-ParallelProcessing: $($_.Exception.Message)"
        $script:RequiredModulesAvailable['ParallelProcessing'] = $false
    }
}

#endregion

#region Logging Functions

function Write-FallbackLog {
    <#
    .SYNOPSIS
    Fallback logging function when module logging is unavailable
    .DESCRIPTION
    Provides basic console logging when the main logging module is not available
    #>
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [string]$Component = "UnityParallelization"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logMessage = "[$timestamp] [$Level] [$Component] $Message"
    
    switch ($Level) {
        "ERROR" { Write-Host $logMessage -ForegroundColor Red }
        "WARNING" { Write-Host $logMessage -ForegroundColor Yellow }
        "DEBUG" { Write-Host $logMessage -ForegroundColor Gray }
        default { Write-Host $logMessage -ForegroundColor White }
    }
}

function Write-UnityParallelLog {
    <#
    .SYNOPSIS
    Wrapper function for logging with fallback
    .DESCRIPTION
    Attempts to use module logging, falls back to console logging if unavailable
    #>
    param(
        [string]$Message,
        [string]$Level = "INFO", 
        [string]$Component = "UnityParallelization"
    )
    
    if ($script:WriteModuleLogAvailable -and (Get-Command Write-ModuleLog -ErrorAction SilentlyContinue)) {
        Write-ModuleLog -Message $Message -Level $Level -Component $Component
    } else {
        Write-FallbackLog -Message $Message -Level $Level -Component $Component
    }
}

#endregion

#region Configuration Access

function Get-UnityParallelizationConfig {
    <#
    .SYNOPSIS
    Gets the Unity parallelization configuration
    .DESCRIPTION
    Returns the current Unity parallelization configuration settings
    #>
    [CmdletBinding()]
    param()
    
    return $script:UnityParallelizationConfig
}

function Set-UnityParallelizationConfig {
    <#
    .SYNOPSIS
    Sets Unity parallelization configuration values
    .DESCRIPTION
    Updates the Unity parallelization configuration settings
    .PARAMETER Configuration
    Hashtable containing configuration updates
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Configuration
    )
    
    foreach ($key in $Configuration.Keys) {
        if ($script:UnityParallelizationConfig.ContainsKey($key)) {
            $script:UnityParallelizationConfig[$key] = $Configuration[$key]
            Write-UnityParallelLog -Message "Updated configuration: $key = $($Configuration[$key])" -Level "DEBUG"
        } else {
            Write-UnityParallelLog -Message "Unknown configuration key: $key" -Level "WARNING"
        }
    }
}

#endregion

#region Module Initialization

# Initialize dependencies when module loads
Initialize-ModuleDependencies

# Module loading notification
Write-UnityParallelLog -Message "Unity-Claude-UnityParallelization Core module loaded" -Level "DEBUG"

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Test-ModuleDependencyAvailability',
    'Initialize-ModuleDependencies',
    'Write-FallbackLog',
    'Write-UnityParallelLog',
    'Get-UnityParallelizationConfig',
    'Set-UnityParallelizationConfig'
) -Variable @(
    'RegisteredUnityProjects',
    'ActiveUnityMonitors',
    'UnityParallelizationConfig',
    'RequiredModulesAvailable'
)

#endregion

# REFACTORING MARKER: This module was refactored from Unity-Claude-UnityParallelization.psm1 on 2025-08-25
# Original file size: 2084 lines
# This component: Core utilities and configuration (lines 1-119, ~119 lines)