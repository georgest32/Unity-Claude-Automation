#Requires -Version 5.1
<#
.SYNOPSIS
    Unity compilation process integration for UnityParallelization module.

.DESCRIPTION
    Provides Unity compilation job execution and monitoring using batch mode
    with runspace pools and hanging prevention.

.NOTES
    Part of Unity-Claude-UnityParallelization refactored architecture
    Originally from Unity-Claude-UnityParallelization.psm1 (lines 980-1096)
    Refactoring Date: 2025-08-25
#>

# Import required modules
Import-Module "$PSScriptRoot\ParallelizationCore.psm1" -Force
Import-Module "$PSScriptRoot\ProjectConfiguration.psm1" -Force

#region Unity Compilation Process Integration

function Start-UnityCompilationJob {
    <#
    .SYNOPSIS
    Starts a Unity compilation job in batch mode
    .DESCRIPTION
    Executes Unity compilation in batch mode using runspace pools with hanging prevention
    .PARAMETER Monitor
    Unity monitor object
    .PARAMETER ProjectName
    Name of the Unity project to compile
    .PARAMETER CompilationMethod
    Unity method to execute for compilation
    .PARAMETER TimeoutMinutes
    Timeout for compilation job in minutes
    .EXAMPLE
    Start-UnityCompilationJob -Monitor $monitor -ProjectName "MyGame" -CompilationMethod "CompileProject"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Monitor,
        [Parameter(Mandatory)]
        [string]$ProjectName,
        [string]$CompilationMethod = "AssetDatabase.Refresh",
        [int]$TimeoutMinutes = 5
    )
    
    Write-UnityParallelLog -Message "Starting Unity compilation job for project '$ProjectName'..." -Level "INFO"
    
    try {
        # Get project configuration
        $projectConfig = Get-UnityProjectConfiguration -ProjectName $ProjectName
        
        # Create Unity compilation script (research-validated batch mode pattern)
        $compilationScript = {
            param($ProjectPath, $LogPath, $Method, $TimeoutMinutes)
            
            try {
                # Unity batch mode command (research pattern from queries)
                $unityPath = "C:\Program Files\Unity\Hub\Editor\2021.1.14f1\Editor\Unity.exe"
                if (-not (Test-Path $unityPath)) {
                    # Try to find Unity executable
                    $unityPath = Get-ChildItem "C:\Program Files\Unity\Hub\Editor\*\Editor\Unity.exe" | Select-Object -First 1 -ExpandProperty FullName
                }
                
                if (-not $unityPath) {
                    throw "Unity executable not found"
                }
                
                $arguments = @(
                    "-quit"
                    "-batchmode"
                    "-projectPath", "`"$ProjectPath`""
                    "-logFile", "`"$LogPath`""
                    "-executeMethod", $Method
                )
                
                # Start Unity process with timeout (Learning #98: hanging prevention)
                $processStartInfo = New-Object System.Diagnostics.ProcessStartInfo
                $processStartInfo.FileName = $unityPath
                $processStartInfo.Arguments = $arguments -join " "
                $processStartInfo.UseShellExecute = $false
                $processStartInfo.RedirectStandardOutput = $true
                $processStartInfo.RedirectStandardError = $true
                
                $process = [System.Diagnostics.Process]::Start($processStartInfo)
                $startTime = Get-Date
                
                # Wait for completion with timeout
                $completed = $process.WaitForExit($TimeoutMinutes * 60 * 1000) # Convert to milliseconds
                
                if ($completed) {
                    $exitCode = $process.ExitCode
                    $output = $process.StandardOutput.ReadToEnd()
                    $error = $process.StandardError.ReadToEnd()
                    
                    return @{
                        Success = $exitCode -eq 0
                        ExitCode = $exitCode
                        Output = $output
                        Error = $error
                        Duration = (Get-Date) - $startTime
                    }
                } else {
                    # Process timed out, kill it
                    try { $process.Kill() } catch { }
                    throw "Unity compilation timed out after $TimeoutMinutes minutes"
                }
                
            } catch {
                throw "Unity compilation error: $($_.Exception.Message)"
            }
        }
        
        # Submit compilation job to runspace pool
        $job = Submit-RunspaceJob -PoolManager $Monitor.RunspacePool -ScriptBlock $compilationScript -Parameters @{
            ProjectPath = $projectConfig.Path
            LogPath = $projectConfig.LogPath
            Method = $CompilationMethod
            TimeoutMinutes = $TimeoutMinutes
        } -JobName "UnityCompilation-$ProjectName" -TimeoutSeconds ($TimeoutMinutes * 60 + 60)
        
        # Track compilation job
        $Monitor.CompilationJobs += $job
        
        Write-UnityParallelLog -Message "Unity compilation job started for '$ProjectName' (JobId: $($job.JobId))" -Level "INFO"
        
        return $job
        
    } catch {
        Write-UnityParallelLog -Message "Failed to start Unity compilation job for '$ProjectName': $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Find-UnityExecutablePath {
    <#
    .SYNOPSIS
    Finds the Unity executable path on the system
    .DESCRIPTION
    Searches common Unity installation locations to find the Unity executable
    .PARAMETER PreferredVersion
    Preferred Unity version to use
    .EXAMPLE
    $unityPath = Find-UnityExecutablePath -PreferredVersion "2021.1.14f1"
    #>
    [CmdletBinding()]
    param(
        [string]$PreferredVersion = "2021.1.14f1"
    )
    
    Write-UnityParallelLog -Message "Searching for Unity executable..." -Level "DEBUG"
    
    # Check common Unity installation paths
    $searchPaths = @(
        "C:\Program Files\Unity\Hub\Editor\$PreferredVersion\Editor\Unity.exe",
        "C:\Program Files\Unity\Hub\Editor\*\Editor\Unity.exe",
        "C:\Program Files (x86)\Unity\Editor\Unity.exe",
        "C:\Program Files\Unity\Editor\Unity.exe"
    )
    
    foreach ($path in $searchPaths) {
        if ($path -contains '*') {
            $foundPaths = Get-ChildItem $path -ErrorAction SilentlyContinue
            if ($foundPaths) {
                $unityPath = $foundPaths | Select-Object -First 1 -ExpandProperty FullName
                Write-UnityParallelLog -Message "Found Unity executable: $unityPath" -Level "DEBUG"
                return $unityPath
            }
        } else {
            if (Test-Path $path) {
                Write-UnityParallelLog -Message "Found Unity executable: $path" -Level "DEBUG"
                return $path
            }
        }
    }
    
    Write-UnityParallelLog -Message "Unity executable not found in standard locations" -Level "WARNING"
    return $null
}

function Test-UnityCompilationResult {
    <#
    .SYNOPSIS
    Tests Unity compilation job result for success
    .DESCRIPTION
    Analyzes Unity compilation job result to determine if compilation succeeded
    .PARAMETER JobResult
    Result from Unity compilation job
    .EXAMPLE
    $success = Test-UnityCompilationResult -JobResult $job
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$JobResult
    )
    
    try {
        # Check if job completed successfully
        if (-not $JobResult) {
            return @{
                Success = $false
                Reason = "No job result available"
            }
        }
        
        # Check exit code
        if ($JobResult.ExitCode -ne 0) {
            return @{
                Success = $false
                Reason = "Unity exited with code: $($JobResult.ExitCode)"
                ExitCode = $JobResult.ExitCode
            }
        }
        
        # Check for compilation errors in output
        if ($JobResult.Output -match "Compilation failed") {
            return @{
                Success = $false
                Reason = "Compilation errors detected in output"
                Output = $JobResult.Output
            }
        }
        
        # Check error stream
        if ($JobResult.Error -and $JobResult.Error.Length -gt 0) {
            return @{
                Success = $false
                Reason = "Errors detected in error stream"
                Error = $JobResult.Error
            }
        }
        
        return @{
            Success = $true
            Reason = "Compilation completed successfully"
            Duration = $JobResult.Duration
        }
        
    } catch {
        Write-UnityParallelLog -Message "Failed to test compilation result: $($_.Exception.Message)" -Level "ERROR"
        return @{
            Success = $false
            Reason = "Error testing result: $($_.Exception.Message)"
        }
    }
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Start-UnityCompilationJob',
    'Find-UnityExecutablePath',
    'Test-UnityCompilationResult'
)

#endregion

# REFACTORING MARKER: This module was refactored from Unity-Claude-UnityParallelization.psm1 on 2025-08-25
# Original file size: 2084 lines
# This component: Unity compilation process integration (lines 980-1096, ~117 lines)