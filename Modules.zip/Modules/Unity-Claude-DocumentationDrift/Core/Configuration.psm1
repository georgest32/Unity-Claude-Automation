# Unity-Claude-DocumentationDrift Core Configuration Module
# Manages configuration and initialization for Documentation Drift Detection
# Created: 2025-08-25 (Refactored from large monolithic module)

#Requires -Version 7.2

# Module-level variables for managing documentation drift detection
$script:Configuration = @{}              # Module configuration settings
$script:CacheEnabled = $true             # Performance caching flag
$script:LastIndexUpdate = $null          # Timestamp of last documentation index update

# Default configuration values
$script:DefaultConfiguration = @{
    DriftDetectionSensitivity = 'Medium'  # High, Medium, Low
    AutoPRCreationThreshold = 'Medium'    # Critical, High, Medium, Low, Never
    CacheTimeout = 300                    # Cache timeout in seconds (5 minutes)
    MaxBatchSize = 5                      # Maximum changes to batch together
    CooldownPeriod = 300                  # Cooldown between automated actions (5 minutes)
    ExcludePatterns = @(                  # Files to exclude from analysis
        '*.tmp', '*.temp', '*.log', '*.cache',
        'node_modules\*', '.git\*', 'bin\*', 'obj\*',
        '*.lock', '*.pid', '*~', '.DS_Store'
    )
    IncludePatterns = @(                  # Files to include in analysis
        '*.ps1', '*.psm1', '*.psd1',      # PowerShell files
        '*.cs', '*.js', '*.ts', '*.py',   # Code files  
        '*.md', '*.txt', '*.rst'          # Documentation files
    )
    DocumentationPaths = @(               # Paths to scan for documentation
        'docs\*', 'README*', '*.md'
    )
    PRTemplates = @{
        'default' = 'documentation-update.md'
        'api' = 'api-documentation-update.md'
        'breaking' = 'breaking-change-docs.md'
    }
    ReviewerAssignment = @{
        'critical' = @('tech-lead', 'docs-team')
        'high' = @('docs-team') 
        'medium' = @()
        'low' = @()
    }
}

function Initialize-DocumentationDrift {
    <#
    .SYNOPSIS
    Initializes the documentation drift detection system
    
    .DESCRIPTION
    Sets up the documentation drift detection system with default configuration,
    builds initial code-to-documentation mapping, and prepares the system for
    automated drift detection and documentation updates.
    
    .PARAMETER ConfigPath
    Path to custom configuration file. If not specified, uses default configuration.
    
    .PARAMETER Force
    Force reinitialization even if already initialized
    
    .EXAMPLE
    Initialize-DocumentationDrift
    Initializes with default configuration
    
    .EXAMPLE
    Initialize-DocumentationDrift -ConfigPath ".\docs-config.json" -Force
    Initializes with custom configuration and forces reinitialization
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$ConfigPath,
        
        [Parameter(Mandatory = $false)]
        [switch]$Force
    )
    
    Write-Verbose "[Initialize-DocumentationDrift] Starting initialization..."
    
    try {
        # Check if already initialized (unless Force is specified)
        if (-not $Force -and $script:Configuration.Count -gt 0) {
            Write-Verbose "[Initialize-DocumentationDrift] Already initialized, skipping"
            return
        }
        
        # Load configuration
        if ($ConfigPath -and (Test-Path $ConfigPath)) {
            Write-Verbose "[Initialize-DocumentationDrift] Loading configuration from: $ConfigPath"
            $customConfig = Get-Content $ConfigPath | ConvertFrom-Json -AsHashtable
            $script:Configuration = $script:DefaultConfiguration.Clone()
            
            # Merge custom configuration with defaults
            foreach ($key in $customConfig.Keys) {
                $script:Configuration[$key] = $customConfig[$key]
            }
        } else {
            Write-Verbose "[Initialize-DocumentationDrift] Using default configuration"
            $script:Configuration = $script:DefaultConfiguration.Clone()
        }
        
        # Initialize cache settings
        $script:CacheEnabled = $script:Configuration.CacheTimeout -gt 0
        $script:LastIndexUpdate = $null
        
        Write-Information "[Initialize-DocumentationDrift] Documentation drift detection initialized successfully"
        Write-Verbose "[Initialize-DocumentationDrift] Configuration: $($script:Configuration | ConvertTo-Json -Depth 3)"
        
    } catch {
        Write-Error "[Initialize-DocumentationDrift] Initialization failed: $_"
        throw
    }
}

function Get-DocumentationDriftConfig {
    <#
    .SYNOPSIS
    Gets the current documentation drift detection configuration
    
    .DESCRIPTION
    Returns the current configuration settings for the documentation drift detection system
    
    .EXAMPLE
    Get-DocumentationDriftConfig
    Returns the current configuration as a hashtable
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()
    
    if ($script:Configuration.Count -eq 0) {
        Write-Warning "Documentation drift not initialized. Run Initialize-DocumentationDrift first."
        return @{}
    }
    
    return $script:Configuration.Clone()
}

function Set-DocumentationDriftConfig {
    <#
    .SYNOPSIS
    Updates documentation drift detection configuration settings
    
    .DESCRIPTION
    Updates one or more configuration settings for the documentation drift detection system
    
    .PARAMETER Configuration
    Hashtable containing configuration settings to update
    
    .PARAMETER DriftDetectionSensitivity
    Sets the drift detection sensitivity (High, Medium, Low)
    
    .PARAMETER AutoPRCreationThreshold
    Sets the threshold for automatic PR creation (Critical, High, Medium, Low, Never)
    
    .PARAMETER CacheTimeout
    Sets the cache timeout in seconds
    
    .EXAMPLE
    Set-DocumentationDriftConfig -DriftDetectionSensitivity High -AutoPRCreationThreshold Medium
    Updates specific configuration settings
    
    .EXAMPLE
    Set-DocumentationDriftConfig -Configuration @{CacheTimeout = 600; MaxBatchSize = 10}
    Updates multiple settings using a hashtable
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [hashtable]$Configuration,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet('High', 'Medium', 'Low')]
        [string]$DriftDetectionSensitivity,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet('Critical', 'High', 'Medium', 'Low', 'Never')]
        [string]$AutoPRCreationThreshold,
        
        [Parameter(Mandatory = $false)]
        [ValidateRange(0, 3600)]
        [int]$CacheTimeout
    )
    
    if ($script:Configuration.Count -eq 0) {
        Write-Error "Documentation drift not initialized. Run Initialize-DocumentationDrift first."
        return
    }
    
    try {
        # Update from hashtable if provided
        if ($Configuration) {
            foreach ($key in $Configuration.Keys) {
                if ($script:Configuration.ContainsKey($key)) {
                    $script:Configuration[$key] = $Configuration[$key]
                    Write-Verbose "[Set-DocumentationDriftConfig] Updated $key = $($Configuration[$key])"
                } else {
                    Write-Warning "[Set-DocumentationDriftConfig] Unknown configuration key: $key"
                }
            }
        }
        
        # Update individual parameters if provided
        if ($DriftDetectionSensitivity) {
            $script:Configuration.DriftDetectionSensitivity = $DriftDetectionSensitivity
            Write-Verbose "[Set-DocumentationDriftConfig] Updated DriftDetectionSensitivity = $DriftDetectionSensitivity"
        }
        
        if ($AutoPRCreationThreshold) {
            $script:Configuration.AutoPRCreationThreshold = $AutoPRCreationThreshold
            Write-Verbose "[Set-DocumentationDriftConfig] Updated AutoPRCreationThreshold = $AutoPRCreationThreshold"
        }
        
        if ($CacheTimeout -ge 0) {
            $script:Configuration.CacheTimeout = $CacheTimeout
            $script:CacheEnabled = $CacheTimeout -gt 0
            Write-Verbose "[Set-DocumentationDriftConfig] Updated CacheTimeout = $CacheTimeout"
        }
        
        Write-Information "[Set-DocumentationDriftConfig] Configuration updated successfully"
        
    } catch {
        Write-Error "[Set-DocumentationDriftConfig] Failed to update configuration: $_"
        throw
    }
}

function Reset-DocumentationDriftConfig {
    <#
    .SYNOPSIS
    Resets documentation drift configuration to defaults
    
    .DESCRIPTION
    Resets all configuration settings to their default values
    
    .EXAMPLE
    Reset-DocumentationDriftConfig
    Resets configuration to default values
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param()
    
    if ($PSCmdlet.ShouldProcess("Documentation Drift Configuration", "Reset to defaults")) {
        $script:Configuration = $script:DefaultConfiguration.Clone()
        $script:CacheEnabled = $script:Configuration.CacheTimeout -gt 0
        Write-Information "[Reset-DocumentationDriftConfig] Configuration reset to defaults"
    }
}

function Export-DocumentationDriftConfig {
    <#
    .SYNOPSIS
    Exports current configuration to a file
    
    .DESCRIPTION
    Exports the current documentation drift configuration to a JSON file
    
    .PARAMETER Path
    Path where to save the configuration file
    
    .EXAMPLE
    Export-DocumentationDriftConfig -Path ".\my-docs-config.json"
    Exports current configuration to specified file
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    
    if ($script:Configuration.Count -eq 0) {
        Write-Error "Documentation drift not initialized. Run Initialize-DocumentationDrift first."
        return
    }
    
    try {
        $script:Configuration | ConvertTo-Json -Depth 5 | Out-File -FilePath $Path -Encoding UTF8
        Write-Information "[Export-DocumentationDriftConfig] Configuration exported to: $Path"
    } catch {
        Write-Error "[Export-DocumentationDriftConfig] Failed to export configuration: $_"
        throw
    }
}

# Export module members
Export-ModuleMember -Function @(
    'Initialize-DocumentationDrift',
    'Get-DocumentationDriftConfig', 
    'Set-DocumentationDriftConfig',
    'Reset-DocumentationDriftConfig',
    'Export-DocumentationDriftConfig'
)

# Auto-initialize with defaults on module load
Initialize-DocumentationDrift