# Unity-Claude-DocumentationDrift - Refactored Modular Version
# Documentation drift detection and automated update system
# Created: 2025-08-25 (Refactored from large monolithic module)

#Requires -Version 7.2

# Import sub-modules
$ModulePath = $PSScriptRoot

Write-Verbose "[DocumentationDrift] Loading refactored modular components..."

try {
    # Import Core Configuration module
    Import-Module "$ModulePath\Core\Configuration.psd1" -Force -Global -ErrorAction Stop
    Write-Verbose "[DocumentationDrift] Core Configuration module loaded"
    
    # Import Analysis modules
    Import-Module "$ModulePath\Analysis\ImpactAnalysis.psd1" -Force -Global -ErrorAction Stop  
    Write-Verbose "[DocumentationDrift] Impact Analysis module loaded"
    
    Write-Information "[DocumentationDrift] Refactored modular DocumentationDrift system loaded successfully"
    
} catch {
    Write-Error "[DocumentationDrift] Failed to load modular components: $_"
    throw
}

# Module-level variables shared across components
$script:CodeToDocMapping = @{}           # Bidirectional mapping: code->docs and docs->code
$script:DocumentationIndex = @{}         # Index of all documentation files and their relationships  
$script:DriftResults = @{}               # Current drift detection results

function Clear-DriftCache {
    <#
    .SYNOPSIS
    Clears all cached drift detection results and forces fresh analysis
    
    .DESCRIPTION
    Resets the drift detection cache including code-to-documentation mapping,
    documentation index, and previous analysis results. Use this when you want
    to force a complete re-analysis of the codebase.
    
    .PARAMETER Force
    Force cache clearing without confirmation
    
    .EXAMPLE
    Clear-DriftCache
    Clears the drift cache with confirmation prompt
    
    .EXAMPLE
    Clear-DriftCache -Force
    Clears the drift cache without confirmation
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory = $false)]
        [switch]$Force
    )
    
    if ($Force -or $PSCmdlet.ShouldProcess("Documentation drift cache", "Clear")) {
        $script:CodeToDocMapping = @{}
        $script:DocumentationIndex = @{}
        $script:DriftResults = @{}
        Write-Information "[Clear-DriftCache] Drift detection cache cleared"
    }
}

function Get-DriftDetectionResults {
    <#
    .SYNOPSIS
    Gets the current drift detection results
    
    .DESCRIPTION
    Returns the most recent drift detection analysis results including
    affected files, impact levels, and recommendations
    
    .EXAMPLE
    Get-DriftDetectionResults
    Returns current drift detection results
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()
    
    if ($script:DriftResults.Count -eq 0) {
        Write-Warning "No drift detection results available. Run drift analysis first."
        return @{}
    }
    
    return $script:DriftResults.Clone()
}

function Test-DocumentationDrift {
    <#
    .SYNOPSIS
    Performs comprehensive documentation drift analysis
    
    .DESCRIPTION
    Analyzes the entire codebase for documentation drift by comparing
    code changes against existing documentation
    
    .PARAMETER Path
    Root path to analyze (defaults to current directory)
    
    .PARAMETER Quick
    Performs quick analysis (skips some intensive checks)
    
    .EXAMPLE
    Test-DocumentationDrift
    Performs full documentation drift analysis on current directory
    
    .EXAMPLE
    Test-DocumentationDrift -Path ".\Modules" -Quick
    Performs quick analysis on Modules directory
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$Path = ".",
        
        [Parameter(Mandatory = $false)]
        [switch]$Quick
    )
    
    Write-Information "[Test-DocumentationDrift] Starting documentation drift analysis..."
    
    try {
        # Get configuration
        $config = Get-DocumentationDriftConfig
        if ($config.Count -eq 0) {
            Write-Warning "DocumentationDrift not configured. Initializing with defaults..."
            Initialize-DocumentationDrift
            $config = Get-DocumentationDriftConfig
        }
        
        # Get all relevant files
        $allFiles = Get-ChildItem -Path $Path -Recurse -File | Where-Object {
            $file = $_
            $include = $false
            
            # Check include patterns
            foreach ($pattern in $config.IncludePatterns) {
                if ($file.Name -like $pattern) {
                    $include = $true
                    break
                }
            }
            
            if (-not $include) { return $false }
            
            # Check exclude patterns
            foreach ($pattern in $config.ExcludePatterns) {
                if ($file.FullName -like "*$pattern*") {
                    return $false
                }
            }
            
            return $true
        }
        
        Write-Verbose "[Test-DocumentationDrift] Analyzing $($allFiles.Count) files..."
        
        $results = @{
            Timestamp = Get-Date
            Path = $Path
            TotalFiles = $allFiles.Count
            AnalyzedFiles = 0
            ImpactResults = @()
            Summary = @{
                Critical = 0
                High = 0
                Medium = 0
                Low = 0
                None = 0
            }
            Recommendations = @()
        }
        
        foreach ($file in $allFiles) {
            try {
                # For this refactored version, we'll do a simplified analysis
                # In the full implementation, this would use Git to detect changes
                $impact = Analyze-ChangeImpact -FilePath $file.FullName -ChangeType 'Modified'
                $results.ImpactResults += $impact
                $results.Summary[$impact.ImpactLevel]++
                $results.AnalyzedFiles++
                
                if ($impact.Recommendations) {
                    $results.Recommendations += $impact.Recommendations
                }
                
            } catch {
                Write-Warning "[Test-DocumentationDrift] Failed to analyze $($file.FullName): $_"
            }
        }
        
        # Store results in module cache
        $script:DriftResults = $results
        
        Write-Information "[Test-DocumentationDrift] Analysis complete. $($results.AnalyzedFiles) files analyzed."
        Write-Information "[Test-DocumentationDrift] Impact summary - Critical: $($results.Summary.Critical), High: $($results.Summary.High), Medium: $($results.Summary.Medium), Low: $($results.Summary.Low)"
        
        return $results
        
    } catch {
        Write-Error "[Test-DocumentationDrift] Documentation drift analysis failed: $_"
        throw
    }
}

# Export module members (combining exports from sub-modules)
Export-ModuleMember -Function @(
    # From Core.Configuration
    'Initialize-DocumentationDrift',
    'Get-DocumentationDriftConfig', 
    'Set-DocumentationDriftConfig',
    'Reset-DocumentationDriftConfig',
    'Export-DocumentationDriftConfig',
    
    # From Analysis.ImpactAnalysis  
    'Analyze-ChangeImpact',
    'Analyze-NewFileImpact',
    'Analyze-DeletedFileImpact', 
    'Analyze-ModifiedFileImpact',
    'Analyze-RenamedFileImpact',
    'Determine-OverallImpactLevel',
    'Generate-ChangeRecommendations',
    
    # Main module functions
    'Clear-DriftCache',
    'Get-DriftDetectionResults',
    'Test-DocumentationDrift'
)

Write-Verbose "[DocumentationDrift] Refactored modular DocumentationDrift module loaded with $((Get-Command -Module $MyInvocation.MyCommand.ModuleName).Count) exported functions"