# Unity-Claude-DocumentationDrift Impact Analysis Module
# Analyzes impact of code changes on documentation
# Created: 2025-08-25 (Refactored from large monolithic module)

#Requires -Version 7.2

function Analyze-ChangeImpact {
    <#
    .SYNOPSIS
    Analyzes the impact of code changes on documentation
    
    .DESCRIPTION
    Compares current code against previous version using AST analysis to determine
    the impact on documentation. Classifies changes as semantic vs formatting and
    provides impact severity assessment.
    
    .PARAMETER FilePath
    Path to the file that has changed
    
    .PARAMETER PreviousContent
    Previous content of the file for comparison (optional - will use Git if not provided)
    
    .PARAMETER ChangeType
    Type of change: Added, Modified, Deleted, Renamed
    
    .EXAMPLE
    Analyze-ChangeImpact -FilePath ".\Modules\MyModule\MyModule.psm1" -ChangeType Modified
    Analyzes impact of changes to MyModule.psm1
    
    .EXAMPLE
    Analyze-ChangeImpact -FilePath ".\Scripts\Deploy.ps1" -PreviousContent $oldContent -ChangeType Modified
    Analyzes impact with explicit previous content comparison
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        
        [Parameter(Mandatory = $false)]
        [string]$PreviousContent,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet('Added', 'Modified', 'Deleted', 'Renamed')]
        [string]$ChangeType
    )
    
    Write-Verbose "[Analyze-ChangeImpact] Analyzing impact for file: $FilePath (Change: $ChangeType)"
    
    try {
        # Initialize impact analysis result
        $impactResult = @{
            FilePath = $FilePath
            ChangeType = $ChangeType
            Timestamp = Get-Date
            ImpactLevel = 'None'
            ChangeCategory = 'Unknown'
            AffectedFunctions = @()
            AffectedClasses = @()
            DocumentationImpact = @()
            Recommendations = @()
            Details = @{
                SemanticChanges = @()
                FormattingChanges = @()
                NewElements = @()
                RemovedElements = @()
                ModifiedElements = @()
                BreakingChanges = @()
            }
        }
        
        # Handle different change types
        switch ($ChangeType) {
            'Added' {
                Write-Verbose "[Analyze-ChangeImpact] Analyzing new file addition"
                $impactResult = Analyze-NewFileImpact -FilePath $FilePath -ImpactResult $impactResult
            }
            
            'Deleted' {
                Write-Verbose "[Analyze-ChangeImpact] Analyzing file deletion"
                $impactResult = Analyze-DeletedFileImpact -FilePath $FilePath -ImpactResult $impactResult
            }
            
            'Modified' {
                Write-Verbose "[Analyze-ChangeImpact] Analyzing file modifications"
                $impactResult = Analyze-ModifiedFileImpact -FilePath $FilePath -PreviousContent $PreviousContent -ImpactResult $impactResult
            }
            
            'Renamed' {
                Write-Verbose "[Analyze-ChangeImpact] Analyzing file rename"
                $impactResult = Analyze-RenamedFileImpact -FilePath $FilePath -ImpactResult $impactResult
            }
        }
        
        # Determine overall impact level based on analysis
        $impactResult.ImpactLevel = Determine-OverallImpactLevel -ImpactResult $impactResult
        
        # Generate recommendations based on impact
        $impactResult.Recommendations = Generate-ChangeRecommendations -ImpactResult $impactResult
        
        Write-Verbose "[Analyze-ChangeImpact] Impact analysis completed. Level: $($impactResult.ImpactLevel), Affected docs: $($impactResult.DocumentationImpact.Count)"
        
        return $impactResult
        
    } catch {
        Write-Error "[Analyze-ChangeImpact] Failed to analyze change impact for $($FilePath): $_"
        throw
    }
}

function Analyze-NewFileImpact {
    <#
    .SYNOPSIS
    Analyzes the impact of adding a new file
    
    .DESCRIPTION
    Determines what documentation needs to be created for a new file
    
    .PARAMETER FilePath
    Path to the new file
    
    .PARAMETER ImpactResult
    Base impact result to enhance
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    Write-Verbose "[Analyze-NewFileImpact] Analyzing new file: $FilePath"
    
    $ImpactResult.ImpactLevel = 'Medium'
    $ImpactResult.ChangeCategory = 'Addition'
    
    # Analyze file type and content
    $extension = [System.IO.Path]::GetExtension($FilePath)
    
    switch ($extension.ToLower()) {
        '.ps1' {
            $ImpactResult.Recommendations += "Create documentation for new PowerShell script: $FilePath"
            $ImpactResult.ImpactLevel = 'Medium'
        }
        '.psm1' {
            $ImpactResult.Recommendations += "Create module documentation for: $FilePath"
            $ImpactResult.ImpactLevel = 'High'
        }
        '.cs' {
            $ImpactResult.Recommendations += "Create API documentation for new C# file: $FilePath"
            $ImpactResult.ImpactLevel = 'Medium'
        }
        default {
            $ImpactResult.Recommendations += "Review documentation needs for new file: $FilePath"
            $ImpactResult.ImpactLevel = 'Low'
        }
    }
    
    return $ImpactResult
}

function Analyze-DeletedFileImpact {
    <#
    .SYNOPSIS
    Analyzes the impact of deleting a file
    
    .DESCRIPTION
    Determines what documentation needs to be removed or updated when a file is deleted
    
    .PARAMETER FilePath
    Path to the deleted file
    
    .PARAMETER ImpactResult
    Base impact result to enhance
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    Write-Verbose "[Analyze-DeletedFileImpact] Analyzing deleted file: $FilePath"
    
    $ImpactResult.ImpactLevel = 'High'
    $ImpactResult.ChangeCategory = 'Deletion'
    $ImpactResult.Recommendations += "Remove or update documentation references to deleted file: $FilePath"
    $ImpactResult.Details.BreakingChanges += @{
        Type = 'File Deletion'
        Description = "File $FilePath has been deleted"
        Impact = 'High'
    }
    
    return $ImpactResult
}

function Analyze-ModifiedFileImpact {
    <#
    .SYNOPSIS
    Analyzes the impact of modifying a file
    
    .DESCRIPTION
    Compares current and previous content to determine documentation impact
    
    .PARAMETER FilePath
    Path to the modified file
    
    .PARAMETER PreviousContent
    Previous content of the file
    
    .PARAMETER ImpactResult
    Base impact result to enhance
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        
        [Parameter(Mandatory = $false)]
        [string]$PreviousContent,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    Write-Verbose "[Analyze-ModifiedFileImpact] Analyzing modified file: $FilePath"
    
    try {
        if (-not $PreviousContent) {
            # Try to get previous content from Git
            try {
                $PreviousContent = git show HEAD:$FilePath 2>$null
            } catch {
                Write-Warning "[Analyze-ModifiedFileImpact] Could not retrieve previous content from Git"
                $PreviousContent = ""
            }
        }
        
        if (Test-Path $FilePath) {
            $currentContent = Get-Content $FilePath -Raw
            
            # Basic comparison for now - this could be enhanced with AST parsing
            $differences = Compare-Object ($PreviousContent -split "`n") ($currentContent -split "`n") -IncludeEqual
            
            $addedLines = ($differences | Where-Object SideIndicator -eq '=>').Count
            $removedLines = ($differences | Where-Object SideIndicator -eq '<=').Count
            $totalChanges = $addedLines + $removedLines
            
            if ($totalChanges -gt 50) {
                $ImpactResult.ImpactLevel = 'High'
            } elseif ($totalChanges -gt 10) {
                $ImpactResult.ImpactLevel = 'Medium'
            } else {
                $ImpactResult.ImpactLevel = 'Low'
            }
            
            $ImpactResult.ChangeCategory = 'Modification'
            $ImpactResult.Details.SemanticChanges += @{
                AddedLines = $addedLines
                RemovedLines = $removedLines
                TotalChanges = $totalChanges
            }
            
            $ImpactResult.Recommendations += "Review documentation for modified file: $FilePath ($totalChanges lines changed)"
            
        } else {
            Write-Warning "[Analyze-ModifiedFileImpact] File not found: $FilePath"
            $ImpactResult.ImpactLevel = 'High'
            $ImpactResult.Recommendations += "File $FilePath appears to be missing - check documentation impact"
        }
        
    } catch {
        Write-Error "[Analyze-ModifiedFileImpact] Error analyzing file modifications: $_"
        $ImpactResult.ImpactLevel = 'Medium'
        $ImpactResult.Recommendations += "Manual review required for file: $FilePath (analysis error)"
    }
    
    return $ImpactResult
}

function Analyze-RenamedFileImpact {
    <#
    .SYNOPSIS
    Analyzes the impact of renaming a file
    
    .DESCRIPTION
    Determines what documentation needs to be updated when a file is renamed
    
    .PARAMETER FilePath
    New path of the renamed file
    
    .PARAMETER ImpactResult
    Base impact result to enhance
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    Write-Verbose "[Analyze-RenamedFileImpact] Analyzing renamed file: $FilePath"
    
    $ImpactResult.ImpactLevel = 'Medium'
    $ImpactResult.ChangeCategory = 'Rename'
    $ImpactResult.Recommendations += "Update documentation references to reflect renamed file: $FilePath"
    
    return $ImpactResult
}

function Determine-OverallImpactLevel {
    <#
    .SYNOPSIS
    Determines the overall impact level based on analysis results
    
    .PARAMETER ImpactResult
    Impact analysis result
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    # Priority order: Critical > High > Medium > Low > None
    $levels = @('Critical', 'High', 'Medium', 'Low', 'None')
    
    $highestLevel = 'None'
    
    # Check breaking changes
    if ($ImpactResult.Details.BreakingChanges.Count -gt 0) {
        $highestLevel = 'Critical'
    }
    
    # Check current impact level
    $currentIndex = $levels.IndexOf($ImpactResult.ImpactLevel)
    $highestIndex = $levels.IndexOf($highestLevel)
    
    if ($currentIndex -lt $highestIndex) {
        $highestLevel = $ImpactResult.ImpactLevel
    }
    
    return $highestLevel
}

function Generate-ChangeRecommendations {
    <#
    .SYNOPSIS
    Generates recommendations based on impact analysis
    
    .PARAMETER ImpactResult
    Impact analysis result
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$ImpactResult
    )
    
    $recommendations = @()
    
    switch ($ImpactResult.ImpactLevel) {
        'Critical' {
            $recommendations += "URGENT: Critical documentation updates required immediately"
            $recommendations += "Create detailed migration guide for breaking changes"
        }
        'High' {
            $recommendations += "High priority documentation update needed"
            $recommendations += "Update API documentation and examples"
        }
        'Medium' {
            $recommendations += "Documentation review and update recommended"
            $recommendations += "Update relevant user guides"
        }
        'Low' {
            $recommendations += "Minor documentation updates may be needed"
        }
    }
    
    return $recommendations
}

# Export module members
Export-ModuleMember -Function @(
    'Analyze-ChangeImpact',
    'Analyze-NewFileImpact',
    'Analyze-DeletedFileImpact', 
    'Analyze-ModifiedFileImpact',
    'Analyze-RenamedFileImpact',
    'Determine-OverallImpactLevel',
    'Generate-ChangeRecommendations'
)