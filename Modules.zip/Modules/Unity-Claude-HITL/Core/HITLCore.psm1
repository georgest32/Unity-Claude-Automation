# HITLCore.psm1
# Human-in-the-Loop Core Configuration and Utilities
# Version 2.0.0 - 2025-08-26
# Part of refactored Unity-Claude-HITL module

#region Module Variables and Configuration

# Global configuration storage
$script:HITLConfig = @{
    DatabasePath = "$env:USERPROFILE\.unity-claude\hitl.db"
    DefaultTimeout = 1440  # 24 hours in minutes
    EscalationTimeout = 720  # 12 hours in minutes
    TokenExpirationMinutes = 4320  # 3 days
    MaxEscalationLevels = 3
    EmailTemplate = "DefaultApproval"
    NotificationSettings = @{
        EmailEnabled = $true
        WebhookEnabled = $false
        MobileOptimized = $true
    }
    LangGraphEndpoint = "http://localhost:8001"
    SecuritySettings = @{
        RequireTokenValidation = $true
        AllowMobileApprovals = $true
        AuditAllActions = $true
    }
}

Write-Verbose "REFACTORED VERSION - HITLCore component initialized"

#endregion

#region Configuration Management Functions

function Set-HITLConfiguration {
    <#
    .SYNOPSIS
        Sets HITL module configuration.
    
    .DESCRIPTION
        Updates module configuration with validation and persistence.
    
    .PARAMETER Configuration
        Hashtable containing configuration settings.
    
    .EXAMPLE
        Set-HITLConfiguration -Configuration @{ DefaultTimeout = 720; EmailEnabled = $true }
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Configuration
    )
    
    try {
        foreach ($key in $Configuration.Keys) {
            if ($script:HITLConfig.ContainsKey($key)) {
                $script:HITLConfig[$key] = $Configuration[$key]
                Write-Verbose "Updated configuration: $key = $($Configuration[$key])"
            } else {
                Write-Warning "Unknown configuration key: $key"
            }
        }
        
        Write-Host "HITL configuration updated successfully." -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to update configuration: $($_.Exception.Message)"
        return $false
    }
}

function Get-HITLConfiguration {
    <#
    .SYNOPSIS
        Gets current HITL module configuration.
    
    .EXAMPLE
        $config = Get-HITLConfiguration
    #>
    [CmdletBinding()]
    param()
    
    return $script:HITLConfig.Clone()
}

#endregion

#region Governance Integration

# Import governance integration module
$governanceModule = Join-Path $PSScriptRoot "..\Unity-Claude-GovernanceIntegration.psm1"
if (Test-Path $governanceModule) {
    Import-Module $governanceModule -Force -ErrorAction SilentlyContinue
    Write-Verbose "Imported governance integration module"
}

#endregion

#region Export Module Members

Export-ModuleMember -Function @(
    'Set-HITLConfiguration',
    'Get-HITLConfiguration'
) -Variable @(
    'HITLConfig'
)

#endregion