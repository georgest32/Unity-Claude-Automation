# DatabaseManagement.psm1
# Human-in-the-Loop Database Management Component
# Version 2.0.0 - 2025-08-26
# Part of refactored Unity-Claude-HITL module

# Import core configuration
$coreModule = Join-Path $PSScriptRoot "HITLCore.psm1"
if (Test-Path $coreModule) {
    Import-Module $coreModule -Force -Global -ErrorAction SilentlyContinue
}

#region Database Management Functions

function Initialize-ApprovalDatabase {
    <#
    .SYNOPSIS
        Initializes the SQLite database for approval tracking.
    
    .DESCRIPTION
        Creates the necessary tables for approval tracking, escalation rules, and audit logs.
        Based on research findings for optimal schema design.
    
    .PARAMETER DatabasePath
        Path to the SQLite database file. Defaults to module configuration.
    
    .EXAMPLE
        Initialize-ApprovalDatabase
        Initialize-ApprovalDatabase -DatabasePath "C:\Data\approvals.db"
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$DatabasePath = $(if ($script:HITLConfig) { $script:HITLConfig.DatabasePath } else { "$env:USERPROFILE\.unity-claude\hitl.db" })
    )
    
    Write-Verbose "Initializing approval database at: $DatabasePath"
    
    try {
        # Ensure directory exists
        $dbDir = Split-Path -Path $DatabasePath -Parent
        if (-not (Test-Path $dbDir)) {
            New-Item -Path $dbDir -ItemType Directory -Force | Out-Null
        }
        
        # Database schema based on research findings
        $schema = @"
-- Approval Requests (Enhanced based on research)
CREATE TABLE IF NOT EXISTS approval_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id TEXT NOT NULL,
    thread_id TEXT NOT NULL,
    request_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    changes_summary TEXT,
    impact_analysis TEXT,
    urgency_level TEXT DEFAULT 'medium',
    requested_by TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    escalation_level INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending',
    approved_by TEXT,
    approved_at TIMESTAMP,
    rejection_reason TEXT,
    approval_token TEXT UNIQUE,
    mobile_friendly INTEGER DEFAULT 1,
    metadata TEXT
);

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_status_created ON approval_requests(status, created_at);
CREATE INDEX IF NOT EXISTS idx_workflow_thread ON approval_requests(workflow_id, thread_id);
CREATE INDEX IF NOT EXISTS idx_expires_at ON approval_requests(expires_at);
CREATE INDEX IF NOT EXISTS idx_approval_token ON approval_requests(approval_token);

-- Escalation Rules (Research-Based)
CREATE TABLE IF NOT EXISTS escalation_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name TEXT UNIQUE NOT NULL,
    request_type TEXT NOT NULL,
    urgency_level TEXT NOT NULL,
    initial_timeout_minutes INTEGER DEFAULT 1440,
    escalation_levels TEXT NOT NULL,
    escalation_timeout_minutes INTEGER DEFAULT 720,
    fallback_action TEXT DEFAULT 'reject',
    auto_approve_threshold TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audit Log
CREATE TABLE IF NOT EXISTS approval_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    approval_id INTEGER,
    action TEXT NOT NULL,
    actor TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    ip_address TEXT,
    user_agent TEXT,
    FOREIGN KEY (approval_id) REFERENCES approval_requests(id)
);

-- Configuration Storage
CREATE TABLE IF NOT EXISTS hitl_configuration (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"@
        
        # Execute schema using PowerShell SQLite support
        if (Get-Command -Name Invoke-SqliteQuery -ErrorAction SilentlyContinue) {
            Invoke-SqliteQuery -DataSource $DatabasePath -Query $schema
        } else {
            # Fallback: Create database file and log schema for manual execution
            New-Item -Path $DatabasePath -ItemType File -Force | Out-Null
            Write-Warning "SQLite module not available. Database file created but schema must be initialized manually."
            Write-Host "Schema SQL saved to: $DatabasePath.schema.sql"
            $schema | Out-File -FilePath "$DatabasePath.schema.sql" -Encoding UTF8
        }
        
        Write-Host "Approval database initialized successfully." -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to initialize approval database: $($_.Exception.Message)"
        return $false
    }
}

function Test-DatabaseConnection {
    <#
    .SYNOPSIS
        Tests database connectivity and schema.
    
    .PARAMETER DatabasePath
        Path to the SQLite database file.
    
    .EXAMPLE
        Test-DatabaseConnection -DatabasePath $config.DatabasePath
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$DatabasePath = $(if ($script:HITLConfig) { $script:HITLConfig.DatabasePath } else { "$env:USERPROFILE\.unity-claude\hitl.db" })
    )
    
    try {
        if (-not (Test-Path $DatabasePath)) {
            Write-Warning "Database file does not exist: $DatabasePath"
            return $false
        }
        
        # Test basic connectivity
        if (Get-Command -Name Invoke-SqliteQuery -ErrorAction SilentlyContinue) {
            $result = Invoke-SqliteQuery -DataSource $DatabasePath -Query "SELECT COUNT(*) as TableCount FROM sqlite_master WHERE type='table';"
            Write-Verbose "Database contains $($result.TableCount) tables"
            return $true
        } else {
            Write-Warning "SQLite module not available for connectivity test"
            return $false
        }
    }
    catch {
        Write-Error "Database connectivity test failed: $($_.Exception.Message)"
        return $false
    }
}

#endregion

#region Export Module Members

Export-ModuleMember -Function @(
    'Initialize-ApprovalDatabase',
    'Test-DatabaseConnection'
)

#endregion