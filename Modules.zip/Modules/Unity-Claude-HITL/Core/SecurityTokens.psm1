# SecurityTokens.psm1
# Human-in-the-Loop Security and Token Management Component
# Version 2.0.0 - 2025-08-26
# Part of refactored Unity-Claude-HITL module

# Import core configuration
$coreModule = Join-Path $PSScriptRoot "HITLCore.psm1"
if (Test-Path $coreModule) {
    Import-Module $coreModule -Force -Global -ErrorAction SilentlyContinue
}

#region Security and Token Management

function New-ApprovalToken {
    <#
    .SYNOPSIS
        Generates a secure approval token for email-based approvals.
    
    .DESCRIPTION
        Creates a cryptographically secure token for approval requests, 
        implementing research-based security practices.
    
    .PARAMETER ApprovalId
        The ID of the approval request.
    
    .PARAMETER ExpirationMinutes
        Token expiration time in minutes. Defaults to configuration value.
    
    .EXAMPLE
        $token = New-ApprovalToken -ApprovalId 123
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$ApprovalId,
        
        [Parameter()]
        [int]$ExpirationMinutes = $(if ($script:HITLConfig) { $script:HITLConfig.TokenExpirationMinutes } else { 4320 })
    )
    
    try {
        # Generate cryptographically secure random bytes
        $bytes = New-Object byte[] 32
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        $rng.GetBytes($bytes)
        $rng.Dispose()
        
        # Create token with metadata
        $tokenData = @{
            ApprovalId = $ApprovalId
            ExpiresAt = (Get-Date).AddMinutes($ExpirationMinutes).ToString('o')
            Nonce = [Convert]::ToBase64String($bytes)
        }
        
        # Encode as Base64 JSON
        $jsonString = ConvertTo-Json $tokenData -Compress
        $tokenBytes = [System.Text.Encoding]::UTF8.GetBytes($jsonString)
        $token = [Convert]::ToBase64String($tokenBytes)
        
        Write-Verbose "Generated approval token for approval ID: $ApprovalId"
        return $token
    }
    catch {
        Write-Error "Failed to generate approval token: $($_.Exception.Message)"
        return $null
    }
}

function Test-ApprovalToken {
    <#
    .SYNOPSIS
        Validates an approval token.
    
    .DESCRIPTION
        Validates approval tokens using research-based security practices,
        including expiration and tamper detection.
    
    .PARAMETER Token
        The approval token to validate.
    
    .EXAMPLE
        $isValid = Test-ApprovalToken -Token $token
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token
    )
    
    try {
        # Decode token
        $tokenBytes = [Convert]::FromBase64String($Token)
        $jsonString = [System.Text.Encoding]::UTF8.GetString($tokenBytes)
        $tokenData = ConvertFrom-Json $jsonString
        
        # Validate expiration
        $expiresAt = [DateTime]::Parse($tokenData.ExpiresAt)
        if ((Get-Date) -gt $expiresAt) {
            Write-Verbose "Token expired at: $expiresAt"
            return $false
        }
        
        # Validate approval ID exists and is pending
        # This would query the database in a full implementation
        Write-Verbose "Token validation successful for approval ID: $($tokenData.ApprovalId)"
        return $true
    }
    catch {
        Write-Verbose "Token validation failed: $($_.Exception.Message)"
        return $false
    }
}

function Get-TokenMetadata {
    <#
    .SYNOPSIS
        Extracts metadata from an approval token without validation.
    
    .PARAMETER Token
        The approval token to decode.
    
    .EXAMPLE
        $metadata = Get-TokenMetadata -Token $token
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token
    )
    
    try {
        $tokenBytes = [Convert]::FromBase64String($Token)
        $jsonString = [System.Text.Encoding]::UTF8.GetString($tokenBytes)
        $tokenData = ConvertFrom-Json $jsonString
        
        return @{
            ApprovalId = $tokenData.ApprovalId
            ExpiresAt = [DateTime]::Parse($tokenData.ExpiresAt)
            IsExpired = (Get-Date) -gt [DateTime]::Parse($tokenData.ExpiresAt)
        }
    }
    catch {
        Write-Error "Failed to decode token metadata: $($_.Exception.Message)"
        return $null
    }
}

function Revoke-ApprovalToken {
    <#
    .SYNOPSIS
        Revokes an approval token by updating database.
    
    .PARAMETER Token
        The token to revoke.
    
    .EXAMPLE
        Revoke-ApprovalToken -Token $token
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token
    )
    
    try {
        $metadata = Get-TokenMetadata -Token $Token
        if ($metadata) {
            # In full implementation, would update database to mark token as revoked
            Write-Verbose "Token revoked for approval ID: $($metadata.ApprovalId)"
            return $true
        }
        return $false
    }
    catch {
        Write-Error "Failed to revoke token: $($_.Exception.Message)"
        return $false
    }
}

#endregion

#region Export Module Members

Export-ModuleMember -Function @(
    'New-ApprovalToken',
    'Test-ApprovalToken', 
    'Get-TokenMetadata',
    'Revoke-ApprovalToken'
)

#endregion