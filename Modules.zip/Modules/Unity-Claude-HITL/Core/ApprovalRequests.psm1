# ApprovalRequests.psm1
# Human-in-the-Loop Approval Request Management Component
# Version 2.0.0 - 2025-08-26
# Part of refactored Unity-Claude-HITL module

# Import required components
$coreModule = Join-Path $PSScriptRoot "HITLCore.psm1"
$tokenModule = Join-Path $PSScriptRoot "SecurityTokens.psm1"
if (Test-Path $coreModule) { Import-Module $coreModule -Force -Global -ErrorAction SilentlyContinue }
if (Test-Path $tokenModule) { Import-Module $tokenModule -Force -Global -ErrorAction SilentlyContinue }

#region Approval Request Management

function New-ApprovalRequest {
    <#
    .SYNOPSIS
        Creates a new approval request.
    
    .DESCRIPTION
        Creates a comprehensive approval request with context, impact analysis,
        and metadata based on research findings for effective HITL workflows.
    
    .PARAMETER WorkflowId
        Unique identifier for the workflow requiring approval.
    
    .PARAMETER Title
        Short, descriptive title for the approval request.
    
    .PARAMETER Description
        Detailed description of what requires approval.
    
    .PARAMETER ChangesSummary
        Summary of changes being made.
    
    .PARAMETER ImpactAnalysis
        Analysis of the impact of the proposed changes.
    
    .PARAMETER UrgencyLevel
        Urgency level: low, medium, high, critical.
    
    .PARAMETER RequestType
        Type of approval: documentation, config, critical, etc.
    
    .PARAMETER Metadata
        Additional metadata as hashtable.
    
    .EXAMPLE
        $request = New-ApprovalRequest -WorkflowId "doc-update-001" -Title "Update API Documentation" -Description "Update REST API docs for v2.0" -UrgencyLevel "medium"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$WorkflowId,
        
        [Parameter(Mandatory = $true)]
        [string]$Title,
        
        [Parameter(Mandatory = $true)]
        [string]$Description,
        
        [Parameter()]
        [string]$ChangesSummary = "",
        
        [Parameter()]
        [string]$ImpactAnalysis = "",
        
        [Parameter()]
        [ValidateSet('low', 'medium', 'high', 'critical')]
        [string]$UrgencyLevel = 'medium',
        
        [Parameter()]
        [string]$RequestType = 'documentation',
        
        [Parameter()]
        [hashtable]$Metadata = @{}
    )
    
    Write-Verbose "Creating approval request for workflow: $WorkflowId"
    
    try {
        # Generate unique thread ID (LangGraph integration)
        $threadId = [System.Guid]::NewGuid().ToString()
        
        # Calculate expiration based on urgency and configuration
        $timeoutMinutes = switch ($UrgencyLevel) {
            'critical' { 480 }    # 8 hours
            'high' { 720 }        # 12 hours
            'medium' { $(if ($script:HITLConfig) { $script:HITLConfig.DefaultTimeout } else { 1440 }) }  # 24 hours
            'low' { 2880 }        # 48 hours
        }
        
        $expiresAt = (Get-Date).AddMinutes($timeoutMinutes)
        
        # Create approval request object
        $approvalRequest = [PSCustomObject]@{
            Id = 0  # Will be set by database
            WorkflowId = $WorkflowId
            ThreadId = $threadId
            RequestType = $RequestType
            Title = $Title
            Description = $Description
            ChangesSummary = $ChangesSummary
            ImpactAnalysis = $ImpactAnalysis
            UrgencyLevel = $UrgencyLevel
            RequestedBy = $env:USERNAME
            CreatedAt = (Get-Date)
            ExpiresAt = $expiresAt
            EscalationLevel = 0
            Status = 'pending'
            ApprovedBy = $null
            ApprovedAt = $null
            RejectionReason = $null
            ApprovalToken = $null
            MobileFriendly = $true
            Metadata = (ConvertTo-Json $Metadata -Compress)
        }
        
        # In a full implementation, this would insert into the database
        # For now, we'll simulate by generating an ID and token
        $approvalRequest.Id = Get-Random -Minimum 1000 -Maximum 9999
        $approvalRequest.ApprovalToken = New-ApprovalToken -ApprovalId $approvalRequest.Id
        
        Write-Host "Approval request created successfully. ID: $($approvalRequest.Id)" -ForegroundColor Green
        return $approvalRequest
    }
    catch {
        Write-Error "Failed to create approval request: $($_.Exception.Message)"
        return $null
    }
}

function Get-ApprovalStatus {
    <#
    .SYNOPSIS
        Gets the current status of an approval request.
    
    .PARAMETER ApprovalId
        The ID of the approval request.
    
    .EXAMPLE
        $status = Get-ApprovalStatus -ApprovalId 123
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$ApprovalId
    )
    
    # Simulate database query for demo
    # In full implementation, this would query the SQLite database
    return [PSCustomObject]@{
        Id = $ApprovalId
        Status = 'pending'  # pending, approved, rejected, expired
        ApprovedBy = $null
        ApprovedAt = $null
        RejectionReason = $null
        Comments = $null
        EscalationLevel = 0
    }
}

function Set-ApprovalEscalation {
    <#
    .SYNOPSIS
        Handles approval escalation based on timeout and rules.
    
    .PARAMETER ApprovalRequest
        The approval request to escalate.
    
    .EXAMPLE
        $result = Set-ApprovalEscalation -ApprovalRequest $request
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$ApprovalRequest
    )
    
    try {
        $maxLevels = if ($script:HITLConfig) { $script:HITLConfig.MaxEscalationLevels } else { 3 }
        if ($ApprovalRequest.EscalationLevel -ge $maxLevels) {
            return @{ Escalated = $false; MaxReached = $true }
        }
        
        # Increment escalation level
        $ApprovalRequest.EscalationLevel++
        
        Write-Host "📈 Escalating approval request to level: $($ApprovalRequest.EscalationLevel)" -ForegroundColor Yellow
        
        # In full implementation, this would:
        # 1. Update database
        # 2. Notify next escalation level
        # 3. Reset timeout
        
        return @{ Escalated = $true; NewLevel = $ApprovalRequest.EscalationLevel }
    }
    catch {
        Write-Error "Failed to escalate approval: $($_.Exception.Message)"
        return @{ Escalated = $false; Error = $_.Exception.Message }
    }
}

function Get-PendingApprovals {
    <#
    .SYNOPSIS
        Gets all pending approval requests.
    
    .EXAMPLE
        $pending = Get-PendingApprovals
    #>
    [CmdletBinding()]
    param()
    
    # Simulate database query
    Write-Host "📋 Retrieving pending approvals..." -ForegroundColor Blue
    return @()  # Would return actual pending approvals from database
}

function Update-ApprovalStatus {
    <#
    .SYNOPSIS
        Updates the status of an approval request.
    
    .PARAMETER ApprovalId
        ID of the approval request.
    
    .PARAMETER Status
        New status for the request.
    
    .PARAMETER ApprovedBy
        Who approved/rejected the request.
    
    .PARAMETER Comments
        Optional comments.
    
    .EXAMPLE
        Update-ApprovalStatus -ApprovalId 123 -Status 'approved' -ApprovedBy 'john.doe'
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$ApprovalId,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet('pending', 'approved', 'rejected', 'expired')]
        [string]$Status,
        
        [Parameter()]
        [string]$ApprovedBy,
        
        [Parameter()]
        [string]$Comments
    )
    
    try {
        # In full implementation, would update database
        Write-Verbose "Updated approval $ApprovalId status to: $Status"
        return $true
    }
    catch {
        Write-Error "Failed to update approval status: $($_.Exception.Message)"
        return $false
    }
}

#endregion

#region Export Module Members

Export-ModuleMember -Function @(
    'New-ApprovalRequest',
    'Get-ApprovalStatus',
    'Set-ApprovalEscalation', 
    'Get-PendingApprovals',
    'Update-ApprovalStatus'
)

#endregion