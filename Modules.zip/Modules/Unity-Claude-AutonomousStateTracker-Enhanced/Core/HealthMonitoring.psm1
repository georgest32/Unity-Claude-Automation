# HealthMonitoring.psm1
# Performance and health monitoring for autonomous state tracking
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: Performance and health monitoring (115 lines)

#region Performance and Health Monitoring

function Start-EnhancedHealthMonitoring {
    <#
    .SYNOPSIS
    Start enhanced health monitoring with performance counters and thresholds
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId
    )
    
    try {
        Write-EnhancedStateLog -Message "Starting enhanced health monitoring for agent: $AgentId" -Level "INFO"
        
        # Get configurations
        $stateConfig = Get-EnhancedStateConfig
        $performanceCounters = Get-PerformanceCounters
        $autonomousStates = Get-EnhancedAutonomousStates
        
        # Create monitoring job
        $monitoringScript = {
            param($AgentId, $StateConfig, $PerformanceCounters, $EnhancedAutonomousStates)
            
            # Import module functions in job context
            $modulePath = Split-Path $PSScriptRoot -Parent
            Import-Module (Join-Path $modulePath "Unity-Claude-AutonomousStateTracker-Enhanced.psm1") -Force
            
            while ($true) {
                try {
                    # Get current agent state
                    $agentState = Get-AgentState -AgentId $AgentId
                    if (-not $agentState) {
                        Start-Sleep -Seconds $StateConfig.HealthCheckIntervalSeconds
                        continue
                    }
                    
                    # Skip monitoring if not required
                    $stateDefinition = $EnhancedAutonomousStates[$agentState.CurrentState]
                    if (-not $stateDefinition.RequiresMonitoring) {
                        Start-Sleep -Seconds $StateConfig.HealthCheckIntervalSeconds
                        continue
                    }
                    
                    # Collect performance metrics
                    $performanceMetrics = Get-SystemPerformanceMetrics
                    
                    # Test health thresholds
                    $healthAssessment = Test-SystemHealthThresholds -PerformanceMetrics $performanceMetrics
                    
                    # Update agent state with health data
                    $agentState.HealthMetrics = $performanceMetrics
                    $agentState.LastHealthCheck = Get-Date
                    
                    # Handle health issues
                    if ($healthAssessment.RequiresIntervention) {
                        $reasons = $healthAssessment.CriticalIssues -join "; "
                        Request-HumanIntervention -AgentId $AgentId -Reason "Critical system health issues: $reasons" -Priority "Critical"
                        
                        # Transition to error state
                        Set-EnhancedAutonomousState -AgentId $AgentId -NewState "Error" -Reason "Critical health threshold exceeded"
                    } elseif ($healthAssessment.RequiresAttention) {
                        $reasons = $healthAssessment.HealthIssues -join "; "
                        Write-EnhancedStateLog -Message "Health warning: $reasons" -Level "WARNING" -Component "HealthMonitor"
                    }
                    
                    # Save updated state
                    Save-AgentState -AgentState $agentState
                    
                    # Log performance data
                    Write-EnhancedStateLog -Message "Health check completed" -Level "PERFORMANCE" -AdditionalData $performanceMetrics
                    
                } catch {
                    Write-EnhancedStateLog -Message "Health monitoring error: $($_.Exception.Message)" -Level "ERROR" -Component "HealthMonitor"
                }
                
                Start-Sleep -Seconds $StateConfig.HealthCheckIntervalSeconds
            }
        }
        
        # Start monitoring job
        $job = Start-Job -ScriptBlock $monitoringScript -ArgumentList $AgentId, $stateConfig, $performanceCounters, $autonomousStates
        
        Write-EnhancedStateLog -Message "Enhanced health monitoring started (Job ID: $($job.Id))" -Level "INFO"
        
        return $job
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to start health monitoring: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Stop-EnhancedHealthMonitoring {
    <#
    .SYNOPSIS
    Stop enhanced health monitoring jobs
    #>
    [CmdletBinding()]
    param(
        [string]$AgentId
    )
    
    try {
        # Find and stop monitoring jobs
        $jobs = Get-Job | Where-Object { $_.Command -like "*HealthMonitoring*" }
        
        foreach ($job in $jobs) {
            Stop-Job $job -ErrorAction SilentlyContinue
            Remove-Job $job -Force -ErrorAction SilentlyContinue
        }
        
        Write-EnhancedStateLog -Message "Enhanced health monitoring stopped" -Level "INFO"
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to stop health monitoring: $($_.Exception.Message)" -Level "ERROR"
    }
}

function Get-HealthMonitoringStatus {
    <#
    .SYNOPSIS
    Get status of health monitoring jobs
    #>
    [CmdletBinding()]
    param()
    
    try {
        $jobs = Get-Job | Where-Object { $_.Command -like "*HealthMonitoring*" }
        
        $status = @()
        foreach ($job in $jobs) {
            $status += @{
                JobId = $job.Id
                State = $job.State
                HasMoreData = $job.HasMoreData
                StartTime = $job.PSBeginTime
                Command = $job.Command
            }
        }
        
        return $status
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to get health monitoring status: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
}

function Test-AgentHealth {
    <#
    .SYNOPSIS
    Perform immediate health check on an agent
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId
    )
    
    try {
        # Get agent state
        $agentState = Get-AgentState -AgentId $AgentId
        if (-not $agentState) {
            return @{
                AgentId = $AgentId
                HealthStatus = "Unknown"
                Reason = "Agent state not found"
            }
        }
        
        # Get current performance metrics
        $performanceMetrics = Get-SystemPerformanceMetrics
        
        # Test health thresholds
        $healthAssessment = Test-SystemHealthThresholds -PerformanceMetrics $performanceMetrics
        
        # Determine overall health status
        $healthStatus = if ($healthAssessment.RequiresIntervention) {
            "Critical"
        } elseif ($healthAssessment.RequiresAttention) {
            "Warning"
        } else {
            "Healthy"
        }
        
        return @{
            AgentId = $AgentId
            HealthStatus = $healthStatus
            CurrentState = $agentState.CurrentState
            LastHealthCheck = $agentState.LastHealthCheck
            PerformanceMetrics = $performanceMetrics
            HealthIssues = $healthAssessment.HealthIssues
            CriticalIssues = $healthAssessment.CriticalIssues
            UptimeMinutes = [math]::Round((Get-UptimeMinutes -StartTime $agentState.StartTime), 2)
        }
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to test agent health: $($_.Exception.Message)" -Level "ERROR"
        return @{
            AgentId = $AgentId
            HealthStatus = "Error"
            Reason = $_.Exception.Message
        }
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Start-EnhancedHealthMonitoring',
    'Stop-EnhancedHealthMonitoring',
    'Get-HealthMonitoringStatus',
    'Test-AgentHealth'
)

#endregion