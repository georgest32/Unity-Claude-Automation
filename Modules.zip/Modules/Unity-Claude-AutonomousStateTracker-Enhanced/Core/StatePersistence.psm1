# StatePersistence.psm1
# State persistence and recovery functions for autonomous state tracking
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: State persistence and recovery (200 lines)

#region State Persistence and Recovery

function New-StateCheckpoint {
    <#
    .SYNOPSIS
    Create a state checkpoint for recovery purposes (based on research findings)
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AgentState,
        
        [string]$Reason = "Scheduled checkpoint"
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $checkpointId = "$($AgentState.AgentId)-$timestamp"
        $checkpointFile = Join-Path $stateConfig.CheckpointPath "$checkpointId.json"
        
        # Create checkpoint data
        $checkpoint = @{
            CheckpointId = $checkpointId
            AgentId = $AgentState.AgentId
            Timestamp = Get-Date
            Reason = $Reason
            AgentState = $AgentState
            SystemState = Get-SystemPerformanceMetrics
            PowerShellProcess = @{
                PID = $PID
                WorkingSet = (Get-Process -Id $PID).WorkingSet64
                StartTime = Get-SafeDateTime -DateTimeObject (Get-Process -Id $PID).StartTime
            }
        }
        
        # Save checkpoint
        $checkpoint | ConvertTo-Json -Depth 15 | Out-File -FilePath $checkpointFile -Encoding UTF8
        
        # Update agent state with checkpoint reference
        $checkpointEntry = @{
            CheckpointId = $checkpointId
            Timestamp = Get-Date
            Reason = $Reason
            FilePath = $checkpointFile
        }
        $AgentState.CheckpointHistory = @($AgentState.CheckpointHistory) + @($checkpointEntry)
        
        # Trim checkpoint history
        if ($AgentState.CheckpointHistory.Count -gt 50) {
            $AgentState.CheckpointHistory = $AgentState.CheckpointHistory | Select-Object -Last 50
        }
        
        Write-EnhancedStateLog -Message "State checkpoint created: $checkpointId" -Level "INFO" -AdditionalData @{ Reason = $Reason }
        
        return $checkpointId
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to create state checkpoint: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Restore-AgentStateFromCheckpoint {
    <#
    .SYNOPSIS
    Restore agent state from the most recent checkpoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [string]$CheckpointId
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        $checkpointFiles = Get-ChildItem -Path $stateConfig.CheckpointPath -Filter "$AgentId-*.json" | 
                          Sort-Object LastWriteTime -Descending
        
        if (-not $checkpointFiles) {
            Write-EnhancedStateLog -Message "No checkpoints found for agent: $AgentId" -Level "WARNING"
            return $null
        }
        
        $targetCheckpoint = if ($CheckpointId) {
            $checkpointFiles | Where-Object { $_.BaseName -eq $CheckpointId } | Select-Object -First 1
        } else {
            $checkpointFiles | Select-Object -First 1  # Most recent
        }
        
        if (-not $targetCheckpoint) {
            Write-EnhancedStateLog -Message "Checkpoint not found: $CheckpointId" -Level "WARNING"
            return $null
        }
        
        # Load checkpoint data
        $checkpointJson = Get-Content $targetCheckpoint.FullName -Raw
        $checkpointData = ConvertTo-HashTable -Object ($checkpointJson | ConvertFrom-Json) -Recurse
        
        # Extract agent state
        $restoredState = $checkpointData.AgentState
        
        # Update restoration metadata
        $restoredState.RestoredFromCheckpoint = $checkpointData.CheckpointId
        $restoredState.RestoredAt = Get-Date
        
        Write-EnhancedStateLog -Message "Agent state restored from checkpoint: $($checkpointData.CheckpointId)" -Level "INFO" -AdditionalData @{
            AgentId = $AgentId
            CheckpointTimestamp = $checkpointData.Timestamp
        }
        
        return $restoredState
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to restore from checkpoint: $($_.Exception.Message)" -Level "ERROR"
        return $null
    }
}

function Get-CheckpointHistory {
    <#
    .SYNOPSIS
    Get checkpoint history for an agent
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [int]$Limit = 20
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        $checkpointFiles = Get-ChildItem -Path $stateConfig.CheckpointPath -Filter "$AgentId-*.json" | 
                          Sort-Object LastWriteTime -Descending |
                          Select-Object -First $Limit
        
        $checkpoints = @()
        
        foreach ($file in $checkpointFiles) {
            try {
                $checkpointJson = Get-Content $file.FullName -Raw
                $checkpointData = $checkpointJson | ConvertFrom-Json
                
                $checkpoints += @{
                    CheckpointId = $checkpointData.CheckpointId
                    AgentId = $checkpointData.AgentId
                    Timestamp = $checkpointData.Timestamp
                    Reason = $checkpointData.Reason
                    FilePath = $file.FullName
                    FileSize = [math]::Round($file.Length / 1KB, 2)
                }
            } catch {
                Write-EnhancedStateLog -Message "Failed to read checkpoint file: $($file.Name)" -Level "WARNING"
            }
        }
        
        return $checkpoints
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to get checkpoint history: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
}

function Remove-OldCheckpoints {
    <#
    .SYNOPSIS
    Clean up old checkpoints based on retention policy
    #>
    [CmdletBinding()]
    param(
        [string]$AgentId,
        [int]$RetentionDays
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        if (-not $RetentionDays) {
            $RetentionDays = $stateConfig.BackupRetentionDays
        }
        
        $cutoffDate = (Get-Date).AddDays(-$RetentionDays)
        
        $filter = if ($AgentId) { "$AgentId-*.json" } else { "*.json" }
        
        $oldCheckpoints = Get-ChildItem -Path $stateConfig.CheckpointPath -Filter $filter | 
                         Where-Object { $_.LastWriteTime -lt $cutoffDate }
        
        $removedCount = 0
        foreach ($checkpoint in $oldCheckpoints) {
            try {
                Remove-Item $checkpoint.FullName -Force
                $removedCount++
            } catch {
                Write-EnhancedStateLog -Message "Failed to remove old checkpoint: $($checkpoint.Name)" -Level "WARNING"
            }
        }
        
        if ($removedCount -gt 0) {
            Write-EnhancedStateLog -Message "Removed $removedCount old checkpoints (older than $RetentionDays days)" -Level "INFO"
        }
        
        return $removedCount
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to clean up old checkpoints: $($_.Exception.Message)" -Level "ERROR"
        return 0
    }
}

function Test-CheckpointIntegrity {
    <#
    .SYNOPSIS
    Test the integrity of checkpoint files
    #>
    [CmdletBinding()]
    param(
        [string]$AgentId
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        $filter = if ($AgentId) { "$AgentId-*.json" } else { "*.json" }
        
        $checkpointFiles = Get-ChildItem -Path $stateConfig.CheckpointPath -Filter $filter
        
        $results = @()
        
        foreach ($file in $checkpointFiles) {
            $integrity = @{
                FileName = $file.Name
                FilePath = $file.FullName
                FileSize = $file.Length
                LastModified = $file.LastWriteTime
                IsValid = $false
                Error = $null
            }
            
            try {
                $checkpointJson = Get-Content $file.FullName -Raw
                $checkpointData = $checkpointJson | ConvertFrom-Json
                
                # Validate required fields
                if ($checkpointData.CheckpointId -and 
                    $checkpointData.AgentId -and 
                    $checkpointData.Timestamp -and 
                    $checkpointData.AgentState) {
                    $integrity.IsValid = $true
                }
            } catch {
                $integrity.Error = $_.Exception.Message
            }
            
            $results += $integrity
        }
        
        return $results
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to test checkpoint integrity: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
}

# Export functions
Export-ModuleMember -Function @(
    'New-StateCheckpoint',
    'Restore-AgentStateFromCheckpoint',
    'Get-CheckpointHistory',
    'Remove-OldCheckpoints',
    'Test-CheckpointIntegrity'
)

#endregion