# CoreUtilities.psm1
# Core utility functions for autonomous state tracking
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: Core utilities and helper functions (220 lines)

#region Core Utility Functions

function ConvertTo-HashTable {
    <#
    .SYNOPSIS
    Convert PSCustomObject to hashtable recursively for JSON compatibility
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $Object,
        
        [switch]$Recurse
    )
    
    if ($null -eq $Object) {
        return $null
    }
    
    if ($Object -is [System.Collections.IDictionary]) {
        $hashTable = @{}
        foreach ($key in $Object.Keys) {
            if ($Recurse -and $null -ne $Object[$key] -and 
                ($Object[$key].GetType().Name -eq 'PSCustomObject' -or $Object[$key] -is [System.Collections.IDictionary])) {
                $hashTable[$key] = ConvertTo-HashTable -Object $Object[$key] -Recurse
            } else {
                $hashTable[$key] = $Object[$key]
            }
        }
        return $hashTable
    }
    
    if ($Object.GetType().Name -eq 'PSCustomObject') {
        $hashTable = @{}
        $Object.PSObject.Properties | ForEach-Object {
            if ($Recurse -and $null -ne $_.Value -and 
                ($_.Value.GetType().Name -eq 'PSCustomObject' -or $_.Value -is [System.Collections.IDictionary])) {
                $hashTable[$_.Name] = ConvertTo-HashTable -Object $_.Value -Recurse
            } else {
                $hashTable[$_.Name] = $_.Value
            }
        }
        return $hashTable
    }
    
    if ($Object -is [Array]) {
        $arrayResult = @()
        foreach ($item in $Object) {
            if ($Recurse -and $null -ne $item -and 
                ($item.GetType().Name -eq 'PSCustomObject' -or $item -is [System.Collections.IDictionary])) {
                $arrayResult += ConvertTo-HashTable -Object $item -Recurse
            } else {
                $arrayResult += $item
            }
        }
        return $arrayResult
    }
    
    return $Object
}

function Get-SafeDateTime {
    <#
    .SYNOPSIS
    Safe DateTime conversion that handles various input types and prevents exceptions
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $DateTimeObject
    )
    
    try {
        if ($null -eq $DateTimeObject) {
            Write-Warning "Get-SafeDateTime: Null DateTime object provided"
            return $null
        }
        
        # Handle different input types
        if ($DateTimeObject -is [DateTime]) {
            return $DateTimeObject
        }
        
        if ($DateTimeObject -is [string]) {
            $parsedDate = $null
            if ([DateTime]::TryParse($DateTimeObject, [ref]$parsedDate)) {
                return $parsedDate
            } else {
                Write-Warning "Get-SafeDateTime: Failed to parse string '$DateTimeObject' as DateTime"
                return $null
            }
        }
        
        # Try to convert using DateTime constructor
        $convertedDate = [DateTime]$DateTimeObject
        return $convertedDate
        
    } catch {
        Write-Warning "Get-SafeDateTime: Exception converting DateTime: $($_.Exception.Message)"
        return $null
    }
}

function Get-UptimeMinutes {
    <#
    .SYNOPSIS
    Calculate uptime in minutes with proper error handling and type safety
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $StartTime
    )
    
    try {
        # Get current time as ticks only - avoid DateTime object operations
        $currentTicks = [long](Get-Date).Ticks
        
        # Convert StartTime to DateTime safely and extract ticks
        $startDateTime = Get-SafeDateTime -DateTimeObject $StartTime
        if ($null -eq $startDateTime) {
            return 0.0
        }
        
        $startTicks = [long]$startDateTime.Ticks
        
        # Calculate difference using only arithmetic (no DateTime operations)
        # Force explicit conversion to [long] to avoid type ambiguity
        if ([long]$currentTicks -ge [long]$startTicks) {
            $ticksDifference = [long]$currentTicks - [long]$startTicks
            # Convert ticks to minutes: 1 tick = 100 nanoseconds, 1 minute = 600,000,000 ticks
            $uptimeMinutes = [double]([long]$ticksDifference / 600000000.0)
            
            return [double]$uptimeMinutes
        } else {
            return 0.0
        }
        
    } catch {
        Write-Warning "Get-UptimeMinutes: Exception occurred: $($_.Exception.Message)"
        return 0.0
    }
}

function Write-EnhancedStateLog {
    <#
    .SYNOPSIS
    Enhanced logging with multiple output methods and performance tracking
    #>
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARNING", "ERROR", "DEBUG", "PERFORMANCE", "INTERVENTION")]
        [string]$Level = "INFO",
        [string]$Component = "Enhanced-StateTracker",
        [hashtable]$AdditionalData = @{}
    )
    
    # Get configuration from StateConfiguration module
    $stateConfig = Get-EnhancedStateConfig
    if (-not $stateConfig) {
        Write-Warning "StateConfiguration not available, using default logging"
        Write-Host "[$Level] [$Component] $Message"
        return
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logEntry = "[$timestamp] [$Level] [$Component] $Message"
    
    # Add additional data if provided
    if ($AdditionalData.Count -gt 0) {
        $dataJson = $AdditionalData | ConvertTo-Json -Compress
        $logEntry += " | Data: $dataJson"
    }
    
    # Console output with colors
    $color = switch ($Level) {
        "INFO" { "White" }
        "WARNING" { "Yellow" }
        "ERROR" { "Red" }
        "DEBUG" { "Gray" }
        "PERFORMANCE" { "Cyan" }
        "INTERVENTION" { "Magenta" }
    }
    
    if ($Level -ne "DEBUG" -or $stateConfig.VerboseLogging) {
        Write-Host $logEntry -ForegroundColor $color
    }
    
    # File logging based on level
    $logFile = switch ($Level) {
        "PERFORMANCE" { $stateConfig.PerformanceLogFile }
        "INTERVENTION" { $stateConfig.InterventionLogFile }
        default { $stateConfig.LogFile }
    }
    
    try {
        $logEntry | Out-File -FilePath (Join-Path $stateConfig.StateDataPath $logFile) -Append -Encoding UTF8
    } catch {
        Write-Warning "Failed to write to log file: $($_.Exception.Message)"
    }
    
    # Event log for critical items
    if ($Level -in @("ERROR", "INTERVENTION") -and $stateConfig.NotificationMethods -contains "Event") {
        try {
            Write-EventLog -LogName Application -Source "Unity-Claude-Automation" -EventId 1001 -EntryType Information -Message $logEntry
        } catch {
            # Event source may not exist, ignore for now
        }
    }
}

function Get-SystemPerformanceMetrics {
    <#
    .SYNOPSIS
    Collect comprehensive system performance metrics using Get-Counter
    #>
    [CmdletBinding()]
    param()
    
    try {
        $metrics = @{}
        $timestamp = Get-Date
        
        # Get performance counters configuration
        $performanceCounters = Get-PerformanceCounters
        if (-not $performanceCounters) {
            Write-Warning "Performance counters configuration not available"
            return @{}
        }
        
        # Get state configuration for thresholds
        $stateConfig = Get-EnhancedStateConfig
        
        # Collect all performance counters in one operation for efficiency
        $counterPaths = $performanceCounters.Values | ForEach-Object { $_.CounterPath }
        $counterData = Get-Counter -Counter $counterPaths -ErrorAction SilentlyContinue
        
        foreach ($counter in $performanceCounters.GetEnumerator()) {
            $counterName = $counter.Key
            $counterConfig = $counter.Value
            
            $counterValue = $counterData.CounterSamples | Where-Object { $_.Path -like "*$($counterConfig.CounterPath.Split('\')[-1])*" } | Select-Object -First 1
            
            if ($counterValue) {
                $value = [math]::Round($counterValue.CookedValue, 2)
                $status = "Normal"
                
                if ($value -ge $counterConfig.ThresholdCritical) {
                    $status = "Critical"
                } elseif ($value -ge $counterConfig.ThresholdWarning) {
                    $status = "Warning"
                }
                
                $metrics[$counterName] = @{
                    Value = $value
                    Unit = $counterConfig.Unit
                    Status = $status
                    Timestamp = $timestamp
                    ThresholdWarning = $counterConfig.ThresholdWarning
                    ThresholdCritical = $counterConfig.ThresholdCritical
                }
            }
        }
        
        # Add PowerShell-specific metrics if state config available
        if ($stateConfig) {
            $psProcess = Get-Process -Id $PID
            $metrics["PowerShellMemory"] = @{
                Value = [math]::Round($psProcess.WorkingSet64 / 1MB, 2)
                Unit = "MB"
                Status = if ($psProcess.WorkingSet64 / 1MB -gt $stateConfig.MaxMemoryUsageMB) { "Warning" } else { "Normal" }
                Timestamp = $timestamp
            }
            
            $metrics["PowerShellCPU"] = @{
                Value = [math]::Round($psProcess.CPU, 2)
                Unit = "Seconds"
                Status = "Normal"
                Timestamp = $timestamp
            }
        }
        
        return $metrics
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to collect performance metrics: $($_.Exception.Message)" -Level "ERROR"
        return @{}
    }
}

function Test-SystemHealthThresholds {
    <#
    .SYNOPSIS
    Test system health against configured thresholds and trigger interventions if needed
    #>
    [CmdletBinding()]
    param(
        [hashtable]$PerformanceMetrics
    )
    
    $healthIssues = @()
    $criticalIssues = @()
    
    foreach ($metric in $PerformanceMetrics.GetEnumerator()) {
        $metricName = $metric.Key
        $metricData = $metric.Value
        
        if ($metricData.Status -eq "Critical") {
            $criticalIssues += "$metricName is critical: $($metricData.Value) $($metricData.Unit)"
        } elseif ($metricData.Status -eq "Warning") {
            $healthIssues += "$metricName is elevated: $($metricData.Value) $($metricData.Unit)"
        }
    }
    
    return @{
        HealthIssues = $healthIssues
        CriticalIssues = $criticalIssues
        RequiresIntervention = $criticalIssues.Count -gt 0
        RequiresAttention = $healthIssues.Count -gt 0
    }
}

# Export functions
Export-ModuleMember -Function @(
    'ConvertTo-HashTable',
    'Get-SafeDateTime',
    'Get-UptimeMinutes',
    'Write-EnhancedStateLog',
    'Get-SystemPerformanceMetrics',
    'Test-SystemHealthThresholds'
)

#endregion