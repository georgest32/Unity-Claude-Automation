# StateMachineCore.psm1
# Core state machine functions for autonomous state tracking
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: State machine core functions (400 lines)

#region State Machine Core Functions

function Initialize-EnhancedAutonomousStateTracking {
    <#
    .SYNOPSIS
    Initialize enhanced autonomous state tracking with persistence and recovery
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [string]$InitialState = "Idle",
        
        [switch]$RestoreFromCheckpoint
    )
    
    try {
        Write-EnhancedStateLog -Message "Initializing enhanced autonomous state tracking for agent: $AgentId" -Level "INFO"
        
        # Get state configurations
        $stateConfig = Get-EnhancedStateConfig
        $autonomousStates = Get-EnhancedAutonomousStates
        
        # Create agent state structure with proper DateTime handling
        $currentTime = Get-Date
        $agentState = @{
            AgentId = $AgentId
            CurrentState = $InitialState
            PreviousState = $null
            StateHistory = @()
            StartTime = $currentTime
            LastStateChange = $currentTime
            LastHealthCheck = $currentTime
            HealthMetrics = @{}
            InterventionHistory = @()
            CheckpointHistory = @()
            ConsecutiveFailures = 0
            SuccessfulOperations = 0
            TotalOperations = 0
            CircuitBreakerState = "Closed"
            HumanInterventionRequested = $false
            PerformanceBaseline = @{}
        }
        
        # Attempt to restore from checkpoint if requested
        if ($RestoreFromCheckpoint) {
            $restored = Restore-AgentStateFromCheckpoint -AgentId $AgentId
            if ($restored) {
                $agentState = $restored
                Write-EnhancedStateLog -Message "Agent state restored from checkpoint" -Level "INFO"
            }
        }
        
        # Validate initial state
        if (-not $autonomousStates.ContainsKey($agentState.CurrentState)) {
            throw "Invalid initial state: $($agentState.CurrentState)"
        }
        
        # Save initial state
        Save-AgentState -AgentState $agentState
        
        # Create initial checkpoint
        New-StateCheckpoint -AgentState $agentState -Reason "Initial state tracking initialization"
        
        Write-EnhancedStateLog -Message "Enhanced autonomous state tracking initialized successfully" -Level "INFO" -AdditionalData @{
            AgentId = $AgentId
            InitialState = $agentState.CurrentState
            RestoreRequested = $RestoreFromCheckpoint.IsPresent
        }
        
        return $agentState
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to initialize enhanced state tracking: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Set-EnhancedAutonomousState {
    <#
    .SYNOPSIS
    Set autonomous agent state with enhanced validation and persistence
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [Parameter(Mandatory = $true)]
        [string]$NewState,
        
        [string]$Reason = "State transition",
        
        [hashtable]$AdditionalData = @{},
        
        [switch]$Force
    )
    
    try {
        # Get configurations
        $stateConfig = Get-EnhancedStateConfig
        $autonomousStates = Get-EnhancedAutonomousStates
        
        # Load current agent state
        $agentState = Get-AgentState -AgentId $AgentId
        if (-not $agentState) {
            throw "Agent state not found for AgentId: $AgentId"
        }
        
        $currentState = $agentState.CurrentState
        
        # Validate state transition unless forced
        if (-not $Force) {
            $allowedTransitions = $autonomousStates[$currentState].AllowedTransitions
            if ($NewState -notin $allowedTransitions) {
                throw "Invalid state transition from '$currentState' to '$NewState'. Allowed transitions: $($allowedTransitions -join ', ')"
            }
        }
        
        # Validate new state exists
        if (-not $autonomousStates.ContainsKey($NewState)) {
            throw "Invalid state: $NewState"
        }
        
        Write-EnhancedStateLog -Message "State transition: $currentState -> $NewState | Reason: $Reason" -Level "INFO" -AdditionalData $AdditionalData
        
        # Update agent state with proper DateTime handling
        $changeTime = Get-Date
        $agentState.PreviousState = $currentState
        $agentState.CurrentState = $NewState
        $agentState.LastStateChange = $changeTime
        
        # Add to state history
        $stateTransition = @{
            FromState = $currentState
            ToState = $NewState
            Timestamp = $changeTime
            Reason = $Reason
            AdditionalData = $AdditionalData
            Forced = $Force.IsPresent
        }
        
        $agentState.StateHistory = @($agentState.StateHistory) + @($stateTransition)
        
        # Trim state history if needed
        if ($agentState.StateHistory.Count -gt $stateConfig.StateHistoryRetention) {
            $agentState.StateHistory = $agentState.StateHistory | Select-Object -Last $stateConfig.StateHistoryRetention
        }
        
        # Handle special state transitions
        switch ($NewState) {
            "Error" {
                $agentState.ConsecutiveFailures++
                
                # Check for circuit breaker activation
                if ($agentState.ConsecutiveFailures -ge $stateConfig.CircuitBreakerFailureThreshold -and 
                    $agentState.CircuitBreakerState -eq "Closed") {
                    
                    Write-EnhancedStateLog -Message "Circuit breaker opened due to consecutive failures: $($agentState.ConsecutiveFailures)" -Level "WARNING"
                    $agentState.CircuitBreakerState = "Open"
                    $NewState = "CircuitBreakerOpen"  # Override the state to circuit breaker
                    
                    # Request human intervention for circuit breaker
                    Request-HumanIntervention -AgentId $AgentId -Reason "Circuit breaker activated" -Priority "High"
                }
            }
            "Active" {
                if ($agentState.PreviousState -eq "Error" -or $agentState.PreviousState -eq "Recovering") {
                    $agentState.ConsecutiveFailures = 0  # Reset failure count on successful recovery
                    $agentState.CircuitBreakerState = "Closed"
                }
                $agentState.SuccessfulOperations++
            }
            "HumanApprovalRequired" {
                Request-HumanIntervention -AgentId $AgentId -Reason $Reason -Priority "Medium"
            }
        }
        
        $agentState.TotalOperations++
        
        # Save updated state
        Save-AgentState -AgentState $agentState
        
        # Create checkpoint for critical state changes
        if ($NewState -in @("Error", "CircuitBreakerOpen", "HumanApprovalRequired", "Stopped")) {
            New-StateCheckpoint -AgentState $agentState -Reason "Critical state change: $NewState"
        }
        
        return $agentState
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to set autonomous state: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-EnhancedAutonomousState {
    <#
    .SYNOPSIS
    Get current autonomous agent state with enhanced information
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [switch]$IncludeHistory,
        
        [switch]$IncludePerformanceMetrics
    )
    
    try {
        $agentState = Get-AgentState -AgentId $AgentId
        if (-not $agentState) {
            return $null
        }
        
        # Get autonomous states configuration
        $autonomousStates = Get-EnhancedAutonomousStates
        
        # Calculate current success rate
        $successRate = if ($agentState.TotalOperations -gt 0) {
            [math]::Round($agentState.SuccessfulOperations / $agentState.TotalOperations, 3)
        } else {
            0
        }
        
        # Get current state definition
        $stateDefinition = $autonomousStates[$agentState.CurrentState]
        
        # Build response object
        $response = @{
            AgentId = $agentState.AgentId
            CurrentState = $agentState.CurrentState
            PreviousState = $agentState.PreviousState
            StateDescription = $stateDefinition.Description
            IsOperational = $stateDefinition.IsOperational
            RequiresMonitoring = $stateDefinition.RequiresMonitoring
            HumanInterventionRequired = $stateDefinition.HumanInterventionRequired
            LastStateChange = $agentState.LastStateChange
            UptimeMinutes = if ($agentState.StartTime) { 
                [math]::Round((Get-UptimeMinutes -StartTime $agentState.StartTime), 2) 
            } else { 
                0.0 
            }
            SuccessRate = $successRate
            ConsecutiveFailures = $agentState.ConsecutiveFailures
            TotalOperations = $agentState.TotalOperations
            CircuitBreakerState = $agentState.CircuitBreakerState
            HumanInterventionRequested = $agentState.HumanInterventionRequested
        }
        
        # Add history if requested
        if ($IncludeHistory) {
            $response.StateHistory = $agentState.StateHistory | Select-Object -Last 20
            $response.InterventionHistory = $agentState.InterventionHistory | Select-Object -Last 10
        }
        
        # Add performance metrics if requested
        if ($IncludePerformanceMetrics) {
            $response.CurrentPerformanceMetrics = Get-SystemPerformanceMetrics
            $response.HealthMetrics = $agentState.HealthMetrics
        }
        
        return $response
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to get autonomous state: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Save-AgentState {
    <#
    .SYNOPSIS
    Save agent state to JSON with backup rotation
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AgentState
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        $agentId = $AgentState.AgentId
        $stateFile = Join-Path $stateConfig.StateDataPath "$agentId.json"
        
        # Create backup of existing state
        if (Test-Path $stateFile) {
            $backupFile = Join-Path $stateConfig.BackupPath "$agentId-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
            Copy-Item $stateFile $backupFile -ErrorAction SilentlyContinue
        }
        
        # Save current state
        $AgentState | ConvertTo-Json -Depth 10 | Out-File -FilePath $stateFile -Encoding UTF8
        
        Write-EnhancedStateLog -Message "Agent state saved successfully" -Level "DEBUG" -AdditionalData @{ AgentId = $agentId }
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to save agent state: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-AgentState {
    <#
    .SYNOPSIS
    Load agent state from JSON
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        $stateFile = Join-Path $stateConfig.StateDataPath "$AgentId.json"
        
        if (-not (Test-Path $stateFile)) {
            return $null
        }
        
        $stateJson = Get-Content $stateFile -Raw
        $agentState = ConvertTo-HashTable -Object ($stateJson | ConvertFrom-Json) -Recurse
        
        return $agentState
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to load agent state: $($_.Exception.Message)" -Level "ERROR"
        return $null
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Initialize-EnhancedAutonomousStateTracking',
    'Set-EnhancedAutonomousState',
    'Get-EnhancedAutonomousState',
    'Save-AgentState',
    'Get-AgentState'
)

#endregion