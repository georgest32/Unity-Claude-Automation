# HumanIntervention.psm1
# Human intervention system for autonomous state tracking
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: Human intervention system (240 lines)

#region Human Intervention System

function Request-HumanIntervention {
    <#
    .SYNOPSIS
    Request human intervention with multiple notification methods
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AgentId,
        
        [Parameter(Mandatory = $true)]
        [string]$Reason,
        
        [ValidateSet("Low", "Medium", "High", "Critical")]
        [string]$Priority = "Medium",
        
        [hashtable]$Context = @{}
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        
        $timestamp = Get-Date
        $interventionId = New-Guid | Select-Object -ExpandProperty Guid
        
        # Create intervention record
        $intervention = @{
            InterventionId = $interventionId
            AgentId = $AgentId
            Timestamp = $timestamp
            Reason = $Reason
            Priority = $Priority
            Context = $Context
            Status = "Requested"
            ResponseDeadline = $timestamp.AddSeconds($stateConfig.HumanApprovalTimeout)
            ResolutionTime = $null
            Response = $null
        }
        
        # Update agent state
        $agentState = Get-AgentState -AgentId $AgentId
        if ($agentState) {
            $agentState.HumanInterventionRequested = $true
            $agentState.InterventionHistory = @($agentState.InterventionHistory) + @($intervention)
            Save-AgentState -AgentState $agentState
        }
        
        # Log intervention request
        Write-EnhancedStateLog -Message "Human intervention requested: $Reason" -Level "INTERVENTION" -AdditionalData @{
            InterventionId = $interventionId
            Priority = $Priority
            AgentId = $AgentId
        }
        
        # Send notifications based on configuration
        foreach ($method in $stateConfig.NotificationMethods) {
            switch ($method) {
                "Console" {
                    $message = @"
[HUMAN INTERVENTION REQUIRED]
Agent: $AgentId
Priority: $Priority
Reason: $Reason
Intervention ID: $interventionId
Response required by: $($intervention.ResponseDeadline)

Actions available:
- Use 'Approve-AgentIntervention -InterventionId $interventionId' to approve
- Use 'Deny-AgentIntervention -InterventionId $interventionId -Reason "explanation"' to deny
- Use 'Get-PendingInterventions -AgentId $AgentId' to view all pending interventions
"@
                    Write-Host $message -ForegroundColor Yellow -BackgroundColor DarkRed
                }
                "File" {
                    $interventionFile = Join-Path $stateConfig.StateDataPath "pending_interventions.json"
                    $existingInterventions = if (Test-Path $interventionFile) {
                        $existingData = ConvertTo-HashTable -Object (Get-Content $interventionFile -Raw | ConvertFrom-Json) -Recurse
                        if ($existingData -is [Array]) { $existingData } else { @() }
                    } else {
                        @()
                    }
                    $existingInterventions = @($existingInterventions) + @($intervention)
                    $existingInterventions | ConvertTo-Json -Depth 10 | Out-File -FilePath $interventionFile -Encoding UTF8
                }
            }
        }
        
        return $interventionId
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to request human intervention: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Approve-AgentIntervention {
    <#
    .SYNOPSIS
    Approve a pending human intervention request
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$InterventionId,
        
        [string]$Response = "Approved",
        
        [string]$NextAction = "Continue"
    )
    
    try {
        # Find and update intervention
        $updated = Update-InterventionStatus -InterventionId $InterventionId -Status "Approved" -Response $Response
        
        if ($updated) {
            Write-EnhancedStateLog -Message "Human intervention approved: $InterventionId" -Level "INTERVENTION" -AdditionalData @{
                Response = $Response
                NextAction = $NextAction
            }
            
            # Update agent state to clear intervention flag
            $agentState = Get-AgentState -AgentId $updated.AgentId
            if ($agentState) {
                $agentState.HumanInterventionRequested = $false
                Save-AgentState -AgentState $agentState
                
                # Transition to appropriate state based on next action
                switch ($NextAction) {
                    "Continue" { 
                        if ($agentState.CurrentState -ne "Active") {
                            Set-EnhancedAutonomousState -AgentId $updated.AgentId -NewState "Active" -Reason "Human intervention approved"
                        }
                    }
                    "Pause" { Set-EnhancedAutonomousState -AgentId $updated.AgentId -NewState "Paused" -Reason "Human intervention approved - paused" }
                    "Stop" { Set-EnhancedAutonomousState -AgentId $updated.AgentId -NewState "Stopped" -Reason "Human intervention approved - stopped" }
                }
            }
            
            return $true
        }
        
        return $false
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to approve intervention: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Deny-AgentIntervention {
    <#
    .SYNOPSIS
    Deny a pending human intervention request
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$InterventionId,
        
        [Parameter(Mandatory = $true)]
        [string]$Reason
    )
    
    try {
        $updated = Update-InterventionStatus -InterventionId $InterventionId -Status "Denied" -Response $Reason
        
        if ($updated) {
            Write-EnhancedStateLog -Message "Human intervention denied: $InterventionId" -Level "INTERVENTION" -AdditionalData @{
                Reason = $Reason
            }
            
            # Update agent state
            $agentState = Get-AgentState -AgentId $updated.AgentId
            if ($agentState) {
                $agentState.HumanInterventionRequested = $false
                Save-AgentState -AgentState $agentState
                
                # Transition to paused state for manual resolution
                Set-EnhancedAutonomousState -AgentId $updated.AgentId -NewState "Paused" -Reason "Human intervention denied: $Reason"
            }
            
            return $true
        }
        
        return $false
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to deny intervention: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Update-InterventionStatus {
    <#
    .SYNOPSIS
    Update intervention status in persistent storage
    #>
    [CmdletBinding()]
    param(
        [string]$InterventionId,
        [string]$Status,
        [string]$Response
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        $interventionFile = Join-Path $stateConfig.StateDataPath "pending_interventions.json"
        
        if (-not (Test-Path $interventionFile)) {
            return $null
        }
        
        $interventionsData = ConvertTo-HashTable -Object (Get-Content $interventionFile -Raw | ConvertFrom-Json) -Recurse
        $interventions = if ($interventionsData -is [Array]) { $interventionsData } else { @($interventionsData) }
        $targetIntervention = $interventions | Where-Object { $_.InterventionId -eq $InterventionId }
        
        if ($targetIntervention) {
            $targetIntervention.Status = $Status
            $targetIntervention.Response = $Response
            $targetIntervention.ResolutionTime = Get-Date
            
            # Save updated interventions
            $interventions | ConvertTo-Json -Depth 10 | Out-File -FilePath $interventionFile -Encoding UTF8
            
            return $targetIntervention
        }
        
        return $null
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to update intervention status: $($_.Exception.Message)" -Level "ERROR"
        return $null
    }
}

function Get-PendingInterventions {
    <#
    .SYNOPSIS
    Get all pending intervention requests
    #>
    [CmdletBinding()]
    param(
        [string]$AgentId
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        $interventionFile = Join-Path $stateConfig.StateDataPath "pending_interventions.json"
        
        if (-not (Test-Path $interventionFile)) {
            return @()
        }
        
        $interventionsData = ConvertTo-HashTable -Object (Get-Content $interventionFile -Raw | ConvertFrom-Json) -Recurse
        $interventions = if ($interventionsData -is [Array]) { $interventionsData } else { @($interventionsData) }
        
        # Filter by agent if specified
        if ($AgentId) {
            $interventions = $interventions | Where-Object { $_.AgentId -eq $AgentId }
        }
        
        # Filter to only pending (not resolved) interventions
        $pending = $interventions | Where-Object { $_.Status -eq "Requested" }
        
        return $pending
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to get pending interventions: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
}

function Clear-ResolvedInterventions {
    <#
    .SYNOPSIS
    Clean up resolved intervention requests from pending file
    #>
    [CmdletBinding()]
    param(
        [int]$OlderThanDays = 7
    )
    
    try {
        $stateConfig = Get-EnhancedStateConfig
        $interventionFile = Join-Path $stateConfig.StateDataPath "pending_interventions.json"
        
        if (-not (Test-Path $interventionFile)) {
            return 0
        }
        
        $interventionsData = ConvertTo-HashTable -Object (Get-Content $interventionFile -Raw | ConvertFrom-Json) -Recurse
        $interventions = if ($interventionsData -is [Array]) { $interventionsData } else { @($interventionsData) }
        
        $cutoffDate = (Get-Date).AddDays(-$OlderThanDays)
        
        # Keep only recent or unresolved interventions
        $filteredInterventions = $interventions | Where-Object {
            $interventionDate = [DateTime]$_.Timestamp
            $_.Status -eq "Requested" -or $interventionDate -gt $cutoffDate
        }
        
        $removedCount = $interventions.Count - $filteredInterventions.Count
        
        if ($removedCount -gt 0) {
            # Save filtered interventions
            $filteredInterventions | ConvertTo-Json -Depth 10 | Out-File -FilePath $interventionFile -Encoding UTF8
            
            Write-EnhancedStateLog -Message "Cleaned up $removedCount resolved interventions older than $OlderThanDays days" -Level "INFO"
        }
        
        return $removedCount
        
    } catch {
        Write-EnhancedStateLog -Message "Failed to clear resolved interventions: $($_.Exception.Message)" -Level "ERROR"
        return 0
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Request-HumanIntervention',
    'Approve-AgentIntervention',
    'Deny-AgentIntervention',
    'Update-InterventionStatus',
    'Get-PendingInterventions',
    'Clear-ResolvedInterventions'
)

#endregion