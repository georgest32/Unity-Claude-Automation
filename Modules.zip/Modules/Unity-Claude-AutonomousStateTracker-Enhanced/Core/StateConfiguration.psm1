# StateConfiguration.psm1
# Enhanced autonomous operation configuration and state definitions
# Refactored component from Unity-Claude-AutonomousStateTracker-Enhanced.psm1
# Component: Configuration and state definitions (220 lines)

#region Module Configuration and Enhanced Dependencies

$ErrorActionPreference = "Stop"

Write-Host "[StateConfiguration] Loading autonomous state configuration..." -ForegroundColor Cyan

# Enhanced state tracking configuration based on research findings
$script:EnhancedStateConfig = @{
    # Core state management paths
    StateDataPath = Join-Path $PSScriptRoot "..\..\..\..\SessionData\States"
    CheckpointPath = Join-Path $PSScriptRoot "..\..\..\..\SessionData\Checkpoints"
    HealthDataPath = Join-Path $PSScriptRoot "..\..\..\..\SessionData\Health"
    BackupPath = Join-Path $PSScriptRoot "..\..\..\..\SessionData\Backups"
    
    # State persistence settings (based on research)
    StateHistoryRetention = 2000
    CheckpointIntervalMinutes = 5     # Create checkpoints every 5 minutes
    BackupRetentionDays = 7
    IncrementalCheckpoints = $true    # Research finding: minimize checkpoint cost
    
    # Performance monitoring (Get-Counter integration)
    HealthCheckIntervalSeconds = 15   # More frequent for real-time monitoring
    PerformanceCounterInterval = 30   # Performance counter sampling
    MetricsCollectionIntervalSeconds = 60
    AlertThresholdMinutes = 3         # Faster alerts for autonomous operation
    CriticalThresholdMinutes = 10
    
    # Human intervention triggers (research-based thresholds)
    MaxConsecutiveFailures = 3        # Lower threshold for faster intervention
    MaxCycleTimeMinutes = 8           # Tighter cycle time monitoring
    MinSuccessRate = 0.75             # 75% success rate minimum
    MaxMemoryUsageMB = 800           # Higher threshold for complex operations
    MaxCpuPercentage = 70            # Conservative CPU usage
    
    # Performance counter thresholds (research findings)
    CriticalMemoryPercentage = 85
    CriticalDiskSpaceGB = 5
    NetworkLatencyThresholdMs = 1000
    
    # Circuit breaker enhancements
    CircuitBreakerFailureThreshold = 2  # More sensitive
    CircuitBreakerTimeoutMinutes = 5     # Faster recovery attempts
    CircuitBreakerRecoveryAttempts = 5   # More recovery attempts
    
    # Human intervention configuration
    HumanApprovalTimeout = 300        # 5 minutes for human response
    EscalationEnabled = $true
    NotificationMethods = @("Console", "File", "Event")  # Multiple notification methods
    
    # Logging enhancements
    VerboseLogging = $true
    LogFile = "autonomous_state_tracker_enhanced.log"
    PerformanceLogFile = "performance_metrics.log"
    InterventionLogFile = "human_interventions.log"
}

function Get-EnhancedStateConfig {
    <#
    .SYNOPSIS
    Get the enhanced state configuration
    #>
    return $script:EnhancedStateConfig
}

function Initialize-StateDirectories {
    <#
    .SYNOPSIS
    Ensure all required state directories exist
    #>
    [CmdletBinding()]
    param()
    
    # Ensure all directories exist
    foreach ($path in @($script:EnhancedStateConfig.StateDataPath, $script:EnhancedStateConfig.CheckpointPath, 
                       $script:EnhancedStateConfig.HealthDataPath, $script:EnhancedStateConfig.BackupPath)) {
        if (-not (Test-Path $path)) {
            New-Item -Path $path -ItemType Directory -Force | Out-Null
        }
    }
}

# Enhanced autonomous operation states (building on Day 14 implementation)
$script:EnhancedAutonomousStates = @{
    "Idle" = @{
        Description = "Agent is idle, awaiting triggers or initialization"
        AllowedTransitions = @("Initializing", "Stopped", "Error")
        IsOperational = $false
        RequiresMonitoring = $false
        HumanInterventionRequired = $false
        HealthCheckLevel = "Minimal"
    }
    "Initializing" = @{
        Description = "Agent is initializing components and performing startup checks"
        AllowedTransitions = @("Active", "Error", "Stopped")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Standard"
    }
    "Active" = @{
        Description = "Agent is actively managing autonomous feedback loops"
        AllowedTransitions = @("Monitoring", "Processing", "Paused", "Error", "Stopped")
        IsOperational = $true
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Comprehensive"
    }
    "Monitoring" = @{
        Description = "Agent is monitoring Claude responses and system state"
        AllowedTransitions = @("Processing", "Active", "Paused", "Error", "Stopped")
        IsOperational = $true
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Comprehensive"
    }
    "Processing" = @{
        Description = "Agent is processing responses and executing safe commands"
        AllowedTransitions = @("Generating", "Active", "Error", "Stopped", "HumanApprovalRequired")
        IsOperational = $true
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Intensive"
    }
    "Generating" = @{
        Description = "Agent is generating intelligent follow-up prompts"
        AllowedTransitions = @("Submitting", "Active", "Error", "Stopped")
        IsOperational = $true
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Standard"
    }
    "Submitting" = @{
        Description = "Agent is submitting prompts to Claude Code CLI"
        AllowedTransitions = @("Monitoring", "Active", "Error", "Stopped")
        IsOperational = $true
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Standard"
    }
    "Paused" = @{
        Description = "Agent is paused, awaiting human intervention"
        AllowedTransitions = @("Active", "Stopped", "Error")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $true
        HealthCheckLevel = "Minimal"
    }
    "HumanApprovalRequired" = @{
        Description = "Agent requires human approval for high-impact operations"
        AllowedTransitions = @("Processing", "Active", "Paused", "Error", "Stopped")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $true
        HealthCheckLevel = "Standard"
    }
    "Error" = @{
        Description = "Agent encountered an error and requires attention"
        AllowedTransitions = @("Recovering", "Stopped", "Idle", "HumanApprovalRequired")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Diagnostic"
    }
    "Recovering" = @{
        Description = "Agent is attempting autonomous recovery from error state"
        AllowedTransitions = @("Active", "Error", "Stopped", "HumanApprovalRequired")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $false
        HealthCheckLevel = "Intensive"
    }
    "CircuitBreakerOpen" = @{
        Description = "Circuit breaker activated due to repeated failures"
        AllowedTransitions = @("Recovering", "Stopped", "HumanApprovalRequired")
        IsOperational = $false
        RequiresMonitoring = $true
        HumanInterventionRequired = $true
        HealthCheckLevel = "Diagnostic"
    }
    "Stopped" = @{
        Description = "Agent has been safely stopped"
        AllowedTransitions = @("Idle", "Initializing")
        IsOperational = $false
        RequiresMonitoring = $false
        HumanInterventionRequired = $false
        HealthCheckLevel = "None"
    }
}

function Get-EnhancedAutonomousStates {
    <#
    .SYNOPSIS
    Get the enhanced autonomous states configuration
    #>
    return $script:EnhancedAutonomousStates
}

# Performance counter definitions (based on research findings)
$script:PerformanceCounters = @{
    "CPU" = @{
        CounterPath = "\Processor(_Total)\% Processor Time"
        ThresholdWarning = 60
        ThresholdCritical = 80
        Unit = "Percentage"
    }
    "Memory" = @{
        CounterPath = "\Memory\% Committed Bytes In Use"
        ThresholdWarning = 70
        ThresholdCritical = 85
        Unit = "Percentage"
    }
    "DiskSpace" = @{
        CounterPath = "\LogicalDisk(C:)\% Free Space"
        ThresholdWarning = 15
        ThresholdCritical = 10
        Unit = "Percentage"
    }
    "ProcessCount" = @{
        CounterPath = "\System\Processes"
        ThresholdWarning = 200
        ThresholdCritical = 300
        Unit = "Count"
    }
}

function Get-PerformanceCounters {
    <#
    .SYNOPSIS
    Get the performance counters configuration
    #>
    return $script:PerformanceCounters
}

# Initialize directories on module load
Initialize-StateDirectories

# Export functions
Export-ModuleMember -Function @(
    'Get-EnhancedStateConfig',
    'Initialize-StateDirectories', 
    'Get-EnhancedAutonomousStates',
    'Get-PerformanceCounters'
)

#endregion