# Unity-Claude-PredictiveAnalysis Core Component
# Core initialization, cache management, and shared utilities
# Part of refactored PredictiveAnalysis module

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Module-level script variables
$script:PredictionCache = $null
$script:MetricsHistory = @{}
$script:PredictionModels = @{}
$script:ModuleConfig = @{}

function Initialize-PredictiveCache {
    <#
    .SYNOPSIS
    Initializes the predictive analysis cache system
    .DESCRIPTION
    Sets up caching for predictions, metrics history, and prediction models
    .PARAMETER MaxSizeMB
    Maximum cache size in megabytes
    .PARAMETER TTLMinutes  
    Time to live for cache entries in minutes
    .EXAMPLE
    Initialize-PredictiveCache -MaxSizeMB 100 -TTLMinutes 60
    #>
    [CmdletBinding()]
    param(
        [int]$MaxSizeMB = 100,
        [int]$TTLMinutes = 60
    )
    
    Write-Verbose "Initializing predictive analysis cache..."
    
    try {
        $script:PredictionCache = New-CacheManager -MaxSize $MaxSizeMB
        
        # Initialize metric history storage
        $script:MetricsHistory = @{
            CodeChurn = @{}
            Complexity = @{}
            Coverage = @{}
            BugReports = @{}
            LastUpdated = Get-Date
        }
        
        # Initialize prediction models
        $script:PredictionModels = @{
            MaintenanceModel = @{
                Weights = @{
                    Complexity = 0.3
                    Churn = 0.25
                    Coverage = 0.15
                    Age = 0.1
                    Dependencies = 0.2
                }
            }
            SmellModel = @{
                Thresholds = @{
                    MethodLength = 50
                    ClassSize = 500
                    CyclomaticComplexity = 10
                    CouplingScore = 7
                    DuplicationRatio = 0.05
                }
            }
        }
        
        # Initialize module configuration
        $script:ModuleConfig = @{
            DefaultDaysBack = 30
            MaxHotspots = 10
            CacheEnabled = $true
            VerboseLogging = $false
        }
        
        Write-Verbose "Predictive cache initialized successfully"
        return $true
    }
    catch {
        Write-Error "Failed to initialize predictive cache: $_"
        return $false
    }
}

function Get-PredictiveConfig {
    <#
    .SYNOPSIS
    Gets the current predictive analysis configuration
    .DESCRIPTION
    Returns the module configuration settings
    .EXAMPLE
    Get-PredictiveConfig
    #>
    [CmdletBinding()]
    param()
    
    return $script:ModuleConfig.Clone()
}

function Set-PredictiveConfig {
    <#
    .SYNOPSIS
    Updates predictive analysis configuration
    .DESCRIPTION
    Modifies module configuration settings
    .PARAMETER DefaultDaysBack
    Default number of days to look back in analysis
    .PARAMETER MaxHotspots
    Maximum number of hotspots to return
    .PARAMETER CacheEnabled
    Enable or disable caching
    .PARAMETER VerboseLogging
    Enable verbose logging
    .EXAMPLE
    Set-PredictiveConfig -DefaultDaysBack 60 -CacheEnabled $true
    #>
    [CmdletBinding()]
    param(
        [int]$DefaultDaysBack,
        [int]$MaxHotspots,
        [bool]$CacheEnabled,
        [bool]$VerboseLogging
    )
    
    if ($PSBoundParameters.ContainsKey('DefaultDaysBack')) {
        $script:ModuleConfig.DefaultDaysBack = $DefaultDaysBack
    }
    if ($PSBoundParameters.ContainsKey('MaxHotspots')) {
        $script:ModuleConfig.MaxHotspots = $MaxHotspots
    }
    if ($PSBoundParameters.ContainsKey('CacheEnabled')) {
        $script:ModuleConfig.CacheEnabled = $CacheEnabled
    }
    if ($PSBoundParameters.ContainsKey('VerboseLogging')) {
        $script:ModuleConfig.VerboseLogging = $VerboseLogging
    }
    
    Write-Verbose "Predictive configuration updated"
}

function Get-CacheItem {
    <#
    .SYNOPSIS
    Retrieves an item from the prediction cache
    .DESCRIPTION
    Gets a cached prediction result if available
    .PARAMETER Key
    Cache key to retrieve
    .EXAMPLE
    Get-CacheItem -Key "evolution_project_30_Weekly"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Key
    )
    
    if (-not $script:ModuleConfig.CacheEnabled -or -not $script:PredictionCache) {
        return $null
    }
    
    try {
        return $script:PredictionCache.Get($Key)
    }
    catch {
        Write-Verbose "Cache retrieval failed for key '$Key': $_"
        return $null
    }
}

function Set-CacheItem {
    <#
    .SYNOPSIS
    Stores an item in the prediction cache
    .DESCRIPTION
    Caches a prediction result for future use
    .PARAMETER Key
    Cache key to store under
    .PARAMETER Value
    Value to cache
    .PARAMETER TTLMinutes
    Time to live in minutes (optional)
    .EXAMPLE
    Set-CacheItem -Key "evolution_project_30_Weekly" -Value $result
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Key,
        
        [Parameter(Mandatory)]
        $Value,
        
        [int]$TTLMinutes = 60
    )
    
    if (-not $script:ModuleConfig.CacheEnabled -or -not $script:PredictionCache) {
        return
    }
    
    try {
        $script:PredictionCache.Set($Key, $Value, $TTLMinutes)
        Write-Verbose "Cached item with key '$Key'"
    }
    catch {
        Write-Verbose "Cache storage failed for key '$Key': $_"
    }
}

function Clear-PredictiveCache {
    <#
    .SYNOPSIS
    Clears the predictive analysis cache
    .DESCRIPTION
    Removes all cached prediction results
    .EXAMPLE
    Clear-PredictiveCache
    #>
    [CmdletBinding()]
    param()
    
    if ($script:PredictionCache) {
        $script:PredictionCache.Clear()
        Write-Verbose "Predictive cache cleared"
    }
}

function New-CacheManager {
    <#
    .SYNOPSIS
    Creates a simple cache manager
    .DESCRIPTION
    Creates a basic in-memory cache with TTL support
    .PARAMETER MaxSize
    Maximum cache size in MB
    .EXAMPLE
    $cache = New-CacheManager -MaxSize 100
    #>
    [CmdletBinding()]
    param(
        [int]$MaxSize = 100
    )
    
    $cache = @{
        Data = @{}
        MaxSize = $MaxSize
    }
    
    # Add methods
    $cache | Add-Member -MemberType ScriptMethod -Name "Get" -Value {
        param($key)
        $item = $this.Data[$key]
        if ($item -and $item.Expires -gt (Get-Date)) {
            return $item.Value
        }
        $this.Data.Remove($key)
        return $null
    }
    
    $cache | Add-Member -MemberType ScriptMethod -Name "Set" -Value {
        param($key, $value, $ttlMinutes)
        $expires = (Get-Date).AddMinutes($ttlMinutes)
        $this.Data[$key] = @{
            Value = $value
            Expires = $expires
        }
    }
    
    $cache | Add-Member -MemberType ScriptMethod -Name "Clear" -Value {
        $this.Data = @{}
    }
    
    return $cache
}

# Export functions
Export-ModuleMember -Function @(
    'Initialize-PredictiveCache',
    'Get-PredictiveConfig',
    'Set-PredictiveConfig',
    'Get-CacheItem',
    'Set-CacheItem', 
    'Clear-PredictiveCache',
    'New-CacheManager'
)

Write-Verbose "PredictiveCore component loaded successfully"