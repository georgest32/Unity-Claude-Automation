# Unity-Claude-IntegratedWorkflow Dependency Management Component
# Handles module dependencies and validation
# Part of refactored IntegratedWorkflow module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "WorkflowCore.psm1"
Import-Module $CorePath -Force

# Module dependency tracking
$script:RequiredModulesAvailable = @{}
$script:WriteModuleLogAvailable = $false

# Dependency validation function
function Test-ModuleDependencyAvailability {
    param(
        [string[]]$RequiredModules,
        [string]$ModuleName = "Unknown"
    )
    
    $missingModules = @()
    foreach ($reqModule in $RequiredModules) {
        $module = Get-Module $reqModule -ErrorAction SilentlyContinue
        if (-not $module) {
            $missingModules += $reqModule
        }
    }
    
    if ($missingModules.Count -gt 0) {
        Write-Warning "[$ModuleName] Missing required modules: $($missingModules -join ', '). Import them explicitly before using this module."
        return $false
    }
    
    return $true
}

# Initialize required modules
function Initialize-RequiredModules {
    param(
        [string]$ModulesPath
    )
    
    if (-not $ModulesPath) {
        $ModulesPath = Split-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) -Parent | Join-Path -ChildPath "Modules"
    }
    
    # Load RunspaceManagement module
    try {
        $RunspaceManagementPath = Join-Path $ModulesPath "Unity-Claude-RunspaceManagement"
        if (-not (Get-Module Unity-Claude-RunspaceManagement -ErrorAction SilentlyContinue)) {
            Import-Module $RunspaceManagementPath -ErrorAction Stop
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Loaded Unity-Claude-RunspaceManagement module" -Level "DEBUG"
        } else {
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Unity-Claude-RunspaceManagement already loaded, preserving state" -Level "DEBUG"
        }
        $script:RequiredModulesAvailable['RunspaceManagement'] = $true
        $script:WriteModuleLogAvailable = $true
    } catch {
        Write-Warning "Failed to import Unity-Claude-RunspaceManagement: $($_.Exception.Message)"
        $script:RequiredModulesAvailable['RunspaceManagement'] = $false
    }
    
    # Load UnityParallelization module
    try {
        $UnityParallelizationPath = Join-Path $ModulesPath "Unity-Claude-UnityParallelization"
        if (-not (Get-Module Unity-Claude-UnityParallelization -ErrorAction SilentlyContinue)) {
            Import-Module $UnityParallelizationPath -ErrorAction Stop
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Loaded Unity-Claude-UnityParallelization module" -Level "DEBUG"
        } else {
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Unity-Claude-UnityParallelization already loaded, PRESERVING REGISTRATION STATE" -Level "DEBUG"
        }
        $script:RequiredModulesAvailable['UnityParallelization'] = $true
    } catch {
        Write-Warning "Failed to import Unity-Claude-UnityParallelization: $($_.Exception.Message)"
        $script:RequiredModulesAvailable['UnityParallelization'] = $false
    }
    
    # Load ClaudeParallelization module
    try {
        $ClaudeParallelizationPath = Join-Path $ModulesPath "Unity-Claude-ClaudeParallelization"
        if (-not (Get-Module Unity-Claude-ClaudeParallelization -ErrorAction SilentlyContinue)) {
            Import-Module $ClaudeParallelizationPath -ErrorAction Stop
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Loaded Unity-Claude-ClaudeParallelization module" -Level "DEBUG"
        } else {
            Write-IntegratedWorkflowLog -Message "[StatePreservation] Unity-Claude-ClaudeParallelization already loaded, preserving state" -Level "DEBUG"
        }
        $script:RequiredModulesAvailable['ClaudeParallelization'] = $true
    } catch {
        Write-Warning "Failed to import Unity-Claude-ClaudeParallelization: $($_.Exception.Message)"
        $script:RequiredModulesAvailable['ClaudeParallelization'] = $false
    }
    
    return $script:RequiredModulesAvailable
}

# Comprehensive dependency validation
function Test-ModuleDependencies {
    $totalDependencies = $script:RequiredModulesAvailable.Count
    $loadedDependencies = ($script:RequiredModulesAvailable.Values | Where-Object { $_ -eq $true }).Count
    
    Write-Host "Module Dependencies: $loadedDependencies/$totalDependencies loaded" -ForegroundColor $(if ($loadedDependencies -eq $totalDependencies) { "Green" } else { "Yellow" })
    
    foreach ($dep in $script:RequiredModulesAvailable.GetEnumerator()) {
        $status = if ($dep.Value) { "LOADED" } else { "FAILED" }
        Write-Host "  $($dep.Key): $status" -ForegroundColor $(if ($dep.Value) { "Green" } else { "Red" })
    }
    
    return $loadedDependencies -eq $totalDependencies
}

# Dependency validation helper for functions
function Assert-Dependencies {
    param(
        [string[]]$RequiredDependencies
    )
    
    foreach ($dep in $RequiredDependencies) {
        if (-not $script:RequiredModulesAvailable[$dep]) {
            throw "Required dependency '$dep' is not available. Function cannot execute."
        }
    }
}

# Get module availability status
function Get-ModuleAvailability {
    return $script:RequiredModulesAvailable
}

# Export functions
Export-ModuleMember -Function @(
    'Test-ModuleDependencyAvailability',
    'Initialize-RequiredModules',
    'Test-ModuleDependencies',
    'Assert-Dependencies',
    'Get-ModuleAvailability'
)

Write-IntegratedWorkflowLog -Message "DependencyManagement component loaded successfully" -Level "DEBUG"