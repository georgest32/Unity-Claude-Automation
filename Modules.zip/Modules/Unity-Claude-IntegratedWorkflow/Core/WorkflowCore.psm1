# Unity-Claude-IntegratedWorkflow Core Component
# Core configuration, logging, and shared state management
# Part of refactored IntegratedWorkflow module

$ErrorActionPreference = "Stop"

# Module-level variables for integrated workflow
$script:IntegratedWorkflowState = @{
    ActiveWorkflows = [hashtable]::Synchronized(@{})
    WorkflowScheduler = [System.Collections.ArrayList]::Synchronized(@())
    CrossStageErrors = [System.Collections.ArrayList]::Synchronized(@())
    PerformanceMetrics = [hashtable]::Synchronized(@{})
    SharedResources = [hashtable]::Synchronized(@{})
}

# Fallback logging function
function Write-FallbackLog {
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [string]$Component = "IntegratedWorkflow"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logMessage = "[$timestamp] [$Level] [$Component] $Message"
    
    switch ($Level) {
        "ERROR" { Write-Host $logMessage -ForegroundColor Red }
        "WARNING" { Write-Host $logMessage -ForegroundColor Yellow }
        "DEBUG" { Write-Host $logMessage -ForegroundColor Gray }
        default { Write-Host $logMessage -ForegroundColor White }
    }
    
    # Write to centralized log
    Add-Content -Path ".\unity_claude_automation.log" -Value $logMessage -ErrorAction SilentlyContinue
}

# Wrapper function for logging with fallback
function Write-IntegratedWorkflowLog {
    param(
        [string]$Message,
        [string]$Level = "INFO", 
        [string]$Component = "IntegratedWorkflow"
    )
    
    Write-FallbackLog -Message "[$Level] [$Component] $Message" -Level $Level -Component $Component
    
    # Debug logging for troubleshooting
    if ($Level -eq "DEBUG") {
        Write-Verbose "IntegratedWorkflow Debug: $Message" -Verbose
    }
}

# Get module state
function Get-IntegratedWorkflowState {
    return $script:IntegratedWorkflowState
}

# Export functions
Export-ModuleMember -Function @(
    'Write-FallbackLog',
    'Write-IntegratedWorkflowLog',
    'Get-IntegratedWorkflowState'
)

Write-IntegratedWorkflowLog -Message "WorkflowCore component loaded successfully" -Level "DEBUG"
