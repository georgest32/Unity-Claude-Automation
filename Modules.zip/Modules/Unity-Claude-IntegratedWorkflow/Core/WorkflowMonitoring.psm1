# Unity-Claude-IntegratedWorkflow Monitoring Component  
# Workflow status and monitoring functions
# Part of refactored IntegratedWorkflow module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "WorkflowCore.psm1"
Import-Module $CorePath -Force

<#
.SYNOPSIS
Gets the status and performance metrics of an integrated workflow
.DESCRIPTION
Returns comprehensive status information about workflow stages, performance, and health
.PARAMETER IntegratedWorkflow
The integrated workflow object to query
.PARAMETER IncludeDetailedMetrics
Include detailed performance metrics for each stage
.EXAMPLE
$status = Get-IntegratedWorkflowStatus -IntegratedWorkflow $workflow -IncludeDetailedMetrics
#>
function Get-IntegratedWorkflowStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$IntegratedWorkflow,
        [switch]$IncludeDetailedMetrics
    )
    
    try {
        $workflowName = $IntegratedWorkflow.WorkflowName
        Write-IntegratedWorkflowLog -Message "Getting status for integrated workflow '$workflowName'..." -Level "DEBUG"
        
        # Get current orchestration status
        $orchestrationStatus = 'Stopped'
        $orchestrationDuration = 0
        
        if ($IntegratedWorkflow.ContainsKey('OrchestrationJob') -and $IntegratedWorkflow.OrchestrationJob) {
            if ($IntegratedWorkflow.OrchestrationJob.AsyncResult.IsCompleted) {
                $orchestrationStatus = 'Completed'
            } else {
                $orchestrationStatus = 'Running'
            }
            
            $orchestrationDuration = ((Get-Date) - $IntegratedWorkflow.OrchestrationJob.StartTime).TotalSeconds
        }
        
        # Build status summary
        $workflowStatus = @{
            WorkflowName = $workflowName
            OverallStatus = $IntegratedWorkflow.Status
            OrchestrationStatus = $orchestrationStatus
            OrchestrationDuration = $orchestrationDuration
            CreatedTime = $IntegratedWorkflow.Created
            LastUpdate = Get-Date
            
            # Component status
            Components = @{
                UnityMonitor = @{
                    Status = if ($IntegratedWorkflow.UnityMonitor) { 'Available' } else { 'Not Available' }
                    MaxConcurrentProjects = $IntegratedWorkflow.MaxUnityProjects
                }
                ClaudeSubmitter = @{
                    Status = if ($IntegratedWorkflow.ClaudeSubmitter) { 'Available' } else { 'Not Available' }
                    MaxConcurrentSubmissions = $IntegratedWorkflow.MaxClaudeSubmissions
                }
                OrchestrationPool = @{
                    Status = $IntegratedWorkflow.OrchestrationPool.Status
                    MaxRunspaces = $IntegratedWorkflow.OrchestrationPool.MaxRunspaces
                }
            }
            
            # Workflow stage status
            StageStatus = $IntegratedWorkflow.WorkflowState.WorkflowStages
            
            # Queue lengths (current work)
            Queues = @{
                UnityErrors = $IntegratedWorkflow.WorkflowState.UnityErrorQueue.Count
                ClaudePrompts = $IntegratedWorkflow.WorkflowState.ClaudePromptQueue.Count
                ClaudeResponses = $IntegratedWorkflow.WorkflowState.ClaudeResponseQueue.Count
                Fixes = $IntegratedWorkflow.WorkflowState.FixQueue.Count
                ActiveJobs = $IntegratedWorkflow.WorkflowState.ActiveJobs.Count
                CompletedJobs = $IntegratedWorkflow.WorkflowState.CompletedJobs.Count
                FailedJobs = $IntegratedWorkflow.WorkflowState.FailedJobs.Count
            }
            
            # Workflow metrics
            Metrics = $IntegratedWorkflow.WorkflowState.WorkflowMetrics
            
            # Health status
            Health = $IntegratedWorkflow.HealthStatus
        }
        
        # Add detailed performance metrics if requested
        if ($IncludeDetailedMetrics) {
            $workflowStatus.DetailedMetrics = @{
                StagePerformance = $IntegratedWorkflow.WorkflowState.StagePerformance
                ResourceUsage = $IntegratedWorkflow.WorkflowState.ResourceUsage
                ErrorHistory = $IntegratedWorkflow.WorkflowState.CrossStageErrors
            }
        }
        
        Write-IntegratedWorkflowLog -Message "Status retrieved for workflow '$workflowName': $orchestrationStatus ($($orchestrationDuration)s)" -Level "DEBUG"
        
        return $workflowStatus
        
    } catch {
        Write-IntegratedWorkflowLog -Message "Failed to get workflow status: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

<#
.SYNOPSIS
Stops an integrated workflow and cleans up resources
.DESCRIPTION
Gracefully stops workflow orchestration and disposes of all resources
.PARAMETER IntegratedWorkflow
The integrated workflow object to stop
.PARAMETER WaitForCompletion
Wait for current operations to complete before stopping
.PARAMETER TimeoutSeconds
Maximum time to wait for graceful shutdown
.EXAMPLE
Stop-IntegratedWorkflow -IntegratedWorkflow $workflow -WaitForCompletion -TimeoutSeconds 60
#>
function Stop-IntegratedWorkflow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$IntegratedWorkflow,
        [switch]$WaitForCompletion,
        [int]$TimeoutSeconds = 30
    )
    
    $workflowName = $IntegratedWorkflow.WorkflowName
    Write-IntegratedWorkflowLog -Message "Stopping integrated workflow '$workflowName'..." -Level "INFO"
    
    try {
        $stopStartTime = Get-Date
        
        # Stop orchestration job if running
        if ($IntegratedWorkflow.ContainsKey('OrchestrationJob') -and $IntegratedWorkflow.OrchestrationJob) {
            Write-IntegratedWorkflowLog -Message "Stopping workflow orchestration job..." -Level "DEBUG"
            
            if (-not $IntegratedWorkflow.OrchestrationJob.AsyncResult.IsCompleted) {
                if ($WaitForCompletion) {
                    Write-IntegratedWorkflowLog -Message "Waiting for orchestration job to complete (timeout: $TimeoutSeconds seconds)..." -Level "DEBUG"
                    
                    $waitStart = Get-Date
                    while (-not $IntegratedWorkflow.OrchestrationJob.AsyncResult.IsCompleted) {
                        if (((Get-Date) - $waitStart).TotalSeconds -ge $TimeoutSeconds) {
                            Write-IntegratedWorkflowLog -Message "Timeout waiting for orchestration job completion" -Level "WARNING"
                            break
                        }
                        Start-Sleep -Milliseconds 500
                    }
                }
                
                # Force stop if still running
                if (-not $IntegratedWorkflow.OrchestrationJob.AsyncResult.IsCompleted) {
                    Write-IntegratedWorkflowLog -Message "Force stopping orchestration job..." -Level "WARNING"
                    try {
                        $IntegratedWorkflow.OrchestrationJob.PowerShell.Stop()
                    } catch {
                        Write-IntegratedWorkflowLog -Message "Error force stopping job: $($_.Exception.Message)" -Level "WARNING"
                    }
                }
            }
            
            # Collect final results and dispose
            try {
                if ($IntegratedWorkflow.OrchestrationJob.AsyncResult.IsCompleted) {
                    $result = $IntegratedWorkflow.OrchestrationJob.PowerShell.EndInvoke($IntegratedWorkflow.OrchestrationJob.AsyncResult)
                    Write-IntegratedWorkflowLog -Message "Orchestration job result: $result" -Level "DEBUG"
                }
                $IntegratedWorkflow.OrchestrationJob.PowerShell.Dispose()
            } catch {
                Write-IntegratedWorkflowLog -Message "Error disposing orchestration job: $($_.Exception.Message)" -Level "WARNING"
            }
            
            $IntegratedWorkflow.Remove('OrchestrationJob')
        }
        
        # Close runspace pools
        Write-IntegratedWorkflowLog -Message "Closing orchestration runspace pool..." -Level "DEBUG"
        if ($IntegratedWorkflow.OrchestrationPool.Status -eq 'Open') {
            Close-RunspacePool -PoolManager $IntegratedWorkflow.OrchestrationPool | Out-Null
        }
        
        # Stop Unity monitoring
        if ($IntegratedWorkflow.UnityMonitor) {
            Write-IntegratedWorkflowLog -Message "Stopping Unity parallel monitoring..." -Level "DEBUG"
            try {
                Stop-UnityParallelMonitoring -UnityMonitor $IntegratedWorkflow.UnityMonitor | Out-Null
            } catch {
                Write-IntegratedWorkflowLog -Message "Error stopping Unity monitoring: $($_.Exception.Message)" -Level "WARNING"
            }
        }
        
        # Close Claude submitter resources
        if ($IntegratedWorkflow.ClaudeSubmitter -and $IntegratedWorkflow.ClaudeSubmitter.RunspacePool) {
            Write-IntegratedWorkflowLog -Message "Closing Claude submitter runspace pool..." -Level "DEBUG"
            try {
                Close-RunspacePool -PoolManager $IntegratedWorkflow.ClaudeSubmitter.RunspacePool | Out-Null
            } catch {
                Write-IntegratedWorkflowLog -Message "Error closing Claude submitter: $($_.Exception.Message)" -Level "WARNING"
            }
        }
        
        # Update workflow status
        $IntegratedWorkflow.Status = 'Stopped'
        $IntegratedWorkflow.WorkflowState.WorkflowStages.UnityMonitoring.Status = 'Stopped'
        $IntegratedWorkflow.WorkflowState.WorkflowStages.ErrorProcessing.Status = 'Stopped'
        $IntegratedWorkflow.WorkflowState.WorkflowStages.ClaudeSubmission.Status = 'Stopped'
        $IntegratedWorkflow.WorkflowState.WorkflowStages.ResponseProcessing.Status = 'Stopped'
        $IntegratedWorkflow.WorkflowState.WorkflowStages.FixApplication.Status = 'Stopped'
        
        # Calculate final statistics
        $stopDuration = ((Get-Date) - $stopStartTime).TotalMilliseconds
        $IntegratedWorkflow.Statistics.WorkflowsCompleted++
        
        # Remove from module tracking
        $workflowState = Get-IntegratedWorkflowState
        if ($workflowState.ActiveWorkflows.ContainsKey($workflowName)) {
            $workflowState.ActiveWorkflows.Remove($workflowName)
        }
        
        Write-IntegratedWorkflowLog -Message "Integrated workflow '$workflowName' stopped successfully (shutdown time: ${stopDuration}ms)" -Level "INFO"
        
        return @{
            Success = $true
            Message = "Workflow stopped successfully"
            WorkflowName = $workflowName
            ShutdownDuration = $stopDuration
            FinalMetrics = $IntegratedWorkflow.WorkflowState.WorkflowMetrics
        }
        
    } catch {
        Write-IntegratedWorkflowLog -Message "Failed to stop integrated workflow '$workflowName': $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Get-IntegratedWorkflowStatus',
    'Stop-IntegratedWorkflow'
)

Write-IntegratedWorkflowLog -Message "WorkflowMonitoring component loaded successfully" -Level "DEBUG"