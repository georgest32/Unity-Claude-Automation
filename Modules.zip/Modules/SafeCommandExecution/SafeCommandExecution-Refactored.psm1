#Requires -Version 5.1
<#
.SYNOPSIS
    SafeCommandExecution - Refactored modular security framework.

.DESCRIPTION
    Main orchestrator module for safe command execution with constrained runspaces,
    comprehensive validation, and Unity automation support. This refactored version
    replaces the monolithic 2860-line SafeCommandExecution.psm1 with 10 focused,
    maintainable components organized in the Core/ subdirectory.

.NOTES
    Refactored Architecture (2025-08-25):
    - SafeCommandCore.psm1 (~180 lines) - Configuration and logging
    - RunspaceManagement.psm1 (~150 lines) - Constrained runspace creation
    - ValidationEngine.psm1 (~280 lines) - Security validation
    - CommandExecution.psm1 (~220 lines) - Command execution orchestration
    - CommandTypeHandlers.psm1 (~320 lines) - Command type implementations
    - UnityBuildOperations.psm1 (~500 lines) - Unity build functions
    - UnityProjectOperations.psm1 (~384 lines) - Project validation & compilation
    - UnityLogAnalysis.psm1 (~310 lines) - Log analysis functions
    - UnityPerformanceAnalysis.psm1 (~308 lines) - Performance analysis
    - UnityReportingOperations.psm1 (~497 lines) - Reporting and metrics
    
    Total: ~3149 lines across 10 components (avg ~315 lines each)
    Original: 2860 lines in single file
    Complexity Reduction: ~89% per component
#>

# === REFACTORING DEBUG LOG ===
Write-Host "✅ LOADING REFACTORED VERSION: SafeCommandExecution-Refactored.psm1 with 10 modular components" -ForegroundColor Green
Write-Host "📦 Components: Core, Runspace, Validation, Execution, Handlers, Unity Build/Project/Analysis/Performance/Reporting" -ForegroundColor Cyan

#region Module Configuration and Dependencies

# Component loading path
$script:ComponentPath = Join-Path $PSScriptRoot "Core"

# Required component modules in dependency order
$script:RequiredComponents = @(
    'SafeCommandCore',           # Must load first - provides configuration and logging
    'RunspaceManagement',        # Constrained runspace creation
    'ValidationEngine',          # Security validation
    'CommandExecution',          # Command execution orchestration
    'CommandTypeHandlers',       # Command type implementations
    'UnityBuildOperations',      # Unity build functions
    'UnityProjectOperations',    # Project validation & compilation  
    'UnityLogAnalysis',          # Log analysis functions
    'UnityPerformanceAnalysis',  # Performance analysis
    'UnityReportingOperations'   # Reporting and metrics
)

# Load all component modules
$loadedCount = 0
foreach ($component in $script:RequiredComponents) {
    $componentFile = Join-Path $script:ComponentPath "$component.psm1"
    if (Test-Path $componentFile) {
        try {
            Import-Module $componentFile -Force -Global
            Write-Host "Loaded component: $component" -ForegroundColor Green
            $loadedCount++
        }
        catch {
            Write-Warning "Failed to load component $component : $_"
        }
    } else {
        Write-Warning "Component not found: $componentFile"
    }
}

Write-Host "Successfully loaded $loadedCount/$($script:RequiredComponents.Count) components" -ForegroundColor $(if ($loadedCount -eq $script:RequiredComponents.Count) { 'Green' } else { 'Yellow' })

#endregion

#region Core Orchestrator Functions

function Initialize-SafeCommandExecution {
    <#
    .SYNOPSIS
    Initializes the complete safe command execution system.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [hashtable]$Configuration = @{},
        
        [Parameter()]
        [string[]]$AllowedPaths = @(),
        
        [Parameter()]
        [switch]$Force
    )
    
    Write-Host "Initializing Safe Command Execution (Refactored Version)" -ForegroundColor Cyan
    
    try {
        # Initialize core configuration
        if ($Configuration.Count -gt 0) {
            Set-SafeCommandConfig @Configuration
        }
        
        # Set allowed paths if provided
        if ($AllowedPaths.Count -gt 0) {
            Set-SafeCommandConfig -AllowedPaths $AllowedPaths
        }
        
        # Test initialization
        $initTest = Test-SafeCommandInitialization
        if (-not $initTest.IsInitialized -and -not $Force) {
            throw "Initialization failed: $($initTest.Issues -join ', ')"
        }
        
        Write-SafeLog -Message "Safe Command Execution initialized successfully" -Level "Info"
        
        return @{
            Success = $true
            ComponentsLoaded = $loadedCount
            Configuration = Get-SafeCommandConfig
            InitializationTime = Get-Date
        }
    }
    catch {
        Write-SafeLog -Message "Safe Command Execution initialization failed: $_" -Level "Error"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-SafeCommandStatus {
    <#
    .SYNOPSIS
    Gets comprehensive status of the safe command execution system.
    #>
    [CmdletBinding()]
    param()
    
    try {
        $config = Get-SafeCommandConfig
        $stats = Get-CommandExecutionStatistics
        
        return @{
            Configuration = $config
            Statistics = $stats
            ComponentsLoaded = $loadedCount
            Architecture = @{
                ComponentsCount = $script:RequiredComponents.Count
                RefactoredVersion = $true
                OriginalFileSize = "2860 lines"
                RefactoredTotalSize = "~3149 lines across 10 components"
                ComplexityReduction = "~89% per component"
            }
            StatusTime = Get-Date
        }
    }
    catch {
        Write-SafeLog -Message "Error getting safe command status: $_" -Level "Error"
        return @{
            Error = $_.Exception.Message
            StatusTime = Get-Date
        }
    }
}

function Test-SafeCommandIntegration {
    <#
    .SYNOPSIS
    Performs comprehensive integration testing across all components.
    #>
    [CmdletBinding()]
    param()
    
    Write-SafeLog -Message "Testing Safe Command Execution integration" -Level "Info"
    
    $testResults = @{
        ComponentTests = @()
        OverallStatus = "UNKNOWN"
        TestTime = Get-Date
    }
    
    try {
        # Test core initialization
        $initTest = Test-SafeCommandInitialization
        $testResults.ComponentTests += @{
            Component = "SafeCommandCore"
            Result = $initTest
        }
        
        # Test runspace creation
        try {
            $runspace = New-ConstrainedRunspace
            if ($runspace) {
                Remove-ConstrainedRunspace -Runspace $runspace
                $testResults.ComponentTests += @{
                    Component = "RunspaceManagement"
                    Result = @{ IsInitialized = $true }
                }
            }
        }
        catch {
            $testResults.ComponentTests += @{
                Component = "RunspaceManagement"
                Result = @{ IsInitialized = $false; Issues = @($_.Exception.Message) }
            }
        }
        
        # Test validation engine
        $validationTest = Test-CommandSafety -Command @{
            CommandType = 'Test'
            Arguments = 'Get-Date'
        }
        $testResults.ComponentTests += @{
            Component = "ValidationEngine"
            Result = @{ IsInitialized = $validationTest.IsSafe }
        }
        
        # Calculate overall status
        $passedTests = ($testResults.ComponentTests | Where-Object { $_.Result.IsInitialized }).Count
        $totalTests = $testResults.ComponentTests.Count
        
        if ($passedTests -eq $totalTests) {
            $testResults.OverallStatus = "PASS"
        } elseif ($passedTests -gt 0) {
            $testResults.OverallStatus = "PARTIAL"
        } else {
            $testResults.OverallStatus = "FAIL"
        }
        
        Write-SafeLog -Message "Safe Command integration test: $($testResults.OverallStatus) ($passedTests/$totalTests components passed)" -Level "Info"
        
        return $testResults
    }
    catch {
        Write-SafeLog -Message "Error during safe command integration test: $_" -Level "Error"
        $testResults.OverallStatus = "ERROR"
        $testResults.Error = $_.Exception.Message
        return $testResults
    }
}

#endregion

#region Module Exports

# Export all functions from component modules
Export-ModuleMember -Function @(
    # Main orchestrator functions
    'Initialize-SafeCommandExecution',
    'Get-SafeCommandStatus',
    'Test-SafeCommandIntegration',
    
    # Core functions (from SafeCommandCore.psm1)
    'Write-SafeLog',
    'Get-SafeCommandConfig',
    'Set-SafeCommandConfig',
    'Test-SafeCommandInitialization',
    
    # Runspace functions (from RunspaceManagement.psm1)
    'New-ConstrainedRunspace',
    'Remove-ConstrainedRunspace',
    'Test-RunspaceHealth',
    
    # Validation functions (from ValidationEngine.psm1)
    'Test-CommandSafety',
    'Test-PathSafety',
    'Remove-DangerousCharacters',
    'Test-InputValidity',
    
    # Execution functions (from CommandExecution.psm1)
    'Invoke-SafeCommand',
    'Test-ExecutionResult',
    'Get-CommandExecutionStatistics',
    
    # Command type handlers (from CommandTypeHandlers.psm1)
    'Invoke-UnityCommand',
    'Invoke-TestCommand',
    'Invoke-PowerShellCommand',
    'Invoke-BuildCommand',
    'Invoke-AnalysisCommand',
    
    # Unity build operations (from UnityBuildOperations.psm1)
    'Invoke-UnityPlayerBuild',
    'New-UnityBuildScript',
    'Test-UnityBuildResult',
    'Invoke-UnityAssetImport',
    'New-UnityAssetImportScript',
    'Invoke-UnityCustomMethod',
    
    # Unity project operations (from UnityProjectOperations.psm1)
    'Invoke-UnityProjectValidation',
    'Invoke-UnityScriptCompilation',
    'Test-UnityCompilationResult',
    
    # Unity log analysis (from UnityLogAnalysis.psm1)
    'Invoke-UnityLogAnalysis',
    'Invoke-UnityErrorPatternAnalysis',
    
    # Unity performance analysis (from UnityPerformanceAnalysis.psm1)
    'Invoke-UnityPerformanceAnalysis',
    'Invoke-UnityTrendAnalysis',
    
    # Unity reporting operations (from UnityReportingOperations.psm1)
    'Invoke-UnityReportGeneration',
    'Export-UnityAnalysisData',
    'Get-UnityAnalyticsMetrics',
    
    # Helper functions
    'Find-UnityExecutable',
    'Set-SafeCommandConfiguration',
    'Get-SafeCommandConfiguration'
)

#endregion

# REFACTORING MARKER: This file replaces SafeCommandExecution.psm1 (2860 lines) on 2025-08-25
# New Architecture: 10 modular components in Core/ subdirectory totaling ~3149 lines
# Complexity Reduction: ~89% per component (average 315 lines vs 2860 lines)