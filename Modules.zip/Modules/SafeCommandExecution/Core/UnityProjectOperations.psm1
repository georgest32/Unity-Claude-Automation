#Requires -Version 5.1
<#
.SYNOPSIS
    Unity project validation and compilation operations for SafeCommandExecution module.

.DESCRIPTION
    Provides Unity project structure validation and script compilation
    verification functionality.

.NOTES
    Part of SafeCommandExecution refactored architecture
    Originally from SafeCommandExecution.psm1 (lines 1317-1595)
    Refactoring Date: 2025-08-25
#>

# Import required modules
Import-Module "$PSScriptRoot\SafeCommandCore.psm1" -Force
Import-Module "$PSScriptRoot\ValidationEngine.psm1" -Force

#region Unity Project Validation

function Invoke-UnityProjectValidation {
    <#
    .SYNOPSIS
    Validates Unity project structure and configuration.
    
    .DESCRIPTION
    Performs comprehensive validation of Unity project including
    folder structure, assets, and project settings.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Command,
        
        [Parameter()]
        [int]$TimeoutSeconds = 180
    )
    
    Write-SafeLog "Starting Unity project validation" -Level Info
    
    # Set default project path if not provided
    $projectPath = $Command.Arguments.ProjectPath
    if (-not $projectPath) {
        $projectPath = "C:\UnityProjects\Sound-and-Shoal\Dithering"
        Write-SafeLog "Using default project path: $projectPath" -Level Debug
    }
    
    # Validate project path exists and is safe
    if (-not (Test-PathSafety -Path $projectPath)) {
        throw "Project path is not safe or accessible: $projectPath"
    }
    
    $validation = @{
        ProjectPath = $projectPath
        IsValid = $true
        Issues = @()
        Warnings = @()
        Assets = @{
            Count = 0
            Size = 0
            Types = @{}
        }
        Scripts = @{
            Count = 0
            Size = 0
            CompilationErrors = @()
        }
    }
    
    Write-SafeLog "Validating Unity project at: $projectPath" -Level Debug
    
    try {
        # Check basic project structure
        $requiredFolders = @('Assets', 'ProjectSettings')
        foreach ($folder in $requiredFolders) {
            $folderPath = Join-Path $projectPath $folder
            if (-not (Test-Path $folderPath)) {
                $validation.IsValid = $false
                $validation.Issues += "Missing required folder: $folder"
                Write-SafeLog "Project validation issue: Missing folder $folder" -Level Warning
            }
        }
        
        # Analyze assets if Assets folder exists
        $assetsPath = Join-Path $projectPath "Assets"
        if (Test-Path $assetsPath) {
            $assetFiles = Get-ChildItem $assetsPath -Recurse -File -ErrorAction SilentlyContinue
            $validation.Assets.Count = $assetFiles.Count
            $validation.Assets.Size = ($assetFiles | Measure-Object -Property Length -Sum).Sum
            
            # Group by file extension
            $typeGroups = $assetFiles | Group-Object Extension
            foreach ($group in $typeGroups) {
                $validation.Assets.Types[$group.Name] = $group.Count
            }
            
            Write-SafeLog "Project assets analysis: $($validation.Assets.Count) files, $($validation.Assets.Size) bytes" -Level Debug
            
            # Analyze C# scripts specifically
            $scriptFiles = $assetFiles | Where-Object { $_.Extension -eq '.cs' }
            $validation.Scripts.Count = $scriptFiles.Count
            $validation.Scripts.Size = ($scriptFiles | Measure-Object -Property Length -Sum).Sum
            
            Write-SafeLog "Project scripts analysis: $($validation.Scripts.Count) files, $($validation.Scripts.Size) bytes" -Level Debug
        }
        
        # Check ProjectSettings files
        $projectSettingsPath = Join-Path $projectPath "ProjectSettings"
        if (Test-Path $projectSettingsPath) {
            $requiredSettings = @('ProjectSettings.asset', 'TagManager.asset', 'InputManager.asset')
            foreach ($setting in $requiredSettings) {
                $settingPath = Join-Path $projectSettingsPath $setting
                if (-not (Test-Path $settingPath)) {
                    $validation.Warnings += "Missing project setting: $setting"
                    Write-SafeLog "Project validation warning: Missing setting $setting" -Level Warning
                }
            }
        }
        
        Write-SafeLog "Unity project validation completed. Valid: $($validation.IsValid), Issues: $($validation.Issues.Count)" -Level Info
        
        return @{
            Success = $true
            Output = $validation
            Error = $null
            Validation = $validation
        }
    }
    catch {
        Write-SafeLog "Unity project validation failed: $($_.Exception.Message)" -Level Error
        return @{
            Success = $false
            Output = $null
            Error = $_.ToString()
            Validation = @{
                ProjectPath = $projectPath
                IsValid = $false
                Issues = @("Validation failed: $($_.ToString())")
            }
        }
    }
}

#endregion

#region Unity Script Compilation

function Invoke-UnityScriptCompilation {
    <#
    .SYNOPSIS
    Verifies Unity script compilation status.
    
    .DESCRIPTION
    Executes Unity in batch mode to check for script compilation errors
    and returns detailed compilation results.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Command,
        
        [Parameter()]
        [int]$TimeoutSeconds = 180
    )
    
    Write-SafeLog "Starting Unity script compilation verification" -Level Info
    
    # Set default project path if not provided
    $projectPath = $Command.Arguments.ProjectPath
    if (-not $projectPath) {
        $projectPath = "C:\UnityProjects\Sound-and-Shoal\Dithering"
        Write-SafeLog "Using default project path: $projectPath" -Level Debug
    }
    
    # Validate project path exists and is safe
    if (-not (Test-PathSafety -Path $projectPath)) {
        throw "Project path is not safe or accessible: $projectPath"
    }
    
    # Find Unity executable
    $unityPath = Find-UnityExecutable
    if (-not $unityPath) {
        throw "Unity executable not found"
    }
    
    # Prepare Unity command arguments for compilation check
    $unityArgs = @(
        '-batchmode',
        '-quit',
        '-projectPath', "`"$projectPath`"",
        '-executeMethod', 'UnityEditor.EditorApplication.Exit',
        '-logFile', "$env:TEMP\Unity_Compilation_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    )
    
    Write-SafeLog "Executing Unity script compilation check with arguments: $($unityArgs -join ' ')" -Level Info
    
    try {
        # Execute Unity for compilation check
        $startTime = Get-Date
        $processInfo = Start-Process -FilePath $unityPath `
                                    -ArgumentList $unityArgs `
                                    -NoNewWindow `
                                    -PassThru `
                                    -RedirectStandardOutput "$env:TEMP\unity_compile_output.txt" `
                                    -RedirectStandardError "$env:TEMP\unity_compile_error.txt"
        
        $completed = $processInfo.WaitForExit($TimeoutSeconds * 1000)
        $duration = (Get-Date) - $startTime
        
        if (-not $completed) {
            $processInfo.Kill()
            throw "Unity script compilation check timed out after $TimeoutSeconds seconds"
        }
        
        # Read compilation output and errors
        $output = Get-Content "$env:TEMP\unity_compile_output.txt" -ErrorAction SilentlyContinue
        $errors = Get-Content "$env:TEMP\unity_compile_error.txt" -ErrorAction SilentlyContinue
        $logPath = $unityArgs | Where-Object { $_ -like '*.log' } | Select-Object -First 1
        
        # Analyze compilation result
        $compilationResult = Test-UnityCompilationResult -LogPath $logPath -ProcessExitCode $processInfo.ExitCode
        $compilationResult.Duration = $duration.TotalSeconds
        
        Write-SafeLog "Unity script compilation check completed. Status: $($compilationResult.Status), Duration: $($duration.TotalSeconds)s" -Level Info
        
        if ($errors) {
            Write-SafeLog "Unity compilation check had errors: $($errors -join '; ')" -Level Warning
        }
        
        return @{
            Success = ($compilationResult.Status -eq 'Success')
            Output = $output
            Error = if ($errors) { $errors -join '; ' } else { $null }
            CompilationResult = $compilationResult
        }
    }
    catch {
        Write-SafeLog "Unity script compilation check failed: $($_.Exception.Message)" -Level Error
        return @{
            Success = $false
            Output = $null
            Error = $_.ToString()
            CompilationResult = @{
                Status = 'Failed'
                ErrorMessage = $_.ToString()
                Duration = 0
                Errors = @()
                Warnings = @()
            }
        }
    }
}

function Test-UnityCompilationResult {
    <#
    .SYNOPSIS
    Analyzes Unity compilation log for errors and warnings.
    
    .DESCRIPTION
    Parses Unity log file to extract compilation errors, warnings,
    and determine overall compilation status.
    #>
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]$LogPath,
        
        [Parameter()]
        [int]$ProcessExitCode
    )
    
    Write-SafeLog "Validating Unity compilation result. Exit code: $ProcessExitCode" -Level Debug
    
    $compilationResult = @{
        Status = 'Unknown'
        ErrorMessage = $null
        Errors = @()
        Warnings = @()
        Duration = 0
    }
    
    # Check process exit code first
    if ($ProcessExitCode -ne 0) {
        $compilationResult.Status = 'Failed'
        $compilationResult.ErrorMessage = "Unity process exited with code: $ProcessExitCode"
        Write-SafeLog "Compilation failed - Unity exit code: $ProcessExitCode" -Level Warning
    }
    
    # Parse Unity log if available
    if ($LogPath -and (Test-Path $LogPath)) {
        Write-SafeLog "Parsing Unity compilation log: $LogPath" -Level Debug
        
        $logContent = Get-Content $LogPath -ErrorAction SilentlyContinue
        
        foreach ($line in $logContent) {
            # Look for compilation errors
            if ($line -match 'error CS\d+:') {
                $compilationResult.Errors += $line
                $compilationResult.Status = 'Failed'
                Write-SafeLog "Compilation error detected: $line" -Level Warning
            }
            
            # Look for compilation warnings
            if ($line -match 'warning CS\d+:') {
                $compilationResult.Warnings += $line
                Write-SafeLog "Compilation warning detected: $line" -Level Debug
            }
            
            # Look for successful compilation
            if ($line -match 'Compilation succeeded') {
                if ($compilationResult.Status -ne 'Failed') {
                    $compilationResult.Status = 'Success'
                    Write-SafeLog "Compilation success detected: $line" -Level Debug
                }
            }
        }
    }
    
    # Default to success if no errors detected and exit code is 0
    if ($compilationResult.Status -eq 'Unknown' -and $ProcessExitCode -eq 0) {
        $compilationResult.Status = 'Success'
    }
    
    Write-SafeLog "Compilation result validation complete. Status: $($compilationResult.Status), Errors: $($compilationResult.Errors.Count), Warnings: $($compilationResult.Warnings.Count)" -Level Info
    return $compilationResult
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Invoke-UnityProjectValidation',
    'Invoke-UnityScriptCompilation',
    'Test-UnityCompilationResult'
)

#endregion

# REFACTORING MARKER: This module was refactored from SafeCommandExecution.psm1 on 2025-08-25
# Original file size: 2860 lines
# This component: Unity project validation and compilation (lines 1317-1595, ~384 lines)