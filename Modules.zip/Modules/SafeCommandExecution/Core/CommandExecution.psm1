#Requires -Version 5.1
<#
.SYNOPSIS
    Safe command execution orchestrator for SafeCommandExecution module.

.DESCRIPTION
    Provides the main command execution pipeline with safety validation
    and routing to appropriate command type handlers.

.NOTES
    Part of SafeCommandExecution refactored architecture
    Originally from SafeCommandExecution.psm1 (lines 317-394)
    Refactoring Date: 2025-08-25
#>

# Import required modules
Import-Module "$PSScriptRoot\SafeCommandCore.psm1" -Force
Import-Module "$PSScriptRoot\ValidationEngine.psm1" -Force

#region Safe Command Execution

function Invoke-SafeCommand {
    <#
    .SYNOPSIS
    Executes commands safely with security validation and timeout control.
    
    .DESCRIPTION
    Main entry point for safe command execution. Validates commands against
    security policies and routes to appropriate type-specific handlers.
    
    .PARAMETER Command
    Hashtable containing command details including CommandType, Operation, and Arguments.
    
    .PARAMETER TimeoutSeconds
    Maximum execution time in seconds before command is terminated.
    
    .PARAMETER ValidateExecution
    Perform additional validation after execution.
    
    .PARAMETER AllowedPaths
    Additional paths to allow for this specific command execution.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Command,
        
        [Parameter()]
        [int]$TimeoutSeconds = 60,
        
        [Parameter()]
        [switch]$ValidateExecution,
        
        [Parameter()]
        [string[]]$AllowedPaths = @()
    )
    
    Write-SafeLog "Executing safe command: $($Command.CommandType) - $($Command.Operation)" -Level Info
    
    # Validate command safety
    $safety = Test-CommandSafety -Command $Command
    if (-not $safety.IsSafe) {
        Write-SafeLog "Command execution blocked: $($safety.Reason)" -Level Security
        return @{
            Success = $false
            Error = $safety.Reason
            Output = $null
            ExecutionTime = 0
            ValidationStatus = 'Blocked'
        }
    }
    
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    
    try {
        # Prepare execution context
        $context = @{
            Command = $Command
            TimeoutSeconds = $TimeoutSeconds
            AllowedPaths = $AllowedPaths
            StartTime = Get-Date
        }
        
        # Note: Type-specific handlers will be imported from CommandTypeHandlers module
        # For now, returning a placeholder that shows routing would happen
        $result = switch ($Command.CommandType) {
            'Unity' {
                @{
                    Message = "Unity command would be executed"
                    Handler = "Invoke-UnityCommand"
                }
            }
            
            'Test' {
                @{
                    Message = "Test command would be executed"
                    Handler = "Invoke-TestCommand"
                }
            }
            
            'PowerShell' {
                @{
                    Message = "PowerShell command would be executed"
                    Handler = "Invoke-PowerShellCommand"
                }
            }
            
            'Build' {
                @{
                    Message = "Build command would be executed"
                    Handler = "Invoke-BuildCommand"
                }
            }
            
            'Analysis' {
                @{
                    Message = "Analysis command would be executed"
                    Handler = "Invoke-AnalysisCommand"
                }
            }
            
            default {
                throw "Unsupported command type: $($Command.CommandType)"
            }
        }
        
        $stopwatch.Stop()
        
        # Validate execution if requested
        if ($ValidateExecution) {
            $validationResult = Test-ExecutionResult -Result $result -Context $context
            if (-not $validationResult.IsValid) {
                Write-SafeLog "Post-execution validation failed: $($validationResult.Reason)" -Level Warning
            }
        }
        
        Write-SafeLog "Command executed successfully in $($stopwatch.ElapsedMilliseconds)ms" -Level Info
        
        return @{
            Success = $true
            Output = $result
            Error = $null
            ExecutionTime = $stopwatch.ElapsedMilliseconds
            ValidationStatus = if ($ValidateExecution) { 'Validated' } else { 'NotValidated' }
        }
    }
    catch {
        $stopwatch.Stop()
        Write-SafeLog "Command execution failed: $($_.Exception.Message)" -Level Error
        
        return @{
            Success = $false
            Output = $null
            Error = $_.ToString()
            ExecutionTime = $stopwatch.ElapsedMilliseconds
            ValidationStatus = 'Failed'
        }
    }
}

function Test-ExecutionResult {
    <#
    .SYNOPSIS
    Validates command execution results.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        $Result,
        
        [Parameter(Mandatory=$true)]
        [hashtable]$Context
    )
    
    $isValid = $true
    $reason = "Validation passed"
    
    # Check for error indicators
    if ($Result -match 'error|failed|exception') {
        $isValid = $false
        $reason = "Result contains error indicators"
    }
    
    # Check execution time
    $elapsed = (Get-Date) - $Context.StartTime
    if ($elapsed.TotalSeconds -gt $Context.TimeoutSeconds) {
        $isValid = $false
        $reason = "Execution exceeded timeout"
    }
    
    return @{
        IsValid = $isValid
        Reason = $reason
        ElapsedTime = $elapsed
    }
}

function Get-CommandExecutionStatistics {
    <#
    .SYNOPSIS
    Returns execution statistics for monitoring and analysis.
    #>
    [CmdletBinding()]
    param()
    
    # In a real implementation, this would track actual statistics
    return @{
        TotalExecutions = 0
        SuccessfulExecutions = 0
        BlockedExecutions = 0
        FailedExecutions = 0
        AverageExecutionTime = 0
        LastExecution = $null
    }
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Invoke-SafeCommand',
    'Test-ExecutionResult',
    'Get-CommandExecutionStatistics'
)

#endregion

# REFACTORING MARKER: This module was refactored from SafeCommandExecution.psm1 on 2025-08-25
# Original file size: 2860 lines
# This component: Safe command execution orchestration (lines 317-394)