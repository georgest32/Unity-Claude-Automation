#Requires -Version 5.1
<#
.SYNOPSIS
    Unity log analysis operations for SafeCommandExecution module.

.DESCRIPTION
    Provides Unity Editor.log parsing, error pattern analysis,
    and diagnostic reporting functionality.

.NOTES
    Part of SafeCommandExecution refactored architecture
    Originally from SafeCommandExecution.psm1 (lines 1600-1909)
    Refactoring Date: 2025-08-25
#>

# Import required modules
Import-Module "$PSScriptRoot\SafeCommandCore.psm1" -Force
Import-Module "$PSScriptRoot\ValidationEngine.psm1" -Force

#region Unity Log Analysis

function Invoke-UnityLogAnalysis {
    <#
    .SYNOPSIS
    Analyzes Unity Editor log for errors, warnings, and patterns.
    
    .DESCRIPTION
    Parses Unity log files to extract compilation errors, runtime errors,
    warnings, and other diagnostic information.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Command,
        
        [Parameter()]
        [int]$TimeoutSeconds = 180
    )
    
    Write-SafeLog "Starting Unity log analysis operation" -Level Info
    
    # Set default log path if not provided
    $logPath = $Command.Arguments.LogPath
    if (-not $logPath) {
        # Default Unity Editor.log location for Windows
        $logPath = Join-Path $env:LOCALAPPDATA "Unity\Editor\Editor.log"
        Write-SafeLog "Using default Unity log path: $logPath" -Level Debug
    }
    
    # Validate log path exists and is safe
    if (-not (Test-Path $logPath)) {
        throw "Unity log file not found: $logPath"
    }
    
    if (-not (Test-PathSafety -Path $logPath)) {
        throw "Log path is not safe or accessible: $logPath"
    }
    
    $analysis = @{
        LogPath = $logPath
        ParsedAt = Get-Date
        TotalLines = 0
        Errors = @()
        Warnings = @()
        Info = @()
        ErrorPatterns = @{}
        Summary = @{
            ErrorCount = 0
            WarningCount = 0
            InfoCount = 0
            CompilationErrors = 0
            RuntimeErrors = 0
        }
    }
    
    Write-SafeLog "Analyzing Unity log file: $logPath" -Level Debug
    
    try {
        # Read log file content
        $startTime = Get-Date
        $logContent = Get-Content $logPath -ErrorAction SilentlyContinue
        $analysis.TotalLines = $logContent.Count
        
        Write-SafeLog "Read $($analysis.TotalLines) lines from Unity log" -Level Debug
        
        # Define error patterns for Unity 2021.1.14f1
        $errorPatterns = @{
            'CompilationError' = 'error CS\d+:'
            'CompilationWarning' = 'warning CS\d+:'
            'RuntimeError' = 'Exception|Error:|ArgumentException|NullReferenceException'
            'AssetError' = 'Failed to import|Asset import failed'
            'BuildError' = 'Build failed|BuildPlayerWindow'
        }
        
        # Analyze each line
        foreach ($line in $logContent) {
            $lineAnalysis = @{
                Content = $line
                LineNumber = $logContent.IndexOf($line) + 1
                Timestamp = $null
                Severity = 'Info'
                Category = 'General'
                ErrorCode = $null
                FilePath = $null
            }
            
            # Extract file path and line number if present
            if ($line -match 'Assets/.*\.cs\((\d+),(\d+)\):') {
                $lineAnalysis.FilePath = ($line -split ':')[0]
            }
            
            # Check for compilation errors
            if ($line -match $errorPatterns.CompilationError) {
                $lineAnalysis.Severity = 'Error'
                $lineAnalysis.Category = 'Compilation'
                $analysis.Errors += $lineAnalysis
                $analysis.Summary.CompilationErrors++
                
                # Extract error code
                if ($line -match 'error (CS\d+):') {
                    $lineAnalysis.ErrorCode = $matches[1]
                }
                
                Write-SafeLog "Compilation error detected: $($lineAnalysis.ErrorCode)" -Level Debug
            }
            # Check for compilation warnings
            elseif ($line -match $errorPatterns.CompilationWarning) {
                $lineAnalysis.Severity = 'Warning'
                $lineAnalysis.Category = 'Compilation'
                $analysis.Warnings += $lineAnalysis
                
                Write-SafeLog "Compilation warning detected" -Level Debug
            }
            # Check for runtime errors
            elseif ($line -match $errorPatterns.RuntimeError) {
                $lineAnalysis.Severity = 'Error'
                $lineAnalysis.Category = 'Runtime'
                $analysis.Errors += $lineAnalysis
                $analysis.Summary.RuntimeErrors++
                
                Write-SafeLog "Runtime error detected" -Level Debug
            }
            # Check for asset errors
            elseif ($line -match $errorPatterns.AssetError) {
                $lineAnalysis.Severity = 'Error'
                $lineAnalysis.Category = 'Asset'
                $analysis.Errors += $lineAnalysis
                
                Write-SafeLog "Asset error detected" -Level Debug
            }
            # Check for build errors
            elseif ($line -match $errorPatterns.BuildError) {
                $lineAnalysis.Severity = 'Error'
                $lineAnalysis.Category = 'Build'
                $analysis.Errors += $lineAnalysis
                
                Write-SafeLog "Build error detected" -Level Debug
            }
            else {
                $analysis.Info += $lineAnalysis
            }
        }
        
        # Update summary counts
        $analysis.Summary.ErrorCount = $analysis.Errors.Count
        $analysis.Summary.WarningCount = $analysis.Warnings.Count
        $analysis.Summary.InfoCount = $analysis.Info.Count
        
        $duration = (Get-Date) - $startTime
        
        Write-SafeLog "Unity log analysis completed. Errors: $($analysis.Summary.ErrorCount), Warnings: $($analysis.Summary.WarningCount), Duration: $($duration.TotalSeconds)s" -Level Info
        
        return @{
            Success = $true
            Output = $analysis
            Error = $null
            AnalysisResult = $analysis
            Duration = $duration.TotalSeconds
        }
    }
    catch {
        Write-SafeLog "Unity log analysis failed: $($_.Exception.Message)" -Level Error
        return @{
            Success = $false
            Output = $null
            Error = $_.ToString()
            AnalysisResult = @{
                Status = 'Failed'
                ErrorMessage = $_.ToString()
                Duration = 0
            }
        }
    }
}

#endregion

#region Error Pattern Analysis

function Invoke-UnityErrorPatternAnalysis {
    <#
    .SYNOPSIS
    Analyzes Unity log for specific error patterns and provides solutions.
    
    .DESCRIPTION
    Identifies common Unity error patterns, tracks their frequency,
    and provides recommendations for resolution.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Command,
        
        [Parameter()]
        [int]$TimeoutSeconds = 180
    )
    
    Write-SafeLog "Starting Unity error pattern analysis" -Level Info
    
    # Get log path from command or use default
    $logPath = $Command.Arguments.LogPath
    if (-not $logPath) {
        $logPath = Join-Path $env:LOCALAPPDATA "Unity\Editor\Editor.log"
    }
    
    # Validate log path
    if (-not (Test-Path $logPath)) {
        throw "Unity log file not found: $logPath"
    }
    
    $patternAnalysis = @{
        LogPath = $logPath
        AnalyzedAt = Get-Date
        ErrorPatterns = @{}
        TrendAnalysis = @{}
        FrequencyAnalysis = @{}
        Recommendations = @()
    }
    
    Write-SafeLog "Analyzing error patterns in Unity log: $logPath" -Level Debug
    
    try {
        # Read log content
        $logContent = Get-Content $logPath -ErrorAction SilentlyContinue
        
        # Define specific Unity error patterns with solutions
        $knownPatterns = @{
            'CS0246' = @{
                Pattern = 'error CS0246:.*could not be found'
                Description = 'Type or namespace not found'
                Category = 'Missing Reference'
                Solution = 'Add missing using statement or assembly reference'
                Frequency = 0
            }
            'CS0103' = @{
                Pattern = 'error CS0103:.*does not exist'
                Description = 'Name does not exist in current context'
                Category = 'Scope Issue'
                Solution = 'Check variable declaration and scope'
                Frequency = 0
            }
            'CS1061' = @{
                Pattern = 'error CS1061:.*does not contain a definition'
                Description = 'Member not found on type'
                Category = 'API Issue'
                Solution = 'Check API documentation or add extension method'
                Frequency = 0
            }
            'CS0029' = @{
                Pattern = 'error CS0029:.*Cannot implicitly convert'
                Description = 'Type conversion error'
                Category = 'Type Mismatch'
                Solution = 'Add explicit cast or change variable type'
                Frequency = 0
            }
        }
        
        # Analyze patterns in log
        foreach ($line in $logContent) {
            foreach ($patternName in $knownPatterns.Keys) {
                $pattern = $knownPatterns[$patternName]
                if ($line -match $pattern.Pattern) {
                    $pattern.Frequency++
                    
                    Write-SafeLog "Found error pattern $patternName in log" -Level Debug
                }
            }
        }
        
        # Update pattern analysis
        $patternAnalysis.ErrorPatterns = $knownPatterns
        
        # Generate frequency analysis (PowerShell 5.1 compatible)
        $frequencyValues = @()
        foreach ($pattern in $knownPatterns.Values) {
            $frequencyValues += $pattern.Frequency
        }
        $totalErrors = ($frequencyValues | Measure-Object -Sum).Sum
        foreach ($patternName in $knownPatterns.Keys) {
            $frequency = $knownPatterns[$patternName].Frequency
            $percentage = if ($totalErrors -gt 0) { [math]::Round(($frequency / $totalErrors) * 100, 2) } else { 0 }
            
            $patternAnalysis.FrequencyAnalysis[$patternName] = @{
                Count = $frequency
                Percentage = $percentage
                Description = $knownPatterns[$patternName].Description
            }
        }
        
        # Generate recommendations based on most frequent errors
        $topErrors = $knownPatterns.GetEnumerator() | 
                    Where-Object { $_.Value.Frequency -gt 0 } |
                    Sort-Object { $_.Value.Frequency } -Descending |
                    Select-Object -First 3
        
        foreach ($error in $topErrors) {
            $patternAnalysis.Recommendations += @{
                ErrorType = $error.Key
                Priority = switch ($error.Value.Frequency) {
                    { $_ -ge 10 } { 'High' }
                    { $_ -ge 5 } { 'Medium' }
                    default { 'Low' }
                }
                Description = $error.Value.Description
                Solution = $error.Value.Solution
                Frequency = $error.Value.Frequency
            }
        }
        
        Write-SafeLog "Error pattern analysis completed. Found $totalErrors total errors across $($knownPatterns.Count) pattern types" -Level Info
        
        return @{
            Success = $true
            Output = $patternAnalysis
            Error = $null
            PatternAnalysis = $patternAnalysis
        }
    }
    catch {
        Write-SafeLog "Error pattern analysis failed: $($_.Exception.Message)" -Level Error
        return @{
            Success = $false
            Output = $null
            Error = $_.ToString()
            PatternAnalysis = @{
                Status = 'Failed'
                ErrorMessage = $_.ToString()
            }
        }
    }
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Invoke-UnityLogAnalysis',
    'Invoke-UnityErrorPatternAnalysis'
)

#endregion

# REFACTORING MARKER: This module was refactored from SafeCommandExecution.psm1 on 2025-08-25
# Original file size: 2860 lines
# This component: Unity log analysis operations (lines 1600-1909, ~310 lines)