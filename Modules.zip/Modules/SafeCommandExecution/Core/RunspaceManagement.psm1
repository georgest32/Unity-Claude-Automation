#Requires -Version 5.1
<#
.SYNOPSIS
    Constrained runspace creation and management for SafeCommandExecution module.

.DESCRIPTION
    Provides secure runspace creation with constrained language mode and
    limited command access for safe execution of potentially untrusted code.

.NOTES
    Part of SafeCommandExecution refactored architecture
    Originally from SafeCommandExecution.psm1 (lines 69-138)
    Refactoring Date: 2025-08-25
#>

# Import core module for logging
Import-Module "$PSScriptRoot\SafeCommandCore.psm1" -Force

#region Constrained Runspace Creation

function New-ConstrainedRunspace {
    <#
    .SYNOPSIS
    Creates a constrained runspace with limited command access.
    
    .DESCRIPTION
    Creates a PowerShell runspace with constrained language mode and
    only specified commands available for secure code execution.
    
    .PARAMETER AllowedCommands
    List of commands that will be available in the constrained runspace.
    
    .PARAMETER Variables
    Variables to pre-populate in the runspace.
    
    .PARAMETER Modules
    Modules to import into the runspace.
    #>
    [CmdletBinding()]
    param (
        [Parameter()]
        [string[]]$AllowedCommands = @(
            'Get-Content', 'Set-Content', 'Add-Content',
            'Test-Path', 'Get-ChildItem', 'Join-Path',
            'Split-Path', 'Resolve-Path', 'Get-Item',
            'Get-Date', 'Measure-Command', 'Select-Object',
            'Where-Object', 'ForEach-Object', 'Sort-Object',
            'ConvertTo-Json', 'ConvertFrom-Json',
            'Write-Output', 'Write-Host', 'Out-String'
        ),
        
        [Parameter()]
        [hashtable]$Variables = @{},
        
        [Parameter()]
        [string[]]$Modules = @()
    )
    
    Write-SafeLog "Creating constrained runspace with $($AllowedCommands.Count) allowed commands" -Level Debug
    
    try {
        # Create initial session state
        $iss = [System.Management.Automation.Runspaces.InitialSessionState]::Create()
        $iss.LanguageMode = [System.Management.Automation.PSLanguageMode]::ConstrainedLanguage
        
        # Add only allowed commands
        foreach ($cmd in $AllowedCommands) {
            $cmdlet = Get-Command $cmd -ErrorAction SilentlyContinue
            if ($cmdlet) {
                $entry = New-Object System.Management.Automation.Runspaces.SessionStateCmdletEntry(
                    $cmd, 
                    $cmdlet.ImplementingType,
                    $null
                )
                $iss.Commands.Add($entry)
                Write-SafeLog "Added allowed command: $cmd" -Level Debug
            }
        }
        
        # Add variables
        foreach ($var in $Variables.GetEnumerator()) {
            $entry = New-Object System.Management.Automation.Runspaces.SessionStateVariableEntry(
                $var.Key,
                $var.Value,
                $null
            )
            $iss.Variables.Add($entry)
            Write-SafeLog "Added variable: $($var.Key)" -Level Debug
        }
        
        # Create runspace
        $runspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
        $runspace.Open()
        
        Write-SafeLog "Constrained runspace created successfully" -Level Info
        return $runspace
    }
    catch {
        Write-SafeLog "Failed to create constrained runspace: $($_.Exception.Message)" -Level Error
        throw
    }
}

function Remove-ConstrainedRunspace {
    <#
    .SYNOPSIS
    Safely disposes of a constrained runspace.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.Runspaces.Runspace]$Runspace
    )
    
    try {
        if ($Runspace -and $Runspace.RunspaceStateInfo.State -ne 'Closed') {
            $Runspace.Close()
            $Runspace.Dispose()
            Write-SafeLog "Constrained runspace disposed successfully" -Level Debug
        }
    }
    catch {
        Write-SafeLog "Error disposing runspace: $($_.Exception.Message)" -Level Warning
    }
}

function Test-RunspaceHealth {
    <#
    .SYNOPSIS
    Tests if a runspace is healthy and available for use.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.Runspaces.Runspace]$Runspace
    )
    
    if (-not $Runspace) {
        return $false
    }
    
    $state = $Runspace.RunspaceStateInfo.State
    return $state -eq 'Opened'
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'New-ConstrainedRunspace',
    'Remove-ConstrainedRunspace',
    'Test-RunspaceHealth'
)

#endregion

# REFACTORING MARKER: This module was refactored from SafeCommandExecution.psm1 on 2025-08-25
# Original file size: 2860 lines
# This component: Constrained runspace management (lines 69-138)