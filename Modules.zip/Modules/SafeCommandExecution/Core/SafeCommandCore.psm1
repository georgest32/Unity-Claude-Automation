#Requires -Version 5.1
<#
.SYNOPSIS
    Core configuration and logging infrastructure for SafeCommandExecution module.

.DESCRIPTION
    Provides centralized configuration management, thread-safe logging, and
    core security settings for the safe command execution framework.

.NOTES
    Part of SafeCommandExecution refactored architecture
    Originally from SafeCommandExecution.psm1 (lines 1-68)
    Refactoring Date: 2025-08-25
#>

#region Module Configuration

# Script-level configuration
$script:SafeCommandConfig = @{
    MaxExecutionTime = 300  # Maximum seconds for command execution
    AllowedPaths = @()      # Project boundaries
    BlockedCommands = @(    # Dangerous commands to block
        'Invoke-Expression',
        'iex',
        'Invoke-Command',
        'Add-Type',
        'New-Object System.Diagnostics.Process',
        'Start-Process cmd',
        'Start-Process powershell'
    )
}

# Thread-safe logging
$script:LogMutex = New-Object System.Threading.Mutex($false, "UnityClaudeAutomation")

#endregion

#region Logging Infrastructure

function Write-SafeLog {
    <#
    .SYNOPSIS
    Thread-safe logging function for safe command execution operations.
    
    .DESCRIPTION
    Provides synchronized logging to prevent file access conflicts in
    multi-threaded scenarios while maintaining console output.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter()]
        [ValidateSet('Info', 'Warning', 'Error', 'Debug', 'Security')]
        [string]$Level = 'Info'
    )
    
    $logFile = Join-Path $PSScriptRoot "..\..\..\unity_claude_automation.log"
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    $logEntry = "[$timestamp] [SafeCommand] [$Level] $Message"
    
    try {
        $acquired = $script:LogMutex.WaitOne(1000)
        if ($acquired) {
            Add-Content -Path $logFile -Value $logEntry -ErrorAction SilentlyContinue
        }
    }
    finally {
        if ($acquired) {
            $script:LogMutex.ReleaseMutex()
        }
    }
    
    # Also output to console based on level
    switch ($Level) {
        'Error' { Write-Error $Message }
        'Warning' { Write-Warning $Message }
        'Debug' { Write-Debug $Message }
        'Security' { Write-Host "[SECURITY] $Message" -ForegroundColor Magenta }
        default { Write-Verbose $Message }
    }
}

#endregion

#region Configuration Management

function Get-SafeCommandConfig {
    <#
    .SYNOPSIS
    Returns the current safe command configuration.
    #>
    [CmdletBinding()]
    param()
    
    return $script:SafeCommandConfig.Clone()
}

function Set-SafeCommandConfig {
    <#
    .SYNOPSIS
    Updates the safe command configuration settings.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [int]$MaxExecutionTime,
        
        [Parameter()]
        [string[]]$AllowedPaths,
        
        [Parameter()]
        [string[]]$BlockedCommands
    )
    
    if ($PSBoundParameters.ContainsKey('MaxExecutionTime')) {
        $script:SafeCommandConfig.MaxExecutionTime = $MaxExecutionTime
        Write-SafeLog -Message "Updated MaxExecutionTime to $MaxExecutionTime seconds" -Level 'Info'
    }
    
    if ($PSBoundParameters.ContainsKey('AllowedPaths')) {
        $script:SafeCommandConfig.AllowedPaths = $AllowedPaths
        Write-SafeLog -Message "Updated AllowedPaths: $($AllowedPaths -join ', ')" -Level 'Info'
    }
    
    if ($PSBoundParameters.ContainsKey('BlockedCommands')) {
        $script:SafeCommandConfig.BlockedCommands = $BlockedCommands
        Write-SafeLog -Message "Updated BlockedCommands count: $($BlockedCommands.Count)" -Level 'Security'
    }
}

function Test-SafeCommandInitialization {
    <#
    .SYNOPSIS
    Tests if the safe command core is properly initialized.
    #>
    [CmdletBinding()]
    param()
    
    $isInitialized = $true
    $issues = @()
    
    # Check configuration
    if (-not $script:SafeCommandConfig) {
        $isInitialized = $false
        $issues += "Configuration not initialized"
    }
    
    # Check mutex
    if (-not $script:LogMutex) {
        $isInitialized = $false
        $issues += "Log mutex not initialized"
    }
    
    # Check log file accessibility
    $logFile = Join-Path $PSScriptRoot "..\..\..\unity_claude_automation.log"
    $logDir = Split-Path $logFile -Parent
    if (-not (Test-Path $logDir)) {
        $issues += "Log directory does not exist: $logDir"
    }
    
    return @{
        IsInitialized = $isInitialized
        Issues = $issues
        Configuration = if ($script:SafeCommandConfig) { $script:SafeCommandConfig } else { $null }
    }
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Write-SafeLog',
    'Get-SafeCommandConfig',
    'Set-SafeCommandConfig',
    'Test-SafeCommandInitialization'
) -Variable @(
    'SafeCommandConfig',
    'LogMutex'
)

#endregion

# REFACTORING MARKER: This module was refactored from SafeCommandExecution.psm1 on 2025-08-25
# Original file size: 2860 lines
# This component: Core configuration and logging (lines 1-68)