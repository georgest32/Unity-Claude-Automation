# Unity-Claude-RunspaceManagement Variable Sharing Component
# Thread-safe variable sharing across runspaces
# Part of refactored RunspaceManagement module

$ErrorActionPreference = "Stop"

# Import core components
$CorePath = Join-Path $PSScriptRoot "RunspaceCore.psm1"
$SessionStatePath = Join-Path $PSScriptRoot "SessionStateConfiguration.psm1"
Import-Module $CorePath -Force
Import-Module $SessionStatePath -Force

function New-SessionStateVariableEntry {
    <#
    .SYNOPSIS
    Creates a new SessionStateVariableEntry
    .DESCRIPTION
    Creates a SessionStateVariableEntry using research-validated patterns for thread-safe variable sharing
    .PARAMETER Name
    Variable name
    .PARAMETER Value
    Variable value
    .PARAMETER Description
    Variable description
    .PARAMETER Options
    Variable options (None, ReadOnly, Constant, Private, AllScope)
    .EXAMPLE
    $entry = New-SessionStateVariableEntry -Name "SharedData" -Value $data -Description "Shared data between runspaces"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        $Value,
        [string]$Description = "",
        [System.Management.Automation.ScopedItemOptions]$Options = 'None'
    )
    
    Write-ModuleLog -Message "Creating SessionStateVariableEntry for $Name..." -Level "DEBUG"
    
    try {
        # Create SessionStateVariableEntry using research-validated pattern
        $variableEntry = New-Object System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList $Name, $Value, $Description, $Options
        
        Write-ModuleLog -Message "Created SessionStateVariableEntry for $Name successfully" -Level "DEBUG"
        
        return $variableEntry
        
    } catch {
        Write-ModuleLog -Message "Failed to create SessionStateVariableEntry for ${Name}: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Add-SharedVariable {
    <#
    .SYNOPSIS
    Adds a shared variable to session state
    .DESCRIPTION
    Adds a variable that will be shared across all runspaces in the pool
    .PARAMETER SessionStateConfig
    Session state configuration object
    .PARAMETER Name
    Variable name
    .PARAMETER Value
    Variable value
    .PARAMETER Description
    Variable description
    .PARAMETER MakeThreadSafe
    If true, wraps collections in synchronized wrappers
    .EXAMPLE
    Add-SharedVariable -SessionStateConfig $config -Name "SharedQueue" -Value $queue -MakeThreadSafe
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        $Value,
        [string]$Description = "Shared variable across runspaces",
        [switch]$MakeThreadSafe
    )
    
    Write-ModuleLog -Message "Adding shared variable $Name to session state..." -Level "INFO"
    
    try {
        $finalValue = $Value
        
        # Make thread-safe if requested and applicable
        if ($MakeThreadSafe) {
            if ($Value -is [hashtable]) {
                $finalValue = [hashtable]::Synchronized($Value)
                Write-ModuleLog -Message "Made hashtable $Name thread-safe" -Level "DEBUG"
            } elseif ($Value -is [System.Collections.ArrayList]) {
                $finalValue = [System.Collections.ArrayList]::Synchronized($Value)
                Write-ModuleLog -Message "Made ArrayList $Name thread-safe" -Level "DEBUG"
            } elseif ($Value -is [System.Collections.Queue]) {
                $finalValue = [System.Collections.Queue]::Synchronized($Value)
                Write-ModuleLog -Message "Made Queue $Name thread-safe" -Level "DEBUG"
            } else {
                Write-ModuleLog -Message "Cannot make $Name thread-safe - unsupported type: $($Value.GetType().Name)" -Level "WARNING"
            }
        }
        
        # Add to session state
        Add-SessionStateVariable -SessionStateConfig $SessionStateConfig -Name $Name -Value $finalValue -Description $Description
        
        # Also add to shared variables dictionary for external access
        $sharedDict = Get-SharedVariablesDictionary
        [void]$sharedDict.TryAdd($Name, $finalValue)
        
        Write-ModuleLog -Message "Shared variable $Name added successfully" -Level "INFO"
        
    } catch {
        Write-ModuleLog -Message "Failed to add shared variable ${Name}: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-SharedVariable {
    <#
    .SYNOPSIS
    Gets a shared variable value (not available in session state context)
    .DESCRIPTION
    This function is for documentation purposes - shared variables are accessed directly in runspace context
    .PARAMETER Name
    Variable name
    .EXAMPLE
    # In runspace context: $value = $SharedVariableName
    Get-SharedVariable -Name "SharedData"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )
    
    Write-ModuleLog -Message "Note: Shared variables are accessed directly in runspace context as dollar-sign-$Name" -Level "INFO"
    
    # Try to get from shared variables dictionary
    $sharedDict = Get-SharedVariablesDictionary
    $value = $null
    if ($sharedDict.TryGetValue($Name, [ref]$value)) {
        return @{
            VariableName = $Name
            CurrentValue = $value
            AccessPattern = "`$$Name"
            Note = "Access this variable directly in runspace scriptblocks using `$$Name"
        }
    }
    
    # Return information about how to access the variable
    return @{
        VariableName = $Name
        AccessPattern = "`$$Name"
        Note = "Access this variable directly in runspace scriptblocks using `$$Name"
    }
}

function Set-SharedVariable {
    <#
    .SYNOPSIS
    Sets a shared variable value (not available in session state context)
    .DESCRIPTION
    This function is for documentation purposes - shared variables are modified directly in runspace context
    .PARAMETER Name
    Variable name
    .PARAMETER Value
    New value
    .EXAMPLE
    # In runspace context: $SharedVariableName = $newValue
    Set-SharedVariable -Name "SharedData" -Value $newValue
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        $Value
    )
    
    Write-ModuleLog -Message "Note: Shared variables are modified directly in runspace context as dollar-sign-$Name = dollar-sign-value" -Level "INFO"
    
    # Update in shared variables dictionary
    $sharedDict = Get-SharedVariablesDictionary
    $sharedDict[$Name] = $Value
    
    # Return information about how to modify the variable
    return @{
        VariableName = $Name
        ModificationPattern = "`$$Name = `$newValue"
        Note = "Modify this variable directly in runspace scriptblocks using assignment"
        ThreadSafetyNote = "Ensure thread-safe operations when modifying shared variables"
    }
}

function Remove-SharedVariable {
    <#
    .SYNOPSIS
    Removes a shared variable (not available in session state context)
    .DESCRIPTION
    This function is for documentation purposes - shared variables cannot be removed from session state after creation
    .PARAMETER Name
    Variable name
    .EXAMPLE
    Remove-SharedVariable -Name "SharedData"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )
    
    Write-ModuleLog -Message "Note: Shared variables cannot be removed from InitialSessionState after runspace pool creation" -Level "WARNING"
    
    # Remove from shared variables dictionary
    $sharedDict = Get-SharedVariablesDictionary
    $removed = $null
    [void]$sharedDict.TryRemove($Name, [ref]$removed)
    
    return @{
        VariableName = $Name
        Note = "SessionState variables cannot be removed after runspace pool is created"
        Alternative = "Set variable to null or empty value in runspace context"
        RemovedFromCache = ($null -ne $removed)
    }
}

function Test-SharedVariableAccess {
    <#
    .SYNOPSIS
    Tests if a shared variable is accessible
    .DESCRIPTION
    Checks if a shared variable exists in the shared variables dictionary
    .PARAMETER Name
    Variable name to test
    .EXAMPLE
    Test-SharedVariableAccess -Name "SharedQueue"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )
    
    $sharedDict = Get-SharedVariablesDictionary
    return $sharedDict.ContainsKey($Name)
}

function Get-AllSharedVariables {
    <#
    .SYNOPSIS
    Gets all shared variables
    .DESCRIPTION
    Returns information about all shared variables in the dictionary
    .EXAMPLE
    Get-AllSharedVariables
    #>
    [CmdletBinding()]
    param()
    
    $sharedDict = Get-SharedVariablesDictionary
    $variables = @()
    
    foreach ($key in $sharedDict.Keys) {
        $value = $null
        if ($sharedDict.TryGetValue($key, [ref]$value)) {
            $variables += @{
                Name = $key
                Type = if ($value) { $value.GetType().Name } else { "null" }
                IsThreadSafe = ($value -is [System.Collections.Hashtable] -and $value.IsSynchronized) -or
                               ($value -is [System.Collections.ArrayList] -and $value.IsSynchronized) -or
                               ($value -is [System.Collections.Queue] -and $value.IsSynchronized)
            }
        }
    }
    
    return $variables
}

# Export functions
Export-ModuleMember -Function @(
    'New-SessionStateVariableEntry',
    'Add-SharedVariable',
    'Get-SharedVariable',
    'Set-SharedVariable',
    'Remove-SharedVariable',
    'Test-SharedVariableAccess',
    'Get-AllSharedVariables'
)

Write-ModuleLog -Message "VariableSharing component loaded successfully" -Level "DEBUG"