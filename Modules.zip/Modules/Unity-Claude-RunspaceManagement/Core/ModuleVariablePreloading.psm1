# Unity-Claude-RunspaceManagement Module/Variable Preloading Component
# Handles module and variable preloading for session states
# Part of refactored RunspaceManagement module

$ErrorActionPreference = "Stop"

# Import core components
$CorePath = Join-Path $PSScriptRoot "RunspaceCore.psm1"
$SessionStatePath = Join-Path $PSScriptRoot "SessionStateConfiguration.psm1"
Import-Module $CorePath -Force
Import-Module $SessionStatePath -Force

# Track registered modules and variables
$script:RegisteredModules = @()
$script:RegisteredVariables = @()

function Import-SessionStateModules {
    <#
    .SYNOPSIS
    Imports critical Unity-Claude modules into session state
    .DESCRIPTION
    Pre-loads essential modules for Unity-Claude automation in runspace pool session state
    .PARAMETER SessionStateConfig
    Session state configuration object
    .PARAMETER ModuleList
    Array of module names to import (defaults to critical Unity-Claude modules)
    .EXAMPLE
    Import-SessionStateModules -SessionStateConfig $config
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [string[]]$ModuleList = @(
            'Unity-Claude-ParallelProcessing',
            'Unity-Claude-SystemStatus'
        )
    )
    
    Write-ModuleLog -Message "Importing critical Unity-Claude modules into session state..." -Level "INFO"
    
    try {
        $importedCount = 0
        $failedCount = 0
        
        foreach ($moduleName in $ModuleList) {
            try {
                # Check if module exists in current session first
                $moduleExists = Get-Module -Name $moduleName -ListAvailable -ErrorAction SilentlyContinue
                
                if ($moduleExists) {
                    Add-SessionStateModule -SessionStateConfig $SessionStateConfig -ModuleName $moduleName
                    $script:RegisteredModules += $moduleName
                    $importedCount++
                    Write-ModuleLog -Message "Successfully imported module: $moduleName" -Level "DEBUG"
                } else {
                    Write-ModuleLog -Message "Module not found: $moduleName" -Level "WARNING"
                    $failedCount++
                }
            } catch {
                Write-ModuleLog -Message "Failed to import module ${moduleName}: $($_.Exception.Message)" -Level "WARNING"
                $failedCount++
            }
        }
        
        $result = @{
            ImportedCount = $importedCount
            FailedCount = $failedCount
            TotalModules = $ModuleList.Count
            SuccessRate = [math]::Round(($importedCount / $ModuleList.Count) * 100, 2)
        }
        
        Write-ModuleLog -Message "Module import completed: $importedCount/$($ModuleList.Count) modules imported successfully ($($result.SuccessRate)%)" -Level "INFO"
        
        return $result
        
    } catch {
        Write-ModuleLog -Message "Failed to import session state modules: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Initialize-SessionStateVariables {
    <#
    .SYNOPSIS
    Initializes critical variables in session state
    .DESCRIPTION
    Pre-loads essential variables for Unity-Claude automation in runspace pool session state
    .PARAMETER SessionStateConfig
    Session state configuration object
    .PARAMETER Variables
    Hashtable of variables to initialize
    .EXAMPLE
    Initialize-SessionStateVariables -SessionStateConfig $config -Variables @{GlobalStatus=$statusData}
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [hashtable]$Variables = @{}
    )
    
    Write-ModuleLog -Message "Initializing critical variables in session state..." -Level "INFO"
    
    try {
        # Add default Unity-Claude variables
        $defaultVariables = @{
            'UnityClaudeVersion' = '2.0.0'
            'AutomationStartTime' = Get-Date
            'RunspaceMode' = 'Pool'
            'ThreadSafeLogging' = $true
        }
        
        # Merge with provided variables
        $allVariables = $defaultVariables.Clone()
        foreach ($key in $Variables.Keys) {
            $allVariables[$key] = $Variables[$key]
        }
        
        $initializedCount = 0
        
        foreach ($varName in $allVariables.Keys) {
            try {
                Add-SessionStateVariable -SessionStateConfig $SessionStateConfig -Name $varName -Value $allVariables[$varName] -Description "Unity-Claude automation variable"
                $script:RegisteredVariables += $varName
                $initializedCount++
                Write-ModuleLog -Message "Initialized variable: $varName" -Level "DEBUG"
            } catch {
                Write-ModuleLog -Message "Failed to initialize variable ${varName}: $($_.Exception.Message)" -Level "WARNING"
            }
        }
        
        $result = @{
            InitializedCount = $initializedCount
            TotalVariables = $allVariables.Count
            SuccessRate = [math]::Round(($initializedCount / $allVariables.Count) * 100, 2)
        }
        
        Write-ModuleLog -Message "Variable initialization completed: $initializedCount/$($allVariables.Count) variables initialized ($($result.SuccessRate)%)" -Level "INFO"
        
        return $result
        
    } catch {
        Write-ModuleLog -Message "Failed to initialize session state variables: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-SessionStateModules {
    <#
    .SYNOPSIS
    Gets list of modules in session state
    .DESCRIPTION
    Returns information about modules configured in the session state
    .PARAMETER SessionStateConfig
    Session state configuration object
    .EXAMPLE
    Get-SessionStateModules -SessionStateConfig $config
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig
    )
    
    try {
        $sessionState = $SessionStateConfig.SessionState
        
        # Get modules from session state (this is limited in PowerShell 5.1)
        $moduleInfo = @{
            RegisteredModules = $script:RegisteredModules
            ModuleCount = $SessionStateConfig.Metadata.ModulesCount
            LastUpdate = Get-Date
        }
        
        Write-ModuleLog -Message "Retrieved session state modules: $($moduleInfo.ModuleCount) modules" -Level "INFO"
        
        return $moduleInfo
        
    } catch {
        Write-ModuleLog -Message "Failed to get session state modules: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-SessionStateVariables {
    <#
    .SYNOPSIS
    Gets list of variables in session state
    .DESCRIPTION
    Returns information about variables configured in the session state
    .PARAMETER SessionStateConfig
    Session state configuration object
    .EXAMPLE
    Get-SessionStateVariables -SessionStateConfig $config
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig
    )
    
    try {
        $sessionState = $SessionStateConfig.SessionState
        
        # Get variables from session state
        $variableInfo = @{
            RegisteredVariables = $script:RegisteredVariables
            VariableCount = $SessionStateConfig.Metadata.VariablesCount
            SessionStateVariables = @()
            LastUpdate = Get-Date
        }
        
        # Get variables from session state (limited access in PowerShell 5.1)
        try {
            $variableInfo.SessionStateVariables = $sessionState.Variables | ForEach-Object { 
                @{
                    Name = $_.Name
                    Type = if ($_.Value) { $_.Value.GetType().Name } else { "Unknown" }
                    Description = $_.Description
                }
            }
        } catch {
            Write-ModuleLog -Message "Unable to enumerate session state variables directly" -Level "DEBUG"
        }
        
        Write-ModuleLog -Message "Retrieved session state variables: $($variableInfo.VariableCount) variables" -Level "INFO"
        
        return $variableInfo
        
    } catch {
        Write-ModuleLog -Message "Failed to get session state variables: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Import-SessionStateModules',
    'Initialize-SessionStateVariables',
    'Get-SessionStateModules',
    'Get-SessionStateVariables'
)

Write-ModuleLog -Message "ModuleVariablePreloading component loaded successfully" -Level "DEBUG"