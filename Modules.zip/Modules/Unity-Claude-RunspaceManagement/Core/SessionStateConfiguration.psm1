# Unity-Claude-RunspaceManagement Session State Configuration Component
# InitialSessionState configuration and management
# Part of refactored RunspaceManagement module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "RunspaceCore.psm1"
Import-Module $CorePath -Force

# Default configuration
$script:DefaultSessionConfiguration = @{
    LanguageMode = 'FullLanguage'
    ExecutionPolicy = 'Bypass'
    ApartmentState = 'STA'
    ThreadOptions = 'ReuseThread'
    UseCreateDefault = $true
}

function New-RunspaceSessionState {
    <#
    .SYNOPSIS
    Creates a new InitialSessionState configuration for runspace pools
    .DESCRIPTION
    Creates an optimized InitialSessionState using research-validated patterns for PowerShell 5.1 compatibility
    .PARAMETER UseCreateDefault
    Use CreateDefault() for better performance (default) vs CreateDefault2()
    .PARAMETER LanguageMode
    PowerShell language mode (FullLanguage, ConstrainedLanguage, NoLanguage)
    .PARAMETER ExecutionPolicy
    Execution policy for the session state
    .PARAMETER ApartmentState
    Threading apartment state (STA, MTA)
    .PARAMETER ThreadOptions
    Thread reuse options (ReuseThread, UseNewThread)
    .EXAMPLE
    $sessionState = New-RunspaceSessionState -LanguageMode FullLanguage
    #>
    [CmdletBinding()]
    param(
        [switch]$UseCreateDefault = $true,
        [ValidateSet('FullLanguage', 'ConstrainedLanguage', 'NoLanguage')]
        [string]$LanguageMode = 'FullLanguage',
        [ValidateSet('Unrestricted', 'RemoteSigned', 'AllSigned', 'Restricted', 'Default', 'Bypass', 'Undefined')]
        [string]$ExecutionPolicy = 'Bypass',
        [ValidateSet('STA', 'MTA', 'Unknown')]
        [string]$ApartmentState = 'STA',
        [ValidateSet('ReuseThread', 'UseNewThread')]
        [string]$ThreadOptions = 'ReuseThread'
    )
    
    Write-ModuleLog -Message "Creating new InitialSessionState with research-validated configuration..." -Level "INFO"
    
    try {
        # Use CreateDefault() for better performance (research finding: CreateDefault2 is 3-8x slower)
        if ($UseCreateDefault) {
            $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
            Write-ModuleLog -Message "Using CreateDefault() for optimal performance" -Level "DEBUG"
        } else {
            $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault2()
            Write-ModuleLog -Message "Using CreateDefault2() with core commands only" -Level "DEBUG"
        }
        
        # Configure session state properties based on research best practices
        $sessionState.LanguageMode = [System.Management.Automation.PSLanguageMode]$LanguageMode
        
        # Convert ExecutionPolicy string to enum (research-validated approach)
        try {
            $sessionState.ExecutionPolicy = [Microsoft.PowerShell.ExecutionPolicy]$ExecutionPolicy
            Write-ModuleLog -Message "ExecutionPolicy set to $ExecutionPolicy using enum" -Level "DEBUG"
        } catch {
            Write-ModuleLog -Message "ExecutionPolicy enum not available, using string fallback" -Level "WARNING"
        }
        
        # Convert ApartmentState string to enum
        $sessionState.ApartmentState = [System.Threading.ApartmentState]$ApartmentState
        
        # Convert ThreadOptions string to enum  
        $sessionState.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]$ThreadOptions
        
        # Add metadata for tracking
        $sessionMetadata = @{
            Created = Get-Date
            LanguageMode = $LanguageMode
            ExecutionPolicy = $ExecutionPolicy
            ApartmentState = $ApartmentState
            ThreadOptions = $ThreadOptions
            UseCreateDefault = $UseCreateDefault
            ModulesCount = 0
            VariablesCount = 0
        }
        
        # Return session state with metadata
        $result = @{
            SessionState = $sessionState
            Metadata = $sessionMetadata
        }
        
        # Register in session state registry
        $stateName = "SessionState_$(Get-Date -Format 'yyyyMMddHHmmss')"
        Update-SessionStateRegistry -StateName $stateName -State $result
        
        Write-ModuleLog -Message "InitialSessionState created successfully with $LanguageMode language mode" -Level "INFO"
        return $result
        
    } catch {
        Write-ModuleLog -Message "Failed to create InitialSessionState: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Set-SessionStateConfiguration {
    <#
    .SYNOPSIS
    Sets configuration for session state creation
    .DESCRIPTION
    Configures default settings for session state creation across the module
    .PARAMETER Configuration
    Hashtable containing configuration settings
    .EXAMPLE
    Set-SessionStateConfiguration -Configuration @{LanguageMode='FullLanguage'; ExecutionPolicy='Bypass'}
    #>
    [CmdletBinding()]
    param(
        [hashtable]$Configuration
    )
    
    Write-ModuleLog -Message "Updating session state configuration..." -Level "INFO"
    
    try {
        foreach ($key in $Configuration.Keys) {
            if ($script:DefaultSessionConfiguration.ContainsKey($key)) {
                $oldValue = $script:DefaultSessionConfiguration[$key]
                $script:DefaultSessionConfiguration[$key] = $Configuration[$key]
                Write-ModuleLog -Message "Updated $key from $oldValue to $($Configuration[$key])" -Level "DEBUG"
            } else {
                Write-ModuleLog -Message "Unknown configuration key: $key" -Level "WARNING"
            }
        }
        
        Write-ModuleLog -Message "Session state configuration updated successfully" -Level "INFO"
        
    } catch {
        Write-ModuleLog -Message "Failed to set session state configuration: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Add-SessionStateModule {
    <#
    .SYNOPSIS
    Adds a PowerShell module to session state
    .DESCRIPTION
    Adds a module to the InitialSessionState for pre-loading in runspace pools
    .PARAMETER SessionStateConfig
    Session state configuration object from New-RunspaceSessionState
    .PARAMETER ModuleName
    Name of the module to add
    .PARAMETER ModulePath
    Optional path to the module
    .EXAMPLE
    Add-SessionStateModule -SessionStateConfig $config -ModuleName "Unity-Claude-Core"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [Parameter(Mandatory)]
        [string]$ModuleName,
        [string]$ModulePath = $null
    )
    
    Write-ModuleLog -Message "Adding module '$ModuleName' to session state..." -Level "DEBUG"
    
    try {
        if (-not $SessionStateConfig.SessionState) {
            throw "Invalid session state configuration object"
        }
        
        # Determine module path if not provided
        if ([string]::IsNullOrEmpty($ModulePath)) {
            $module = Get-Module -Name $ModuleName -ListAvailable | Select-Object -First 1
            if ($module) {
                $ModulePath = Split-Path $module.Path -Parent
                Write-ModuleLog -Message "Auto-detected module path: $ModulePath" -Level "DEBUG"
            } else {
                Write-ModuleLog -Message "Module '$ModuleName' not found in available modules" -Level "WARNING"
                return
            }
        }
        
        # Add module to session state
        $SessionStateConfig.SessionState.ImportPSModule($ModuleName)
        
        # Update metadata
        $SessionStateConfig.Metadata.ModulesCount++
        
        Write-ModuleLog -Message "Module '$ModuleName' added to session state" -Level "INFO"
        
    } catch {
        Write-ModuleLog -Message "Failed to add module to session state: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Add-SessionStateVariable {
    <#
    .SYNOPSIS
    Adds a variable to the InitialSessionState
    .DESCRIPTION
    Adds a variable that will be available in all runspaces created from this session state
    .PARAMETER SessionStateConfig
    Session state configuration object
    .PARAMETER Name
    Variable name
    .PARAMETER Value
    Variable value
    .PARAMETER Description
    Optional description
    .EXAMPLE
    Add-SessionStateVariable -SessionStateConfig $config -Name "ProjectRoot" -Value "C:\Projects"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        $Value,
        [string]$Description = ""
    )
    
    Write-ModuleLog -Message "Adding variable '$Name' to session state..." -Level "DEBUG"
    
    try {
        if (-not $SessionStateConfig.SessionState) {
            throw "Invalid session state configuration object"
        }
        
        # Create variable entry
        $variableEntry = New-Object System.Management.Automation.Runspaces.SessionStateVariableEntry(
            $Name, $Value, $Description
        )
        
        # Add to session state
        $SessionStateConfig.SessionState.Variables.Add($variableEntry)
        
        # Update metadata
        $SessionStateConfig.Metadata.VariablesCount++
        
        Write-ModuleLog -Message "Variable '$Name' added to session state" -Level "INFO"
        
    } catch {
        Write-ModuleLog -Message "Failed to add variable to session state: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Test-SessionStateConfiguration {
    <#
    .SYNOPSIS
    Tests if session state configuration is valid
    .DESCRIPTION
    Validates session state configuration and returns test results
    .PARAMETER SessionStateConfig
    Session state configuration object to test
    .EXAMPLE
    Test-SessionStateConfiguration -SessionStateConfig $config
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig
    )
    
    Write-ModuleLog -Message "Testing session state configuration..." -Level "DEBUG"
    
    $results = @{
        IsValid = $false
        HasSessionState = $false
        HasMetadata = $false
        ModulesCount = 0
        VariablesCount = 0
        Errors = @()
    }
    
    try {
        # Check for session state
        if ($SessionStateConfig.SessionState) {
            $results.HasSessionState = $true
            
            # Check if it's a valid InitialSessionState object
            if ($SessionStateConfig.SessionState -is [System.Management.Automation.Runspaces.InitialSessionState]) {
                $results.IsValid = $true
            } else {
                $results.Errors += "SessionState is not of type InitialSessionState"
            }
        } else {
            $results.Errors += "SessionState property not found"
        }
        
        # Check for metadata
        if ($SessionStateConfig.Metadata) {
            $results.HasMetadata = $true
            $results.ModulesCount = $SessionStateConfig.Metadata.ModulesCount
            $results.VariablesCount = $SessionStateConfig.Metadata.VariablesCount
        } else {
            $results.Errors += "Metadata property not found"
        }
        
        Write-ModuleLog -Message "Session state configuration test completed. IsValid: $($results.IsValid)" -Level "INFO"
        
    } catch {
        $results.Errors += $_.Exception.Message
        Write-ModuleLog -Message "Error testing session state configuration: $($_.Exception.Message)" -Level "ERROR"
    }
    
    return $results
}

# Export functions
Export-ModuleMember -Function @(
    'New-RunspaceSessionState',
    'Set-SessionStateConfiguration',
    'Add-SessionStateModule',
    'Add-SessionStateVariable',
    'Test-SessionStateConfiguration'
)

Write-ModuleLog -Message "SessionStateConfiguration component loaded successfully" -Level "DEBUG"