# Unity-Claude-RunspaceManagement Pool Management Component
# Core runspace pool management functionality
# Part of refactored RunspaceManagement module

$ErrorActionPreference = "Stop"

# Import core components
$CorePath = Join-Path $PSScriptRoot "RunspaceCore.psm1"
$SessionStatePath = Join-Path $PSScriptRoot "SessionStateConfiguration.psm1"
Import-Module $CorePath -Force
Import-Module $SessionStatePath -Force

# Active runspace pools registry
$script:ActiveRunspacePools = @{}

function New-ManagedRunspacePool {
    <#
    .SYNOPSIS
    Creates a new managed runspace pool with configured session state
    .DESCRIPTION
    Creates a runspace pool using research-validated patterns with proper session state configuration
    .PARAMETER SessionStateConfig
    Session state configuration object
    .PARAMETER MinRunspaces
    Minimum number of runspaces in the pool
    .PARAMETER MaxRunspaces
    Maximum number of runspaces in the pool
    .PARAMETER Name
    Optional name for the runspace pool
    .EXAMPLE
    $pool = New-ManagedRunspacePool -SessionStateConfig $config -MinRunspaces 1 -MaxRunspaces 5
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$SessionStateConfig,
        [int]$MinRunspaces = 1,
        [int]$MaxRunspaces = 5,
        [string]$Name = "Unity-Claude-Pool-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    )
    
    Write-ModuleLog -Message "Creating managed runspace pool '$Name' with $MinRunspaces-$MaxRunspaces runspaces..." -Level "INFO"
    
    try {
        $sessionState = $SessionStateConfig.SessionState
        
        # Create runspace pool using research-validated pattern
        $runspacePool = [runspacefactory]::CreateRunspacePool($MinRunspaces, $MaxRunspaces, $sessionState, $Host)
        
        # Create pool management object
        $poolManager = @{
            RunspacePool = $runspacePool
            Name = $Name
            MinRunspaces = $MinRunspaces
            MaxRunspaces = $MaxRunspaces
            SessionStateConfig = $SessionStateConfig
            Created = Get-Date
            Status = 'Created'
            ActiveJobs = @()
            CompletedJobs = @()
            Statistics = @{
                JobsSubmitted = 0
                JobsCompleted = 0
                JobsFailed = 0
                AverageExecutionTimeMs = 0
            }
        }
        
        # Register pool in both local and core registries
        $script:ActiveRunspacePools[$Name] = $poolManager
        Update-RunspacePoolRegistry -PoolName $Name -Pool $poolManager
        
        Write-ModuleLog -Message "Managed runspace pool '$Name' created successfully" -Level "INFO"
        
        return $poolManager
        
    } catch {
        Write-ModuleLog -Message "Failed to create managed runspace pool '$Name': $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Open-RunspacePool {
    <#
    .SYNOPSIS
    Opens a runspace pool for use
    .DESCRIPTION
    Opens the runspace pool and makes it available for job execution
    .PARAMETER PoolManager
    Pool manager object from New-ManagedRunspacePool
    .EXAMPLE
    Open-RunspacePool -PoolManager $poolManager
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$PoolManager
    )
    
    $poolName = $PoolManager.Name
    Write-ModuleLog -Message "Opening runspace pool '$poolName'..." -Level "INFO"
    
    try {
        $runspacePool = $PoolManager.RunspacePool
        
        # Open the pool
        $runspacePool.Open()
        
        # Update status
        $PoolManager.Status = 'Open'
        $PoolManager.Opened = Get-Date
        
        Write-ModuleLog -Message "Runspace pool '$poolName' opened successfully (State: $($runspacePool.RunspacePoolStateInfo.State))" -Level "INFO"
        
        return @{
            Success = $true
            State = $runspacePool.RunspacePoolStateInfo.State
            AvailableRunspaces = $runspacePool.GetAvailableRunspaces()
            MaxRunspaces = $runspacePool.GetMaxRunspaces()
        }
        
    } catch {
        Write-ModuleLog -Message "Failed to open runspace pool '$poolName': $($_.Exception.Message)" -Level "ERROR"
        $PoolManager.Status = 'Failed'
        throw
    }
}

function Close-RunspacePool {
    <#
    .SYNOPSIS
    Closes a runspace pool
    .DESCRIPTION
    Closes the runspace pool and cleans up resources
    .PARAMETER PoolManager
    Pool manager object
    .PARAMETER Force
    Force close even if jobs are running
    .EXAMPLE
    Close-RunspacePool -PoolManager $poolManager
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$PoolManager,
        [switch]$Force
    )
    
    $poolName = $PoolManager.Name
    Write-ModuleLog -Message "Closing runspace pool '$poolName'..." -Level "INFO"
    
    try {
        $runspacePool = $PoolManager.RunspacePool
        
        # Check for active jobs
        if ($PoolManager.ActiveJobs.Count -gt 0 -and -not $Force) {
            Write-ModuleLog -Message "Cannot close pool '$poolName' - $($PoolManager.ActiveJobs.Count) active jobs running. Use -Force to override." -Level "WARNING"
            return @{
                Success = $false
                Reason = "ActiveJobs"
                ActiveJobCount = $PoolManager.ActiveJobs.Count
            }
        }
        
        # Close the pool
        $runspacePool.Close()
        
        # Update status
        $PoolManager.Status = 'Closed'
        $PoolManager.Closed = Get-Date
        
        # Remove from active pools
        $script:ActiveRunspacePools.Remove($poolName)
        
        # Update core registry
        $coreRegistry = Get-RunspacePoolRegistry
        if ($coreRegistry.ContainsKey($poolName)) {
            $coreRegistry.Remove($poolName)
        }
        
        Write-ModuleLog -Message "Runspace pool '$poolName' closed successfully" -Level "INFO"
        
        return @{
            Success = $true
            State = $runspacePool.RunspacePoolStateInfo.State
            Statistics = $PoolManager.Statistics
        }
        
    } catch {
        Write-ModuleLog -Message "Failed to close runspace pool '$poolName': $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Get-RunspacePoolStatus {
    <#
    .SYNOPSIS
    Gets runspace pool status
    .DESCRIPTION
    Returns current status and statistics for a runspace pool
    .PARAMETER PoolManager
    Pool manager object
    .EXAMPLE
    Get-RunspacePoolStatus -PoolManager $poolManager
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$PoolManager
    )
    
    try {
        $runspacePool = $PoolManager.RunspacePool
        $poolName = $PoolManager.Name
        
        $status = @{
            Name = $poolName
            Status = $PoolManager.Status
            State = $runspacePool.RunspacePoolStateInfo.State
            Created = $PoolManager.Created
            MinRunspaces = $PoolManager.MinRunspaces
            MaxRunspaces = $PoolManager.MaxRunspaces
            AvailableRunspaces = 0
            ActiveJobs = $PoolManager.ActiveJobs.Count
            Statistics = $PoolManager.Statistics
            SessionStateInfo = @{
                ModulesCount = $PoolManager.SessionStateConfig.Metadata.ModulesCount
                VariablesCount = $PoolManager.SessionStateConfig.Metadata.VariablesCount
                LanguageMode = $PoolManager.SessionStateConfig.Metadata.LanguageMode
            }
        }
        
        # Get available runspaces if pool is open
        if ($PoolManager.Status -eq 'Open') {
            try {
                $status.AvailableRunspaces = $runspacePool.GetAvailableRunspaces()
            } catch {
                $status.AvailableRunspaces = "Unknown"
            }
        }
        
        return $status
        
    } catch {
        Write-ModuleLog -Message "Failed to get runspace pool status: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function Test-RunspacePoolHealth {
    <#
    .SYNOPSIS
    Tests runspace pool health
    .DESCRIPTION
    Performs health checks on a runspace pool to ensure it's functioning properly
    .PARAMETER PoolManager
    Pool manager object
    .EXAMPLE
    Test-RunspacePoolHealth -PoolManager $poolManager
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$PoolManager
    )
    
    $poolName = $PoolManager.Name
    Write-ModuleLog -Message "Testing health of runspace pool '$poolName'..." -Level "INFO"
    
    try {
        $runspacePool = $PoolManager.RunspacePool
        
        $healthChecks = @{
            PoolExists = $null -ne $runspacePool
            StateValid = $runspacePool.RunspacePoolStateInfo.State -in @('Opened', 'Opening')
            NoErrors = $null -eq $runspacePool.RunspacePoolStateInfo.Reason
            HasAvailableRunspaces = $false
            SessionStateConfigured = $null -ne $PoolManager.SessionStateConfig
            ManagerStatusConsistent = $PoolManager.Status -eq 'Open'
        }
        
        # Check available runspaces
        if ($healthChecks.StateValid) {
            try {
                $availableRunspaces = $runspacePool.GetAvailableRunspaces()
                $healthChecks.HasAvailableRunspaces = $availableRunspaces -gt 0
                $healthChecks.AvailableRunspaces = $availableRunspaces
            } catch {
                $healthChecks.HasAvailableRunspaces = $false
                $healthChecks.AvailableRunspaces = 0
            }
        }
        
        # Calculate health score
        $healthScore = ($healthChecks.GetEnumerator() | Where-Object { $_.Value -eq $true }).Count
        $totalChecks = ($healthChecks.GetEnumerator() | Where-Object { $_.Key -notlike "*Runspaces" }).Count
        $healthPercentage = [math]::Round(($healthScore / $totalChecks) * 100, 2)
        
        $healthChecks.HealthScore = $healthPercentage
        $healthChecks.IsHealthy = $healthPercentage -ge 80
        
        $healthStatus = if ($healthChecks.IsHealthy) { "Healthy" } else { "Unhealthy" }
        Write-ModuleLog -Message "Runspace pool '$poolName' health check completed: $healthStatus ($healthPercentage%)" -Level "INFO"
        
        return $healthChecks
        
    } catch {
        Write-ModuleLog -Message "Failed to test runspace pool health for '$poolName': $($_.Exception.Message)" -Level "ERROR"
        return @{
            PoolExists = $false
            IsHealthy = $false
            HealthScore = 0
            Error = $_.Exception.Message
        }
    }
}

function Get-AllRunspacePools {
    <#
    .SYNOPSIS
    Gets all active runspace pools
    .DESCRIPTION
    Returns information about all currently active runspace pools
    .EXAMPLE
    Get-AllRunspacePools
    #>
    [CmdletBinding()]
    param()
    
    Write-ModuleLog -Message "Getting all active runspace pools..." -Level "DEBUG"
    
    $pools = @()
    foreach ($poolName in $script:ActiveRunspacePools.Keys) {
        try {
            $status = Get-RunspacePoolStatus -PoolManager $script:ActiveRunspacePools[$poolName]
            $pools += $status
        } catch {
            Write-ModuleLog -Message "Failed to get status for pool '$poolName': $($_.Exception.Message)" -Level "WARNING"
        }
    }
    
    Write-ModuleLog -Message "Found $($pools.Count) active runspace pools" -Level "INFO"
    return $pools
}

# Export functions
Export-ModuleMember -Function @(
    'New-ManagedRunspacePool',
    'Open-RunspacePool',
    'Close-RunspacePool',
    'Get-RunspacePoolStatus',
    'Test-RunspacePoolHealth',
    'Get-AllRunspacePools'
)

Write-ModuleLog -Message "RunspacePoolManagement component loaded successfully" -Level "DEBUG"