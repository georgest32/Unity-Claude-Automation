# === Added by Fix-RunspaceManagementNesting ===
if (\) {
    # Prevent side-effects if this file is re-executed
    return
}
\ = \True
# === End added ===
# === Added by Fix-RunspaceManagementNesting ===
if (\) {
    # Prevent side-effects if this file is re-executed
    return
}
# Removed stray path line: \ = \True
# === End added ===
# Unity-Claude-RunspaceManagement Core Component
# Core configuration and logging for runspace management
# Part of refactored RunspaceManagement module

$ErrorActionPreference = "Stop"

# Script-level variables for module state
$script:WriteAgentLogAvailable = $false
$script:RunspacePools = @{}
$script:SharedVariables = [System.Collections.Concurrent.ConcurrentDictionary[string, object]]::new()
$script:SessionStates = @{}

# Dependency validation function
function Test-ModuleDependencyAvailability {
    param(
        [string[]]$RequiredModules,
        [string]$ModuleName = "Unknown"
    )
    
    $missingModules = @()
    foreach ($reqModule in $RequiredModules) {
        $module = Get-Module $reqModule -ErrorAction SilentlyContinue
        if (-not $module) {
            $missingModules += $reqModule
        }
    }
    
    if ($missingModules.Count -gt 0) {
        Write-Warning "[$ModuleName] Missing required modules: $($missingModules -join ', '). Import them explicitly before using this module."
        return $false
    }
    
    return $true
}

# Initialize parallel processing module if available
try {
    if (-not (Get-Module Unity-Claude-ParallelProcessing -ErrorAction SilentlyContinue)) {
# Removed by Fix-RunspaceManagementNesting: \0
        Write-Host "[DEBUG] [StatePreservation] Loaded Unity-Claude-ParallelProcessing module" -ForegroundColor Gray
    } else {
        Write-Host "[DEBUG] [StatePreservation] Unity-Claude-ParallelProcessing already loaded, preserving state" -ForegroundColor Gray
    }
    $script:WriteAgentLogAvailable = $true
} catch {
    Write-Warning "Failed to import Unity-Claude-ParallelProcessing: $($_.Exception.Message)"
    Write-Warning "Using Write-Host fallback for logging"
}

# Fallback logging function if Write-AgentLog not available
function Write-FallbackLog {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $prefix = "[$timestamp] [RunspaceManagement] [$Level]"
    
    switch ($Level) {
        "ERROR" { Write-Host "$prefix $Message" -ForegroundColor Red }
        "WARNING" { Write-Host "$prefix $Message" -ForegroundColor Yellow }
        "SUCCESS" { Write-Host "$prefix $Message" -ForegroundColor Green }
        "DEBUG" { Write-Debug "$prefix $Message" }
        default { Write-Host "$prefix $Message" }
    }
}

# Module logging function with fallback
function Write-ModuleLog {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARNING", "ERROR", "SUCCESS", "DEBUG")]
        [string]$Level = "INFO"
    )
    
    if ($script:WriteAgentLogAvailable) {
        try {
            Write-AgentLog -Message $Message -Level $Level -Component "RunspaceManagement"
        } catch {
            Write-FallbackLog -Message $Message -Level $Level
        }
    } else {
        Write-FallbackLog -Message $Message -Level $Level
    }
}

# Get runspace pools registry
function Get-RunspacePoolRegistry {
    <#
    .SYNOPSIS
    Returns the current runspace pools registry
    #>
    [CmdletBinding()]
    param()
    
    return $script:RunspacePools.Clone()
}

# Update runspace pool registry
function Update-RunspacePoolRegistry {
    param(
        [string]$PoolName,
        [object]$Pool
    )
    
    $script:RunspacePools[$PoolName] = $Pool
    Write-ModuleLog -Message "Updated runspace pool registry for: $PoolName" -Level "DEBUG"
}

# Get shared variables dictionary
function Get-SharedVariablesDictionary {
    <#
    .SYNOPSIS
    Returns reference to the shared variables concurrent dictionary
    #>
    [CmdletBinding()]
    param()
    
    return $script:SharedVariables
}

# Get session states registry
function Get-SessionStatesRegistry {
    <#
    .SYNOPSIS
    Returns the current session states registry
    #>
    [CmdletBinding()]
    param()
    
    return $script:SessionStates.Clone()
}

# Update session state registry
function Update-SessionStateRegistry {
    param(
        [string]$StateName,
        [object]$State
    )
    
    $script:SessionStates[$StateName] = $State
    Write-ModuleLog -Message "Updated session state registry for: $StateName" -Level "DEBUG"
}

# Export module members
Export-ModuleMember -Function @(
    'Test-ModuleDependencyAvailability',
    'Write-FallbackLog',
    'Write-ModuleLog',
    'Get-RunspacePoolRegistry',
    'Update-RunspacePoolRegistry',
    'Get-SharedVariablesDictionary',
    'Get-SessionStatesRegistry',
    'Update-SessionStateRegistry'
) -Variable @(
    'WriteAgentLogAvailable',
    'RunspacePools',
    'SharedVariables',
    'SessionStates'
)

Write-ModuleLog -Message "RunspaceCore component loaded successfully" -Level "DEBUG"



