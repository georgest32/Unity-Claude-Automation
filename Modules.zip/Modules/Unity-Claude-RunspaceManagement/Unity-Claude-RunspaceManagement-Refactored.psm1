# Unity-Claude-RunspaceManagement Refactored Orchestrator Module
# Loads and coordinates all refactored components
# Version 2.0.0 - Modular Architecture

$ErrorActionPreference = "Stop"

# Module base path
$ModuleBase = $PSScriptRoot
$CorePath = Join-Path $ModuleBase "Core"

Write-Host "[Unity-Claude-RunspaceManagement] Loading REFACTORED VERSION (modular)" -ForegroundColor Green

# Load core components in dependency order
$components = @(
    'RunspaceCore.psm1',
    'SessionStateConfiguration.psm1',
    'ModuleVariablePreloading.psm1',
    'VariableSharing.psm1',
    'RunspacePoolManagement.psm1',
    'ProductionRunspacePool.psm1',
    'ThrottlingResourceControl.psm1'
)

$loadedComponents = @()
$failedComponents = @()

foreach ($component in $components) {
    $componentPath = Join-Path $CorePath $component
    try {
        if (Test-Path $componentPath) {
            Import-Module $componentPath -Force -Global
            $loadedComponents += $component
            Write-Host "  [OK] Loaded component: $component" -ForegroundColor Gray
        } else {
            throw "Component file not found: $componentPath"
        }
    } catch {
        $failedComponents += $component
        Write-Warning "  [FAILED] Could not load component $component : $($_.Exception.Message)"
    }
}

# Summary
Write-Host "[Unity-Claude-RunspaceManagement] Component loading complete:" -ForegroundColor Green
Write-Host "  Loaded: $($loadedComponents.Count)/$($components.Count) components" -ForegroundColor $(if($failedComponents.Count -eq 0){'Green'}else{'Yellow'})

if ($failedComponents.Count -gt 0) {
    Write-Warning "  Failed components: $($failedComponents -join ', ')"
    Write-Warning "  Some functionality may be limited"
}

# Module-level variables for state preservation
$script:ModuleState = @{
    Version = '2.0.0'
    Architecture = 'Modular'
    LoadedComponents = $loadedComponents
    FailedComponents = $failedComponents
    InitializedTime = Get-Date
}

# High-level wrapper functions that coordinate components

function Initialize-RunspaceManagement {
    <#
    .SYNOPSIS
    Initializes the runspace management system with all components
    .DESCRIPTION
    Sets up the complete runspace management infrastructure with session state, pools, and monitoring
    .PARAMETER EnableResourceMonitoring
    Enable CPU and memory monitoring
    .PARAMETER MaxRunspaces
    Maximum number of runspaces to allow
    .EXAMPLE
    Initialize-RunspaceManagement -EnableResourceMonitoring -MaxRunspaces 5
    #>
    [CmdletBinding()]
    param(
        [switch]$EnableResourceMonitoring,
        [int]$MaxRunspaces = [Environment]::ProcessorCount
    )
    
    Write-Host "[RunspaceManagement] Initializing runspace management system..." -ForegroundColor Cyan
    
    try {
        # Create session state configuration
        $sessionState = New-RunspaceSessionState -UseCreateDefault -LanguageMode FullLanguage -ExecutionPolicy Bypass
        
        # Import critical modules
        Import-SessionStateModules -SessionStateConfig $sessionState
        
        # Initialize variables
        Initialize-SessionStateVariables -SessionStateConfig $sessionState
        
        # Create production pool
        $poolManager = New-ProductionRunspacePool -SessionStateConfig $sessionState -MaxRunspaces $MaxRunspaces -EnableResourceMonitoring:$EnableResourceMonitoring
        
        # Open the pool
        Open-RunspacePool -PoolManager $poolManager
        
        Write-Host "[RunspaceManagement] Initialization complete" -ForegroundColor Green
        
        return $poolManager
        
    } catch {
        Write-Error "[RunspaceManagement] Initialization failed: $($_.Exception.Message)"
        throw
    }
}

function Get-RunspaceManagementStatus {
    <#
    .SYNOPSIS
    Gets the current status of the runspace management system
    .DESCRIPTION
    Returns comprehensive status information about all pools, jobs, and resources
    .EXAMPLE
    Get-RunspaceManagementStatus
    #>
    [CmdletBinding()]
    param()
    
    $status = @{
        ModuleVersion = $script:ModuleState.Version
        Architecture = $script:ModuleState.Architecture
        InitializedTime = $script:ModuleState.InitializedTime
        Uptime = if($script:ModuleState.InitializedTime) { ((Get-Date) - $script:ModuleState.InitializedTime).ToString() } else { "Not initialized" }
        Components = @{
            Loaded = $script:ModuleState.LoadedComponents
            Failed = $script:ModuleState.FailedComponents
        }
        Pools = @()
        ResourceMonitoring = @{}
    }
    
    # Get all pool statuses
    if (Get-Command Get-AllRunspacePools -ErrorAction SilentlyContinue) {
        $status.Pools = Get-AllRunspacePools
    }
    
    # Get resource monitoring status
    if (Get-Command Get-ResourceMonitoringStatus -ErrorAction SilentlyContinue) {
        $status.ResourceMonitoring = Get-ResourceMonitoringStatus
    }
    
    return $status
}

function Stop-RunspaceManagement {
    <#
    .SYNOPSIS
    Stops all runspace pools and cleans up resources
    .DESCRIPTION
    Gracefully shuts down the runspace management system
    .PARAMETER Force
    Force shutdown even if jobs are running
    .EXAMPLE
    Stop-RunspaceManagement -Force
    #>
    [CmdletBinding()]
    param(
        [switch]$Force
    )
    
    Write-Host "[RunspaceManagement] Shutting down runspace management system..." -ForegroundColor Yellow
    
    try {
        # Get all active pools
        $poolRegistry = Get-RunspacePoolRegistry
        $closedCount = 0
        
        foreach ($poolName in $poolRegistry.Keys) {
            try {
                $pool = $poolRegistry[$poolName]
                
                # Cleanup resources
                if (Get-Command Invoke-RunspacePoolCleanup -ErrorAction SilentlyContinue) {
                    Invoke-RunspacePoolCleanup -PoolManager $pool -Force:$Force
                }
                
                # Close pool
                if (Get-Command Close-RunspacePool -ErrorAction SilentlyContinue) {
                    Close-RunspacePool -PoolManager $pool -Force:$Force
                    $closedCount++
                }
                
            } catch {
                Write-Warning "Failed to close pool '$poolName': $($_.Exception.Message)"
            }
        }
        
        Write-Host "[RunspaceManagement] Shutdown complete. Closed $closedCount pools" -ForegroundColor Green
        
        return @{
            Success = $true
            PoolsClosed = $closedCount
            Timestamp = Get-Date
        }
        
    } catch {
        Write-Error "[RunspaceManagement] Shutdown failed: $($_.Exception.Message)"
        throw
    }
}

# Export all functions from loaded components plus orchestrator functions
$exportedFunctions = @(
    # Core functions
    'Write-ModuleLog',
    'Get-RunspacePoolRegistry',
    'Get-SharedVariablesDictionary',
    'Get-SessionStatesRegistry',
    
    # Session State Configuration
    'New-RunspaceSessionState',
    'Set-SessionStateConfiguration',
    'Add-SessionStateModule',
    'Add-SessionStateVariable',
    'Test-SessionStateConfiguration',
    
    # Module/Variable Preloading
    'Import-SessionStateModules',
    'Initialize-SessionStateVariables',
    'Get-SessionStateModules',
    'Get-SessionStateVariables',
    
    # Variable Sharing
    'New-SessionStateVariableEntry',
    'Add-SharedVariable',
    'Get-SharedVariable',
    'Set-SharedVariable',
    'Remove-SharedVariable',
    'Test-SharedVariableAccess',
    'Get-AllSharedVariables',
    
    # Runspace Pool Management
    'New-ManagedRunspacePool',
    'Open-RunspacePool',
    'Close-RunspacePool',
    'Get-RunspacePoolStatus',
    'Test-RunspacePoolHealth',
    'Get-AllRunspacePools',
    
    # Production Runspace Pool
    'New-ProductionRunspacePool',
    'Submit-RunspaceJob',
    'Update-RunspaceJobStatus',
    'Wait-RunspaceJobs',
    'Get-RunspaceJobResults',
    
    # Throttling and Resource Control
    'Test-RunspacePoolResources',
    'Set-AdaptiveThrottling',
    'Invoke-RunspacePoolCleanup',
    'Get-ResourceMonitoringStatus',
    
    # Orchestrator functions
    'Initialize-RunspaceManagement',
    'Get-RunspaceManagementStatus',
    'Stop-RunspaceManagement'
)

# Only export functions that are actually available
$availableFunctions = @()
foreach ($func in $exportedFunctions) {
    if (Get-Command $func -ErrorAction SilentlyContinue) {
        $availableFunctions += $func
    }
}

Export-ModuleMember -Function $availableFunctions

Write-Host "[Unity-Claude-RunspaceManagement] Module loaded with $($availableFunctions.Count) functions" -ForegroundColor Green

