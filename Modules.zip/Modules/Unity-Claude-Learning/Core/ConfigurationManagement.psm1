# Unity-Claude-Learning Configuration Management Component  
# Configuration and settings management
# Part of refactored Learning module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "LearningCore.psm1"
Import-Module $CorePath -Force

function Save-LearningConfiguration {
    <#
    .SYNOPSIS
    Saves learning configuration to file
    .DESCRIPTION
    Persists current configuration settings
    .PARAMETER Path
    Configuration file path (optional)
    .EXAMPLE
    Save-LearningConfiguration
    #>
    [CmdletBinding()]
    param(
        [string]$Path = ""
    )
    
    $config = Get-LearningConfiguration
    
    if (-not $Path) {
        $Path = Join-Path $config.StoragePath "learning_config.json"
    }
    
    try {
        $config | ConvertTo-Json -Depth 3 | Set-Content -Path $Path -Encoding UTF8
        Write-ModuleLog -Message "Configuration saved to: $Path" -Level "INFO"
        return $true
    } catch {
        Write-Error "Failed to save configuration: $_"
        return $false
    }
}

function Load-LearningConfiguration {
    <#
    .SYNOPSIS
    Loads learning configuration from file
    .DESCRIPTION
    Restores saved configuration settings
    .PARAMETER Path
    Configuration file path (optional)
    .EXAMPLE
    Load-LearningConfiguration
    #>
    [CmdletBinding()]
    param(
        [string]$Path = ""
    )
    
    if (-not $Path) {
        $config = Get-LearningConfiguration
        $Path = Join-Path $config.StoragePath "learning_config.json"
    }
    
    if (-not (Test-Path $Path)) {
        Write-Warning "Configuration file not found: $Path"
        return $false
    }
    
    try {
        $loaded = Get-Content -Path $Path -Raw | ConvertFrom-Json
        
        # Update configuration
        Set-LearningConfiguration -DatabasePath $loaded.DatabasePath `
                                  -StoragePath $loaded.StoragePath `
                                  -MaxPatternAge $loaded.MaxPatternAge `
                                  -MinConfidence $loaded.MinConfidence `
                                  -EnableAutoFix $loaded.EnableAutoFix
        
        Write-ModuleLog -Message "Configuration loaded from: $Path" -Level "INFO"
        return $true
        
    } catch {
        Write-Error "Failed to load configuration: $_"
        return $false
    }
}

function Test-LearningConfiguration {
    <#
    .SYNOPSIS
    Tests learning configuration validity
    .DESCRIPTION
    Validates configuration settings and storage backends
    .EXAMPLE
    Test-LearningConfiguration
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-LearningConfiguration
    $issues = @()
    
    # Test storage path
    if (-not (Test-Path $config.StoragePath)) {
        $issues += "Storage path does not exist: $($config.StoragePath)"
    }
    
    # Test database if SQLite backend
    if ($config.StorageBackend -eq "SQLite") {
        if (-not (Test-Path $config.DatabasePath)) {
            $issues += "Database file not found: $($config.DatabasePath)"
        } else {
            # Test database connection
            try {
                $connection = New-Object System.Data.SQLite.SQLiteConnection
                $connection.ConnectionString = "Data Source=$($config.DatabasePath);Version=3;"
                $connection.Open()
                $connection.Close()
            } catch {
                $issues += "Cannot connect to database: $_"
            }
        }
    }
    
    # Test confidence threshold
    if ($config.MinConfidence -lt 0 -or $config.MinConfidence -gt 1) {
        $issues += "MinConfidence must be between 0 and 1"
    }
    
    # Test pattern age
    if ($config.MaxPatternAge -lt 0) {
        $issues += "MaxPatternAge must be positive"
    }
    
    $result = @{
        Valid = ($issues.Count -eq 0)
        Issues = $issues
        Configuration = $config
    }
    
    if ($result.Valid) {
        Write-Host "Configuration is valid" -ForegroundColor Green
    } else {
        Write-Warning "Configuration has issues:"
        $issues | ForEach-Object { Write-Warning "  - $_" }
    }
    
    return $result
}

function Export-LearningConfiguration {
    <#
    .SYNOPSIS
    Exports configuration for backup or sharing
    .DESCRIPTION
    Creates a portable configuration export
    .PARAMETER Path
    Export file path
    .PARAMETER IncludeData
    Include pattern data in export
    .EXAMPLE
    Export-LearningConfiguration -Path "backup.json"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Path,
        
        [switch]$IncludeData
    )
    
    $export = @{
        Configuration = Get-LearningConfiguration
        ExportDate = Get-Date
        Version = "2.0.0"
    }
    
    if ($IncludeData) {
        # Include patterns if requested
        $config = Get-LearningConfiguration
        
        if ($config.StorageBackend -eq "SQLite" -and (Test-Path $config.DatabasePath)) {
            # Export database content
            $export.Data = Export-DatabaseContent
        } elseif ($config.StorageBackend -eq "JSON") {
            # Export JSON patterns
            $export.Data = Export-JSONPatterns
        }
    }
    
    try {
        $export | ConvertTo-Json -Depth 10 | Set-Content -Path $Path -Encoding UTF8
        Write-Host "Configuration exported to: $Path" -ForegroundColor Green
        return $true
    } catch {
        Write-Error "Failed to export configuration: $_"
        return $false
    }
}

function Import-LearningConfiguration {
    <#
    .SYNOPSIS
    Imports configuration from export file
    .DESCRIPTION
    Restores configuration from backup
    .PARAMETER Path
    Import file path
    .PARAMETER ImportData
    Also import pattern data
    .EXAMPLE
    Import-LearningConfiguration -Path "backup.json" -ImportData
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Path,
        
        [switch]$ImportData
    )
    
    if (-not (Test-Path $Path)) {
        Write-Error "Import file not found: $Path"
        return $false
    }
    
    try {
        $import = Get-Content -Path $Path -Raw | ConvertFrom-Json
        
        # Import configuration
        Set-LearningConfiguration -DatabasePath $import.Configuration.DatabasePath `
                                  -StoragePath $import.Configuration.StoragePath `
                                  -MaxPatternAge $import.Configuration.MaxPatternAge `
                                  -MinConfidence $import.Configuration.MinConfidence `
                                  -EnableAutoFix $import.Configuration.EnableAutoFix
        
        if ($ImportData -and $import.Data) {
            # Import pattern data
            Write-Host "Importing pattern data..." -ForegroundColor Cyan
            Import-PatternData -Data $import.Data
        }
        
        Write-Host "Configuration imported successfully" -ForegroundColor Green
        return $true
        
    } catch {
        Write-Error "Failed to import configuration: $_"
        return $false
    }
}

# Helper functions
function Export-DatabaseContent {
    # Simplified export - would need full implementation
    return @{ PatternCount = 0 }
}

function Export-JSONPatterns {
    # Simplified export - would need full implementation
    return @{ PatternCount = 0 }
}

function Import-PatternData {
    param($Data)
    # Simplified import - would need full implementation
    Write-Verbose "Pattern data import not fully implemented"
}

# Export functions
Export-ModuleMember -Function @(
    'Save-LearningConfiguration',
    'Load-LearningConfiguration',
    'Test-LearningConfiguration',
    'Export-LearningConfiguration',
    'Import-LearningConfiguration'
)

Write-ModuleLog -Message "ConfigurationManagement component loaded successfully" -Level "DEBUG"