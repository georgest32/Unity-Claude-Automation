# Unity-Claude-Learning AST Analysis Component
# Abstract Syntax Tree parsing and analysis
# Part of refactored Learning module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "LearningCore.psm1"
Import-Module $CorePath -Force

function Get-CodeAST {
    <#
    .SYNOPSIS
    Parses code file into Abstract Syntax Tree
    .DESCRIPTION
    Supports PowerShell and C# code parsing for pattern analysis
    .PARAMETER FilePath
    Path to the code file
    .PARAMETER Language
    Programming language (PowerShell or CSharp)
    .EXAMPLE
    Get-CodeAST -FilePath "script.ps1" -Language PowerShell
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath,
        
        [ValidateSet('PowerShell','CSharp')]
        [string]$Language = 'PowerShell'
    )
    
    if (-not (Test-Path $FilePath)) {
        Write-Error "File not found: $FilePath"
        return $null
    }
    
    $content = Get-Content $FilePath -Raw
    
    switch ($Language) {
        'PowerShell' {
            try {
                $tokens = $null
                $errors = $null
                $ast = [System.Management.Automation.Language.Parser]::ParseInput(
                    $content, 
                    [ref]$tokens, 
                    [ref]$errors
                )
                
                return @{
                    AST = $ast
                    Tokens = $tokens
                    Errors = $errors
                    Language = 'PowerShell'
                }
            } catch {
                Write-Error "Failed to parse PowerShell AST: $_"
                return $null
            }
        }
        
        'CSharp' {
            # For C#, we'll use Roslyn if available, or regex patterns as fallback
            Write-Warning "C# AST parsing requires Roslyn - using pattern matching instead"
            
            # Extract basic structure using regex
            $patterns = @{
                Classes = [regex]::Matches($content, 'class\s+(\w+)')
                Methods = [regex]::Matches($content, '(public|private|protected|internal)\s+\w+\s+(\w+)\s*\(')
                Properties = [regex]::Matches($content, '(public|private|protected|internal)\s+\w+\s+(\w+)\s*{')
                Usings = [regex]::Matches($content, 'using\s+([\w.]+);')
            }
            
            return @{
                AST = $null  # Placeholder for Roslyn AST
                Patterns = $patterns
                Language = 'CSharp'
                Content = $content
            }
        }
    }
}

function Find-CodePattern {
    <#
    .SYNOPSIS
    Finds patterns in code AST that match error signatures
    .DESCRIPTION
    Analyzes AST to find patterns matching error conditions
    .PARAMETER AST
    Abstract Syntax Tree to analyze
    .PARAMETER ErrorMessage
    Error message to match against
    .EXAMPLE
    Find-CodePattern -AST $ast -ErrorMessage "Variable 'x' is not defined"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$AST,
        
        [Parameter(Mandatory)]
        [string]$ErrorMessage
    )
    
    $patterns = @()
    
    # Extract error type from message
    $errorType = switch -Regex ($ErrorMessage) {
        'CS0246' { 'MissingUsing' }
        'CS0103' { 'UndefinedVariable' }
        'CS1061' { 'MissingMethod' }
        'CS0029' { 'TypeMismatch' }
        'null reference' { 'NullReference' }
        default { 'Unknown' }
    }
    
    # Build pattern signature
    $signature = @{
        ErrorType = $errorType
        ErrorMessage = $ErrorMessage
        Timestamp = Get-Date
    }
    
    # PowerShell AST analysis
    if ($AST.Language -eq 'PowerShell' -and $AST.AST) {
        # Find all variable assignments
        $variables = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.VariableExpressionAst]}, $true)
        
        # Find all function calls
        $functions = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.CommandAst]}, $true)
        
        # Find all pipeline operations
        $pipelines = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.PipelineAst]}, $true)
        
        $signature.Variables = $variables.Count
        $signature.Functions = $functions.Count
        $signature.Pipelines = $pipelines.Count
    }
    
    # Generate pattern hash for matching
    $patternHash = [System.BitConverter]::ToString(
        [System.Security.Cryptography.SHA256]::Create().ComputeHash(
            [System.Text.Encoding]::UTF8.GetBytes($ErrorMessage)
        )
    ).Replace("-","").Substring(0,16)
    
    $signature.PatternHash = $patternHash
    
    return $signature
}

function Get-ASTStatistics {
    <#
    .SYNOPSIS
    Generates statistics from AST analysis
    .DESCRIPTION
    Provides detailed metrics about code structure
    .PARAMETER AST
    AST object to analyze
    .EXAMPLE
    Get-ASTStatistics -AST $ast
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$AST
    )
    
    $stats = @{
        Language = $AST.Language
        TotalLines = 0
        Functions = 0
        Variables = 0
        Commands = 0
        Comments = 0
        Errors = 0
    }
    
    if ($AST.Language -eq 'PowerShell' -and $AST.AST) {
        # Count various AST elements
        $stats.Functions = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst]}, $true).Count
        $stats.Variables = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.VariableExpressionAst]}, $true).Count
        $stats.Commands = $AST.AST.FindAll({$args[0] -is [System.Management.Automation.Language.CommandAst]}, $true).Count
        
        # Count errors
        if ($AST.Errors) {
            $stats.Errors = $AST.Errors.Count
        }
        
        # Count lines
        $stats.TotalLines = $AST.AST.Extent.EndLineNumber - $AST.AST.Extent.StartLineNumber + 1
    }
    
    return $stats
}

function Compare-ASTStructures {
    <#
    .SYNOPSIS
    Compares two AST structures for similarities
    .DESCRIPTION
    Identifies structural similarities between code patterns
    .PARAMETER AST1
    First AST to compare
    .PARAMETER AST2
    Second AST to compare
    .EXAMPLE
    Compare-ASTStructures -AST1 $ast1 -AST2 $ast2
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$AST1,
        
        [Parameter(Mandatory)]
        [object]$AST2
    )
    
    if ($AST1.Language -ne $AST2.Language) {
        Write-Warning "ASTs are from different languages"
        return @{
            Similarity = 0.0
            LanguageMatch = $false
        }
    }
    
    $stats1 = Get-ASTStatistics -AST $AST1
    $stats2 = Get-ASTStatistics -AST $AST2
    
    # Calculate structural similarity
    $similarities = @()
    
    foreach ($key in $stats1.Keys) {
        if ($key -eq 'Language' -or $key -eq 'Errors') { continue }
        
        $val1 = $stats1[$key]
        $val2 = $stats2[$key]
        
        if ($val1 -eq 0 -and $val2 -eq 0) {
            $similarity = 1.0
        } elseif ($val1 -eq 0 -or $val2 -eq 0) {
            $similarity = 0.0
        } else {
            $similarity = 1.0 - ([Math]::Abs($val1 - $val2) / [Math]::Max($val1, $val2))
        }
        
        $similarities += $similarity
    }
    
    $overallSimilarity = if ($similarities.Count -gt 0) {
        ($similarities | Measure-Object -Average).Average
    } else {
        0.0
    }
    
    return @{
        Similarity = [Math]::Round($overallSimilarity, 3)
        LanguageMatch = $true
        Stats1 = $stats1
        Stats2 = $stats2
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Get-CodeAST',
    'Find-CodePattern',
    'Get-ASTStatistics',
    'Compare-ASTStructures'
)

Write-ModuleLog -Message "ASTAnalysis component loaded successfully" -Level "DEBUG"