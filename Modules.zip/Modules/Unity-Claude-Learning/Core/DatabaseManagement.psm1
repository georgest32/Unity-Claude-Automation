# Unity-Claude-Learning Database Management Component
# Database setup and operations for learning system
# Part of refactored Learning module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "LearningCore.psm1"
Import-Module $CorePath -Force

function Initialize-LearningDatabase {
    <#
    .SYNOPSIS
    Initializes the learning database for pattern storage
    
    .DESCRIPTION
    Creates SQLite database with tables for error patterns, fixes, and metrics
    #>
    [CmdletBinding()]
    param(
        [string]$DatabasePath = (Get-LearningConfig).DatabasePath
    )
    
    Write-LearningLog -Message "Initializing learning database at: $DatabasePath" -Level "VERBOSE"
    
    # Create database directory if needed
    $dbDir = Split-Path $DatabasePath -Parent
    if (-not (Test-Path $dbDir)) {
        New-Item -Path $dbDir -ItemType Directory -Force | Out-Null
    }
    
    # Initialize SQLite connection
    $connection = New-Object System.Data.SQLite.SQLiteConnection
    $connection.ConnectionString = "Data Source=$DatabasePath;Version=3;"
    
    try {
        $connection.Open()
        
        # Create tables
        $createTables = @"
-- Error patterns table
CREATE TABLE IF NOT EXISTS ErrorPatterns (
    PatternID INTEGER PRIMARY KEY AUTOINCREMENT,
    ErrorSignature TEXT NOT NULL,
    ErrorType TEXT,
    ASTPattern TEXT,
    SuccessRate REAL DEFAULT 0.0,
    UseCount INTEGER DEFAULT 0,
    LastSeen DATETIME DEFAULT CURRENT_TIMESTAMP,
    Created DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Fix patterns table
CREATE TABLE IF NOT EXISTS FixPatterns (
    FixID INTEGER PRIMARY KEY AUTOINCREMENT,
    PatternID INTEGER NOT NULL,
    FixDescription TEXT,
    FixAST TEXT,
    FixCode TEXT,
    SuccessCount INTEGER DEFAULT 0,
    FailureCount INTEGER DEFAULT 0,
    LastUsed DATETIME,
    Created DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (PatternID) REFERENCES ErrorPatterns(PatternID)
);

-- Success metrics table
CREATE TABLE IF NOT EXISTS SuccessMetrics (
    MetricID INTEGER PRIMARY KEY AUTOINCREMENT,
    PatternID INTEGER,
    FixID INTEGER,
    Success BOOLEAN,
    ExecutionTime REAL,
    ErrorBefore TEXT,
    ErrorAfter TEXT,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (PatternID) REFERENCES ErrorPatterns(PatternID),
    FOREIGN KEY (FixID) REFERENCES FixPatterns(FixID)
);

-- Pattern relationships table
CREATE TABLE IF NOT EXISTS PatternRelationships (
    RelationID INTEGER PRIMARY KEY AUTOINCREMENT,
    ParentPatternID INTEGER,
    ChildPatternID INTEGER,
    RelationType TEXT,
    Confidence REAL,
    FOREIGN KEY (ParentPatternID) REFERENCES ErrorPatterns(PatternID),
    FOREIGN KEY (ChildPatternID) REFERENCES ErrorPatterns(PatternID)
);

-- Pattern similarity table for fuzzy matching
CREATE TABLE IF NOT EXISTS PatternSimilarity (
    SimilarityID INTEGER PRIMARY KEY AUTOINCREMENT,
    SourcePatternID INTEGER NOT NULL,
    TargetPatternID INTEGER NOT NULL,
    SimilarityScore REAL NOT NULL,
    Algorithm TEXT DEFAULT 'Levenshtein',
    Calculated DATETIME DEFAULT CURRENT_TIMESTAMP,
    LastUsed DATETIME,
    UseCount INTEGER DEFAULT 0,
    FOREIGN KEY (SourcePatternID) REFERENCES ErrorPatterns(PatternID),
    FOREIGN KEY (TargetPatternID) REFERENCES ErrorPatterns(PatternID),
    UNIQUE(SourcePatternID, TargetPatternID, Algorithm)
);

-- Confidence scoring cache for performance
CREATE TABLE IF NOT EXISTS ConfidenceScores (
    ScoreID INTEGER PRIMARY KEY AUTOINCREMENT,
    PatternID INTEGER NOT NULL,
    FixID INTEGER,
    BaseConfidence REAL NOT NULL,
    SimilarityBonus REAL DEFAULT 0.0,
    SuccessRateBonus REAL DEFAULT 0.0,
    FinalConfidence REAL NOT NULL,
    Context TEXT,
    Calculated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (PatternID) REFERENCES ErrorPatterns(PatternID),
    FOREIGN KEY (FixID) REFERENCES FixPatterns(FixID)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_error_signature ON ErrorPatterns(ErrorSignature);
CREATE INDEX IF NOT EXISTS idx_pattern_success ON ErrorPatterns(SuccessRate);
CREATE INDEX IF NOT EXISTS idx_fix_success ON FixPatterns(SuccessCount);
CREATE INDEX IF NOT EXISTS idx_similarity_source ON PatternSimilarity(SourcePatternID);
CREATE INDEX IF NOT EXISTS idx_similarity_score ON PatternSimilarity(SimilarityScore);
CREATE INDEX IF NOT EXISTS idx_confidence_pattern ON ConfidenceScores(PatternID);
CREATE INDEX IF NOT EXISTS idx_confidence_final ON ConfidenceScores(FinalConfidence);
"@
        
        $command = $connection.CreateCommand()
        $command.CommandText = $createTables
        $command.ExecuteNonQuery() | Out-Null
        
        Write-LearningLog -Message "Learning database initialized successfully" -Level "VERBOSE"
        return @{
            Success = $true
            DatabasePath = $DatabasePath
        }
        
    } catch {
        Write-LearningLog -Message "Failed to initialize learning database: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    } finally {
        if ($connection.State -eq 'Open') {
            $connection.Close()
        }
        $connection.Dispose()
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Initialize-LearningDatabase'
)

Write-LearningLog -Message "DatabaseManagement component loaded successfully" -Level "DEBUG"