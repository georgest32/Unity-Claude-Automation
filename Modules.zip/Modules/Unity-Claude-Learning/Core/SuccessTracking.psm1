# Unity-Claude-Learning Success Tracking Component
# Tracks success metrics and pattern effectiveness
# Part of refactored Learning module

$ErrorActionPreference = "Stop"

# Import core component
$CorePath = Join-Path $PSScriptRoot "LearningCore.psm1"
Import-Module $CorePath -Force

# Initialize success metrics
$script:SuccessMetrics = @{
    TotalAttempts = 0
    SuccessfulFixes = 0
    FailedFixes = 0
    PatternsLearned = 0
    PatternsApplied = 0
    LastUpdateTime = Get-Date
    SessionStartTime = Get-Date
}

function Update-SuccessMetrics {
    <#
    .SYNOPSIS
    Updates success tracking metrics
    .DESCRIPTION
    Records success/failure of pattern applications
    .PARAMETER Success
    Whether the operation was successful
    .PARAMETER Operation
    Type of operation (Fix, Learn, Apply)
    .PARAMETER PatternID
    Associated pattern ID if applicable
    .EXAMPLE
    Update-SuccessMetrics -Success $true -Operation "Fix"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [bool]$Success,
        
        [Parameter(Mandatory)]
        [ValidateSet('Fix', 'Learn', 'Apply', 'Match')]
        [string]$Operation,
        
        [string]$PatternID = ""
    )
    
    $script:SuccessMetrics.TotalAttempts++
    $script:SuccessMetrics.LastUpdateTime = Get-Date
    
    switch ($Operation) {
        'Fix' {
            if ($Success) {
                $script:SuccessMetrics.SuccessfulFixes++
            } else {
                $script:SuccessMetrics.FailedFixes++
            }
        }
        'Learn' {
            if ($Success) {
                $script:SuccessMetrics.PatternsLearned++
            }
        }
        'Apply' {
            if ($Success) {
                $script:SuccessMetrics.PatternsApplied++
            }
        }
    }
    
    # Log the update
    Write-ModuleLog -Message "Success metrics updated: $Operation = $Success" -Level "DEBUG"
    
    # Persist metrics if configured
    $config = Get-LearningConfiguration
    if ($config.StorageBackend -ne "Memory") {
        Save-SuccessMetrics
    }
}

function Get-SuccessMetrics {
    <#
    .SYNOPSIS
    Retrieves current success metrics
    .DESCRIPTION
    Returns comprehensive success tracking data
    .PARAMETER IncludeRates
    Include calculated success rates
    .EXAMPLE
    Get-SuccessMetrics -IncludeRates
    #>
    [CmdletBinding()]
    param(
        [switch]$IncludeRates
    )
    
    $metrics = $script:SuccessMetrics.Clone()
    
    if ($IncludeRates) {
        # Calculate success rates
        if ($metrics.TotalAttempts -gt 0) {
            $metrics.OverallSuccessRate = ($metrics.SuccessfulFixes / $metrics.TotalAttempts) * 100
        } else {
            $metrics.OverallSuccessRate = 0
        }
        
        $totalFixes = $metrics.SuccessfulFixes + $metrics.FailedFixes
        if ($totalFixes -gt 0) {
            $metrics.FixSuccessRate = ($metrics.SuccessfulFixes / $totalFixes) * 100
        } else {
            $metrics.FixSuccessRate = 0
        }
        
        if ($metrics.PatternsLearned -gt 0) {
            $metrics.PatternUtilizationRate = ($metrics.PatternsApplied / $metrics.PatternsLearned) * 100
        } else {
            $metrics.PatternUtilizationRate = 0
        }
        
        # Session duration
        $metrics.SessionDuration = (Get-Date) - $metrics.SessionStartTime
    }
    
    return $metrics
}

function Reset-SuccessMetrics {
    <#
    .SYNOPSIS
    Resets success metrics to initial state
    .DESCRIPTION
    Clears all tracked metrics and starts fresh
    .PARAMETER Confirm
    Requires confirmation before reset
    .EXAMPLE
    Reset-SuccessMetrics -Confirm
    #>
    [CmdletBinding()]
    param(
        [switch]$Confirm
    )
    
    if ($Confirm) {
        $response = Read-Host "Are you sure you want to reset all success metrics? (Y/N)"
        if ($response -ne 'Y') {
            Write-Host "Reset cancelled"
            return
        }
    }
    
    $script:SuccessMetrics = @{
        TotalAttempts = 0
        SuccessfulFixes = 0
        FailedFixes = 0
        PatternsLearned = 0
        PatternsApplied = 0
        LastUpdateTime = Get-Date
        SessionStartTime = Get-Date
    }
    
    Write-ModuleLog -Message "Success metrics reset" -Level "INFO"
    
    # Clear persisted metrics
    $config = Get-LearningConfiguration
    if ($config.StorageBackend -ne "Memory") {
        Clear-PersistedMetrics
    }
}

function Save-SuccessMetrics {
    <#
    .SYNOPSIS
    Persists success metrics to storage
    .DESCRIPTION
    Saves current metrics to configured storage backend
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-LearningConfiguration
    $metricsPath = Join-Path $config.StoragePath "success_metrics.json"
    
    try {
        $script:SuccessMetrics | ConvertTo-Json -Depth 3 | Set-Content -Path $metricsPath -Encoding UTF8
        Write-ModuleLog -Message "Success metrics saved to $metricsPath" -Level "DEBUG"
    } catch {
        Write-ModuleLog -Message "Failed to save success metrics: $_" -Level "WARNING"
    }
}

function Load-SuccessMetrics {
    <#
    .SYNOPSIS
    Loads success metrics from storage
    .DESCRIPTION
    Restores previously saved metrics
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-LearningConfiguration
    $metricsPath = Join-Path $config.StoragePath "success_metrics.json"
    
    if (Test-Path $metricsPath) {
        try {
            $loaded = Get-Content -Path $metricsPath -Raw | ConvertFrom-Json
            
            # Convert to hashtable
            $script:SuccessMetrics = @{}
            $loaded.PSObject.Properties | ForEach-Object {
                $script:SuccessMetrics[$_.Name] = $_.Value
            }
            
            # Update session start time
            $script:SuccessMetrics.SessionStartTime = Get-Date
            
            Write-ModuleLog -Message "Success metrics loaded from $metricsPath" -Level "DEBUG"
        } catch {
            Write-ModuleLog -Message "Failed to load success metrics: $_" -Level "WARNING"
        }
    }
}

function Clear-PersistedMetrics {
    <#
    .SYNOPSIS
    Clears persisted metrics from storage
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-LearningConfiguration
    $metricsPath = Join-Path $config.StoragePath "success_metrics.json"
    
    if (Test-Path $metricsPath) {
        Remove-Item -Path $metricsPath -Force
        Write-ModuleLog -Message "Persisted metrics cleared" -Level "DEBUG"
    }
}

function Get-PatternEffectiveness {
    <#
    .SYNOPSIS
    Analyzes pattern effectiveness over time
    .DESCRIPTION
    Provides detailed analysis of pattern success rates
    .PARAMETER MinUseCount
    Minimum usage count to include in analysis
    .EXAMPLE
    Get-PatternEffectiveness -MinUseCount 5
    #>
    [CmdletBinding()]
    param(
        [int]$MinUseCount = 1
    )
    
    $config = Get-LearningConfiguration
    
    switch ($config.StorageBackend) {
        "SQLite" {
            return Get-PatternEffectivenessSQLite -MinUseCount $MinUseCount
        }
        "JSON" {
            return Get-PatternEffectivenessJSON -MinUseCount $MinUseCount
        }
        default {
            Write-Warning "Pattern effectiveness requires database storage"
            return @()
        }
    }
}

function Get-PatternEffectivenessSQLite {
    <#
    .SYNOPSIS
    Gets pattern effectiveness from SQLite
    #>
    [CmdletBinding()]
    param(
        [int]$MinUseCount = 1
    )
    
    $config = Get-LearningConfiguration
    $connection = New-Object System.Data.SQLite.SQLiteConnection
    $connection.ConnectionString = "Data Source=$($config.DatabasePath);Version=3;"
    
    try {
        $connection.Open()
        
        $cmd = $connection.CreateCommand()
        $cmd.CommandText = @"
            SELECT 
                PatternID,
                ErrorType,
                UseCount,
                SuccessCount,
                FailureCount,
                SuccessRate,
                LastUsed
            FROM ErrorPatterns
            WHERE UseCount >= @minCount
            ORDER BY SuccessRate DESC, UseCount DESC
"@
        $cmd.Parameters.AddWithValue("@minCount", $MinUseCount) | Out-Null
        
        $patterns = @()
        $reader = $cmd.ExecuteReader()
        
        while ($reader.Read()) {
            $patterns += [PSCustomObject]@{
                PatternID = $reader['PatternID']
                ErrorType = $reader['ErrorType']
                UseCount = $reader['UseCount']
                SuccessCount = $reader['SuccessCount']
                FailureCount = $reader['FailureCount']
                SuccessRate = [double]$reader['SuccessRate']
                LastUsed = $reader['LastUsed']
                Effectiveness = if ($reader['UseCount'] -gt 0) {
                    ($reader['SuccessCount'] / $reader['UseCount']) * 100
                } else { 0 }
            }
        }
        
        return $patterns
        
    } finally {
        if ($connection.State -eq 'Open') {
            $connection.Close()
        }
        $connection.Dispose()
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Update-SuccessMetrics',
    'Get-SuccessMetrics',
    'Reset-SuccessMetrics',
    'Save-SuccessMetrics',
    'Load-SuccessMetrics',
    'Clear-PersistedMetrics',
    'Get-PatternEffectiveness',
    'Get-PatternEffectivenessSQLite'
)

# Load existing metrics on module import
Load-SuccessMetrics

Write-ModuleLog -Message "SuccessTracking component loaded successfully" -Level "DEBUG"