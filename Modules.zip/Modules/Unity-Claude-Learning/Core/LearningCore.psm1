# Unity-Claude-Learning Core Component
# Core configuration and shared utilities for learning system
# Part of refactored Learning module

$ErrorActionPreference = "Stop"

# Module configuration state
$script:LearningConfig = @{
    DatabasePath = Join-Path (Split-Path $PSScriptRoot -Parent) "LearningDatabase.db"
    StoragePath = Split-Path $PSScriptRoot -Parent
    StorageBackend = "Unknown"  # Will be detected: "SQLite" or "JSON"
    MaxPatternAge = 30  # Days before pattern expires
    MinConfidence = 0.7  # Minimum confidence for auto-apply
    EnableAutoFix = $false  # Safety switch for self-patching
}

$script:PatternCache = @{}
$script:SuccessMetrics = @{
    TotalAttempts = 0
    SuccessfulFixes = 0
    FailedFixes = 0
    PatternsLearned = 0
}

# Shared logging function
function Write-LearningLog {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARNING", "ERROR", "DEBUG", "VERBOSE")]
        [string]$Level = "INFO"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [Unity-Claude-Learning] [$Level] $Message"
    
    switch ($Level) {
        "ERROR" { Write-Error $logMessage }
        "WARNING" { Write-Warning $logMessage }
        "DEBUG" { Write-Debug $logMessage }
        "VERBOSE" { Write-Verbose $logMessage }
        default { Write-Host $logMessage }
    }
}

# Get configuration
function Get-LearningConfig {
    <#
    .SYNOPSIS
    Gets the current learning module configuration
    
    .DESCRIPTION
    Returns the current configuration settings for the learning module
    #>
    [CmdletBinding()]
    param()
    
    return $script:LearningConfig.Clone()
}

# Set configuration
function Set-LearningConfig {
    <#
    .SYNOPSIS
    Sets learning module configuration
    
    .DESCRIPTION
    Updates configuration settings for the learning module
    #>
    [CmdletBinding()]
    param(
        [string]$DatabasePath,
        [string]$StoragePath,
        [int]$MaxPatternAge,
        [double]$MinConfidence,
        [bool]$EnableAutoFix
    )
    
    if ($PSBoundParameters.ContainsKey('DatabasePath')) {
        $script:LearningConfig.DatabasePath = $DatabasePath
        Write-LearningLog -Message "Updated DatabasePath to: $DatabasePath" -Level "INFO"
    }
    
    if ($PSBoundParameters.ContainsKey('StoragePath')) {
        $script:LearningConfig.StoragePath = $StoragePath
        Write-LearningLog -Message "Updated StoragePath to: $StoragePath" -Level "INFO"
    }
    
    if ($PSBoundParameters.ContainsKey('MaxPatternAge')) {
        $script:LearningConfig.MaxPatternAge = $MaxPatternAge
        Write-LearningLog -Message "Updated MaxPatternAge to: $MaxPatternAge days" -Level "INFO"
    }
    
    if ($PSBoundParameters.ContainsKey('MinConfidence')) {
        $script:LearningConfig.MinConfidence = $MinConfidence
        Write-LearningLog -Message "Updated MinConfidence to: $MinConfidence" -Level "INFO"
    }
    
    if ($PSBoundParameters.ContainsKey('EnableAutoFix')) {
        $script:LearningConfig.EnableAutoFix = $EnableAutoFix
        $status = if ($EnableAutoFix) { "enabled" } else { "disabled" }
        Write-LearningLog -Message "Auto-fix functionality $status" -Level "WARNING"
    }
}

# Get pattern cache
function Get-PatternCache {
    <#
    .SYNOPSIS
    Returns the current pattern cache
    #>
    [CmdletBinding()]
    param()
    
    return $script:PatternCache.Clone()
}

# Update pattern cache
function Update-PatternCache {
    param(
        [string]$Key,
        [object]$Value
    )
    
    $script:PatternCache[$Key] = $Value
    Write-LearningLog -Message "Updated pattern cache for key: $Key" -Level "DEBUG"
}

# Clear pattern cache
function Clear-PatternCache {
    <#
    .SYNOPSIS
    Clears the pattern cache
    #>
    [CmdletBinding()]
    param()
    
    $script:PatternCache.Clear()
    Write-LearningLog -Message "Pattern cache cleared" -Level "INFO"
}

# Get success metrics
function Get-SuccessMetrics {
    <#
    .SYNOPSIS
    Returns current success metrics
    #>
    [CmdletBinding()]
    param()
    
    return $script:SuccessMetrics.Clone()
}

# Update success metrics
function Update-SuccessMetrics {
    param(
        [ValidateSet("TotalAttempts", "SuccessfulFixes", "FailedFixes", "PatternsLearned")]
        [string]$Metric,
        [int]$Increment = 1
    )
    
    $script:SuccessMetrics[$Metric] += $Increment
    Write-LearningLog -Message "Updated $Metric by $Increment (now: $($script:SuccessMetrics[$Metric]))" -Level "DEBUG"
}

# Utility function to measure execution time
function Measure-ExecutionTime {
    <#
    .SYNOPSIS
    Measures the execution time of a script block
    
    .DESCRIPTION
    Utility function to track performance of operations
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,
        
        [string]$Label = "Operation"
    )
    
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    
    try {
        $result = & $ScriptBlock
        $stopwatch.Stop()
        
        return @{
            Result = $result
            ElapsedMilliseconds = $stopwatch.ElapsedMilliseconds
            Success = $true
            Label = $Label
        }
    }
    catch {
        $stopwatch.Stop()
        
        return @{
            Error = $_.Exception.Message
            ElapsedMilliseconds = $stopwatch.ElapsedMilliseconds
            Success = $false
            Label = $Label
        }
    }
}

# Export module members
Export-ModuleMember -Function @(, Write-ModuleLog, Get-LearningConfiguration
    'Write-LearningLog',
    'Get-LearningConfig',
    'Set-LearningConfig',
    'Get-PatternCache',
    'Update-PatternCache',
    'Clear-PatternCache',
    'Get-SuccessMetrics',
    'Update-SuccessMetrics',
    'Measure-ExecutionTime'
) -Variable @(
    'LearningConfig',
    'PatternCache',
    'SuccessMetrics'
)

Write-LearningLog -Message "LearningCore component loaded successfully" -Level "DEBUG"
