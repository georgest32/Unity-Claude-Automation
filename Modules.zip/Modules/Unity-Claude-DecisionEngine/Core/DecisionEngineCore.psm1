# DecisionEngineCore.psm1
# Core configuration, logging, and utilities for Decision Engine
# Part of the refactored Unity-Claude-DecisionEngine module

# Module-level variables
$script:DecisionEngineConfig = @{
    EnableDebugLogging = $true
    ConfidenceThreshold = 0.7
    MaxDecisionRetries = 3
    DecisionTimeoutMs = 5000
    EnableAIEnhancement = $true
    ContextWindowSize = 10
    LearningEnabled = $true
}

$script:LogPath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation\unity_claude_automation.log"

# Decision state tracking
$script:DecisionHistory = [System.Collections.Generic.List[hashtable]]::new()
$script:ContextBuffer = [System.Collections.Queue]::new()
$script:ActiveDecisions = @{}

#region Logging and Utilities

function Write-DecisionEngineLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter()]
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG")]
        [string]$Level = "INFO"
    )
    
    if (-not $script:DecisionEngineConfig.EnableDebugLogging -and $Level -eq "DEBUG") {
        return
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] [DecisionEngine] $Message"
    
    try {
        Add-Content -Path $script:LogPath -Value $logEntry -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {
        # Silently continue if logging fails
    }
    
    if ($Level -eq "ERROR") {
        Write-Error $Message
    } elseif ($Level -eq "WARN") {
        Write-Warning $Message
    } elseif ($script:DecisionEngineConfig.EnableDebugLogging) {
        Write-Host "[$Level] $Message" -ForegroundColor $(
            switch ($Level) {
                "INFO" { "Green" }
                "DEBUG" { "Gray" }
                default { "White" }
            }
        )
    }
}

function Test-RequiredModule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModuleName
    )
    
    $module = Get-Module -Name $ModuleName -ErrorAction SilentlyContinue
    if (-not $module) {
        Write-DecisionEngineLog -Message "Required module '$ModuleName' not loaded" -Level "WARN"
        return $false
    }
    return $true
}

#endregion

#region Configuration Management

function Get-DecisionEngineConfig {
    [CmdletBinding()]
    param()
    
    Write-DecisionEngineLog -Message "Retrieving Decision Engine configuration" -Level "DEBUG"
    return $script:DecisionEngineConfig.Clone()
}

function Set-DecisionEngineConfig {
    [CmdletBinding()]
    param(
        [Parameter()]
        [hashtable]$Configuration
    )
    
    if ($Configuration) {
        foreach ($key in $Configuration.Keys) {
            if ($script:DecisionEngineConfig.ContainsKey($key)) {
                $script:DecisionEngineConfig[$key] = $Configuration[$key]
                Write-DecisionEngineLog -Message "Updated configuration: $key = $($Configuration[$key])" -Level "DEBUG"
            } else {
                Write-DecisionEngineLog -Message "Unknown configuration key: $key" -Level "WARN"
            }
        }
    }
    
    return $script:DecisionEngineConfig
}

#endregion

#region State Management

function Get-DecisionHistory {
    [CmdletBinding()]
    param(
        [Parameter()]
        [int]$Limit = 10
    )
    
    Write-DecisionEngineLog -Message "Retrieving decision history (limit: $Limit)" -Level "DEBUG"
    
    $history = $script:DecisionHistory
    if ($Limit -gt 0 -and $history.Count -gt $Limit) {
        $history = $history[-$Limit..-1]
    }
    
    return $history
}

function Clear-DecisionHistory {
    [CmdletBinding()]
    param()
    
    Write-DecisionEngineLog -Message "Clearing decision history" -Level "INFO"
    $script:DecisionHistory.Clear()
    $script:ContextBuffer.Clear()
    $script:ActiveDecisions = @{}
}

function Add-DecisionToHistory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Decision
    )
    
    $Decision.Timestamp = Get-Date
    $script:DecisionHistory.Add($Decision)
    
    # Limit history size
    if ($script:DecisionHistory.Count -gt 100) {
        $script:DecisionHistory.RemoveAt(0)
    }
    
    Write-DecisionEngineLog -Message "Added decision to history: $($Decision.Action)" -Level "DEBUG"
}

#endregion

# Export module members
Export-ModuleMember -Function @(
    'Write-DecisionEngineLog',
    'Test-RequiredModule',
    'Get-DecisionEngineConfig',
    'Set-DecisionEngineConfig',
    'Get-DecisionHistory',
    'Clear-DecisionHistory',
    'Add-DecisionToHistory'
) -Variable @(
    'DecisionEngineConfig',
    'LogPath',
    'DecisionHistory',
    'ContextBuffer',
    'ActiveDecisions'
)