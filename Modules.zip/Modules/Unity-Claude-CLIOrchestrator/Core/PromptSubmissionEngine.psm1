#region PromptSubmissionEngine Component
<#
.SYNOPSIS
    Unity-Claude CLI Orchestrator - Prompt Submission Engine Component
    
.DESCRIPTION
    Handles secure and reliable prompt submission to Claude Code CLI using
    TypeKeys technology with input locking and validation.
    
.COMPONENT
    Part of Unity-Claude-CLIOrchestrator refactored architecture
    
.FUNCTIONS
    - Submit-ToClaudeViaTypeKeys: Main prompt submission function with safety measures
    - Execute-TestScript: Executes test scripts with result collection
#>
#endregion

function Submit-ToClaudeViaTypeKeys {
    <#
    .SYNOPSIS
        Submits prompt to Claude via TypeKeys with input locking and safety measures
        
    .DESCRIPTION
        Provides secure prompt submission with user abort capability, window validation,
        and input blocking to prevent interference during submission
        
    .PARAMETER PromptText
        The text prompt to submit to Claude
        
    .OUTPUTS
        Boolean - True if submission was successful, False otherwise
        
    .EXAMPLE
        $success = Submit-ToClaudeViaTypeKeys -PromptText "Analyze this code"
    #>
    [CmdletBinding()]
    param([string]$PromptText)
    
    Write-Host ""
    Write-Host "[SUBMISSION] Preparing to submit to Claude Code CLI..." -ForegroundColor Cyan
    Write-Host "  Press Ctrl+C within 3 seconds to abort submission..." -ForegroundColor Yellow
    
    # Abort window - give user chance to cancel
    for ($i = 3; $i -gt 0; $i--) {
        Write-Host "  Starting in $i seconds... (Ctrl+C to abort)" -ForegroundColor Yellow
        Start-Sleep -Seconds 1
    }
    
    try {
        # Find Claude window
        $claudeWindow = Find-ClaudeWindow
        
        if (-not $claudeWindow) {
            Write-Host "  Failed to find Claude Code CLI window!" -ForegroundColor Red
            return $false
        }
        
        # Switch to Claude window
        Write-Host "  Switching to Claude window..." -ForegroundColor Gray
        $switched = Switch-ToWindow -WindowHandle $claudeWindow
        
        if (-not $switched) {
            Write-Host "  Failed to switch to Claude window!" -ForegroundColor Red
            return $false
        }
        
        Write-Host "  Window switch successful, preparing text submission..." -ForegroundColor Green
        
        # Save current cursor position
        $originalPos = [WindowAPI+POINT]::new()
        [WindowAPI]::GetCursorPos([ref]$originalPos) | Out-Null
        
        try {
            # Block mouse and keyboard input to prevent interference
            Write-Host "  Blocking input during submission..." -ForegroundColor Gray
            [WindowAPI]::BlockInput($true) | Out-Null
            
            # Additional safety - capture input to Claude window
            [WindowAPI]::SetCapture($claudeWindow) | Out-Null
            
            # Short delay to ensure window focus is stable
            Start-Sleep -Milliseconds 500
            
            # Clear any existing content (Ctrl+A, Delete)
            Write-Host "  Clearing existing content..." -ForegroundColor Gray
            [System.Windows.Forms.SendKeys]::SendWait("^a")
            Start-Sleep -Milliseconds 100
            [System.Windows.Forms.SendKeys]::SendWait("{DELETE}")
            Start-Sleep -Milliseconds 200
            
            # Split prompt into chunks to handle long text reliably
            $maxChunkSize = 500
            $chunks = @()
            for ($i = 0; $i -lt $PromptText.Length; $i += $maxChunkSize) {
                $chunkEnd = [Math]::Min($i + $maxChunkSize - 1, $PromptText.Length - 1)
                $chunks += $PromptText.Substring($i, $chunkEnd - $i + 1)
            }
            
            Write-Host "  Typing prompt text ($($chunks.Count) chunks)..." -ForegroundColor Gray
            
            # Type each chunk with small delays
            for ($i = 0; $i -lt $chunks.Count; $i++) {
                $chunk = $chunks[$i]
                
                # Escape special characters for SendKeys
                $chunk = $chunk.Replace("{", "{{").Replace("}", "}}")
                $chunk = $chunk.Replace("+", "{{+}}").Replace("^", "{{^}}")
                $chunk = $chunk.Replace("%", "{{%}}").Replace("~", "{{~}}")
                $chunk = $chunk.Replace("(", "{{(}}").Replace(")", "{{)}}")
                $chunk = $chunk.Replace("[", "{{[}}").Replace("]", "{{]}}")
                
                # Type the chunk
                [System.Windows.Forms.SendKeys]::SendWait($chunk)
                
                # Small delay between chunks
                if ($i -lt ($chunks.Count - 1)) {
                    Start-Sleep -Milliseconds 50
                }
                
                # Progress indicator for long texts
                if ($chunks.Count -gt 3) {
                    Write-Host "    Chunk $($i + 1)/$($chunks.Count) complete" -ForegroundColor DarkGray
                }
            }
            
            # Submit the prompt (Enter key)
            Write-Host "  Submitting prompt..." -ForegroundColor Gray
            Start-Sleep -Milliseconds 500
            [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
            
            Write-Host "  Prompt submitted successfully!" -ForegroundColor Green
            return $true
            
        } finally {
            # Always restore input even if something goes wrong
            Write-Host "  Restoring input controls..." -ForegroundColor Gray
            
            try {
                [WindowAPI]::ReleaseCapture() | Out-Null
                [WindowAPI]::BlockInput($false) | Out-Null
                
                # Restore cursor position
                [WindowAPI]::SetCursorPos($originalPos.X, $originalPos.Y) | Out-Null
                
            } catch {
                Write-Host "    Warning: Could not fully restore input state: $_" -ForegroundColor Yellow
            }
        }
        
    } catch {
        Write-Host "  ERROR in prompt submission: $_" -ForegroundColor Red
        
        # Emergency input restoration
        try {
            [WindowAPI]::ReleaseCapture() | Out-Null
            [WindowAPI]::BlockInput($false) | Out-Null
        } catch {
            Write-Host "    CRITICAL: Could not restore input! Manual intervention may be required." -ForegroundColor Red
        }
        
        return $false
    }
}

function Execute-TestScript {
    <#
    .SYNOPSIS
        Executes a test script and collects results
        
    .DESCRIPTION
        Runs PowerShell test scripts with proper error handling and result collection.
        Supports various test frameworks and provides detailed execution metrics.
        
    .PARAMETER ScriptPath
        Path to the test script to execute
        
    .PARAMETER Arguments
        Optional arguments to pass to the test script
        
    .PARAMETER WorkingDirectory
        Working directory for script execution (defaults to current directory)
        
    .PARAMETER TimeoutMinutes
        Timeout in minutes for script execution (default: 10)
        
    .OUTPUTS
        PSCustomObject with execution results including success status, output, and metrics
        
    .EXAMPLE
        $result = Execute-TestScript -ScriptPath ".\Test-Module.ps1" -Arguments "-Verbose"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ScriptPath,
        
        [string]$Arguments = "",
        [string]$WorkingDirectory = (Get-Location).Path,
        [int]$TimeoutMinutes = 10
    )
    
    $executionStart = Get-Date
    
    Write-Host "Executing test script: $ScriptPath" -ForegroundColor Cyan
    if ($Arguments) {
        Write-Host "  Arguments: $Arguments" -ForegroundColor Gray
    }
    Write-Host "  Working Directory: $WorkingDirectory" -ForegroundColor Gray
    Write-Host "  Timeout: $TimeoutMinutes minutes" -ForegroundColor Gray
    
    try {
        # Validate script exists
        if (-not (Test-Path $ScriptPath)) {
            throw "Test script not found: $ScriptPath"
        }
        
        # Create job for timeout support
        $jobScriptBlock = {
            param($ScriptPath, $Arguments, $WorkingDirectory)
            
            Set-Location $WorkingDirectory
            
            $pinfo = New-Object System.Diagnostics.ProcessStartInfo
            $pinfo.FileName = "powershell.exe"
            $pinfo.Arguments = "-ExecutionPolicy Bypass -File `"$ScriptPath`" $Arguments"
            $pinfo.UseShellExecute = $false
            $pinfo.RedirectStandardOutput = $true
            $pinfo.RedirectStandardError = $true
            $pinfo.CreateNoWindow = $true
            $pinfo.WorkingDirectory = $WorkingDirectory
            
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $pinfo
            
            $process.Start() | Out-Null
            
            $stdout = $process.StandardOutput.ReadToEnd()
            $stderr = $process.StandardError.ReadToEnd()
            
            $process.WaitForExit()
            
            return @{
                ExitCode = $process.ExitCode
                StandardOutput = $stdout
                StandardError = $stderr
            }
        }
        
        # Start job with timeout
        $job = Start-Job -ScriptBlock $jobScriptBlock -ArgumentList $ScriptPath, $Arguments, $WorkingDirectory
        
        # Wait for completion with timeout
        $completed = $job | Wait-Job -Timeout ($TimeoutMinutes * 60)
        
        if ($completed) {
            $result = Receive-Job -Job $job
            Remove-Job -Job $job -Force
            
            $executionTime = ((Get-Date) - $executionStart).TotalMilliseconds
            
            $success = ($result.ExitCode -eq 0)
            
            Write-Host "  Test execution completed" -ForegroundColor $(if ($success) { 'Green' } else { 'Yellow' })
            Write-Host "  Exit Code: $($result.ExitCode)" -ForegroundColor Gray
            Write-Host "  Execution Time: $([math]::Round($executionTime, 2))ms" -ForegroundColor Gray
            
            if ($result.StandardError -and $result.StandardError.Trim()) {
                Write-Host "  Errors detected:" -ForegroundColor Yellow
                $result.StandardError.Split("`n") | ForEach-Object {
                    if ($_.Trim()) {
                        Write-Host "    $_" -ForegroundColor Red
                    }
                }
            }
            
            return [PSCustomObject]@{
                Success = $success
                ExitCode = $result.ExitCode
                StandardOutput = $result.StandardOutput
                StandardError = $result.StandardError
                ExecutionTimeMs = $executionTime
                ScriptPath = $ScriptPath
                Arguments = $Arguments
                Timestamp = $executionStart
                TimeoutOccurred = $false
            }
            
        } else {
            # Timeout occurred
            Remove-Job -Job $job -Force
            
            Write-Host "  Test execution TIMED OUT after $TimeoutMinutes minutes!" -ForegroundColor Red
            
            return [PSCustomObject]@{
                Success = $false
                ExitCode = -1
                StandardOutput = ""
                StandardError = "Test execution timed out after $TimeoutMinutes minutes"
                ExecutionTimeMs = ($TimeoutMinutes * 60 * 1000)
                ScriptPath = $ScriptPath
                Arguments = $Arguments
                Timestamp = $executionStart
                TimeoutOccurred = $true
            }
        }
        
    } catch {
        $executionTime = ((Get-Date) - $executionStart).TotalMilliseconds
        
        Write-Host "  Test execution FAILED: $_" -ForegroundColor Red
        
        return [PSCustomObject]@{
            Success = $false
            ExitCode = -2
            StandardOutput = ""
            StandardError = $_.Exception.Message
            ExecutionTimeMs = $executionTime
            ScriptPath = $ScriptPath
            Arguments = $Arguments
            Timestamp = $executionStart
            TimeoutOccurred = $false
        }
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Submit-ToClaudeViaTypeKeys',
    'Execute-TestScript'
)