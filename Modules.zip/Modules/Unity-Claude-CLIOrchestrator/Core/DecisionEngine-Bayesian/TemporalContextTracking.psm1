# TemporalContextTracking.psm1
# Phase 7 Day 3-4 Hours 5-8: Temporal Context and Time-Series Analysis
# Temporal decision patterns and context relevance analysis
# Date: 2025-08-25

#region Temporal Context Tracking

# Temporal context storage
$script:TemporalContext = @{
    RecentDecisions = New-Object System.Collections.Queue
    MaxHistorySize = 50
    TimeWindows = @{
        Immediate = 60      # 1 minute
        Recent = 300        # 5 minutes
        Short = 1800        # 30 minutes
        Medium = 7200       # 2 hours
        Long = 86400        # 24 hours
    }
}

# Add temporal context to decision
function Add-TemporalContext {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Decision,
        
        [Parameter()]
        [int]$TimeWindowSeconds = 300
    )
    
    Write-DecisionLog "Adding temporal context with window: ${TimeWindowSeconds}s" "DEBUG"
    
    $now = Get-Date
    $decision.Timestamp = $now
    
    # Add to recent decisions queue
    $script:TemporalContext.RecentDecisions.Enqueue($decision)
    
    # Maintain queue size
    while ($script:TemporalContext.RecentDecisions.Count -gt $script:TemporalContext.MaxHistorySize) {
        $script:TemporalContext.RecentDecisions.Dequeue() | Out-Null
    }
    
    # Analyze recent patterns
    $recentDecisions = @($script:TemporalContext.RecentDecisions.ToArray() | 
        Where-Object { ($now - $_.Timestamp).TotalSeconds -le $TimeWindowSeconds })
    
    $temporalAnalysis = @{
        WindowSize = $TimeWindowSeconds
        DecisionCount = $recentDecisions.Count
        TimeRange = if ($recentDecisions.Count -gt 0) {
            @{
                Start = ($recentDecisions | Sort-Object Timestamp | Select-Object -First 1).Timestamp
                End = $now
            }
        } else { @{} }
    }
    
    # Analyze decision type frequency
    if ($recentDecisions.Count -gt 0) {
        $typeFrequency = $recentDecisions | Group-Object DecisionType | ForEach-Object {
            @{
                Type = $_.Name
                Count = $_.Count
                Percentage = [Math]::Round(($_.Count / $recentDecisions.Count) * 100, 2)
            }
        } | Sort-Object Count -Descending
        
        $temporalAnalysis.TypeFrequency = $typeFrequency
        $temporalAnalysis.DominantType = $typeFrequency[0].Type
        
        # Calculate decision velocity (decisions per minute)
        $timeSpan = ($now - $temporalAnalysis.TimeRange.Start).TotalMinutes
        if ($timeSpan -gt 0) {
            $temporalAnalysis.DecisionVelocity = [Math]::Round($recentDecisions.Count / $timeSpan, 2)
        }
        
        # Detect patterns
        $temporalAnalysis.Patterns = @{
            Repetitive = ($typeFrequency[0].Percentage -gt 60)
            HighVelocity = ($temporalAnalysis.DecisionVelocity -gt 10)
            LowVariety = ($typeFrequency.Count -le 2)
        }
    }
    
    $decision.TemporalContext = $temporalAnalysis
    
    return $decision
}

# Get temporal context relevance
function Get-TemporalContextRelevance {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DecisionType,
        
        [Parameter()]
        [string]$TimeWindow = 'Recent'
    )
    
    $windowSeconds = $script:TemporalContext.TimeWindows[$TimeWindow]
    if (-not $windowSeconds) {
        Write-DecisionLog "Unknown time window: $TimeWindow - using Recent" "WARN"
        $windowSeconds = $script:TemporalContext.TimeWindows.Recent
    }
    
    $now = Get-Date
    $relevantDecisions = @($script:TemporalContext.RecentDecisions.ToArray() | 
        Where-Object { 
            ($now - $_.Timestamp).TotalSeconds -le $windowSeconds -and
            $_.DecisionType -eq $DecisionType
        })
    
    if ($relevantDecisions.Count -eq 0) {
        return @{
            Relevance = 0.5  # Neutral relevance
            SampleSize = 0
            TimeWindow = $TimeWindow
            Message = "No recent decisions of type $DecisionType"
        }
    }
    
    # Calculate success rate
    $successCount = @($relevantDecisions | Where-Object { $_.Success -eq $true }).Count
    $successRate = $successCount / $relevantDecisions.Count
    
    # Calculate recency weight (more recent = higher weight)
    $weights = $relevantDecisions | ForEach-Object {
        $age = ($now - $_.Timestamp).TotalSeconds
        1 - ($age / $windowSeconds)  # Linear decay
    }
    $averageWeight = ($weights | Measure-Object -Average).Average
    
    # Combine success rate and recency
    $relevance = ($successRate * 0.7) + ($averageWeight * 0.3)
    
    return @{
        Relevance = [Math]::Round($relevance, 3)
        SampleSize = $relevantDecisions.Count
        TimeWindow = $TimeWindow
        SuccessRate = [Math]::Round($successRate, 3)
        RecencyFactor = [Math]::Round($averageWeight, 3)
        Message = "Based on $($relevantDecisions.Count) recent decisions"
    }
}

#endregion

# Export temporal context functions
Export-ModuleMember -Function Add-TemporalContext, Get-TemporalContextRelevance -Variable TemporalContext