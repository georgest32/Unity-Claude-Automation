# LearningAdaptation.psm1
# Phase 7 Day 3-4 Hours 5-8: Bayesian Learning and Adaptation
# Learning from outcomes and persistent storage management
# Date: 2025-08-25

#region Learning and Adaptation

# Update Bayesian learning based on outcome
function Update-BayesianLearning {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DecisionType,
        
        [Parameter(Mandatory = $true)]
        [bool]$Success,
        
        [Parameter()]
        [double]$ObservedConfidence = 0.0,
        
        [Parameter()]
        [hashtable]$Context = @{}
    )
    
    Write-DecisionLog "Updating Bayesian learning for $DecisionType - Success: $Success" "DEBUG"
    
    try {
        # Update outcome history
        $history = $script:BayesianConfig.OutcomeHistory[$DecisionType]
        if ($history) {
            $history.Total++
            if ($Success) {
                $history.Success++
            } else {
                $history.Failure++
            }
            
            # Apply decay to old observations
            if ($history.Total -gt 100) {
                $decay = $script:BayesianConfig.ConfidenceDecay
                $history.Success = [Math]::Floor($history.Success * $decay)
                $history.Failure = [Math]::Floor($history.Failure * $decay)
                $history.Total = $history.Success + $history.Failure
            }
        }
        
        # Update prior probabilities based on new evidence
        if ($history.Total -ge $script:BayesianConfig.MinimumSamples) {
            $currentPrior = $script:BayesianConfig.PriorProbabilities[$DecisionType]
            $observedRate = $history.Success / $history.Total
            $learningRate = $script:BayesianConfig.LearningRate
            
            # Exponential moving average update
            $newPrior = ($currentPrior * (1 - $learningRate)) + ($observedRate * $learningRate)
            $script:BayesianConfig.PriorProbabilities[$DecisionType] = [Math]::Round($newPrior, 4)
            
            Write-DecisionLog "Updated prior for $DecisionType from $currentPrior to $newPrior" "INFO"
        }
        
        # Persist learning to storage
        Save-BayesianLearning
        
        return @{
            Updated = $true
            DecisionType = $DecisionType
            NewStats = $history
            UpdatedPrior = $script:BayesianConfig.PriorProbabilities[$DecisionType]
        }
        
    } catch {
        Write-DecisionLog "Failed to update Bayesian learning: $($_.Exception.Message)" "ERROR"
        return @{
            Updated = $false
            Error = $_.Exception.Message
        }
    }
}

# Save Bayesian learning data to persistent storage
function Save-BayesianLearning {
    [CmdletBinding()]
    param()
    
    try {
        $data = @{
            PriorProbabilities = $script:BayesianConfig.PriorProbabilities
            OutcomeHistory = $script:BayesianConfig.OutcomeHistory
            LastUpdate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Version = "1.0"
        }
        
        # Create directory if it doesn't exist
        $directory = Split-Path -Path $script:BayesianStoragePath -Parent
        if (-not (Test-Path $directory)) {
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
        }
        
        $data | ConvertTo-Json -Depth 10 | Out-File -FilePath $script:BayesianStoragePath -Encoding UTF8
        Write-DecisionLog "Bayesian learning data saved successfully" "DEBUG"
        
    } catch {
        Write-DecisionLog "Failed to save Bayesian learning data: $($_.Exception.Message)" "ERROR"
    }
}

# Load Bayesian learning data from persistent storage
function Initialize-BayesianLearning {
    [CmdletBinding()]
    param()
    
    try {
        if (Test-Path $script:BayesianStoragePath) {
            $data = Get-Content -Path $script:BayesianStoragePath -Raw | ConvertFrom-Json
            
            # Update configuration with loaded data
            if ($data.PriorProbabilities) {
                foreach ($key in $data.PriorProbabilities.PSObject.Properties.Name) {
                    $script:BayesianConfig.PriorProbabilities[$key] = $data.PriorProbabilities.$key
                }
            }
            
            if ($data.OutcomeHistory) {
                foreach ($key in $data.OutcomeHistory.PSObject.Properties.Name) {
                    $history = $data.OutcomeHistory.$key
                    $script:BayesianConfig.OutcomeHistory[$key] = @{
                        Success = $history.Success
                        Failure = $history.Failure
                        Total = $history.Total
                    }
                }
            }
            
            Write-DecisionLog "Bayesian learning data loaded from $($data.LastUpdate)" "INFO"
            return $true
        } else {
            Write-DecisionLog "No existing Bayesian learning data found - using defaults" "INFO"
            return $false
        }
        
    } catch {
        Write-DecisionLog "Failed to load Bayesian learning data: $($_.Exception.Message)" "ERROR"
        return $false
    }
}

#endregion

# Export learning and adaptation functions
Export-ModuleMember -Function Update-BayesianLearning, Save-BayesianLearning, Initialize-BayesianLearning