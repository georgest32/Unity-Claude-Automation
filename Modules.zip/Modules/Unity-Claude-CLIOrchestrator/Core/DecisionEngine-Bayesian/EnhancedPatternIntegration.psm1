# EnhancedPatternIntegration.psm1
# Phase 7 Day 3-4 Hours 5-8: Enhanced Pattern Analysis Integration
# Main integration function combining all Bayesian analysis components
# Date: 2025-08-25

#region Enhanced Pattern Analysis Integration

# Main enhanced pattern analysis function
function Invoke-EnhancedPatternAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AnalysisResult,
        
        [Parameter()]
        [switch]$UseBayesian,
        
        [Parameter()]
        [switch]$IncludeNGrams,
        
        [Parameter()]
        [switch]$BuildEntityGraph,
        
        [Parameter()]
        [switch]$AddTemporalContext
    )
    
    Write-DecisionLog "Starting enhanced pattern analysis" "INFO"
    $startTime = Get-Date
    
    $enhancedResult = $AnalysisResult.Clone()
    
    try {
        # Apply Bayesian confidence adjustment
        if ($UseBayesian -and $AnalysisResult.Recommendations) {
            foreach ($rec in $AnalysisResult.Recommendations) {
                $bayesianResult = Invoke-BayesianConfidenceAdjustment `
                    -DecisionType $rec.Type `
                    -ObservedConfidence $rec.Confidence `
                    -ReturnDetails
                
                $rec | Add-Member -NotePropertyName 'BayesianConfidence' -NotePropertyValue $bayesianResult.AdjustedConfidence -Force
                $rec | Add-Member -NotePropertyName 'ConfidenceBand' -NotePropertyValue $bayesianResult.ConfidenceBand -Force
                $rec | Add-Member -NotePropertyName 'Uncertainty' -NotePropertyValue $bayesianResult.Uncertainty -Force
            }
        }
        
        # Build n-gram model for response text
        if ($IncludeNGrams -and $AnalysisResult.ResponseText) {
            $ngramModel = Build-NGramModel -Text $AnalysisResult.ResponseText -N 3 -IncludeStatistics
            $enhancedResult | Add-Member -NotePropertyName 'NGramAnalysis' -NotePropertyValue $ngramModel -Force
        }
        
        # Build entity relationship graph
        if ($BuildEntityGraph -and $AnalysisResult.Entities) {
            $allEntities = @()
            
            # Collect all entities with positions
            $position = 0
            if ($AnalysisResult.Entities.FilePaths) {
                foreach ($path in $AnalysisResult.Entities.FilePaths) {
                    $allEntities += @{
                        Type = 'FilePath'
                        Value = if ($path -is [string]) { $path } else { $path.Value }
                        Position = $position
                        Confidence = if ($path.Confidence) { $path.Confidence } else { 0.9 }
                    }
                    $position += 100
                }
            }
            
            if ($AnalysisResult.Entities.PowerShellCommands) {
                foreach ($cmd in $AnalysisResult.Entities.PowerShellCommands) {
                    $allEntities += @{
                        Type = 'PowerShellCommand'
                        Value = $cmd.Value
                        Position = $position
                        Confidence = $cmd.Confidence
                    }
                    $position += 100
                }
            }
            
            if ($allEntities.Count -gt 0) {
                $entityGraph = Build-EntityRelationshipGraph -Entities $allEntities -IncludeMetrics
                $enhancedResult | Add-Member -NotePropertyName 'EntityGraph' -NotePropertyValue $entityGraph -Force
            }
        }
        
        # Add temporal context
        if ($AddTemporalContext) {
            $primaryRecommendation = $AnalysisResult.Recommendations | Select-Object -First 1
            if ($primaryRecommendation) {
                $temporalDecision = @{
                    DecisionType = $primaryRecommendation.Type
                    Confidence = $primaryRecommendation.Confidence
                    Success = $null  # Will be updated after execution
                }
                
                $temporalDecision = Add-TemporalContext -Decision $temporalDecision
                $enhancedResult | Add-Member -NotePropertyName 'TemporalContext' -NotePropertyValue $temporalDecision.TemporalContext -Force
                
                # Get relevance for this decision type
                $relevance = Get-TemporalContextRelevance -DecisionType $primaryRecommendation.Type
                $enhancedResult | Add-Member -NotePropertyName 'TemporalRelevance' -NotePropertyValue $relevance -Force
            }
        }
        
        $processingTime = ((Get-Date) - $startTime).TotalMilliseconds
        $enhancedResult | Add-Member -NotePropertyName 'EnhancementTimeMs' -NotePropertyValue $processingTime -Force
        
        Write-DecisionLog "Enhanced pattern analysis completed in ${processingTime}ms" "SUCCESS"
        
        return $enhancedResult
        
    } catch {
        Write-DecisionLog "Enhanced pattern analysis failed: $($_.Exception.Message)" "ERROR"
        return $AnalysisResult  # Return original on failure
    }
}

#endregion

# Export enhanced pattern integration function
Export-ModuleMember -Function Invoke-EnhancedPatternAnalysis