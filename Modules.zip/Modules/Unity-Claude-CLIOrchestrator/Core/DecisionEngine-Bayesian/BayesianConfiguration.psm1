# BayesianConfiguration.psm1
# Phase 7 Day 3-4 Hours 5-8: Bayesian Configuration Management
# Configuration and initialization for Bayesian decision engine
# Date: 2025-08-25

#region Bayesian Configuration

# Bayesian inference configuration
$script:BayesianConfig = @{
    # Prior probabilities for each decision type (initial beliefs)
    PriorProbabilities = @{
        CONTINUE = 0.50   # Moderate prior for continuation
        TEST = 0.30       # Moderate prior for testing
        FIX = 0.15        # Lower prior for fixes
        COMPILE = 0.10    # Lower prior for compilation
        RESTART = 0.05    # Low prior for restarts
        COMPLETE = 0.08   # Low prior for completion
        ERROR = 0.02      # Very low prior for errors
    }
    
    # Historical outcome tracking
    OutcomeHistory = @{
        CONTINUE = @{ Success = 0; Failure = 0; Total = 0 }
        TEST = @{ Success = 0; Failure = 0; Total = 0 }
        FIX = @{ Success = 0; Failure = 0; Total = 0 }
        COMPILE = @{ Success = 0; Failure = 0; Total = 0 }
        RESTART = @{ Success = 0; Failure = 0; Total = 0 }
        COMPLETE = @{ Success = 0; Failure = 0; Total = 0 }
        ERROR = @{ Success = 0; Failure = 0; Total = 0 }
    }
    
    # Learning parameters
    LearningRate = 0.1          # How quickly to update beliefs
    MinimumSamples = 10          # Minimum samples before significant adjustment
    ConfidenceDecay = 0.95       # Decay factor for old observations
    
    # Confidence bands
    ConfidenceBands = @{
        VeryHigh = 0.95
        High = 0.85
        Medium = 0.70
        Low = 0.50
        VeryLow = 0.30
    }
    
    # Uncertainty metrics
    UncertaintyThreshold = 0.2   # Maximum acceptable uncertainty
    EntropyThreshold = 2.0        # Maximum decision entropy
}

# Persistent storage for Bayesian learning
$script:BayesianStoragePath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation\Data\BayesianLearning.json"

#endregion

# Export configuration accessor functions
Export-ModuleMember -Variable BayesianConfig, BayesianStoragePath