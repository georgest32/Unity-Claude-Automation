# ConfidenceBands.psm1
# Phase 7 Day 3-4 Hours 5-8: Confidence Band Classification
# Confidence band determination and pattern confidence calculations
# Date: 2025-08-25

#region Confidence Band Functions

# Determine confidence band based on adjusted confidence
function Get-ConfidenceBand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [double]$Confidence
    )
    
    $bands = $script:BayesianConfig.ConfidenceBands
    
    if ($Confidence -ge $bands.VeryHigh) {
        return "VeryHigh"
    } elseif ($Confidence -ge $bands.High) {
        return "High"
    } elseif ($Confidence -ge $bands.Medium) {
        return "Medium"
    } elseif ($Confidence -ge $bands.Low) {
        return "Low"
    } else {
        return "VeryLow"
    }
}

# Calculate pattern confidence based on historical patterns
function Calculate-PatternConfidence {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$Patterns,
        
        [Parameter()]
        [hashtable]$HistoricalPatterns = @{}
    )
    
    Write-DecisionLog "Calculating pattern confidence for $($Patterns.Count) patterns" "DEBUG"
    
    $totalConfidence = 0.0
    $weightSum = 0.0
    
    foreach ($pattern in $Patterns) {
        $patternKey = "$($pattern.Type)_$($pattern.Category)"
        
        # Base confidence from pattern
        $baseConfidence = $pattern.Confidence
        
        # Historical adjustment if available
        if ($HistoricalPatterns.ContainsKey($patternKey)) {
            $historical = $HistoricalPatterns[$patternKey]
            $successRate = $historical.SuccessCount / [Math]::Max(1, $historical.TotalCount)
            $adjustedConfidence = ($baseConfidence * 0.6) + ($successRate * 0.4)
        } else {
            $adjustedConfidence = $baseConfidence
        }
        
        # Weight by pattern priority
        $weight = switch ($pattern.Priority) {
            1 { 1.5 }
            2 { 1.2 }
            3 { 1.0 }
            4 { 0.8 }
            default { 0.5 }
        }
        
        $totalConfidence += $adjustedConfidence * $weight
        $weightSum += $weight
    }
    
    if ($weightSum -gt 0) {
        $averageConfidence = $totalConfidence / $weightSum
    } else {
        $averageConfidence = 0.5  # Default confidence
    }
    
    return @{
        PatternConfidence = $averageConfidence
        PatternCount = $Patterns.Count
        ConfidenceBand = Get-ConfidenceBand -Confidence $averageConfidence
        WeightedScore = $totalConfidence
    }
}

#endregion

# Export confidence band functions
Export-ModuleMember -Function Get-ConfidenceBand, Calculate-PatternConfidence