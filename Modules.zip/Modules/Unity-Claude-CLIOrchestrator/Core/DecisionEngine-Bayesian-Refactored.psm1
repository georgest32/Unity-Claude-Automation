# DecisionEngine-Bayesian-Refactored.psm1
# Refactored modular version of the Bayesian Decision Engine
# This orchestrator imports all components and provides the public interface
# Date: 2025-08-26

#region Module Orchestrator

# Import all component modules
$ComponentPath = Join-Path $PSScriptRoot "DecisionEngine-Bayesian"

# Bayesian Configuration Management
Import-Module (Join-Path $ComponentPath "BayesianConfiguration.psm1") -Force -Global

# Core Bayesian Inference Engine
Import-Module (Join-Path $ComponentPath "BayesianInference.psm1") -Force -Global

# Confidence Band Classification
Import-Module (Join-Path $ComponentPath "ConfidenceBands.psm1") -Force -Global

# Learning and Adaptation System
Import-Module (Join-Path $ComponentPath "LearningAdaptation.psm1") -Force -Global

# Advanced Pattern Analysis
Import-Module (Join-Path $ComponentPath "PatternAnalysis.psm1") -Force -Global

# Entity Relationship Management
Import-Module (Join-Path $ComponentPath "EntityRelationshipManagement.psm1") -Force -Global

# Temporal Context Tracking
Import-Module (Join-Path $ComponentPath "TemporalContextTracking.psm1") -Force -Global

# Enhanced Pattern Integration
Import-Module (Join-Path $ComponentPath "EnhancedPatternIntegration.psm1") -Force -Global

Write-DecisionLog "DecisionEngine-Bayesian components loaded successfully" "INFO"

#endregion

# Export all public functions from components
Export-ModuleMember -Function @(
    # From BayesianConfiguration
    'Initialize-BayesianEngine',
    'Get-BayesianConfiguration',
    'Reset-BayesianEngine',
    
    # From BayesianInference  
    'Invoke-BayesianConfidenceAdjustment',
    'Get-BayesianPrior',
    'Calculate-BayesianLikelihood',
    'Update-BayesianOutcome',
    
    # From ConfidenceBands
    'Get-ConfidenceBand',
    'Calculate-PatternConfidence',
    
    # From LearningAdaptation
    'Update-BayesianLearning',
    'Save-BayesianLearning',
    'Load-BayesianLearning',
    
    # From PatternAnalysis
    'Build-NGramModel',
    'Calculate-PatternSimilarity',
    'Get-LevenshteinDistance',
    
    # From EntityRelationshipManagement
    'Build-EntityRelationshipGraph',
    'Find-EntityCluster',
    'Measure-EntityProximity',
    
    # From TemporalContextTracking
    'Add-TemporalContext',
    'Get-TemporalContextRelevance',
    
    # From EnhancedPatternIntegration
    'Invoke-EnhancedPatternAnalysis'
)

# Export script variables that might be needed
Export-ModuleMember -Variable BayesianConfig, TemporalContext