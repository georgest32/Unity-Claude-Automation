#region WindowManager Component
<#
.SYNOPSIS
    Unity-Claude CLI Orchestrator - Window Management Component
    
.DESCRIPTION
    Manages Claude Code CLI window detection, switching, and information tracking.
    Provides reliable window management with multiple detection methods and system
    status integration.
    
.COMPONENT
    Part of Unity-Claude-CLIOrchestrator refactored architecture
    
.FUNCTIONS
    - Update-ClaudeWindowInfo: Updates system status with Claude window information
    - Find-ClaudeWindow: Locates Claude CLI window using multiple methods
    - Switch-ToWindow: Reliably switches to specified window using Windows APIs
#>
#endregion

# Add Windows API functions for reliable window switching and input blocking
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public class WindowAPI {
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    
    [DllImport("user32.dll")]
    public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    
    [DllImport("user32.dll")]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    
    [DllImport("user32.dll")]
    public static extern bool BringWindowToTop(IntPtr hWnd);
    
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    
    [DllImport("user32.dll")]
    public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
    
    [DllImport("kernel32.dll")]
    public static extern uint GetCurrentThreadId();
    
    // Mouse and keyboard blocking functions
    [DllImport("user32.dll")]
    public static extern bool BlockInput(bool fBlockIt);
    
    [DllImport("user32.dll")]
    public static extern IntPtr SetCapture(IntPtr hWnd);
    
    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();
    
    [DllImport("user32.dll")]
    public static extern bool GetCursorPos(out POINT lpPoint);
    
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);
    
    public struct POINT {
        public int X;
        public int Y;
    }
}
"@ -ErrorAction SilentlyContinue

# Load required assemblies for SendKeys functionality
Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue

function Update-ClaudeWindowInfo {
    <#
    .SYNOPSIS
        Updates Claude window information in system_status.json
        
    .DESCRIPTION
        Stores Claude CLI window details for reliable future detection
        
    .PARAMETER WindowHandle
        The window handle of the Claude CLI window
        
    .PARAMETER ProcessId
        The process ID of the Claude CLI window
        
    .PARAMETER WindowTitle
        The title of the Claude CLI window
        
    .PARAMETER ProcessName
        The name of the Claude CLI process
        
    .EXAMPLE
        Update-ClaudeWindowInfo -WindowHandle $handle -ProcessId $pid -WindowTitle $title -ProcessName $name
    #>
    [CmdletBinding()]
    param(
        [IntPtr]$WindowHandle,
        [int]$ProcessId, 
        [string]$WindowTitle,
        [string]$ProcessName
    )
    
    Write-Host "    Updating Claude window info in system_status.json..." -ForegroundColor Gray
    
    try {
        $systemStatusPath = ".\system_status.json"
        $systemStatus = @{}
        
        # Load existing status or create new
        if (Test-Path $systemStatusPath) {
            $systemStatus = Get-Content $systemStatusPath -Raw | ConvertFrom-Json -AsHashtable
        }
        
        # Ensure structure exists
        if (-not $systemStatus.SystemInfo) { $systemStatus.SystemInfo = @{} }
        if (-not $systemStatus.SystemInfo.ClaudeCodeCLI) { $systemStatus.SystemInfo.ClaudeCodeCLI = @{} }
        
        # Update Claude window information
        $systemStatus.SystemInfo.ClaudeCodeCLI.ProcessId = $ProcessId
        $systemStatus.SystemInfo.ClaudeCodeCLI.WindowHandle = [int64]$WindowHandle
        $systemStatus.SystemInfo.ClaudeCodeCLI.WindowTitle = $WindowTitle
        $systemStatus.SystemInfo.ClaudeCodeCLI.ProcessName = $ProcessName
        $systemStatus.SystemInfo.ClaudeCodeCLI.LastDetected = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        $systemStatus.SystemInfo.ClaudeCodeCLI.DetectionMethod = "AutonomousAgent"
        
        # Save back to file
        $systemStatus | ConvertTo-Json -Depth 10 | Set-Content $systemStatusPath -Encoding UTF8
        
        Write-Host "    Claude window info updated successfully" -ForegroundColor Green
        Write-Host "    PID: $ProcessId, Handle: $WindowHandle, Title: '$WindowTitle'" -ForegroundColor Gray
        
    } catch {
        Write-Host "    Warning: Could not update system_status.json: $_" -ForegroundColor Yellow
    }
}

function Find-ClaudeWindow {
    <#
    .SYNOPSIS
        Finds the Claude Code CLI window using multiple detection methods
        
    .DESCRIPTION
        Uses multiple strategies to locate the Claude CLI window:
        1. Check system_status.json for previously detected window info
        2. Search by window title patterns with comprehensive pattern matching
        
    .OUTPUTS
        IntPtr - The window handle if found, $null if not found
        
    .EXAMPLE
        $windowHandle = Find-ClaudeWindow
    #>
    [CmdletBinding()]
    param()
    
    Write-Host "  Searching for Claude Code CLI window..." -ForegroundColor Gray
    
    # Method 1: Check system_status.json for comprehensive window info
    $systemStatusPath = ".\system_status.json"
    if (Test-Path $systemStatusPath) {
        try {
            $systemStatus = Get-Content $systemStatusPath -Raw | ConvertFrom-Json
            $claudeInfo = $systemStatus.SystemInfo.ClaudeCodeCLI
            
            if ($claudeInfo) {
                Write-Host "    Found Claude info in system_status.json" -ForegroundColor Gray
                
                # Try PID first
                if ($claudeInfo.ProcessId) {
                    $claudePID = $claudeInfo.ProcessId
                    Write-Host "    Checking registered PID: $claudePID" -ForegroundColor Gray
                    
                    $claudeProcess = Get-Process -Id $claudePID -ErrorAction SilentlyContinue
                    if ($claudeProcess -and $claudeProcess.MainWindowHandle -ne 0) {
                        # Verify the window title matches what we expect
                        if ($claudeInfo.WindowTitle -and $claudeProcess.MainWindowTitle -eq $claudeInfo.WindowTitle) {
                            Write-Host "    SUCCESS: Found Claude window from registered PID with matching title!" -ForegroundColor Green
                            Write-Host "    PID: $claudePID, Title: '$($claudeProcess.MainWindowTitle)'" -ForegroundColor Gray
                            return $claudeProcess.MainWindowHandle
                        } else {
                            Write-Host "    Warning: Window title changed (expected: '$($claudeInfo.WindowTitle)', actual: '$($claudeProcess.MainWindowTitle)')" -ForegroundColor Yellow
                        }
                    }
                }
                
                # Try window handle if available
                if ($claudeInfo.WindowHandle) {
                    Write-Host "    Trying stored window handle: $($claudeInfo.WindowHandle)" -ForegroundColor Gray
                    $processes = Get-Process | Where-Object { $_.MainWindowHandle -eq $claudeInfo.WindowHandle }
                    if ($processes) {
                        $proc = $processes[0]
                        Write-Host "    SUCCESS: Found window using stored handle!" -ForegroundColor Green
                        Write-Host "    Process: $($proc.ProcessName) (PID: $($proc.Id)), Title: '$($proc.MainWindowTitle)'" -ForegroundColor Gray
                        return $proc.MainWindowHandle
                    }
                }
            }
        } catch {
            Write-Host "    Could not read system_status.json: $_" -ForegroundColor Yellow
        }
    }
    
    # Method 2: Search by window title patterns (enhanced)
    $titlePatterns = @(
        "Claude Code CLI environment",           # Exact match first
        "*Claude Code CLI*",                     # Contains Claude Code CLI
        "*claude*code*cli*",                     # Flexible case
        "*claude*code*environment*",             # Environment variant
        "*Administrator: Windows PowerShell*claude*",  # Admin PowerShell with claude
        "*Windows PowerShell*claude*",          # Regular PowerShell with claude
        "*PowerShell*claude*code*",              # PowerShell with claude code
        "*pwsh*claude*",                         # PowerShell 7 with claude
        "*Terminal*claude*"                      # Windows Terminal with claude
    )
    
    Write-Host "    Checking all running processes with windows..." -ForegroundColor Gray
    $allProcesses = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 }
    Write-Host "    Found $($allProcesses.Count) processes with windows" -ForegroundColor Gray
    
    foreach ($pattern in $titlePatterns) {
        $processes = $allProcesses | Where-Object { 
            $_.MainWindowTitle -like $pattern
        }
        
        if ($processes) {
            $claudeProcess = $processes[0]
            Write-Host "    SUCCESS: Found window matching pattern: $pattern" -ForegroundColor Green
            Write-Host "    Process: $($claudeProcess.ProcessName) (PID: $($claudeProcess.Id))" -ForegroundColor Gray
            Write-Host "    Title: '$($claudeProcess.MainWindowTitle)'" -ForegroundColor Gray
            Write-Host "    Handle: $($claudeProcess.MainWindowHandle)" -ForegroundColor Gray
            
            # Update system_status.json with found window info
            Update-ClaudeWindowInfo -WindowHandle $claudeProcess.MainWindowHandle -ProcessId $claudeProcess.Id -WindowTitle $claudeProcess.MainWindowTitle -ProcessName $claudeProcess.ProcessName
            
            return $claudeProcess.MainWindowHandle
        } else {
            Write-Host "    No match for pattern: $pattern" -ForegroundColor DarkGray
        }
    }
    
    Write-Host "    CRITICAL: No suitable windows found!" -ForegroundColor Red
    Write-Host "    Please ensure the Claude Code CLI window is open and visible" -ForegroundColor Yellow
    return $null
}

function Switch-ToWindow {
    <#
    .SYNOPSIS
        Reliably switches to the specified window using Windows APIs
        
    .DESCRIPTION
        Uses multiple Windows API techniques to ensure reliable window switching,
        including AttachThreadInput for stubborn windows
        
    .PARAMETER WindowHandle
        The handle of the window to switch to
        
    .OUTPUTS
        Boolean - True if window switch was successful, False otherwise
        
    .EXAMPLE
        $success = Switch-ToWindow -WindowHandle $windowHandle
    #>
    [CmdletBinding()]
    param([IntPtr]$WindowHandle)
    
    if ($WindowHandle -eq 0 -or $WindowHandle -eq $null) {
        return $false
    }
    
    try {
        # Get current foreground window
        $currentWindow = [WindowAPI]::GetForegroundWindow()
        
        # Show the window if minimized (4 = SW_RESTORE)
        [WindowAPI]::ShowWindowAsync($WindowHandle, 4) | Out-Null
        Start-Sleep -Milliseconds 100
        
        # Bring to top
        [WindowAPI]::BringWindowToTop($WindowHandle) | Out-Null
        Start-Sleep -Milliseconds 100
        
        # Set as foreground window
        $result = [WindowAPI]::SetForegroundWindow($WindowHandle)
        
        if (-not $result) {
            # If SetForegroundWindow fails, try AttachThreadInput trick
            Write-Host "    Using AttachThreadInput for window switching..." -ForegroundColor Gray
            
            $currentThreadId = [WindowAPI]::GetCurrentThreadId()
            $targetProcessId = 0
            $targetThreadId = [WindowAPI]::GetWindowThreadProcessId($WindowHandle, [ref]$targetProcessId)
            
            if ($targetThreadId -ne 0 -and $currentThreadId -ne $targetThreadId) {
                [WindowAPI]::AttachThreadInput($currentThreadId, $targetThreadId, $true) | Out-Null
                [WindowAPI]::BringWindowToTop($WindowHandle) | Out-Null
                [WindowAPI]::SetForegroundWindow($WindowHandle) | Out-Null
                [WindowAPI]::AttachThreadInput($currentThreadId, $targetThreadId, $false) | Out-Null
            }
        }
        
        Start-Sleep -Milliseconds 500
        return $true
    } catch {
        Write-Host "    Error switching window: $_" -ForegroundColor Red
        return $false
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Update-ClaudeWindowInfo',
    'Find-ClaudeWindow',
    'Switch-ToWindow'
)