# FallbackStrategies.psm1
# Conflict resolution and graceful degradation for DecisionEngine
# Part of Unity-Claude-CLIOrchestrator refactored architecture
# Date: 2025-08-25

#region Fallback Strategies

# Handle ambiguous or conflicting recommendations
function Resolve-ConflictingRecommendations {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$ConflictingRecommendations,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ConfidenceAnalysis
    )
    
    Write-DecisionLog "Resolving conflicts between $($ConflictingRecommendations.Count) recommendations" "WARN"
    
    # Get configuration
    $decisionConfig = Get-DecisionEngineConfiguration
    
    # Strategy 1: Use priority matrix
    $prioritized = $ConflictingRecommendations | ForEach-Object {
        $matrixEntry = $decisionConfig.DecisionMatrix[$_.Type]
        $_ | Add-Member -NotePropertyName 'MatrixPriority' -NotePropertyValue ($matrixEntry?.Priority ?? 10) -PassThru
    } | Sort-Object MatrixPriority, @{Expression = {$_.Confidence}; Descending = $true}
    
    # Strategy 2: If priorities are equal, use confidence
    $selected = $prioritized[0]
    
    # Strategy 3: If confidence is low, default to safe action
    if ($selected.Confidence -lt 0.6) {
        Write-DecisionLog "Low confidence in conflict resolution - defaulting to CONTINUE" "WARN"
        return @{
            RecommendationType = "CONTINUE"
            Action = "Continue due to conflict resolution uncertainty"
            Priority = 1
            SafetyLevel = "Low"
            Reason = "Conflict resolution with low confidence - defaulting to safe action"
            ConflictResolutionStrategy = "SafeDefault"
        }
    }
    
    Write-DecisionLog "Conflict resolved: Selected $($selected.Type) with confidence $($selected.Confidence)" "INFO"
    
    return @{
        RecommendationType = $selected.Type
        Action = $selected.Action
        Priority = $selected.MatrixPriority
        SafetyLevel = $decisionConfig.DecisionMatrix[$selected.Type]?.SafetyLevel ?? "Unknown"
        Confidence = $selected.Confidence
        Reason = "Conflict resolved using priority matrix and confidence scoring"
        ConflictResolutionStrategy = "PriorityMatrix"
        AlternativeRecommendations = if ($prioritized.Count -gt 1) { 
            $alternatives = @()
            for ($i = 1; $i -lt $prioritized.Count; $i++) { $alternatives += $prioritized[$i] }
            $alternatives
        } else { @() }
    }
}

# Graceful degradation for low-confidence scenarios
function Invoke-GracefulDegradation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AnalysisResult,
        
        [Parameter()]
        [string]$DegradationReason = "Low confidence analysis"
    )
    
    Write-DecisionLog "Invoking graceful degradation: $DegradationReason" "WARN"
    
    # Analyze what we can safely do
    $safeActions = @("CONTINUE", "COMPLETE", "ERROR")
    $confidence = $AnalysisResult.ConfidenceAnalysis?.OverallConfidence ?? 0.0
    
    # Select safest action based on context
    $degradedAction = if ($confidence -lt 0.3) {
        @{
            RecommendationType = "ERROR"
            Action = "Request clarification due to low confidence analysis"
            Priority = 7
            SafetyLevel = "Low"
            Reason = "Confidence too low for autonomous decision-making ($confidence)"
        }
    } elseif ($AnalysisResult.Classification?.Category -eq "Complete") {
        @{
            RecommendationType = "COMPLETE"
            Action = "Mark task as complete based on context analysis"
            Priority = 6
            SafetyLevel = "Low"
            Reason = "Task appears complete despite analysis uncertainty"
        }
    } else {
        @{
            RecommendationType = "CONTINUE"
            Action = "Continue processing with manual review recommendation"
            Priority = 1
            SafetyLevel = "Low"
            Reason = "Safe continuation while seeking human guidance"
        }
    }
    
    $degradedAction.DegradationApplied = $true
    $degradedAction.OriginalAnalysis = $AnalysisResult
    $degradedAction.DegradationReason = $DegradationReason
    
    Write-DecisionLog "Graceful degradation applied: $($degradedAction.RecommendationType)" "INFO"
    
    return $degradedAction
}

# Advanced decision conflict analysis
function Get-ConflictAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$Recommendations
    )
    
    if ($Recommendations.Count -lt 2) {
        return @{
            HasConflicts = $false
            ConflictCount = 0
            Reason = "Insufficient recommendations for conflict analysis"
        }
    }
    
    # Get configuration
    $decisionConfig = Get-DecisionEngineConfiguration
    
    # Analyze for conflicts
    $priorities = @()
    $safetyLevels = @()
    $actionTypes = @()
    
    foreach ($rec in $Recommendations) {
        $matrixEntry = $decisionConfig.DecisionMatrix[$rec.Type]
        if ($matrixEntry) {
            $priorities += $matrixEntry.Priority
            $safetyLevels += $matrixEntry.SafetyLevel
            $actionTypes += $matrixEntry.ActionType
        }
    }
    
    # Check for conflicts
    $uniquePriorities = $priorities | Select-Object -Unique
    $uniqueSafetyLevels = $safetyLevels | Select-Object -Unique
    $uniqueActionTypes = $actionTypes | Select-Object -Unique
    
    $hasConflicts = $uniquePriorities.Count -gt 1 -or 
                    $uniqueSafetyLevels.Count -gt 1 -or 
                    $uniqueActionTypes.Count -gt 1
    
    return @{
        HasConflicts = $hasConflicts
        ConflictCount = if ($hasConflicts) { $Recommendations.Count } else { 0 }
        PriorityConflict = $uniquePriorities.Count -gt 1
        SafetyLevelConflict = $uniqueSafetyLevels.Count -gt 1
        ActionTypeConflict = $uniqueActionTypes.Count -gt 1
        RecommendationTypes = @($Recommendations | ForEach-Object { $_.Type })
        Priorities = $priorities
        SafetyLevels = $safetyLevels
        ActionTypes = $actionTypes
    }
}

# Emergency fallback decision
function Get-EmergencyFallback {
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$Reason = "Emergency fallback triggered"
    )
    
    Write-DecisionLog "Emergency fallback activated: $Reason" "ERROR"
    
    return @{
        RecommendationType = "ERROR"
        Action = "Emergency stop - manual intervention required"
        Priority = 7
        SafetyLevel = "Critical"
        Reason = $Reason
        EmergencyFallback = $true
        Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Resolve-ConflictingRecommendations',
    'Invoke-GracefulDegradation',
    'Get-ConflictAnalysis',
    'Get-EmergencyFallback'
)

#endregion