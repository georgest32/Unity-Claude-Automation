# RuleBasedDecisionTrees.psm1
# Rule-based decision processing and priority resolution
# Part of Unity-Claude-CLIOrchestrator refactored architecture
# Date: 2025-08-25

#region Rule-Based Decision Trees

# Main decision tree processor
function Invoke-RuleBasedDecision {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AnalysisResult,
        
        [Parameter()]
        [switch]$IncludeDetails,
        
        [Parameter()]
        [switch]$DryRun
    )
    
    Write-DecisionLog "Starting rule-based decision processing" "INFO"
    $startTime = Get-Date
    
    try {
        # Input validation
        if (-not $AnalysisResult.ContainsKey('Recommendations') -or 
            -not $AnalysisResult.ContainsKey('ConfidenceAnalysis')) {
            throw "Invalid analysis result - missing required components"
        }
        
        $recommendations = $AnalysisResult.Recommendations
        $confidence = $AnalysisResult.ConfidenceAnalysis
        
        Write-DecisionLog "Processing $($recommendations.Count) recommendations with confidence $($confidence.OverallConfidence)" "INFO"
        
        # Step 1: Safety validation
        $safetyResult = Test-SafetyValidation -AnalysisResult $AnalysisResult
        if (-not $safetyResult.IsSafe) {
            Write-DecisionLog "Safety validation failed: $($safetyResult.Reason)" "ERROR"
            return @{
                Decision = "BLOCK"
                Reason = "Safety validation failed: $($safetyResult.Reason)"
                ProcessingTimeMs = ((Get-Date) - $startTime).TotalMilliseconds
                Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
            }
        }
        
        # Step 2: Priority-based decision resolution
        $priorityResult = Resolve-PriorityDecision -Recommendations $recommendations -ConfidenceAnalysis $confidence
        
        # Step 3: Action queue preparation
        $queueResult = New-ActionQueueItem -Decision $priorityResult -AnalysisResult $AnalysisResult -DryRun:$DryRun
        
        # Step 4: Compile final decision
        $finalDecision = @{
            # Core Decision
            Decision = $priorityResult.RecommendationType
            Action = $priorityResult.Action
            Priority = $priorityResult.Priority
            
            # Safety Assessment
            SafetyLevel = $priorityResult.SafetyLevel
            SafetyValidated = $safetyResult.IsSafe
            
            # Confidence and Quality
            ConfidenceScore = $confidence.OverallConfidence
            QualityRating = $confidence.QualityRating
            
            # Action Queue Information
            QueuePosition = $queueResult.QueuePosition
            EstimatedExecutionTime = $queueResult.EstimatedExecutionTime
            
            # Processing Metadata
            ProcessingTimeMs = ((Get-Date) - $startTime).TotalMilliseconds
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
            DryRun = $DryRun.IsPresent
        }
        
        # Add detailed information if requested
        if ($IncludeDetails) {
            $finalDecision.Details = @{
                AllRecommendations = $recommendations
                SafetyDetails = $safetyResult
                PriorityAnalysis = $priorityResult
                QueueDetails = $queueResult
            }
        }
        
        $processingTime = [int]$finalDecision.ProcessingTimeMs
        Write-DecisionLog "Decision completed: $($finalDecision.Decision) (Priority: $($finalDecision.Priority), Time: ${processingTime}ms)" "SUCCESS"
        
        # Get configuration for performance check
        $decisionConfig = Get-DecisionEngineConfiguration
        
        # Performance warning
        if ($processingTime -gt $decisionConfig.PerformanceTargets.DecisionTimeMs) {
            Write-DecisionLog "Decision processing exceeded target time (${processingTime}ms > $($decisionConfig.PerformanceTargets.DecisionTimeMs)ms)" "WARN"
        }
        
        return $finalDecision
        
    } catch {
        $processingTime = ((Get-Date) - $startTime).TotalMilliseconds
        Write-DecisionLog "Decision processing failed: $($_.Exception.Message)" "ERROR"
        
        return @{
            Decision = "ERROR"
            Reason = $_.Exception.Message
            ProcessingTimeMs = $processingTime
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
            Error = $_.Exception.ToString()
        }
    }
}

# Priority-based decision resolver
function Resolve-PriorityDecision {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$Recommendations,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$ConfidenceAnalysis
    )
    
    Write-DecisionLog "Resolving priority decision from $($Recommendations.Count) recommendations" "DEBUG"
    
    if ($Recommendations.Count -eq 0) {
        Write-DecisionLog "No recommendations found - defaulting to CONTINUE" "WARN"
        return @{
            RecommendationType = "CONTINUE"
            Action = "Continue processing"
            Priority = 1
            SafetyLevel = "Low"
            Reason = "No specific recommendations found"
        }
    }
    
    # Get configuration
    $decisionConfig = Get-DecisionEngineConfiguration
    
    # Step 1: Filter by confidence threshold
    $confidenceThreshold = $decisionConfig.SafetyThresholds.MinimumConfidence
    $validRecommendations = @($Recommendations | Where-Object { 
        $_.Confidence -ge $confidenceThreshold 
    })
    
    if ($validRecommendations.Count -eq 0) {
        Write-DecisionLog "No recommendations meet confidence threshold ($confidenceThreshold)" "WARN"
        return @{
            RecommendationType = "ERROR"
            Action = "Insufficient confidence in recommendations"
            Priority = 7
            SafetyLevel = "Low"
            Reason = "No recommendations meet minimum confidence threshold"
        }
    }
    
    Write-DecisionLog "Found $($validRecommendations.Count) recommendations above confidence threshold" "DEBUG"
    
    # Step 2: Sort by priority (lower number = higher priority)
    # Step 2: Add matrix properties and sort
    $prioritizedRecommendations = @()
    foreach ($rec in $validRecommendations) {
        $recType = $rec.Type
        $matrixEntry = $decisionConfig.DecisionMatrix[$recType]
        
        if ($matrixEntry) {
            $rec | Add-Member -NotePropertyName 'MatrixPriority' -NotePropertyValue $matrixEntry.Priority -Force
            $rec | Add-Member -NotePropertyName 'MatrixSafetyLevel' -NotePropertyValue $matrixEntry.SafetyLevel -Force
            $rec | Add-Member -NotePropertyName 'MatrixActionType' -NotePropertyValue $matrixEntry.ActionType -Force
        } else {
            Write-DecisionLog "Unknown recommendation type: $recType - treating as low priority" "WARN"
            $rec | Add-Member -NotePropertyName 'MatrixPriority' -NotePropertyValue 10 -Force
            $rec | Add-Member -NotePropertyName 'MatrixSafetyLevel' -NotePropertyValue "Unknown" -Force
            $rec | Add-Member -NotePropertyName 'MatrixActionType' -NotePropertyValue "Unknown" -Force
        }
        $prioritizedRecommendations += $rec
    }
    
    # Sort by priority (only if multiple recommendations)
    # Lower priority number = higher priority, so sort ascending by priority
    # Then by confidence descending (higher is better) as tiebreaker
    if ($prioritizedRecommendations.Count -gt 1) {
        $prioritizedRecommendations = @($prioritizedRecommendations | Sort-Object @{Expression='MatrixPriority'; Ascending=$true}, @{Expression='Confidence'; Ascending=$false})
    }
    
    # Step 3: Select highest priority recommendation
    if ($prioritizedRecommendations.Count -eq 0) {
        Write-DecisionLog "No prioritized recommendations available" "ERROR"
        return @{
            RecommendationType = "ERROR"
            Action = "No valid recommendations found"
            Priority = 7
            SafetyLevel = "Low"
            Reason = "No prioritized recommendations available"
        }
    }
    
    $selectedRecommendation = $prioritizedRecommendations[0]
    
    # Step 4: Handle conflicts if multiple recommendations have same priority
    $samePriority = $prioritizedRecommendations | Where-Object { $_.MatrixPriority -eq $selectedRecommendation.MatrixPriority }
    if ($samePriority.Count -gt 1) {
        Write-DecisionLog "Found $($samePriority.Count) recommendations with same priority - using confidence as tiebreaker" "DEBUG"
        # Already sorted by confidence descending, so first item is correct
    }
    
    $result = @{
        RecommendationType = $selectedRecommendation.Type
        Action = $selectedRecommendation.Action
        Priority = $selectedRecommendation.MatrixPriority
        SafetyLevel = $selectedRecommendation.MatrixSafetyLevel
        ActionType = $selectedRecommendation.MatrixActionType
        Confidence = $selectedRecommendation.Confidence
        Reason = "Selected highest priority recommendation with confidence $($selectedRecommendation.Confidence)"
    }
    
    Write-DecisionLog "Selected recommendation: $($result.RecommendationType) (Priority: $($result.Priority), Confidence: $($result.Confidence))" "INFO"
    
    return $result
}

# Export functions
Export-ModuleMember -Function @(
    'Invoke-RuleBasedDecision',
    'Resolve-PriorityDecision'
)

#endregion