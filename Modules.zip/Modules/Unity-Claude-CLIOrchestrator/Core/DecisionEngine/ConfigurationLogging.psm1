# ConfigurationLogging.psm1
# Core configuration and logging for DecisionEngine
# Part of Unity-Claude-CLIOrchestrator refactored architecture
# Date: 2025-08-25

#region Module Configuration and Logging

# Core configuration for decision engine
$script:DecisionConfig = @{
    # Rule-based decision matrix
    DecisionMatrix = @{
        "CONTINUE" = @{
            Priority = 1
            ActionType = "Continuation"
            SafetyLevel = "Low"
            RequiresValidation = $false
            MaxRetryAttempts = 1
            TimeoutSeconds = 30
        }
        "TEST" = @{
            Priority = 2
            ActionType = "TestExecution"
            SafetyLevel = "Medium"
            RequiresValidation = $true
            MaxRetryAttempts = 2
            TimeoutSeconds = 300
        }
        "FIX" = @{
            Priority = 3
            ActionType = "FileModification"
            SafetyLevel = "High"
            RequiresValidation = $true
            MaxRetryAttempts = 1
            TimeoutSeconds = 120
        }
        "COMPILE" = @{
            Priority = 4
            ActionType = "BuildOperation"
            SafetyLevel = "Medium"
            RequiresValidation = $true
            MaxRetryAttempts = 2
            TimeoutSeconds = 180
        }
        "RESTART" = @{
            Priority = 5
            ActionType = "ServiceRestart"
            SafetyLevel = "High"
            RequiresValidation = $true
            MaxRetryAttempts = 1
            TimeoutSeconds = 60
        }
        "COMPLETE" = @{
            Priority = 6
            ActionType = "TaskCompletion"
            SafetyLevel = "Low"
            RequiresValidation = $false
            MaxRetryAttempts = 1
            TimeoutSeconds = 30
        }
        "ERROR" = @{
            Priority = 7
            ActionType = "ErrorHandling"
            SafetyLevel = "Low"
            RequiresValidation = $false
            MaxRetryAttempts = 3
            TimeoutSeconds = 60
        }
    }
    
    # Safety validation thresholds
    SafetyThresholds = @{
        MinimumConfidence = 0.7
        MaxFileSize = 10MB
        AllowedFileExtensions = @('.ps1', '.psm1', '.psd1', '.json', '.txt', '.md', '.yml', '.yaml')
        BlockedPaths = @('C:\Windows', 'C:\Program Files', 'C:\Program Files (x86)')
        MaxConcurrentActions = 3
    }
    
    # Performance targets
    PerformanceTargets = @{
        DecisionTimeMs = 100
        ValidationTimeMs = 50
        QueueProcessingTimeMs = 25
    }
    
    # Action queue configuration
    ActionQueue = @{
        MaxQueueSize = 10
        PriorityLevels = 7
        DefaultTimeout = 300
    }
}

# Get decision engine configuration
function Get-DecisionEngineConfiguration {
    [CmdletBinding()]
    param()
    
    return $script:DecisionConfig
}

# Update decision engine configuration
function Set-DecisionEngineConfiguration {
    [CmdletBinding()]
    param(
        [Parameter()]
        [hashtable]$Configuration
    )
    
    if ($Configuration) {
        $script:DecisionConfig = $Configuration
        Write-DecisionLog "Decision engine configuration updated" "INFO"
    }
}

# Logging function with millisecond precision
function Write-DecisionLog {
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [string]$Component = "DecisionEngine"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logEntry = "[$timestamp] [$Level] [$Component] $Message"
    Write-Host $logEntry -ForegroundColor $(
        switch ($Level) {
            "ERROR" { "Red" }
            "WARN" { "Yellow" }
            "SUCCESS" { "Green" }
            "DEBUG" { "Gray" }
            default { "White" }
        }
    )
}

# Export functions
Export-ModuleMember -Function @(
    'Get-DecisionEngineConfiguration',
    'Set-DecisionEngineConfiguration', 
    'Write-DecisionLog'
)

#endregion