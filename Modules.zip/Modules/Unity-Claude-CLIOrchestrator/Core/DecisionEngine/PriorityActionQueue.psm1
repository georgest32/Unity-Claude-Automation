# PriorityActionQueue.psm1
# Priority-based action queue management for DecisionEngine
# Part of Unity-Claude-CLIOrchestrator refactored architecture
# Date: 2025-08-25

#region Priority-Based Action Queue

# Action queue management
$script:ActionQueue = @()
$script:QueueLock = New-Object System.Threading.Mutex($false, "CLIOrchestratorQueue")

# Test action queue capacity
function Test-ActionQueueCapacity {
    [CmdletBinding()]
    param()
    
    # Get configuration
    $decisionConfig = Get-DecisionEngineConfiguration
    
    $currentSize = $script:ActionQueue.Count
    $maxSize = $decisionConfig.ActionQueue.MaxQueueSize
    
    return @{
        HasCapacity = $currentSize -lt $maxSize
        CurrentSize = $currentSize
        MaxSize = $maxSize
        AvailableSlots = [Math]::Max(0, $maxSize - $currentSize)
    }
}

# Create new action queue item
function New-ActionQueueItem {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Decision,
        
        [Parameter(Mandatory = $true)]
        [hashtable]$AnalysisResult,
        
        [Parameter()]
        [switch]$DryRun
    )
    
    Write-DecisionLog "Creating action queue item for: $($Decision.RecommendationType)" "DEBUG"
    
    try {
        # Get configuration
        $decisionConfig = Get-DecisionEngineConfiguration
        
        # Get decision matrix entry
        $matrixEntry = $decisionConfig.DecisionMatrix[$Decision.RecommendationType]
        if (-not $matrixEntry) {
            throw "Unknown recommendation type: $($Decision.RecommendationType)"
        }
        
        # Calculate estimated execution time
        $baseTime = $matrixEntry.TimeoutSeconds
        $complexityMultiplier = switch ($Decision.SafetyLevel) {
            "High" { 1.5 }
            "Medium" { 1.2 }
            "Low" { 1.0 }
            default { 1.0 }
        }
        $estimatedTime = [int]($baseTime * $complexityMultiplier)
        
        # Generate unique action ID
        $actionId = "CLIOrchestratorAction_$($Decision.RecommendationType)_$(Get-Date -Format 'yyyyMMdd_HHmmss_fff')"
        
        $queueItem = @{
            # Core Identification
            ActionId = $actionId
            RecommendationType = $Decision.RecommendationType
            ActionType = $Decision.ActionType
            
            # Execution Parameters
            Action = $Decision.Action
            Priority = $Decision.Priority
            SafetyLevel = $Decision.SafetyLevel
            MaxRetryAttempts = $matrixEntry.MaxRetryAttempts
            TimeoutSeconds = $matrixEntry.TimeoutSeconds
            EstimatedExecutionTime = $estimatedTime
            
            # Context Information
            SourceAnalysis = $AnalysisResult
            ConfidenceScore = $Decision.Confidence
            
            # Queue Management
            QueuedTime = Get-Date
            QueuePosition = $script:ActionQueue.Count + 1
            Status = "Queued"
            DryRun = $DryRun.IsPresent
            
            # Retry Logic
            RetryCount = 0
            LastAttempt = $null
            LastError = $null
        }
        
        # Add to queue if not dry run
        if (-not $DryRun) {
            try {
                $script:QueueLock.WaitOne(1000) | Out-Null
                $script:ActionQueue += $queueItem
                Write-DecisionLog "Action queued: $actionId (Position: $($queueItem.QueuePosition))" "SUCCESS"
            } finally {
                $script:QueueLock.ReleaseMutex()
            }
        } else {
            Write-DecisionLog "DRY RUN: Action would be queued: $actionId" "INFO"
        }
        
        return $queueItem
        
    } catch {
        Write-DecisionLog "Failed to create queue item: $($_.Exception.Message)" "ERROR"
        throw
    }
}

# Get current action queue status
function Get-ActionQueueStatus {
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$IncludeDetails
    )
    
    try {
        $script:QueueLock.WaitOne(1000) | Out-Null
        
        $queueStatus = @{
            TotalItems = $script:ActionQueue.Count
            QueuedItems = ($script:ActionQueue | Where-Object { $_.Status -eq "Queued" }).Count
            ExecutingItems = ($script:ActionQueue | Where-Object { $_.Status -eq "Executing" }).Count
            CompletedItems = ($script:ActionQueue | Where-Object { $_.Status -eq "Completed" }).Count
            FailedItems = ($script:ActionQueue | Where-Object { $_.Status -eq "Failed" }).Count
            Capacity = Test-ActionQueueCapacity
            LastUpdate = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        }
        
        if ($IncludeDetails -and $script:ActionQueue.Count -gt 0) {
            $queueStatus.QueueDetails = $script:ActionQueue | ForEach-Object {
                @{
                    ActionId = $_.ActionId
                    Type = $_.RecommendationType
                    Priority = $_.Priority
                    Status = $_.Status
                    QueuedTime = $_.QueuedTime
                    EstimatedTime = $_.EstimatedExecutionTime
                }
            }
        }
        
        return $queueStatus
        
    } finally {
        $script:QueueLock.ReleaseMutex()
    }
}

# Clear completed or failed actions from queue
function Clear-ActionQueue {
    [CmdletBinding()]
    param(
        [Parameter()]
        [ValidateSet("Completed", "Failed", "All")]
        [string]$Status = "Completed"
    )
    
    try {
        $script:QueueLock.WaitOne(1000) | Out-Null
        
        $originalCount = $script:ActionQueue.Count
        
        if ($Status -eq "All") {
            $script:ActionQueue = @()
        } else {
            $script:ActionQueue = @($script:ActionQueue | Where-Object { $_.Status -ne $Status })
        }
        
        $clearedCount = $originalCount - $script:ActionQueue.Count
        Write-DecisionLog "Cleared $clearedCount actions with status '$Status' from queue" "INFO"
        
        return @{
            ClearedCount = $clearedCount
            RemainingCount = $script:ActionQueue.Count
            Status = $Status
        }
        
    } finally {
        $script:QueueLock.ReleaseMutex()
    }
}

# Update action status
function Update-ActionStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ActionId,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("Queued", "Executing", "Completed", "Failed")]
        [string]$Status,
        
        [Parameter()]
        [string]$ErrorMessage
    )
    
    try {
        $script:QueueLock.WaitOne(1000) | Out-Null
        
        $action = $script:ActionQueue | Where-Object { $_.ActionId -eq $ActionId }
        if ($action) {
            $action.Status = $Status
            $action.LastAttempt = Get-Date
            
            if ($ErrorMessage) {
                $action.LastError = $ErrorMessage
                $action.RetryCount++
            }
            
            Write-DecisionLog "Updated action $ActionId status to '$Status'" "DEBUG"
            return $true
        } else {
            Write-DecisionLog "Action $ActionId not found in queue" "WARN"
            return $false
        }
        
    } finally {
        $script:QueueLock.ReleaseMutex()
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Test-ActionQueueCapacity',
    'New-ActionQueueItem',
    'Get-ActionQueueStatus',
    'Clear-ActionQueue',
    'Update-ActionStatus'
)

#endregion