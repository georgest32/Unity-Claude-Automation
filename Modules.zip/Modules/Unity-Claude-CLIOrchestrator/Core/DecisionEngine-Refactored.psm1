# DecisionEngine-Refactored.psm1
# Refactored Decision Engine - Component-Based Architecture
# Enhanced autonomous decision-making for Claude Code CLI responses
# Unity-Claude-CLIOrchestrator Integration
# Date: 2025-08-25

# ============================================================================
# REFACTORED VERSION - Component-Based Architecture
# Original: 926 lines (monolithic) -> 5 focused components
# Average Component Size: ~185 lines (80% complexity reduction)
# Architecture: Modular components with specialized responsibilities
# ============================================================================

Write-Host "[INFO] Loading DecisionEngine-Refactored.psm1 (Component-Based Architecture)" -ForegroundColor Green

#region Component Imports

# Import all DecisionEngine components
$ComponentPath = Join-Path $PSScriptRoot "DecisionEngine"

# Core Configuration and Logging
Import-Module (Join-Path $ComponentPath "ConfigurationLogging.psm1") -Force -DisableNameChecking

# Rule-Based Decision Trees  
Import-Module (Join-Path $ComponentPath "RuleBasedDecisionTrees.psm1") -Force -DisableNameChecking

# Safety Validation Framework
Import-Module (Join-Path $ComponentPath "SafetyValidationFramework.psm1") -Force -DisableNameChecking

# Priority-Based Action Queue
Import-Module (Join-Path $ComponentPath "PriorityActionQueue.psm1") -Force -DisableNameChecking

# Fallback Strategies
Import-Module (Join-Path $ComponentPath "FallbackStrategies.psm1") -Force -DisableNameChecking

Write-DecisionLog "DecisionEngine components loaded successfully" "SUCCESS"

#endregion

#region Enhanced Orchestration Functions

# Initialize decision engine with comprehensive configuration
function Initialize-DecisionEngine {
    [CmdletBinding()]
    param(
        [Parameter()]
        [hashtable]$CustomConfiguration
    )
    
    Write-DecisionLog "Initializing DecisionEngine with component-based architecture" "INFO"
    
    try {
        # Apply custom configuration if provided
        if ($CustomConfiguration) {
            Set-DecisionEngineConfiguration -Configuration $CustomConfiguration
            Write-DecisionLog "Applied custom configuration" "INFO"
        }
        
        # Initialize queue lock if needed
        $script:QueueInitialized = $true
        
        # Clear any existing actions
        Clear-ActionQueue -Status "All" | Out-Null
        
        # Perform component health check
        $healthCheck = Test-DecisionEngineHealth
        
        if ($healthCheck.IsHealthy) {
            Write-DecisionLog "DecisionEngine initialized successfully" "SUCCESS"
        } else {
            Write-DecisionLog "DecisionEngine initialization completed with warnings" "WARN"
        }
        
        return @{
            Initialized = $true
            ComponentsLoaded = 5
            ConfigurationApplied = $CustomConfiguration -ne $null
            HealthStatus = $healthCheck
            InitializationTime = Get-Date
        }
        
    } catch {
        Write-DecisionLog "DecisionEngine initialization failed: $($_.Exception.Message)" "ERROR"
        throw
    }
}

# Test decision engine component health
function Test-DecisionEngineHealth {
    [CmdletBinding()]
    param()
    
    $healthChecks = @()
    $overallHealthy = $true
    
    try {
        # Check 1: Configuration availability
        $config = Get-DecisionEngineConfiguration
        if ($config -and $config.DecisionMatrix) {
            $healthChecks += @{
                Component = "Configuration"
                Status = "Healthy"
                Details = "Configuration loaded with $($config.DecisionMatrix.Count) decision types"
            }
        } else {
            $healthChecks += @{
                Component = "Configuration"
                Status = "Unhealthy"
                Details = "Configuration missing or invalid"
            }
            $overallHealthy = $false
        }
        
        # Check 2: Action queue capacity
        $queueStatus = Test-ActionQueueCapacity
        if ($queueStatus.HasCapacity) {
            $healthChecks += @{
                Component = "ActionQueue"
                Status = "Healthy"
                Details = "$($queueStatus.AvailableSlots) of $($queueStatus.MaxSize) slots available"
            }
        } else {
            $healthChecks += @{
                Component = "ActionQueue"
                Status = "Warning"
                Details = "Queue at capacity - no available slots"
            }
        }
        
        # Check 3: Component function availability
        $requiredFunctions = @(
            'Invoke-RuleBasedDecision',
            'Test-SafetyValidation',
            'New-ActionQueueItem',
            'Resolve-ConflictingRecommendations',
            'Invoke-GracefulDegradation'
        )
        
        $missingFunctions = @()
        foreach ($func in $requiredFunctions) {
            if (-not (Get-Command $func -ErrorAction SilentlyContinue)) {
                $missingFunctions += $func
            }
        }
        
        if ($missingFunctions.Count -eq 0) {
            $healthChecks += @{
                Component = "Functions"
                Status = "Healthy"
                Details = "All $($requiredFunctions.Count) required functions available"
            }
        } else {
            $healthChecks += @{
                Component = "Functions"
                Status = "Unhealthy"
                Details = "Missing functions: $($missingFunctions -join ', ')"
            }
            $overallHealthy = $false
        }
        
    } catch {
        $healthChecks += @{
            Component = "HealthCheck"
            Status = "Error"
            Details = "Health check failed: $($_.Exception.Message)"
        }
        $overallHealthy = $false
    }
    
    return @{
        IsHealthy = $overallHealthy
        ComponentStatus = $healthChecks
        CheckTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        TotalComponents = 5
        HealthyComponents = ($healthChecks | Where-Object { $_.Status -eq "Healthy" }).Count
    }
}

# Get comprehensive decision engine statistics
function Get-DecisionEngineStatistics {
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$IncludeQueueDetails
    )
    
    try {
        $config = Get-DecisionEngineConfiguration
        $queueStatus = Get-ActionQueueStatus -IncludeDetails:$IncludeQueueDetails
        $healthStatus = Test-DecisionEngineHealth
        
        $statistics = @{
            # Configuration Statistics
            DecisionTypes = $config.DecisionMatrix.Count
            SafetyThresholds = $config.SafetyThresholds.Count
            PerformanceTargets = $config.PerformanceTargets.Count
            
            # Queue Statistics
            QueueStatus = $queueStatus
            
            # Component Health
            ComponentHealth = $healthStatus
            
            # Performance Metrics
            PerformanceTargets = @{
                DecisionTimeMs = $config.PerformanceTargets.DecisionTimeMs
                ValidationTimeMs = $config.PerformanceTargets.ValidationTimeMs
                QueueProcessingTimeMs = $config.PerformanceTargets.QueueProcessingTimeMs
            }
            
            # Architecture Information
            Architecture = @{
                Type = "Component-Based"
                Components = 5
                OriginalLines = 926
                TotalComponentLines = "~925 lines across 5 components"
                AverageComponentSize = "~185 lines"
                ComplexityReduction = "80%"
            }
            
            StatisticsGeneratedAt = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        }
        
        return $statistics
        
    } catch {
        Write-DecisionLog "Failed to generate statistics: $($_.Exception.Message)" "ERROR"
        throw
    }
}

# Advanced decision processing with enhanced error handling
function Invoke-EnhancedDecisionProcessing {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AnalysisResult,
        
        [Parameter()]
        [hashtable]$ProcessingOptions = @{},
        
        [Parameter()]
        [switch]$IncludeAnalytics,
        
        [Parameter()]
        [switch]$DryRun
    )
    
    Write-DecisionLog "Starting enhanced decision processing" "INFO"
    $overallStartTime = Get-Date
    
    try {
        # Pre-processing validation
        if (-not $AnalysisResult -or -not $AnalysisResult.ContainsKey('Recommendations')) {
            return Invoke-GracefulDegradation -AnalysisResult @{} -DegradationReason "Invalid input data"
        }
        
        # Step 1: Analyze for conflicts
        $conflictAnalysis = Get-ConflictAnalysis -Recommendations $AnalysisResult.Recommendations
        
        # Step 2: Handle conflicts if detected
        if ($conflictAnalysis.HasConflicts) {
            Write-DecisionLog "Conflicts detected - invoking resolution strategy" "WARN"
            $decision = Resolve-ConflictingRecommendations -ConflictingRecommendations $AnalysisResult.Recommendations -ConfidenceAnalysis $AnalysisResult.ConfidenceAnalysis
        } else {
            # Step 3: Standard rule-based decision processing
            $decision = Invoke-RuleBasedDecision -AnalysisResult $AnalysisResult -IncludeDetails:$IncludeAnalytics -DryRun:$DryRun
        }
        
        # Step 4: Apply processing options if provided
        if ($ProcessingOptions.Count -gt 0) {
            foreach ($option in $ProcessingOptions.GetEnumerator()) {
                $decision[$option.Key] = $option.Value
            }
        }
        
        # Step 5: Add enhanced metadata
        $decision.EnhancedProcessing = @{
            ConflictAnalysis = $conflictAnalysis
            ProcessingMode = if ($conflictAnalysis.HasConflicts) { "ConflictResolution" } else { "StandardRuleBased" }
            TotalProcessingTimeMs = ((Get-Date) - $overallStartTime).TotalMilliseconds
            ComponentsInvolved = if ($conflictAnalysis.HasConflicts) { @("ConflictResolution", "SafetyValidation", "ActionQueue") } else { @("RuleBased", "SafetyValidation", "ActionQueue") }
        }
        
        Write-DecisionLog "Enhanced decision processing completed: $($decision.Decision)" "SUCCESS"
        
        return $decision
        
    } catch {
        Write-DecisionLog "Enhanced decision processing failed: $($_.Exception.Message)" "ERROR"
        return Get-EmergencyFallback -Reason "Enhanced processing failure: $($_.Exception.Message)"
    }
}

#endregion

# Export all functions for integration
Export-ModuleMember -Function @(
    # Core Decision Functions (from components)
    'Invoke-RuleBasedDecision',
    'Resolve-PriorityDecision',
    'Test-SafetyValidation',
    'Test-SafeFilePath',
    'Test-SafeCommand',
    'Test-ActionQueueCapacity',
    'New-ActionQueueItem',
    'Get-ActionQueueStatus',
    'Clear-ActionQueue',
    'Update-ActionStatus',
    'Resolve-ConflictingRecommendations',
    'Invoke-GracefulDegradation',
    'Get-ConflictAnalysis',
    'Get-EmergencyFallback',
    'Get-DecisionEngineConfiguration',
    'Set-DecisionEngineConfiguration',
    'Write-DecisionLog',
    
    # Enhanced Orchestration Functions
    'Initialize-DecisionEngine',
    'Test-DecisionEngineHealth',
    'Get-DecisionEngineStatistics',
    'Invoke-EnhancedDecisionProcessing'
)

# Module initialization
Write-DecisionLog "DecisionEngine-Refactored module loaded successfully - Component-Based Architecture v2.0" "SUCCESS"
Write-DecisionLog "Components: ConfigurationLogging, RuleBasedDecisionTrees, SafetyValidationFramework, PriorityActionQueue, FallbackStrategies" "INFO"