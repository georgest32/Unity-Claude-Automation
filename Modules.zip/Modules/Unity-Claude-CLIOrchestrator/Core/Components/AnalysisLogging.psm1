# Unity-Claude-CLIOrchestrator - Analysis Logging Component
# Refactored from ResponseAnalysisEngine.psm1 for better maintainability
# Compatible with PowerShell 5.1 and Claude Code CLI 2025

#region Module Configuration

# Default log path - can be overridden by parent module
$script:DefaultLogPath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation\unity_claude_automation.log"
$script:LogPath = $script:DefaultLogPath

#endregion

#region Core Logging Functions

function Write-AnalysisLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter()]
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG", "PERF")]
        [string]$Level = "INFO",
        
        [Parameter()]
        [string]$Component = "ResponseAnalysisEngine",
        
        [Parameter()]
        [string]$LogPath = $script:LogPath
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $logEntry = "[$timestamp] [$Level] [$Component] $Message"
    
    try {
        Add-Content -Path $LogPath -Value $logEntry -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {
        # Silently continue if logging fails - avoid recursive errors
    }
    
    # Console output for debugging
    if ($Level -eq "ERROR") {
        Write-Error $Message
    } elseif ($Level -eq "WARN") {
        Write-Warning $Message
    } else {
        $color = switch ($Level) {
            "INFO" { "Green" }
            "DEBUG" { "Gray" }
            "PERF" { "Cyan" }
            default { "White" }
        }
        Write-Host "[$Level] $Message" -ForegroundColor $color
    }
}

function Set-AnalysisLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )
    
    $script:LogPath = $Path
    Write-AnalysisLog -Message "Log path updated to: $Path" -Level "INFO" -Component "AnalysisLogging"
}

function Get-AnalysisLogPath {
    [CmdletBinding()]
    param()
    
    return $script:LogPath
}

function Test-AnalysisLogging {
    [CmdletBinding()]
    param()
    
    $testResults = @()
    
    try {
        # Test basic logging
        Write-AnalysisLog -Message "Test message" -Level "INFO" -Component "TestComponent"
        $testResults += @{
            Name = "Basic Logging"
            Status = "Passed"
            Details = "Successfully wrote test log entry"
        }
        
        # Test log path functions
        $originalPath = Get-AnalysisLogPath
        $testPath = "$env:TEMP\test_analysis.log"
        Set-AnalysisLogPath -Path $testPath
        
        if ((Get-AnalysisLogPath) -eq $testPath) {
            $testResults += @{
                Name = "Log Path Management"
                Status = "Passed" 
                Details = "Successfully updated and retrieved log path"
            }
        } else {
            $testResults += @{
                Name = "Log Path Management"
                Status = "Failed"
                Details = "Log path not updated correctly"
            }
        }
        
        # Restore original path
        Set-AnalysisLogPath -Path $originalPath
        
    } catch {
        $testResults += @{
            Name = "Logging Component Test"
            Status = "Failed"
            Error = $_.Exception.Message
        }
    }
    
    return $testResults
}

#endregion

#region Module Exports

Export-ModuleMember -Function @(
    'Write-AnalysisLog',
    'Set-AnalysisLogPath', 
    'Get-AnalysisLogPath',
    'Test-AnalysisLogging'
)

#endregion