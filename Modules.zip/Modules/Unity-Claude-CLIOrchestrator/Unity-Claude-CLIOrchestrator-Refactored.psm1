#region Module Header
<#
.SYNOPSIS
    Unity-Claude CLI Orchestrator Module - Refactored
    Phase 7 Advanced Features: Intelligent CLI Orchestration System
    
.DESCRIPTION
    Provides comprehensive autonomous CLI orchestration with intelligent window management,
    secure prompt submission, autonomous operations, and sophisticated decision making.
    This is the refactored version with modular component architecture.
    
.VERSION
    2.0.0
    
.AUTHOR
    Unity-Claude-Automation
    
.DATE
    2025-08-25
    
.ARCHITECTURE
    This module follows a component-based architecture with specialized modules:
    - WindowManager: Claude CLI window detection and management
    - PromptSubmissionEngine: Secure TypeKeys prompt submission with safety measures
    - AutonomousOperations: Autonomous prompt generation and execution loops
    - OrchestrationManager: Main orchestration control and status monitoring
    - (Existing) ResponseAnalysisEngine: Advanced response analysis and processing
    - (Existing) PatternRecognitionEngine: Pattern recognition and classification
    - (Existing) DecisionEngine: Rule-based and Bayesian decision making
    - (Existing) ActionExecutionEngine: Safe action execution with queuing
    
.REFACTORING_NOTES
    Original module: 1,610 lines
    Refactored components: 4 new components + existing Core/ components
    New components average: ~402 lines each (down from 1,610 monolithic)
    Benefits: Improved maintainability, testability, and modularity
#>
#endregion

#region Private Variables
$script:CLIOrchestratorConfig = @{
    IsRunning = $false
    Version = "2.0.0"
    Architecture = "Component-Based"
    StartTime = $null
    LastActivity = $null
    ComponentStatus = @{}
    SessionStats = @{
        PromptsSent = 0
        ResponsesProcessed = 0
        DecisionsMade = 0
        ActionsExecuted = 0
        ErrorCount = 0
    }
}

# Simple directive for backward compatibility
$script:SimpleDirective = " ================================================== CRITICAL: AT THE END OF YOUR RESPONSE, YOU MUST CREATE A RESPONSE .JSON FILE AT ./ClaudeResponses/Autonomous/ AND IN IT WRITE THE END OF YOUR RESPONSE, WHICH SHOULD END WITH: [RECOMMENDATION: CONTINUE]; [RECOMMENDATION: TEST <Name>]; [RECOMMENDATION: FIX <File>]; [RECOMMENDATION: COMPILE]; [RECOMMENDATION: RESTART <Module>]; [RECOMMENDATION: COMPLETE]; [RECOMMENDATION: ERROR <Description>]=================================================="

# Full boilerplate prompt stored as a resource  
$script:BoilerplatePrompt = $null
try {
    $boilerplatePath = Join-Path $PSScriptRoot "Resources\BoilerplatePrompt.txt"
    if (Test-Path $boilerplatePath) {
        $script:BoilerplatePrompt = Get-Content -Path $boilerplatePath -Raw
    }
} catch {
    Write-Host "Warning: Could not load boilerplate prompt file: $_" -ForegroundColor Yellow
}

if (-not $script:BoilerplatePrompt) {
    # Fallback to simple directive if file not found
    $script:BoilerplatePrompt = "Please process the following recommendation and provide a detailed response."
}
#endregion

#region Component Imports

# Import new refactored components
Import-Module (Join-Path $PSScriptRoot "Core\WindowManager.psm1") -Force -Global
Import-Module (Join-Path $PSScriptRoot "Core\PromptSubmissionEngine.psm1") -Force -Global  
Import-Module (Join-Path $PSScriptRoot "Core\AutonomousOperations.psm1") -Force -Global
Import-Module (Join-Path $PSScriptRoot "Core\OrchestrationManager.psm1") -Force -Global

# Import existing Core components (maintain compatibility)
. "$PSScriptRoot\Core\ResponseAnalysisEngine.psm1"
. "$PSScriptRoot\Core\PatternRecognitionEngine.psm1"
. "$PSScriptRoot\Core\DecisionEngine.psm1"
. "$PSScriptRoot\Core\ActionExecutionEngine.psm1"

#endregion

#region Enhanced Orchestration Functions

function Initialize-CLIOrchestrator {
    <#
    .SYNOPSIS
        Initializes the CLI orchestrator system with all components
    .DESCRIPTION
        Performs comprehensive initialization of all orchestration components
        and validates system readiness for autonomous operations
    .PARAMETER ValidateComponents
        Validate all components during initialization
    .PARAMETER SetupDirectories
        Create required directories during initialization
    .EXAMPLE
        Initialize-CLIOrchestrator -ValidateComponents -SetupDirectories
    #>
    [CmdletBinding()]
    param(
        [switch]$ValidateComponents,
        [switch]$SetupDirectories
    )
    
    try {
        Write-Host "Initializing CLI Orchestrator System v2.0..." -ForegroundColor Cyan
        
        # Initialize configuration
        $script:CLIOrchestratorConfig.StartTime = Get-Date
        $script:CLIOrchestratorConfig.LastActivity = Get-Date
        
        # Setup directories if requested
        if ($SetupDirectories) {
            $directories = @(
                ".\ClaudeResponses\Autonomous",
                ".\logs\orchestrator",
                ".\config\orchestrator"
            )
            
            foreach ($dir in $directories) {
                if (-not (Test-Path $dir)) {
                    New-Item -Path $dir -ItemType Directory -Force | Out-Null
                    Write-Verbose "Created directory: $dir"
                }
            }
            Write-Host "  Directory structure validated" -ForegroundColor Gray
        }
        
        # Validate components if requested
        if ($ValidateComponents) {
            $componentResults = Test-CLIOrchestratorComponents
            $healthyComponents = ($componentResults.Components | Where-Object { $_.Status -eq 'Healthy' }).Count
            Write-Host "  Components: $healthyComponents/$($componentResults.Components.Count) healthy" -ForegroundColor Gray
            
            # Update component status
            foreach ($component in $componentResults.Components) {
                $script:CLIOrchestratorConfig.ComponentStatus[$component.Name] = $component.Status
            }
        }
        
        # Validate Claude window availability
        $claudeWindow = Find-ClaudeWindow
        if ($claudeWindow) {
            Write-Host "  Claude CLI window detected successfully" -ForegroundColor Green
        } else {
            Write-Host "  WARNING: Claude CLI window not found" -ForegroundColor Yellow
        }
        
        Write-Host "CLI Orchestrator System initialized successfully" -ForegroundColor Green
        Write-Host "  Version: 2.0.0 (Refactored)" -ForegroundColor Gray
        Write-Host "  Architecture: Component-Based" -ForegroundColor Gray
        
        $script:CLIOrchestratorConfig.IsRunning = $true
        
        return @{
            Version = "2.0.0"
            Initialized = $true
            ComponentHealth = if ($ValidateComponents) { $componentResults } else { @{} }
            ClaudeWindowAvailable = ($claudeWindow -ne $null)
            InitializedAt = $script:CLIOrchestratorConfig.StartTime
        }
        
    } catch {
        Write-Error "Failed to initialize CLI orchestrator: $_"
        throw
    }
}

function Test-CLIOrchestratorComponents {
    <#
    .SYNOPSIS
        Tests health of all CLI orchestrator components
    .DESCRIPTION
        Performs health checks on all system components including new refactored
        components and existing Core components
    .EXAMPLE
        Test-CLIOrchestratorComponents
    #>
    [CmdletBinding()]
    param()
    
    try {
        $healthResults = @{
            Overall = 'Healthy'
            TestedAt = Get-Date
            Components = @()
        }
        
        # Test WindowManager component
        try {
            $claudeWindow = Find-ClaudeWindow
            $healthResults.Components += @{
                Name = 'WindowManager'
                Status = 'Healthy'
                Details = if ($claudeWindow) { "Claude window detected" } else { "Claude window not found" }
            }
        } catch {
            $healthResults.Components += @{
                Name = 'WindowManager'
                Status = 'Error'
                Details = $_.Exception.Message
            }
            $healthResults.Overall = 'Degraded'
        }
        
        # Test PromptSubmissionEngine component
        try {
            # Test by checking if required assemblies are loaded
            $sendKeysAvailable = [System.Windows.Forms.SendKeys] -ne $null
            $healthResults.Components += @{
                Name = 'PromptSubmissionEngine'
                Status = 'Healthy'
                Details = "SendKeys functionality available: $sendKeysAvailable"
            }
        } catch {
            $healthResults.Components += @{
                Name = 'PromptSubmissionEngine'
                Status = 'Error'
                Details = $_.Exception.Message
            }
            $healthResults.Overall = 'Degraded'
        }
        
        # Test AutonomousOperations component
        try {
            $prompt = New-AutonomousPrompt -BasePrompt "Test prompt" -Priority "Low"
            $healthResults.Components += @{
                Name = 'AutonomousOperations'
                Status = 'Healthy'
                Details = "Prompt generation functional, test prompt length: $($prompt.Length) characters"
            }
        } catch {
            $healthResults.Components += @{
                Name = 'AutonomousOperations'
                Status = 'Error'
                Details = $_.Exception.Message
            }
            $healthResults.Overall = 'Degraded'
        }
        
        # Test OrchestrationManager component
        try {
            $status = Get-CLIOrchestrationStatus
            $healthResults.Components += @{
                Name = 'OrchestrationManager'
                Status = 'Healthy'
                Details = "Status reporting functional, overall status: $($status.OverallStatus)"
            }
        } catch {
            $healthResults.Components += @{
                Name = 'OrchestrationManager'
                Status = 'Error'
                Details = $_.Exception.Message
            }
            $healthResults.Overall = 'Degraded'
        }
        
        # Test existing Core components
        $coreComponents = @('ResponseAnalysisEngine', 'PatternRecognitionEngine', 'DecisionEngine', 'ActionExecutionEngine')
        
        foreach ($component in $coreComponents) {
            try {
                # Basic availability test - check if functions are available
                $testFunction = switch ($component) {
                    'ResponseAnalysisEngine' { 'Invoke-EnhancedResponseAnalysis' }
                    'PatternRecognitionEngine' { 'Find-RecommendationPatterns' }  
                    'DecisionEngine' { 'Invoke-RuleBasedDecision' }
                    'ActionExecutionEngine' { 'Invoke-SafeAction' }
                }
                
                if (Get-Command $testFunction -ErrorAction SilentlyContinue) {
                    $healthResults.Components += @{
                        Name = $component
                        Status = 'Healthy'
                        Details = "Core component available"
                    }
                } else {
                    $healthResults.Components += @{
                        Name = $component
                        Status = 'Warning'
                        Details = "Core component function not found: $testFunction"
                    }
                    if ($healthResults.Overall -eq 'Healthy') {
                        $healthResults.Overall = 'Degraded'
                    }
                }
            } catch {
                $healthResults.Components += @{
                    Name = $component
                    Status = 'Error'
                    Details = $_.Exception.Message
                }
                $healthResults.Overall = 'Degraded'
            }
        }
        
        return $healthResults
        
    } catch {
        Write-Error "Failed to test component health: $_"
        throw
    }
}

function Get-CLIOrchestratorInfo {
    <#
    .SYNOPSIS
        Gets comprehensive information about the CLI orchestrator system
    .DESCRIPTION
        Returns detailed system information including version, architecture,
        components, and runtime statistics
    .EXAMPLE
        Get-CLIOrchestratorInfo
    #>
    [CmdletBinding()]
    param()
    
    try {
        $info = @{
            Version = "2.0.0"
            Architecture = "Component-Based"
            RefactoringDetails = @{
                OriginalLines = 1610
                NewComponents = 4
                ExistingCoreComponents = 4
                TotalComponents = 8
                AverageNewComponentSize = 402
                Maintainability = "Significantly Improved"
                Testability = "Enhanced" 
            }
            Components = @{
                New = @(
                    @{ Name = "WindowManager"; Description = "Claude CLI window detection and management"; Lines = "~272" }
                    @{ Name = "PromptSubmissionEngine"; Description = "Secure TypeKeys prompt submission with safety measures"; Lines = "~310" }
                    @{ Name = "AutonomousOperations"; Description = "Autonomous prompt generation and execution loops"; Lines = "~490" }
                    @{ Name = "OrchestrationManager"; Description = "Main orchestration control and status monitoring"; Lines = "~536" }
                )
                Existing = @(
                    @{ Name = "ResponseAnalysisEngine"; Description = "Advanced response analysis and processing" }
                    @{ Name = "PatternRecognitionEngine"; Description = "Pattern recognition and classification" }
                    @{ Name = "DecisionEngine"; Description = "Rule-based and Bayesian decision making" }
                    @{ Name = "ActionExecutionEngine"; Description = "Safe action execution with queuing" }
                )
            }
            Benefits = @(
                "Separation of concerns with focused components"
                "Improved code maintainability and readability"
                "Enhanced testability with isolated components"
                "Better error isolation and debugging"
                "Easier feature development and extension"
                "Preserved existing Core component functionality"
                "Maintained full backward compatibility"
            )
            SessionStatistics = $script:CLIOrchestratorConfig.SessionStats.Clone()
            SystemState = @{
                IsRunning = $script:CLIOrchestratorConfig.IsRunning
                StartTime = $script:CLIOrchestratorConfig.StartTime
                LastActivity = $script:CLIOrchestratorConfig.LastActivity
                ComponentStatus = $script:CLIOrchestratorConfig.ComponentStatus.Clone()
            }
        }
        
        # Add runtime information
        if ($script:CLIOrchestratorConfig.IsRunning -and $script:CLIOrchestratorConfig.StartTime) {
            $runtime = (Get-Date) - $script:CLIOrchestratorConfig.StartTime
            $info.SystemState.RuntimeMinutes = [Math]::Round($runtime.TotalMinutes, 2)
        }
        
        return $info
        
    } catch {
        Write-Error "Failed to get CLI orchestrator info: $_"
        throw
    }
}

function Update-CLISessionStats {
    <#
    .SYNOPSIS
        Updates CLI orchestrator session statistics
    .DESCRIPTION
        Updates various session statistics for monitoring and reporting
    .PARAMETER StatType
        Type of statistic to update
    .PARAMETER Increment
        Amount to increment the statistic by (default: 1)
    .EXAMPLE
        Update-CLISessionStats -StatType "PromptsSent"
    #>
    [CmdletBinding()]
    param(
        [ValidateSet("PromptsSent", "ResponsesProcessed", "DecisionsMade", "ActionsExecuted", "ErrorCount")]
        [string]$StatType,
        
        [int]$Increment = 1
    )
    
    try {
        if ($script:CLIOrchestratorConfig.SessionStats.ContainsKey($StatType)) {
            $script:CLIOrchestratorConfig.SessionStats[$StatType] += $Increment
            $script:CLIOrchestratorConfig.LastActivity = Get-Date
            
            Write-Verbose "Updated $StatType by $Increment (new value: $($script:CLIOrchestratorConfig.SessionStats[$StatType]))"
        } else {
            Write-Warning "Unknown statistic type: $StatType"
        }
    } catch {
        Write-Error "Failed to update session statistics: $_"
    }
}

#endregion

#region Module Initialization
# Initialize module state
if (-not $script:CLIOrchestratorConfig.StartTime) {
    $script:CLIOrchestratorConfig.StartTime = Get-Date
    $script:CLIOrchestratorConfig.LastActivity = Get-Date
}

# Auto-initialize if Claude window is available
try {
    $claudeWindow = Find-ClaudeWindow
    if ($claudeWindow) {
        Write-Verbose "CLI Orchestrator: Claude window detected, system ready for operation"
    }
} catch {
    Write-Verbose "CLI Orchestrator: Initialization check completed"
}
#endregion

# Re-export nested module functions to ensure they are available
# This is needed because nested modules functions aren't automatically available to callers
if (Get-Command 'Invoke-RuleBasedDecision' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Invoke-RuleBasedDecision'
}
if (Get-Command 'Resolve-PriorityDecision' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Resolve-PriorityDecision'
}
if (Get-Command 'Test-SafetyValidation' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Test-SafetyValidation'
}
if (Get-Command 'Test-SafeFilePath' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Test-SafeFilePath'
}
if (Get-Command 'Test-SafeCommand' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Test-SafeCommand'
}
if (Get-Command 'Test-ActionQueueCapacity' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Test-ActionQueueCapacity'
}
if (Get-Command 'New-ActionQueueItem' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'New-ActionQueueItem'
}
if (Get-Command 'Get-ActionQueueStatus' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Get-ActionQueueStatus'
}
if (Get-Command 'Resolve-ConflictingRecommendations' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Resolve-ConflictingRecommendations'
}
if (Get-Command 'Invoke-GracefulDegradation' -ErrorAction SilentlyContinue) {
    Export-ModuleMember -Function 'Invoke-GracefulDegradation'
}

# Export all functions from new components plus orchestration functions
Export-ModuleMember -Function @(
    # New Orchestration Functions
    'Initialize-CLIOrchestrator',
    'Test-CLIOrchestratorComponents',
    'Get-CLIOrchestratorInfo',
    'Update-CLISessionStats',
    
    # WindowManager Functions
    'Update-ClaudeWindowInfo',
    'Find-ClaudeWindow',
    'Switch-ToWindow',
    
    # PromptSubmissionEngine Functions
    'Submit-ToClaudeViaTypeKeys',
    'Execute-TestScript',
    
    # AutonomousOperations Functions
    'New-AutonomousPrompt',
    'Get-ActionResultSummary',
    'Process-ResponseFile',
    'Invoke-AutonomousExecutionLoop',
    
    # OrchestrationManager Functions  
    'Start-CLIOrchestration',
    'Get-CLIOrchestrationStatus',
    'Invoke-ComprehensiveResponseAnalysis',
    'Invoke-AutonomousDecisionMaking',
    'Invoke-DecisionExecution',
    
    # Legacy Functions (maintained for backward compatibility)
    'Invoke-RuleBasedDecision',
    'Resolve-PriorityDecision', 
    'Test-SafetyValidation',
    'Test-SafeFilePath',
    'Test-SafeCommand',
    'Test-ActionQueueCapacity',
    'New-ActionQueueItem',
    'Get-ActionQueueStatus',
    'Resolve-ConflictingRecommendations',
    'Invoke-GracefulDegradation',
    
    # Circuit Breaker Functions
    'Test-CircuitBreakerState',
    'Update-CircuitBreakerState',
    
    # Pattern Recognition Functions
    'Invoke-PatternRecognitionAnalysis',
    'Find-RecommendationPatterns',
    'Extract-ContextEntities',
    'Classify-ResponseType',
    'Calculate-OverallConfidence',
    
    # Response Analysis Functions
    'Invoke-EnhancedResponseAnalysis',
    'Test-JsonTruncation',
    'Repair-TruncatedJson',
    'Extract-ResponseEntities',
    'Analyze-ResponseSentiment',
    'Get-ResponseContext',
    
    # Action Execution Functions
    'Invoke-SafeAction',
    'Add-ActionToQueue',
    'Get-NextQueuedAction',
    'Get-ActionExecutionStatus',
    'Test-ActionSafety'
)