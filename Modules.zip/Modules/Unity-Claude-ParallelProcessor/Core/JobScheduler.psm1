# JobScheduler.psm1
# Job submission, execution, tracking, and result collection for parallel processing

using namespace System.Management.Automation.Runspaces
using namespace System.Collections.Concurrent
using namespace System.Threading

Write-Debug "[JobScheduler] Module loaded - REFACTORED VERSION"

# Import core functions
Import-Module "$PSScriptRoot\ParallelProcessorCore.psm1" -Force
Import-Module "$PSScriptRoot\RunspacePoolManager.psm1" -Force

#region Job Management Classes

class ParallelJob {
    [string]$Id
    [PowerShell]$PowerShell
    [System.IAsyncResult]$Handle
    [datetime]$StartTime
    [datetime]$EndTime
    [hashtable]$Parameters
    [string]$Status  # 'Submitted', 'Running', 'Completed', 'Failed', 'Cancelled'
    [object]$Result
    [System.Management.Automation.ErrorRecord[]]$Errors
    [int]$RetryCount
    [string]$ProcessorId
    [scriptblock]$ScriptBlock
    
    ParallelJob([string]$id, [scriptblock]$scriptBlock, [hashtable]$parameters, [string]$processorId) {
        $this.Id = $id
        $this.ScriptBlock = $scriptBlock
        $this.Parameters = if ($parameters) { $parameters } else { @{} }
        $this.StartTime = [datetime]::Now
        $this.Status = 'Submitted'
        $this.RetryCount = 0
        $this.ProcessorId = $processorId
        $this.Errors = @()
    }
    
    # Get job duration
    [timespan]GetDuration() {
        if ($this.EndTime -eq [datetime]::MinValue) {
            return [datetime]::Now - $this.StartTime
        } else {
            return $this.EndTime - $this.StartTime
        }
    }
    
    # Get job summary
    [hashtable]GetSummary() {
        return @{
            Id = $this.Id
            Status = $this.Status
            StartTime = $this.StartTime
            EndTime = $this.EndTime
            Duration = $this.GetDuration()
            RetryCount = $this.RetryCount
            HasErrors = $this.Errors.Count -gt 0
            ErrorCount = $this.Errors.Count
            ParameterCount = $this.Parameters.Count
        }
    }
}

class JobScheduler {
    [ConcurrentDictionary[string, ParallelJob]]$Jobs
    [System.Collections.Generic.List[ParallelJob]]$RunningJobs
    [object]$PoolManager
    [hashtable]$SharedData
    [System.Threading.CancellationTokenSource]$CancellationTokenSource
    [int]$RetryCount
    [int]$TimeoutSeconds
    [string]$ProcessorId
    
    JobScheduler([object]$poolManager, [string]$processorId) {
        Write-ParallelProcessorLog "Initializing JobScheduler" -Level Debug -ProcessorId $processorId -Component "JobScheduler"
        
        $this.PoolManager = $poolManager
        $this.ProcessorId = $processorId
        $this.Jobs = [ConcurrentDictionary[string, ParallelJob]]::new()
        $this.RunningJobs = [System.Collections.Generic.List[ParallelJob]]::new()
        $this.SharedData = [hashtable]::Synchronized(@{})
        $this.CancellationTokenSource = [System.Threading.CancellationTokenSource]::new()
        
        # Get default configuration
        $config = Get-ParallelProcessorConfiguration
        $this.RetryCount = $config.DefaultRetryCount
        $this.TimeoutSeconds = $config.DefaultTimeoutSeconds
        
        Write-ParallelProcessorLog "JobScheduler initialized" -Level Debug -ProcessorId $processorId -Component "JobScheduler"
    }
    
    # Submit a job for execution
    [string]SubmitJob([scriptblock]$scriptBlock, [hashtable]$parameters = @{}) {
        # Validate inputs
        if (-not (Test-ScriptBlockSafety -ScriptBlock $scriptBlock)) {
            throw "Script block failed safety validation"
        }
        
        if (-not (Test-ParameterValidity -Parameters $parameters)) {
            throw "Parameters failed validation"
        }
        
        $jobId = [Guid]::NewGuid().ToString()
        Write-ParallelProcessorLog "Submitting job: $jobId" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        # Create job object
        $job = [ParallelJob]::new($jobId, $scriptBlock, $parameters, $this.ProcessorId)
        
        try {
            # Create PowerShell instance
            $job.PowerShell = [PowerShell]::Create()
            $job.PowerShell.RunspacePool = $this.PoolManager.RunspacePool
            
            # Add script block
            [void]$job.PowerShell.AddScript($scriptBlock)
            
            # Add parameters
            foreach ($param in $parameters.GetEnumerator()) {
                [void]$job.PowerShell.AddParameter($param.Key, $param.Value)
            }
            
            # Add shared data as a parameter if not already present
            if (-not $parameters.ContainsKey('SharedData')) {
                [void]$job.PowerShell.AddParameter('SharedData', $this.SharedData)
            }
            
            # Start async execution
            $job.Handle = $job.PowerShell.BeginInvoke()
            $job.Status = 'Running'
            
            # Store job
            $this.Jobs[$jobId] = $job
            $this.RunningJobs.Add($job)
            
            Write-ParallelProcessorLog "Job submitted and started: $jobId" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
            return $jobId
        } catch {
            Write-ParallelProcessorLog "Failed to submit job $jobId : $_" -Level Error -ProcessorId $this.ProcessorId -Component "JobScheduler"
            $job.Status = 'Failed'
            $job.Errors += $_
            throw
        }
    }
    
    # Submit multiple jobs
    [string[]]SubmitJobs([scriptblock]$scriptBlock, [array]$parameterSets) {
        Write-ParallelProcessorLog "Submitting batch of $($parameterSets.Count) jobs" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        $jobIds = @()
        
        foreach ($params in $parameterSets) {
            try {
                if ($params -is [hashtable]) {
                    $jobIds += $this.SubmitJob($scriptBlock, $params)
                } else {
                    $jobIds += $this.SubmitJob($scriptBlock, @{ InputObject = $params })
                }
            } catch {
                Write-ParallelProcessorLog "Failed to submit job in batch: $_" -Level Warning -ProcessorId $this.ProcessorId -Component "JobScheduler"
            }
        }
        
        Write-ParallelProcessorLog "Submitted $($jobIds.Count) jobs successfully" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        return $jobIds
    }
    
    # Wait for a specific job
    [object]WaitForJob([string]$jobId, [int]$timeoutSeconds = 0) {
        if (-not $this.Jobs.ContainsKey($jobId)) {
            throw "Job not found: $jobId"
        }
        
        $job = $this.Jobs[$jobId]
        $timeout = if ($timeoutSeconds -gt 0) { $timeoutSeconds } else { $this.TimeoutSeconds }
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        
        Write-ParallelProcessorLog "Waiting for job: $jobId (timeout: $timeout seconds)" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        while ($job.Status -eq 'Running') {
            if ($job.Handle.IsCompleted) {
                $this.CollectJobResult($job)
                break
            }
            
            if ($stopwatch.Elapsed.TotalSeconds -gt $timeout) {
                Write-ParallelProcessorLog "Job $jobId timed out after $timeout seconds" -Level Warning -ProcessorId $this.ProcessorId -Component "JobScheduler"
                $this.CancelJob($jobId)
                throw "Job timed out: $jobId"
            }
            
            Start-Sleep -Milliseconds 100
        }
        
        return $job.Result
    }
    
    # Wait for all running jobs
    [object[]]WaitForAllJobs([int]$timeoutSeconds = 0) {
        $timeout = if ($timeoutSeconds -gt 0) { $timeoutSeconds } else { $this.TimeoutSeconds }
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        
        Write-ParallelProcessorLog "Waiting for all jobs (count: $($this.RunningJobs.Count), timeout: $timeout seconds)" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        while ($this.RunningJobs.Count -gt 0) {
            $completedJobs = @()
            
            # Check for completed jobs
            foreach ($job in $this.RunningJobs) {
                if ($job.Handle.IsCompleted) {
                    $this.CollectJobResult($job)
                    $completedJobs += $job
                }
            }
            
            # Remove completed jobs from running list
            foreach ($job in $completedJobs) {
                $this.RunningJobs.Remove($job)
            }
            
            # Check timeout
            if ($stopwatch.Elapsed.TotalSeconds -gt $timeout) {
                Write-ParallelProcessorLog "Timeout waiting for all jobs after $timeout seconds" -Level Warning -ProcessorId $this.ProcessorId -Component "JobScheduler"
                $this.CancelAllJobs()
                break
            }
            
            if ($this.RunningJobs.Count -gt 0) {
                Start-Sleep -Milliseconds 100
            }
        }
        
        # Collect all results
        $allResults = @()
        foreach ($job in $this.Jobs.Values) {
            if ($job.Status -eq 'Completed' -and $null -ne $job.Result) {
                $allResults += $job.Result
            }
        }
        
        Write-ParallelProcessorLog "All jobs completed. Results: $($allResults.Count)" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        return $allResults
    }
    
    # Collect job result
    hidden [void]CollectJobResult([ParallelJob]$job) {
        Write-ParallelProcessorLog "Collecting result for job: $($job.Id)" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        try {
            # End invoke and get result
            $result = $job.PowerShell.EndInvoke($job.Handle)
            $job.EndTime = [datetime]::Now
            
            # Check for errors
            if ($job.PowerShell.HadErrors) {
                $job.Errors = $job.PowerShell.Streams.Error
                $job.Status = 'Failed'
                
                # Retry logic
                if ($job.RetryCount -lt $this.RetryCount) {
                    Write-ParallelProcessorLog "Job $($job.Id) failed, retrying (attempt $($job.RetryCount + 1)/$($this.RetryCount))" -Level Warning -ProcessorId $this.ProcessorId -Component "JobScheduler"
                    $this.RetryJob($job)
                    return
                } else {
                    Write-ParallelProcessorLog "Job $($job.Id) failed after $($this.RetryCount) retries" -Level Error -ProcessorId $this.ProcessorId -Component "JobScheduler"
                }
            } else {
                $job.Result = $result
                $job.Status = 'Completed'
                Write-ParallelProcessorLog "Job $($job.Id) completed successfully" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
            }
        } catch {
            Write-ParallelProcessorLog "Error collecting job result for $($job.Id): $_" -Level Error -ProcessorId $this.ProcessorId -Component "JobScheduler"
            $job.Status = 'Failed'
            $job.Errors += $_
            $job.EndTime = [datetime]::Now
        } finally {
            # Dispose PowerShell instance
            if ($job.PowerShell) {
                $job.PowerShell.Dispose()
                $job.PowerShell = $null
            }
        }
    }
    
    # Retry failed job
    hidden [void]RetryJob([ParallelJob]$job) {
        $job.RetryCount++
        Write-ParallelProcessorLog "Retrying job $($job.Id) (attempt $($job.RetryCount))" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        try {
            # Dispose old PowerShell instance
            if ($job.PowerShell) {
                $job.PowerShell.Dispose()
            }
            
            # Create new PowerShell instance
            $job.PowerShell = [PowerShell]::Create()
            $job.PowerShell.RunspacePool = $this.PoolManager.RunspacePool
            
            # Re-add script block and parameters
            [void]$job.PowerShell.AddScript($job.ScriptBlock)
            
            foreach ($param in $job.Parameters.GetEnumerator()) {
                [void]$job.PowerShell.AddParameter($param.Key, $param.Value)
            }
            
            [void]$job.PowerShell.AddParameter('SharedData', $this.SharedData)
            
            # Start execution
            $job.Handle = $job.PowerShell.BeginInvoke()
            $job.Status = 'Running'
            $job.Errors = @()
            $job.StartTime = [datetime]::Now  # Reset start time for retry
            
        } catch {
            Write-ParallelProcessorLog "Failed to retry job $($job.Id): $_" -Level Error -ProcessorId $this.ProcessorId -Component "JobScheduler"
            $job.Status = 'Failed'
            $job.Errors += $_
        }
    }
    
    # Cancel specific job
    [void]CancelJob([string]$jobId) {
        if ($this.Jobs.ContainsKey($jobId)) {
            $job = $this.Jobs[$jobId]
            
            if ($job.Status -eq 'Running') {
                Write-ParallelProcessorLog "Cancelling job: $jobId" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
                
                try {
                    $job.PowerShell.Stop()
                    $job.Status = 'Cancelled'
                    $job.EndTime = [datetime]::Now
                    
                    # Remove from running jobs list
                    $this.RunningJobs.Remove($job)
                } catch {
                    Write-ParallelProcessorLog "Error cancelling job $jobId : $_" -Level Warning -ProcessorId $this.ProcessorId -Component "JobScheduler"
                }
            }
        }
    }
    
    # Cancel all jobs
    [void]CancelAllJobs() {
        Write-ParallelProcessorLog "Cancelling all jobs (count: $($this.RunningJobs.Count))" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        $jobsToCancel = $this.RunningJobs.ToArray()  # Create copy to avoid modification during iteration
        
        foreach ($job in $jobsToCancel) {
            $this.CancelJob($job.Id)
        }
        
        $this.RunningJobs.Clear()
        Write-ParallelProcessorLog "All jobs cancelled" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
    }
    
    # Get job status
    [hashtable]GetJobStatus([string]$jobId) {
        if (-not $this.Jobs.ContainsKey($jobId)) {
            return @{ Status = 'NotFound' }
        }
        
        $job = $this.Jobs[$jobId]
        return $job.GetSummary()
    }
    
    # Get all job statuses
    [hashtable[]]GetAllJobStatuses() {
        $statuses = @()
        foreach ($job in $this.Jobs.Values) {
            $statuses += $job.GetSummary()
        }
        return $statuses
    }
    
    # Cleanup completed jobs
    [void]CleanupCompletedJobs() {
        $jobsToRemove = @()
        
        foreach ($job in $this.Jobs.Values) {
            if ($job.Status -in @('Completed', 'Failed', 'Cancelled')) {
                $jobsToRemove += $job.Id
            }
        }
        
        foreach ($jobId in $jobsToRemove) {
            $removed = $null
            $this.Jobs.TryRemove($jobId, [ref]$removed)
        }
        
        if ($jobsToRemove.Count -gt 0) {
            Write-ParallelProcessorLog "Cleaned up $($jobsToRemove.Count) completed jobs" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        }
    }
    
    # Dispose resources
    [void]Dispose() {
        Write-ParallelProcessorLog "Disposing JobScheduler" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
        
        # Cancel all running jobs
        $this.CancelAllJobs()
        
        # Dispose all PowerShell instances
        foreach ($job in $this.Jobs.Values) {
            if ($job.PowerShell) {
                $job.PowerShell.Dispose()
            }
        }
        
        # Dispose cancellation token
        if ($this.CancellationTokenSource) {
            $this.CancellationTokenSource.Dispose()
        }
        
        Write-ParallelProcessorLog "JobScheduler disposed" -Level Debug -ProcessorId $this.ProcessorId -Component "JobScheduler"
    }
}

#endregion

#region Helper Functions

function New-JobScheduler {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$PoolManager,
        
        [Parameter(Mandatory)]
        [string]$ProcessorId
    )
    
    Write-ParallelProcessorLog "Creating JobScheduler" -Level Debug -ProcessorId $ProcessorId -Component "JobScheduler"
    
    try {
        $scheduler = [JobScheduler]::new($PoolManager, $ProcessorId)
        Write-ParallelProcessorLog "JobScheduler created successfully" -Level Debug -ProcessorId $ProcessorId -Component "JobScheduler"
        return $scheduler
    } catch {
        Write-ParallelProcessorLog "Failed to create JobScheduler: $_" -Level Error -ProcessorId $ProcessorId -Component "JobScheduler"
        throw
    }
}

#endregion

# Export functions
Export-ModuleMember -Function @('New-JobScheduler') -Variable @() -Alias @()