# ParallelProcessorCore.psm1
# Core configuration, logging, and shared utilities for the parallel processing framework

using namespace System.Management.Automation.Runspaces
using namespace System.Collections.Concurrent
using namespace System.Threading

Write-Debug "[ParallelProcessorCore] Module loaded - REFACTORED VERSION"

#region Core Configuration

# Global configuration for parallel processing
$script:ParallelProcessorConfig = @{
    DefaultRetryCount = 3
    DefaultTimeoutSeconds = 300  # 5 minutes
    MaxThreadsLimit = 50  # Reasonable maximum
    OptimalCpuMultiplier = 2  # For mixed workloads
    DebugMode = $false
    VerboseLogging = $false
}

# Thread-safe collections for shared state
$script:GlobalProcessorRegistry = [ConcurrentDictionary[string, object]]::new()
$script:GlobalStatistics = [hashtable]::Synchronized(@{
    TotalProcessorsCreated = 0
    TotalJobsSubmitted = 0
    TotalJobsCompleted = 0
    TotalJobsFailed = 0
    LastActivity = [datetime]::Now
})

#endregion

#region Logging and Debugging

function Write-ParallelProcessorLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        
        [Parameter()]
        [ValidateSet('Debug', 'Verbose', 'Information', 'Warning', 'Error')]
        [string]$Level = 'Information',
        
        [Parameter()]
        [string]$Component = 'ParallelProcessor',
        
        [Parameter()]
        [string]$ProcessorId = 'Unknown'
    )
    
    $timestamp = [datetime]::Now.ToString('yyyy-MM-dd HH:mm:ss.fff')
    $logMessage = "[$timestamp] [$Component-$ProcessorId] $Message"
    
    switch ($Level) {
        'Debug' { 
            if ($script:ParallelProcessorConfig.DebugMode) {
                Write-Debug $logMessage 
            }
        }
        'Verbose' { 
            if ($script:ParallelProcessorConfig.VerboseLogging) {
                Write-Verbose $logMessage 
            }
        }
        'Information' { Write-Information $logMessage -InformationAction Continue }
        'Warning' { Write-Warning $logMessage }
        'Error' { Write-Error $logMessage }
    }
}

function Set-ParallelProcessorDebugMode {
    [CmdletBinding()]
    param(
        [Parameter()]
        [bool]$Enabled = $true
    )
    
    $script:ParallelProcessorConfig.DebugMode = $Enabled
    Write-ParallelProcessorLog "Debug mode set to: $Enabled" -Level Information
}

#endregion

#region Core Utility Functions

function Get-OptimalThreadCount {
    [CmdletBinding()]
    param(
        [Parameter()]
        [ValidateSet('CPU', 'IO', 'Mixed')]
        [string]$WorkloadType = 'Mixed',
        
        [Parameter()]
        [int]$MaxThreads = 0
    )
    
    $cpuCount = [Environment]::ProcessorCount
    
    # Calculate based on workload type
    $optimal = switch ($WorkloadType) {
        'CPU' { $cpuCount }
        'IO' { $cpuCount * 4 }
        'Mixed' { $cpuCount * $script:ParallelProcessorConfig.OptimalCpuMultiplier }
    }
    
    # Apply limits
    if ($MaxThreads -gt 0) {
        $optimal = [Math]::Min($optimal, $MaxThreads)
    }
    
    $optimal = [Math]::Min($optimal, $script:ParallelProcessorConfig.MaxThreadsLimit)
    $optimal = [Math]::Max($optimal, 1)  # Minimum of 1
    
    Write-ParallelProcessorLog "Calculated optimal threads: $optimal (CPU: $cpuCount, Type: $WorkloadType)" -Level Debug
    return $optimal
}

function New-ProcessorId {
    [CmdletBinding()]
    param()
    
    $id = [Guid]::NewGuid().ToString('N')[0..7] -join ''
    Write-ParallelProcessorLog "Generated processor ID: $id" -Level Debug
    return $id
}

function Register-ParallelProcessor {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ProcessorId,
        
        [Parameter(Mandatory)]
        [object]$ProcessorInstance
    )
    
    $script:GlobalProcessorRegistry[$ProcessorId] = $ProcessorInstance
    $script:GlobalStatistics.TotalProcessorsCreated++
    $script:GlobalStatistics.LastActivity = [datetime]::Now
    
    Write-ParallelProcessorLog "Registered processor: $ProcessorId" -Level Debug -ProcessorId $ProcessorId
}

function Unregister-ParallelProcessor {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ProcessorId
    )
    
    $removed = $script:GlobalProcessorRegistry.TryRemove($ProcessorId, [ref]$null)
    if ($removed) {
        Write-ParallelProcessorLog "Unregistered processor: $ProcessorId" -Level Debug -ProcessorId $ProcessorId
    }
    return $removed
}

#endregion

#region Validation Functions

function Test-ScriptBlockSafety {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock
    )
    
    $scriptText = $ScriptBlock.ToString()
    
    # Basic safety checks
    $dangerousPatterns = @(
        'Remove-Item.*-Recurse',
        'Format-Volume',
        'Clear-Host',
        'Restart-Computer',
        'Stop-Computer'
    )
    
    foreach ($pattern in $dangerousPatterns) {
        if ($scriptText -match $pattern) {
            Write-ParallelProcessorLog "Potentially dangerous script detected: $pattern" -Level Warning
            return $false
        }
    }
    
    return $true
}

function Test-ParameterValidity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Parameters
    )
    
    # Check for null or invalid parameters
    foreach ($key in $Parameters.Keys) {
        if ($null -eq $Parameters[$key]) {
            Write-ParallelProcessorLog "Null parameter detected: $key" -Level Warning
            return $false
        }
    }
    
    return $true
}

#endregion

#region Configuration Management

function Get-ParallelProcessorConfiguration {
    [CmdletBinding()]
    param()
    
    return $script:ParallelProcessorConfig.Clone()
}

function Set-ParallelProcessorConfiguration {
    [CmdletBinding()]
    param(
        [Parameter()]
        [int]$DefaultRetryCount,
        
        [Parameter()]
        [int]$DefaultTimeoutSeconds,
        
        [Parameter()]
        [int]$MaxThreadsLimit,
        
        [Parameter()]
        [int]$OptimalCpuMultiplier,
        
        [Parameter()]
        [bool]$VerboseLogging
    )
    
    if ($PSBoundParameters.ContainsKey('DefaultRetryCount')) {
        $script:ParallelProcessorConfig.DefaultRetryCount = $DefaultRetryCount
    }
    
    if ($PSBoundParameters.ContainsKey('DefaultTimeoutSeconds')) {
        $script:ParallelProcessorConfig.DefaultTimeoutSeconds = $DefaultTimeoutSeconds
    }
    
    if ($PSBoundParameters.ContainsKey('MaxThreadsLimit')) {
        $script:ParallelProcessorConfig.MaxThreadsLimit = $MaxThreadsLimit
    }
    
    if ($PSBoundParameters.ContainsKey('OptimalCpuMultiplier')) {
        $script:ParallelProcessorConfig.OptimalCpuMultiplier = $OptimalCpuMultiplier
    }
    
    if ($PSBoundParameters.ContainsKey('VerboseLogging')) {
        $script:ParallelProcessorConfig.VerboseLogging = $VerboseLogging
    }
    
    Write-ParallelProcessorLog "Configuration updated" -Level Information
}

function Get-GlobalParallelProcessorStatistics {
    [CmdletBinding()]
    param()
    
    $stats = $script:GlobalStatistics.Clone()
    $stats.ActiveProcessors = $script:GlobalProcessorRegistry.Count
    $stats.LastActivity = $script:GlobalStatistics.LastActivity
    
    return $stats
}

#endregion

# Export functions
Export-ModuleMember -Function @(
    'Write-ParallelProcessorLog',
    'Set-ParallelProcessorDebugMode',
    'Get-OptimalThreadCount',
    'New-ProcessorId',
    'Register-ParallelProcessor',
    'Unregister-ParallelProcessor',
    'Test-ScriptBlockSafety',
    'Test-ParameterValidity',
    'Get-ParallelProcessorConfiguration',
    'Set-ParallelProcessorConfiguration',
    'Get-GlobalParallelProcessorStatistics'
) -Variable @() -Alias @()
# Added by Fix-ParallelProcessorExports
Export-ModuleMember -Function Get-OptimalThreadCount

