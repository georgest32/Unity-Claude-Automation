# HistoryManagement.psm1
# Conversation history tracking and management

# Import core module for shared variables
Import-Module (Join-Path $PSScriptRoot "ConversationCore.psm1") -Force

function Add-ConversationHistoryItem {
    <#
    .SYNOPSIS
    Adds an item to conversation history
    
    .DESCRIPTION
    Records prompts, responses, commands, and errors in conversation history
    
    .PARAMETER Type
    Type of history item (Prompt, Response, Command, Error)
    
    .PARAMETER Content
    The content to record
    
    .PARAMETER Metadata
    Additional metadata for the item
    #>
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Prompt", "Response", "Command", "Error")]
        [string]$Type,
        
        [Parameter(Mandatory = $true)]
        [string]$Content,
        
        [hashtable]$Metadata = @{}
    )
    
    Write-StateLog "Adding $Type to conversation history" -Level "DEBUG"
    
    try {
        $historyItem = [PSCustomObject]@{
            Type = $Type
            Content = $Content
            Timestamp = Get-Date
            SessionId = $script:ConversationState.SessionId
            StateAtTime = $script:ConversationState.CurrentState
            Index = $script:ConversationHistory.Count
            Metadata = $Metadata
        }
        
        # Add to history
        $script:ConversationHistory += $historyItem
        
        # Update session metadata
        switch ($Type) {
            "Prompt" { $script:SessionMetadata.TotalPrompts++ }
            "Response" { $script:SessionMetadata.TotalResponses++ }
            "Command" { $script:SessionMetadata.TotalCommands++ }
            "Error" { $script:SessionMetadata.TotalErrors++ }
        }
        
        $script:SessionMetadata.LastActivity = Get-Date
        
        # Trim history if needed
        if ($script:ConversationHistory.Count -gt $script:MaxHistorySize) {
            # Keep the most recent items
            $script:ConversationHistory = $script:ConversationHistory[-$script:MaxHistorySize..-1]
            Write-StateLog "Trimmed conversation history to $script:MaxHistorySize items" -Level "DEBUG"
        }
        
        # Save history
        Save-ConversationHistory
        
        Write-StateLog "Added $Type to history (Total items: $($script:ConversationHistory.Count))" -Level "DEBUG"
        
        return @{
            Success = $true
            HistoryIndex = $historyItem.Index
            TotalItems = $script:ConversationHistory.Count
        }
    }
    catch {
        Write-StateLog "Failed to add history item: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-ConversationHistory {
    <#
    .SYNOPSIS
    Gets conversation history
    
    .DESCRIPTION
    Returns filtered conversation history items
    
    .PARAMETER Type
    Filter by specific type
    
    .PARAMETER Limit
    Maximum number of items to return
    
    .PARAMETER Since
    Return items since this timestamp
    #>
    param(
        [ValidateSet("Prompt", "Response", "Command", "Error", "All")]
        [string]$Type = "All",
        
        [int]$Limit = 0,
        
        [DateTime]$Since = [DateTime]::MinValue
    )
    
    Write-StateLog "Getting conversation history (Type: $Type, Limit: $Limit)" -Level "DEBUG"
    
    try {
        $filteredHistory = $script:ConversationHistory
        
        # Filter by type
        if ($Type -ne "All") {
            $filteredHistory = $filteredHistory | Where-Object { $_.Type -eq $Type }
        }
        
        # Filter by time
        if ($Since -ne [DateTime]::MinValue) {
            $filteredHistory = $filteredHistory | Where-Object { $_.Timestamp -gt $Since }
        }
        
        # Apply limit
        if ($Limit -gt 0 -and $filteredHistory.Count -gt $Limit) {
            $filteredHistory = $filteredHistory[-$Limit..-1]
        }
        
        Write-StateLog "Retrieved $($filteredHistory.Count) history items" -Level "INFO"
        
        return @{
            Success = $true
            History = $filteredHistory
            TotalCount = $filteredHistory.Count
        }
    }
    catch {
        Write-StateLog "Failed to get conversation history: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-ConversationContext {
    <#
    .SYNOPSIS
    Gets conversation context for decision making
    
    .DESCRIPTION
    Returns recent context including prompts, responses, and errors
    
    .PARAMETER ContextSize
    Number of recent items to include
    #>
    param(
        [int]$ContextSize = 5
    )
    
    Write-StateLog "Getting conversation context (Size: $ContextSize)" -Level "DEBUG"
    
    try {
        $context = @{
            CurrentState = $script:ConversationState.CurrentState
            PreviousState = $script:ConversationState.PreviousState
            SessionId = $script:ConversationState.SessionId
            ErrorCount = $script:ConversationState.ErrorCount
            SuccessCount = $script:ConversationState.SuccessCount
            RecentHistory = @()
            ActiveGoals = @()
            LastPrompt = $null
            LastResponse = $null
            LastError = $null
        }
        
        # Get recent history
        if ($script:ConversationHistory.Count -gt 0) {
            $startIndex = [Math]::Max(0, $script:ConversationHistory.Count - $ContextSize)
            $context.RecentHistory = $script:ConversationHistory[$startIndex..($script:ConversationHistory.Count - 1)]
            
            # Find last prompt
            $lastPrompt = $script:ConversationHistory | Where-Object { $_.Type -eq "Prompt" } | Select-Object -Last 1
            if ($lastPrompt) {
                $context.LastPrompt = @{
                    Content = $lastPrompt.Content
                    Timestamp = $lastPrompt.Timestamp
                }
            }
            
            # Find last response
            $lastResponse = $script:ConversationHistory | Where-Object { $_.Type -eq "Response" } | Select-Object -Last 1
            if ($lastResponse) {
                $context.LastResponse = @{
                    Content = $lastResponse.Content
                    Timestamp = $lastResponse.Timestamp
                }
            }
            
            # Find last error
            $lastError = $script:ConversationHistory | Where-Object { $_.Type -eq "Error" } | Select-Object -Last 1
            if ($lastError) {
                $context.LastError = @{
                    Content = $lastError.Content
                    Timestamp = $lastError.Timestamp
                }
            }
        }
        
        # Get active goals
        $context.ActiveGoals = $script:ConversationGoals | Where-Object { $_.Status -eq "Active" }
        
        Write-StateLog "Generated context with $($context.RecentHistory.Count) history items" -Level "INFO"
        
        return @{
            Success = $true
            Context = $context
        }
    }
    catch {
        Write-StateLog "Failed to get conversation context: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Clear-ConversationHistory {
    <#
    .SYNOPSIS
    Clears conversation history
    
    .DESCRIPTION
    Removes conversation history with optional persistence
    
    .PARAMETER KeepPersisted
    Whether to keep persisted history file
    #>
    param(
        [switch]$KeepPersisted
    )
    
    Write-StateLog "Clearing conversation history" -Level "WARNING"
    
    try {
        $oldCount = $script:ConversationHistory.Count
        $script:ConversationHistory = @()
        
        if (-not $KeepPersisted -and (Test-Path $script:HistoryPersistencePath)) {
            Remove-Item $script:HistoryPersistencePath -Force
            Write-StateLog "Removed persisted history file" -Level "INFO"
        }
        
        Write-StateLog "Cleared $oldCount history items" -Level "SUCCESS"
        
        return @{
            Success = $true
            ItemsCleared = $oldCount
        }
    }
    catch {
        Write-StateLog "Failed to clear conversation history: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-SessionMetadata {
    <#
    .SYNOPSIS
    Gets session metadata and statistics
    
    .DESCRIPTION
    Returns comprehensive session information and metrics
    #>
    
    Write-StateLog "Getting session metadata" -Level "DEBUG"
    
    try {
        # Calculate average response time
        $responseTimes = @()
        for ($i = 0; $i -lt $script:ConversationHistory.Count - 1; $i++) {
            if ($script:ConversationHistory[$i].Type -eq "Prompt" -and 
                $script:ConversationHistory[$i + 1].Type -eq "Response") {
                $responseTime = ($script:ConversationHistory[$i + 1].Timestamp - $script:ConversationHistory[$i].Timestamp).TotalSeconds
                $responseTimes += $responseTime
            }
        }
        
        if ($responseTimes.Count -gt 0) {
            $script:SessionMetadata.AverageResponseTime = [Math]::Round(($responseTimes | Measure-Object -Average).Average, 2)
            $script:SessionMetadata.MaxResponseTime = [Math]::Round(($responseTimes | Measure-Object -Maximum).Maximum, 2)
            $script:SessionMetadata.MinResponseTime = [Math]::Round(($responseTimes | Measure-Object -Minimum).Minimum, 2)
        }
        
        # Calculate success rate
        if ($script:SessionMetadata.TotalCommands -gt 0) {
            $successRate = [Math]::Round($script:SessionMetadata.SuccessfulCommands / $script:SessionMetadata.TotalCommands * 100, 1)
        } else {
            $successRate = 0
        }
        
        $result = @{
            Success = $true
            Metadata = $script:SessionMetadata
            Statistics = @{
                SuccessRate = $successRate
                AverageResponseTimeSeconds = $script:SessionMetadata.AverageResponseTime
                MaxResponseTimeSeconds = $script:SessionMetadata.MaxResponseTime
                MinResponseTimeSeconds = $script:SessionMetadata.MinResponseTime
                SessionDurationMinutes = [Math]::Round(((Get-Date) - $script:SessionMetadata.StartTime).TotalMinutes, 2)
                HistoryItemCount = $script:ConversationHistory.Count
                StateTransitionCount = $script:SessionMetadata.TotalStateTransitions
                ActiveGoalCount = ($script:ConversationGoals | Where-Object { $_.Status -eq "Active" }).Count
            }
        }
        
        Write-StateLog "Retrieved session metadata" -Level "INFO"
        return $result
    }
    catch {
        Write-StateLog "Failed to get session metadata: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

# Private helper function for saving history
function Save-ConversationHistory {
    Write-StateLog "Saving conversation history" -Level "DEBUG"
    
    try {
        if ($script:ConversationHistory.Count -gt 0) {
            $historyData = $script:ConversationHistory | ConvertTo-Json -Depth 10
            Set-Content -Path $script:HistoryPersistencePath -Value $historyData -Force
            
            Write-StateLog "Conversation history saved ($($script:ConversationHistory.Count) items)" -Level "DEBUG"
        }
    }
    catch {
        Write-StateLog "Failed to save conversation history: $_" -Level "WARNING"
    }
}

Export-ModuleMember -Function Add-ConversationHistoryItem, Get-ConversationHistory, Get-ConversationContext, Clear-ConversationHistory, Get-SessionMetadata