# PromptTypeSelection.psm1
# Prompt type selection logic with decision tree analysis
# Refactored component from IntelligentPromptEngine.psm1
# Component: Prompt type selection logic (400 lines)

#region Prompt Type Selection Logic

function Invoke-PromptTypeSelection {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$ResultAnalysis,
        
        [Parameter()]
        [hashtable]$ConversationContext = @{},
        
        [Parameter()]
        [hashtable]$HistoricalData = @{}
    )
    
    Write-AgentLog -Message "Starting intelligent prompt type selection" -Level "DEBUG" -Component "PromptSelector"
    
    try {
        $config = Get-PromptEngineConfig
        $selection = @{
            PromptType = $config.PromptTypeConfig.DefaultType
            Confidence = 0.0
            DecisionFactors = @()
            FallbackUsed = $false
            DecisionTree = @{}
        }
        
        # Decision tree implementation with rule-based logic
        $decisionTree = New-PromptTypeDecisionTree -ResultAnalysis $ResultAnalysis -Context $ConversationContext
        $selection.DecisionTree = $decisionTree
        
        Write-AgentLog -Message "Decision tree created with $($decisionTree.Nodes.Count) decision nodes" -Level "DEBUG" -Component "PromptSelector"
        
        # Apply decision tree logic
        $decision = Invoke-DecisionTreeAnalysis -DecisionTree $decisionTree -ResultAnalysis $ResultAnalysis
        $selection.PromptType = $decision.PromptType
        $selection.Confidence = $decision.Confidence
        $selection.DecisionFactors = $decision.Factors
        
        # Validate confidence threshold
        if ($selection.Confidence -lt $config.PromptTypeConfig.ConfidenceThreshold) {
            Write-AgentLog -Message "Confidence $($selection.Confidence) below threshold, using fallback" -Level "WARNING" -Component "PromptSelector"
            $selection.PromptType = $config.PromptTypeConfig.FallbackType
            $selection.FallbackUsed = $true
            $selection.Confidence = 0.6  # Assign moderate confidence to fallback
        }
        
        Write-AgentLog -Message "Prompt type selected: $($selection.PromptType) with confidence: $($selection.Confidence)" -Level "INFO" -Component "PromptSelector"
        
        return @{
            Success = $true
            Selection = $selection
            Error = $null
        }
    }
    catch {
        Write-AgentLog -Message "Prompt type selection failed: $_" -Level "ERROR" -Component "PromptSelector"
        return @{
            Success = $false
            Selection = @{
                PromptType = $config.PromptTypeConfig.FallbackType
                Confidence = 0.5
                DecisionFactors = @("Selection Process Exception")
                FallbackUsed = $true
            }
            Error = $_.ToString()
        }
    }
}

function New-PromptTypeDecisionTree {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$ResultAnalysis,
        
        [Parameter()]
        [hashtable]$Context = @{}
    )
    
    Write-AgentLog -Message "Creating prompt type decision tree" -Level "DEBUG" -Component "DecisionTreeBuilder"
    
    try {
        $decisionTree = @{
            Nodes = @()
            Rules = @()
            Metadata = @{
                CreatedAt = Get-Date
                Version = "1.0"
            }
        }
        
        # Root decision node: Classification type
        $classificationNode = @{
            NodeId = "root_classification"
            Question = "What is the result classification?"
            Type = "Classification"
            Branches = @{
                "Exception" = @{
                    PromptType = "Debugging"
                    Confidence = 0.95
                    Reason = "Exceptions require immediate debugging"
                }
                "Failure" = @{
                    NextNode = "severity_assessment"
                    Reason = "Failures need severity-based routing"
                }
                "Success" = @{
                    NextNode = "continuation_check"
                    Reason = "Success should continue workflow"
                }
            }
        }
        
        # Severity assessment node for failures
        $severityNode = @{
            NodeId = "severity_assessment"
            Question = "What is the failure severity?"
            Type = "Severity"
            Branches = @{
                "Critical" = @{
                    PromptType = "Debugging"
                    Confidence = 0.9
                    Reason = "Critical failures need immediate debugging"
                }
                "High" = @{
                    NextNode = "error_pattern_check"
                    Reason = "High severity needs pattern analysis"
                }
                "Medium" = @{
                    PromptType = "Test Results"
                    Confidence = 0.75
                    Reason = "Medium severity suitable for test results analysis"
                }
                "Low" = @{
                    PromptType = "Continue"
                    Confidence = 0.8
                    Reason = "Low severity can continue with monitoring"
                }
            }
        }
        
        # Error pattern check for high severity failures
        $errorPatternNode = @{
            NodeId = "error_pattern_check"
            Question = "Are there known error patterns?"
            Type = "ErrorPattern"
            Branches = @{
                "CompilationError" = @{
                    PromptType = "ARP"
                    Confidence = 0.85
                    Reason = "Compilation errors need research and planning"
                }
                "TestFailure" = @{
                    PromptType = "Test Results"
                    Confidence = 0.8
                    Reason = "Test failures need result analysis"
                }
                "BuildError" = @{
                    PromptType = "Debugging"
                    Confidence = 0.85
                    Reason = "Build errors need immediate debugging"
                }
                "Unknown" = @{
                    NextNode = "context_analysis"
                    Reason = "Unknown patterns need context analysis"
                }
            }
        }
        
        # Continuation check for successful operations
        $continuationNode = @{
            NodeId = "continuation_check"
            Question = "Should workflow continue automatically?"
            Type = "Continuation"
            Branches = @{
                "AutoContinue" = @{
                    PromptType = "Continue"
                    Confidence = 0.9
                    Reason = "Successful operations continue workflow"
                }
                "RequiresInput" = @{
                    PromptType = "Test Results"
                    Confidence = 0.7
                    Reason = "Success requiring input needs result review"
                }
            }
        }
        
        # Context analysis for complex scenarios
        $contextNode = @{
            NodeId = "context_analysis"
            Question = "What does conversation context suggest?"
            Type = "Context"
            Branches = @{
                "OngoingDebug" = @{
                    PromptType = "Debugging"
                    Confidence = 0.8
                    Reason = "Continue ongoing debugging session"
                }
                "TestSequence" = @{
                    PromptType = "Test Results"
                    Confidence = 0.75
                    Reason = "Continue test sequence analysis"
                }
                "PlanningPhase" = @{
                    PromptType = "ARP"
                    Confidence = 0.7
                    Reason = "Continue planning and research"
                }
                "Default" = @{
                    PromptType = "Continue"
                    Confidence = 0.6
                    Reason = "Default continuation when context unclear"
                }
            }
        }
        
        # Add nodes to decision tree
        $decisionTree.Nodes = @(
            $classificationNode,
            $severityNode,
            $errorPatternNode,
            $continuationNode,
            $contextNode
        )
        
        Write-AgentLog -Message "Decision tree created with $($decisionTree.Nodes.Count) nodes" -Level "DEBUG" -Component "DecisionTreeBuilder"
        
        return $decisionTree
    }
    catch {
        Write-AgentLog -Message "Decision tree creation failed: $_" -Level "ERROR" -Component "DecisionTreeBuilder"
        return @{
            Nodes = @()
            Rules = @()
            Metadata = @{ Error = $_.ToString() }
        }
    }
}

function Invoke-DecisionTreeAnalysis {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$DecisionTree,
        
        [Parameter(Mandatory=$true)]
        [hashtable]$ResultAnalysis
    )
    
    Write-AgentLog -Message "Executing decision tree analysis" -Level "DEBUG" -Component "DecisionTreeAnalyzer"
    
    try {
        $config = Get-PromptEngineConfig
        $result = @{
            PromptType = $config.PromptTypeConfig.DefaultType
            Confidence = 0.5
            Factors = @()
            Path = @()
        }
        
        # Start at root node
        $currentNodeId = "root_classification"
        $maxDepth = 10  # Prevent infinite loops
        $depth = 0
        
        while ($currentNodeId -and $depth -lt $maxDepth) {
            $depth++
            $currentNode = $DecisionTree.Nodes | Where-Object { $_.NodeId -eq $currentNodeId }
            
            if (-not $currentNode) {
                Write-AgentLog -Message "Node not found: $currentNodeId" -Level "WARNING" -Component "DecisionTreeAnalyzer"
                break
            }
            
            $result.Path += $currentNode.NodeId
            Write-AgentLog -Message "Processing node: $($currentNode.NodeId)" -Level "DEBUG" -Component "DecisionTreeAnalyzer"
            
            # Evaluate current node
            $nodeResult = Invoke-NodeEvaluation -Node $currentNode -ResultAnalysis $ResultAnalysis
            
            if ($nodeResult.FinalDecision) {
                # Node returned a final decision
                $result.PromptType = $nodeResult.PromptType
                $result.Confidence = $nodeResult.Confidence
                $result.Factors += $nodeResult.Reason
                break
            }
            else {
                # Continue to next node
                $currentNodeId = $nodeResult.NextNode
                $result.Factors += $nodeResult.Reason
            }
        }
        
        if ($depth -eq $maxDepth) {
            Write-AgentLog -Message "Decision tree depth limit reached, using default" -Level "WARNING" -Component "DecisionTreeAnalyzer"
            $result.PromptType = $config.PromptTypeConfig.DefaultType
            $result.Confidence = 0.5
        }
        
        Write-AgentLog -Message "Decision tree analysis completed: $($result.PromptType) with confidence $($result.Confidence)" -Level "DEBUG" -Component "DecisionTreeAnalyzer"
        
        return $result
    }
    catch {
        Write-AgentLog -Message "Decision tree analysis failed: $_" -Level "ERROR" -Component "DecisionTreeAnalyzer"
        return @{
            PromptType = $config.PromptTypeConfig.DefaultType
            Confidence = 0.3
            Factors = @("Decision Tree Analysis Exception")
            Path = @()
        }
    }
}

function Invoke-NodeEvaluation {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$Node,
        
        [Parameter(Mandatory=$true)]
        [hashtable]$ResultAnalysis
    )
    
    try {
        Write-AgentLog -Message "Evaluating node: $($Node.NodeId) of type: $($Node.Type)" -Level "DEBUG" -Component "NodeEvaluator"
        
        $evaluation = @{
            FinalDecision = $false
            PromptType = $null
            Confidence = 0.0
            Reason = $null
            NextNode = $null
        }
        
        # Evaluate based on node type
        switch ($Node.Type) {
            'Classification' {
                $classification = $ResultAnalysis.Analysis.Classification
                if ($Node.Branches.ContainsKey($classification)) {
                    $branch = $Node.Branches[$classification]
                    if ($branch.ContainsKey('PromptType')) {
                        $evaluation.FinalDecision = $true
                        $evaluation.PromptType = $branch.PromptType
                        $evaluation.Confidence = $branch.Confidence
                        $evaluation.Reason = $branch.Reason
                    }
                    else {
                        $evaluation.NextNode = $branch.NextNode
                        $evaluation.Reason = $branch.Reason
                    }
                }
            }
            
            'Severity' {
                $severity = $ResultAnalysis.Analysis.Severity
                if ($Node.Branches.ContainsKey($severity)) {
                    $branch = $Node.Branches[$severity]
                    if ($branch.ContainsKey('PromptType')) {
                        $evaluation.FinalDecision = $true
                        $evaluation.PromptType = $branch.PromptType
                        $evaluation.Confidence = $branch.Confidence
                        $evaluation.Reason = $branch.Reason
                    }
                    else {
                        $evaluation.NextNode = $branch.NextNode
                        $evaluation.Reason = $branch.Reason
                    }
                }
            }
            
            'ErrorPattern' {
                $patterns = $ResultAnalysis.Analysis.Patterns
                $errorPattern = $patterns | Where-Object { $_.Type -eq "CompilationError" } | Select-Object -First 1
                
                $patternType = if ($errorPattern) { "CompilationError" } 
                              elseif ($patterns | Where-Object { $_.Type -eq "Performance" }) { "Performance" }
                              else { "Unknown" }
                
                if ($Node.Branches.ContainsKey($patternType)) {
                    $branch = $Node.Branches[$patternType]
                    if ($branch.ContainsKey('PromptType')) {
                        $evaluation.FinalDecision = $true
                        $evaluation.PromptType = $branch.PromptType
                        $evaluation.Confidence = $branch.Confidence
                        $evaluation.Reason = $branch.Reason
                    }
                    else {
                        $evaluation.NextNode = $branch.NextNode
                        $evaluation.Reason = $branch.Reason
                    }
                }
            }
            
            'Continuation' {
                # Simple heuristic: successful operations should continue
                $continuationType = if ($ResultAnalysis.Analysis.Classification -eq "Success") { "AutoContinue" } else { "RequiresInput" }
                
                if ($Node.Branches.ContainsKey($continuationType)) {
                    $branch = $Node.Branches[$continuationType]
                    $evaluation.FinalDecision = $true
                    $evaluation.PromptType = $branch.PromptType
                    $evaluation.Confidence = $branch.Confidence
                    $evaluation.Reason = $branch.Reason
                }
            }
            
            'Context' {
                # Default to continue for now - more sophisticated context analysis could be added
                $contextType = "Default"
                
                if ($Node.Branches.ContainsKey($contextType)) {
                    $branch = $Node.Branches[$contextType]
                    $evaluation.FinalDecision = $true
                    $evaluation.PromptType = $branch.PromptType
                    $evaluation.Confidence = $branch.Confidence
                    $evaluation.Reason = $branch.Reason
                }
            }
            
            default {
                Write-AgentLog -Message "Unknown node type: $($Node.Type)" -Level "WARNING" -Component "NodeEvaluator"
                $evaluation.FinalDecision = $true
                $config = Get-PromptEngineConfig
                $evaluation.PromptType = $config.PromptTypeConfig.DefaultType
                $evaluation.Confidence = 0.5
                $evaluation.Reason = "Unknown node type, using default"
            }
        }
        
        Write-AgentLog -Message "Node evaluation completed: Final=$($evaluation.FinalDecision), Type=$($evaluation.PromptType)" -Level "DEBUG" -Component "NodeEvaluator"
        
        return $evaluation
    }
    catch {
        Write-AgentLog -Message "Node evaluation failed: $_" -Level "ERROR" -Component "NodeEvaluator"
        $config = Get-PromptEngineConfig
        return @{
            FinalDecision = $true
            PromptType = $config.PromptTypeConfig.DefaultType
            Confidence = 0.3
            Reason = "Node evaluation exception"
            NextNode = $null
        }
    }
}

# Export functions
Export-ModuleMember -Function @(
    'Invoke-PromptTypeSelection',
    'New-PromptTypeDecisionTree',
    'Invoke-DecisionTreeAnalysis',
    'Invoke-NodeEvaluation'
)

#endregion