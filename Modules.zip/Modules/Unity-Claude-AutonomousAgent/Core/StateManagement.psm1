# StateManagement.psm1
# State machine core functionality for ConversationStateManager

# Import core module for shared variables
Import-Module (Join-Path $PSScriptRoot "ConversationCore.psm1") -Force

function Initialize-ConversationState {
    <#
    .SYNOPSIS
    Initializes the conversation state machine
    
    .DESCRIPTION
    Sets up the initial state, loads persisted state if available, and prepares the state machine
    
    .PARAMETER SessionId
    Optional session identifier for continuing previous sessions
    
    .PARAMETER LoadPersisted
    Whether to load previously persisted state
    #>
    param(
        [string]$SessionId = "",
        [switch]$LoadPersisted
    )
    
    Write-StateLog "Initializing conversation state machine" -Level "INFO"
    
    try {
        # Generate session ID if not provided
        if ([string]::IsNullOrEmpty($SessionId)) {
            $SessionId = [Guid]::NewGuid().ToString()
            Write-StateLog "Generated new session ID: $SessionId" -Level "INFO"
        }
        
        # Define state machine structure
        $script:ConversationState = @{
            CurrentState = "Idle"
            PreviousState = $null
            SessionId = $SessionId
            StartTime = Get-Date
            LastStateChange = Get-Date
            TransitionCount = 0
            ErrorCount = 0
            SuccessCount = 0
            Metadata = @{
                UnityVersion = "2021.1.14f1"
                PowerShellVersion = $PSVersionTable.PSVersion.ToString()
                ModuleVersion = "2.0.0"
            }
        }
        
        # Initialize session metadata
        $script:SessionMetadata = @{
            SessionId = $SessionId
            StartTime = Get-Date
            LastActivity = Get-Date
            TotalPrompts = 0
            TotalResponses = 0
            TotalCommands = 0
            SuccessfulCommands = 0
            FailedCommands = 0
            TotalErrors = 0
            TotalStateTransitions = 0
            AverageResponseTime = 0.0
            MaxResponseTime = 0.0
            MinResponseTime = [double]::MaxValue
        }
        
        # Load persisted state if requested
        if ($LoadPersisted) {
            if (Test-Path $script:StatePersistencePath) {
                try {
                    $persistedState = Get-Content $script:StatePersistencePath | ConvertFrom-Json
                    $script:ConversationState = $persistedState
                    Write-StateLog "Loaded persisted state from previous session" -Level "INFO"
                }
                catch {
                    Write-StateLog "Failed to load persisted state: $_" -Level "WARNING"
                }
            }
            
            if (Test-Path $script:HistoryPersistencePath) {
                try {
                    $persistedHistory = Get-Content $script:HistoryPersistencePath | ConvertFrom-Json
                    $script:ConversationHistory = @($persistedHistory)
                    Write-StateLog "Loaded $($script:ConversationHistory.Count) history items" -Level "INFO"
                }
                catch {
                    Write-StateLog "Failed to load persisted history: $_" -Level "WARNING"
                }
            }
        }
        
        Write-StateLog "Conversation state machine initialized" -Level "SUCCESS"
        
        return @{
            Success = $true
            SessionId = $SessionId
            LoadedPersisted = $LoadPersisted.IsPresent
        }
    }
    catch {
        Write-StateLog "Failed to initialize conversation state: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Set-ConversationState {
    <#
    .SYNOPSIS
    Updates the conversation state
    
    .DESCRIPTION
    Transitions the state machine to a new state with validation
    
    .PARAMETER NewState
    The target state to transition to
    
    .PARAMETER Force
    Force the transition even if not normally valid
    #>
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Idle", "PromptPreparing", "PromptSubmitted", "WaitingForResponse", 
                     "ResponseReceived", "ProcessingResponse", "ExecutingAction", 
                     "Error", "Completed", "Suspended")]
        [string]$NewState,
        
        [switch]$Force
    )
    
    Write-StateLog "Attempting state transition to: $NewState" -Level "DEBUG"
    
    try {
        # Validate transition
        if (-not $Force) {
            $validTransitions = Get-ValidStateTransitions
            if ($NewState -notin $validTransitions) {
                Write-StateLog "Invalid state transition from $($script:ConversationState.CurrentState) to $NewState" -Level "WARNING"
                return @{
                    Success = $false
                    Reason = "Invalid transition"
                    CurrentState = $script:ConversationState.CurrentState
                    ValidTransitions = $validTransitions
                }
            }
        }
        
        # Store current state in history
        $script:StateHistory += @{
            State = $script:ConversationState.CurrentState
            Timestamp = Get-Date
            TransitionNumber = $script:ConversationState.TransitionCount
        }
        
        # Trim history if needed
        if ($script:StateHistory.Count -gt 100) {
            $script:StateHistory = $script:StateHistory[-100..-1]
        }
        
        # Update state
        $script:ConversationState.PreviousState = $script:ConversationState.CurrentState
        $script:ConversationState.CurrentState = $NewState
        $script:ConversationState.LastStateChange = Get-Date
        $script:ConversationState.TransitionCount++
        
        # Update session metadata
        $script:SessionMetadata.TotalStateTransitions++
        $script:SessionMetadata.LastActivity = Get-Date
        
        # Handle state-specific actions
        switch ($NewState) {
            "Error" {
                $script:ConversationState.ErrorCount++
                $script:SessionMetadata.TotalErrors++
            }
            "Completed" {
                $script:ConversationState.SuccessCount++
            }
        }
        
        # Save state
        Save-ConversationState
        
        Write-StateLog "State transitioned from $($script:ConversationState.PreviousState) to $NewState" -Level "INFO"
        
        return @{
            Success = $true
            PreviousState = $script:ConversationState.PreviousState
            CurrentState = $NewState
            TransitionCount = $script:ConversationState.TransitionCount
        }
    }
    catch {
        Write-StateLog "Failed to set conversation state: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-ConversationState {
    <#
    .SYNOPSIS
    Gets the current conversation state
    
    .DESCRIPTION
    Returns the current state machine status and metadata
    #>
    
    Write-StateLog "Getting conversation state" -Level "DEBUG"
    
    try {
        if ($null -eq $script:ConversationState) {
            Write-StateLog "Conversation state not initialized" -Level "WARNING"
            return @{
                Success = $false
                Reason = "State not initialized"
            }
        }
        
        return @{
            Success = $true
            State = $script:ConversationState
            SessionDuration = ((Get-Date) - $script:ConversationState.StartTime)
            HistoryCount = $script:ConversationHistory.Count
            GoalCount = $script:ConversationGoals.Count
        }
    }
    catch {
        Write-StateLog "Failed to get conversation state: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-ValidStateTransitions {
    <#
    .SYNOPSIS
    Gets valid state transitions from current state
    
    .DESCRIPTION
    Returns list of states the machine can transition to from current state
    #>
    
    Write-StateLog "Getting valid state transitions" -Level "DEBUG"
    
    $stateTransitionMap = @{
        "Idle" = @("PromptPreparing", "Error", "Suspended")
        "PromptPreparing" = @("PromptSubmitted", "Error", "Idle")
        "PromptSubmitted" = @("WaitingForResponse", "Error", "Idle")
        "WaitingForResponse" = @("ResponseReceived", "Error", "Suspended")
        "ResponseReceived" = @("ProcessingResponse", "Error")
        "ProcessingResponse" = @("ExecutingAction", "Completed", "Error")
        "ExecutingAction" = @("Completed", "Error", "WaitingForResponse")
        "Error" = @("Idle", "PromptPreparing")
        "Completed" = @("Idle", "PromptPreparing")
        "Suspended" = @("Idle")
    }
    
    $currentState = $script:ConversationState.CurrentState
    return $stateTransitionMap[$currentState]
}

function Reset-ConversationState {
    <#
    .SYNOPSIS
    Resets the conversation state machine
    
    .DESCRIPTION
    Clears all state and history, optionally preserving files
    
    .PARAMETER PreserveFiles
    Whether to keep persisted state files
    #>
    param(
        [switch]$PreserveFiles
    )
    
    Write-StateLog "Resetting conversation state machine" -Level "WARNING"
    
    try {
        # Clear in-memory data
        $script:ConversationState = $null
        $script:StateHistory = @()
        $script:ConversationHistory = @()
        $script:SessionMetadata = @{}
        $script:ConversationGoals = @()
        $script:RoleAwareHistory = @()
        $script:DialoguePatterns = @{}
        $script:ConversationEffectiveness = @{}
        
        # Remove persisted files if requested
        if (-not $PreserveFiles) {
            $filesToRemove = @(
                $script:StatePersistencePath,
                $script:HistoryPersistencePath,
                $script:GoalsPersistencePath,
                $script:EffectivenessPersistencePath
            )
            
            foreach ($file in $filesToRemove) {
                if (Test-Path $file) {
                    Remove-Item $file -Force
                    Write-StateLog "Removed persistence file: $(Split-Path $file -Leaf)" -Level "INFO"
                }
            }
        }
        
        Write-StateLog "Conversation state machine reset complete" -Level "SUCCESS"
        
        return @{
            Success = $true
            FilesPreserved = $PreserveFiles.IsPresent
        }
    }
    catch {
        Write-StateLog "Failed to reset conversation state: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

# Private helper function for saving state
function Save-ConversationState {
    Write-StateLog "Saving conversation state" -Level "DEBUG"
    
    try {
        $stateData = $script:ConversationState | ConvertTo-Json -Depth 10
        Set-Content -Path $script:StatePersistencePath -Value $stateData -Force
        
        Write-StateLog "Conversation state saved successfully" -Level "DEBUG"
    }
    catch {
        Write-StateLog "Failed to save conversation state: $_" -Level "WARNING"
    }
}

Export-ModuleMember -Function Initialize-ConversationState, Set-ConversationState, Get-ConversationState, Get-ValidStateTransitions, Reset-ConversationState