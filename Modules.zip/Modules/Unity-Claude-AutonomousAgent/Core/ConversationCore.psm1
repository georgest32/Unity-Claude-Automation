# ConversationCore.psm1
# Core configuration, logging, and state variables for ConversationStateManager

# Module-level variables for state management
$script:ConversationState = $null
$script:StateHistory = @()
$script:ConversationHistory = @()
$script:SessionMetadata = @{}
$script:MaxHistorySize = 20
$script:StatePersistencePath = Join-Path (Split-Path $PSScriptRoot -Parent) "ConversationState.json"
$script:HistoryPersistencePath = Join-Path (Split-Path $PSScriptRoot -Parent) "ConversationHistory.json"

# Day 16 Enhancement: Advanced Conversation Management Variables
$script:ConversationGoals = @()
$script:RoleAwareHistory = @()
$script:DialoguePatterns = @{}
$script:ConversationEffectiveness = @{}
$script:GoalsPersistencePath = Join-Path (Split-Path $PSScriptRoot -Parent) "ConversationGoals.json"
$script:EffectivenessPersistencePath = Join-Path (Split-Path $PSScriptRoot -Parent) "ConversationEffectiveness.json"
$script:MaxRoleHistorySize = 50

# Logging configuration
$script:LogPath = Join-Path (Split-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) -Parent) "unity_claude_automation.log"
$script:LogMutex = [System.Threading.Mutex]::new($false, "UnityClaudeAutomationLogMutex")

function Write-StateLog {
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [string]$Component = "ConversationStateManager"
    )
    
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        $logEntry = "[$timestamp] [$Level] [$Component] $Message"
        
        # Thread-safe file writing
        $acquired = $script:LogMutex.WaitOne(1000)
        if ($acquired) {
            try {
                Add-Content -Path $script:LogPath -Value $logEntry -ErrorAction SilentlyContinue
            }
            finally {
                $script:LogMutex.ReleaseMutex()
            }
        }
    }
    catch {
        Write-Verbose "Failed to write log: $_"
    }
}

# Export core variables and functions for other components
Export-ModuleMember -Variable * -Function Write-StateLog