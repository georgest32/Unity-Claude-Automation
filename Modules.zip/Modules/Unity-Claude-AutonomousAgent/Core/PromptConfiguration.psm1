# PromptConfiguration.psm1
# Configuration and shared collections for intelligent prompt engine
# Refactored component from IntelligentPromptEngine.psm1
# Component: Configuration and thread-safe collections (50 lines)

#region Module Configuration and Collections

# Module configuration settings
$script:ModuleConfig = @{
    ResultAnalysisConfig = @{
        PatternLearningThreshold = 3  # Minimum occurrences for pattern establishment
        ConfidenceThreshold = 0.7     # Minimum confidence for automation decisions
        HistoryRetentionDays = 30     # Days to retain result history
        BaselineWindowSize = 10       # Number of results for baseline establishment
    }
    PromptTypeConfig = @{
        Types = @('Debugging', 'Test Results', 'Continue', 'ARP')
        DefaultType = 'Continue'
        ConfidenceThreshold = 0.8     # Minimum confidence for automatic selection
        FallbackType = 'Continue'     # Fallback when confidence is low
    }
    ConversationStateConfig = @{
        States = @('Idle', 'Processing', 'WaitingForInput', 'Error', 'Learning', 'Autonomous')
        DefaultState = 'Idle'
        TransitionTimeout = 300       # Seconds before state timeout
        ContextRetentionLimit = 50    # Maximum context items to retain
    }
    SeverityConfig = @{
        Levels = @('Critical', 'High', 'Medium', 'Low')
        CriticalThreshold = 0.9       # Confidence threshold for critical classification
        AutomationThresholds = @{     # Minimum confidence for automated handling
            Critical = 0.95
            High = 0.85
            Medium = 0.75
            Low = 0.65
        }
    }
}

# Thread-safe collections for result tracking
$script:ResultHistory = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()
$script:PatternRegistry = [System.Collections.Concurrent.ConcurrentDictionary[string,object]]::new()
$script:ConversationContext = [System.Collections.Concurrent.ConcurrentDictionary[string,object]]::new()

function Get-PromptEngineConfig {
    <#
    .SYNOPSIS
    Get the current prompt engine configuration
    #>
    [CmdletBinding()]
    param()
    
    return $script:ModuleConfig
}

# Export functions
Export-ModuleMember -Function @(
    'Get-PromptEngineConfig'
)

#endregion