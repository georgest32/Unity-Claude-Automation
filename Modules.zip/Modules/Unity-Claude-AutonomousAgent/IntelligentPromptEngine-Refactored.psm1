# IntelligentPromptEngine-Refactored.psm1
# Refactored orchestrator for intelligent prompt generation engine
# Modular architecture with component imports
# Version: 2.0.0 - Refactored from 1,457-line monolithic module

#region Import Required Components

# Import core configuration and collections
Import-Module "$PSScriptRoot\Core\PromptConfiguration.psm1" -Force

# Import result analysis engine
Import-Module "$PSScriptRoot\Core\ResultAnalysisEngine.psm1" -Force

# Import prompt type selection logic
Import-Module "$PSScriptRoot\Core\PromptTypeSelection.psm1" -Force

# Import template management system
Import-Module "$PSScriptRoot\Core\PromptTemplateSystem.psm1" -Force

Write-AgentLog -Message "IntelligentPromptEngine-Refactored: All core components imported successfully" -Level "INFO" -Component "PromptEngineOrchestrator"

#endregion

#region Enhanced Orchestration Functions

function Invoke-IntelligentPromptGeneration {
    <#
    .SYNOPSIS
    Enhanced orchestrated intelligent prompt generation with modular components
    
    .DESCRIPTION
    Orchestrates the complete intelligent prompt generation process using modular components:
    - Command result analysis and classification
    - Decision tree-based prompt type selection
    - Template-based prompt generation with context
    - Comprehensive error handling and fallback mechanisms
    
    .PARAMETER CommandResult
    The result of a command execution to analyze
    
    .PARAMETER ConversationContext
    Current conversation context for decision making
    
    .PARAMETER HistoricalData
    Historical data for pattern recognition and learning
    
    .EXAMPLE
    $result = Invoke-IntelligentPromptGeneration -CommandResult $cmdResult -ConversationContext $context
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$CommandResult,
        
        [Parameter()]
        [hashtable]$ConversationContext = @{},
        
        [Parameter()]
        [hashtable]$HistoricalData = @{}
    )
    
    Write-AgentLog -Message "Starting enhanced intelligent prompt generation orchestration" -Level "INFO" -Component "PromptEngineOrchestrator"
    
    try {
        $generationResult = @{
            Success = $false
            Prompt = ""
            Analysis = @{}
            Selection = @{}
            Template = @{}
            ProcessingTime = 0
            Error = $null
        }
        
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        
        # Step 1: Analyze command result
        Write-AgentLog -Message "Step 1: Analyzing command result" -Level "DEBUG" -Component "PromptEngineOrchestrator"
        $analysisResult = Invoke-CommandResultAnalysis -CommandResult $CommandResult -ConversationContext $ConversationContext -HistoricalData $HistoricalData
        
        if (-not $analysisResult.Success) {
            throw "Result analysis failed: $($analysisResult.Error)"
        }
        
        $generationResult.Analysis = $analysisResult
        Write-AgentLog -Message "Result analysis completed: Classification=$($analysisResult.Analysis.Classification), Confidence=$($analysisResult.Analysis.Confidence)" -Level "INFO" -Component "PromptEngineOrchestrator"
        
        # Step 2: Select prompt type using decision tree
        Write-AgentLog -Message "Step 2: Selecting prompt type using decision tree" -Level "DEBUG" -Component "PromptEngineOrchestrator"
        $selectionResult = Invoke-PromptTypeSelection -ResultAnalysis $analysisResult -ConversationContext $ConversationContext -HistoricalData $HistoricalData
        
        if (-not $selectionResult.Success) {
            throw "Prompt type selection failed: $($selectionResult.Error)"
        }
        
        $generationResult.Selection = $selectionResult
        Write-AgentLog -Message "Prompt type selected: $($selectionResult.Selection.PromptType) with confidence $($selectionResult.Selection.Confidence)" -Level "INFO" -Component "PromptEngineOrchestrator"
        
        # Step 3: Create and render prompt template
        Write-AgentLog -Message "Step 3: Creating and rendering prompt template" -Level "DEBUG" -Component "PromptEngineOrchestrator"
        $templateResult = New-PromptTemplate -TemplateType $selectionResult.Selection.PromptType -ResultAnalysis $analysisResult -ConversationContext $ConversationContext -HistoricalData $HistoricalData
        
        if (-not $templateResult.Success) {
            throw "Template creation failed: $($templateResult.Error)"
        }
        
        # Step 4: Render final prompt
        $renderResult = Invoke-TemplateRendering -Template $templateResult.Template -AdditionalContext $ConversationContext
        
        if (-not $renderResult.Success) {
            throw "Template rendering failed: $($renderResult.Error)"
        }
        
        $generationResult.Template = $templateResult
        $generationResult.Prompt = $renderResult.RenderedPrompt
        $generationResult.Success = $true
        
        $stopwatch.Stop()
        $generationResult.ProcessingTime = $stopwatch.ElapsedMilliseconds
        
        Write-AgentLog -Message "Enhanced intelligent prompt generation completed successfully in $($generationResult.ProcessingTime)ms" -Level "INFO" -Component "PromptEngineOrchestrator"
        
        return $generationResult
    }
    catch {
        $stopwatch.Stop() if $stopwatch
        $generationResult.ProcessingTime = $stopwatch.ElapsedMilliseconds if $stopwatch
        $generationResult.Error = $_.ToString()
        
        Write-AgentLog -Message "Enhanced intelligent prompt generation failed: $_" -Level "ERROR" -Component "PromptEngineOrchestrator"
        
        # Fallback: Create simple prompt
        $fallbackPrompt = New-FallbackPrompt -CommandResult $CommandResult -Error $_
        $generationResult.Prompt = $fallbackPrompt
        
        return $generationResult
    }
}

function New-FallbackPrompt {
    <#
    .SYNOPSIS
    Creates a simple fallback prompt when intelligent generation fails
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [hashtable]$CommandResult,
        
        [Parameter()]
        [object]$Error
    )
    
    Write-AgentLog -Message "Creating fallback prompt due to generation failure" -Level "WARNING" -Component "PromptEngineOrchestrator"
    
    $fallbackPrompt = "# Fallback Prompt - Analysis Required`n`n"
    $fallbackPrompt += "*Generated at: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')*`n"
    $fallbackPrompt += "*Note: Intelligent prompt generation encountered an error and fell back to basic mode*`n`n"
    
    $fallbackPrompt += "## Command Result Analysis Needed`n`n"
    $fallbackPrompt += "A command was executed and needs analysis. Please review the following information:`n`n"
    
    if ($CommandResult.ContainsKey('ExitCode')) {
        $fallbackPrompt += "**Exit Code**: $($CommandResult.ExitCode)`n"
    }
    
    if ($CommandResult.ContainsKey('Output') -and $CommandResult.Output) {
        $fallbackPrompt += "**Output**: $($CommandResult.Output.ToString().Substring(0, [Math]::Min(500, $CommandResult.Output.ToString().Length)))"
        if ($CommandResult.Output.ToString().Length -gt 500) {
            $fallbackPrompt += "... (truncated)"
        }
        $fallbackPrompt += "`n"
    }
    
    if ($CommandResult.ContainsKey('Error') -and $CommandResult.Error) {
        $fallbackPrompt += "**Error**: $($CommandResult.Error.ToString().Substring(0, [Math]::Min(300, $CommandResult.Error.ToString().Length)))"
        if ($CommandResult.Error.ToString().Length -gt 300) {
            $fallbackPrompt += "... (truncated)"
        }
        $fallbackPrompt += "`n"
    }
    
    $fallbackPrompt += "`n## Request`n`n"
    $fallbackPrompt += "Please analyze this command result and advise on:"
    $fallbackPrompt += "`n1. Whether the operation was successful or failed"
    $fallbackPrompt += "`n2. Any issues that need to be addressed"
    $fallbackPrompt += "`n3. Recommended next steps"
    $fallbackPrompt += "`n4. Any patterns or insights from the output"
    
    return $fallbackPrompt
}

function Get-PromptEngineStatus {
    <#
    .SYNOPSIS
    Get comprehensive status of the intelligent prompt engine and its components
    #>
    [CmdletBinding()]
    param()
    
    Write-AgentLog -Message "Gathering intelligent prompt engine status" -Level "DEBUG" -Component "PromptEngineOrchestrator"
    
    try {
        $status = @{
            EngineVersion = "2.0.0"
            Architecture = "Modular"
            Components = @{}
            Configuration = @{}
            Health = "Unknown"
            LastUpdate = Get-Date
        }
        
        # Get configuration
        $config = Get-PromptEngineConfig
        $status.Configuration = $config
        
        # Check component availability
        $components = @{
            'PromptConfiguration' = Test-ComponentAvailability -ComponentName 'Get-PromptEngineConfig'
            'ResultAnalysisEngine' = Test-ComponentAvailability -ComponentName 'Invoke-CommandResultAnalysis'
            'PromptTypeSelection' = Test-ComponentAvailability -ComponentName 'Invoke-PromptTypeSelection'
            'PromptTemplateSystem' = Test-ComponentAvailability -ComponentName 'New-PromptTemplate'
        }
        
        $status.Components = $components
        
        # Determine overall health
        $healthyComponents = ($components.Values | Where-Object { $_ -eq $true }).Count
        $totalComponents = $components.Count
        
        if ($healthyComponents -eq $totalComponents) {
            $status.Health = "Healthy"
        }
        elseif ($healthyComponents -gt ($totalComponents / 2)) {
            $status.Health = "Degraded"
        }
        else {
            $status.Health = "Critical"
        }
        
        Write-AgentLog -Message "Prompt engine status: $($status.Health) ($healthyComponents/$totalComponents components healthy)" -Level "INFO" -Component "PromptEngineOrchestrator"
        
        return @{
            Success = $true
            Status = $status
            Error = $null
        }
    }
    catch {
        Write-AgentLog -Message "Failed to get prompt engine status: $_" -Level "ERROR" -Component "PromptEngineOrchestrator"
        return @{
            Success = $false
            Status = @{}
            Error = $_.ToString()
        }
    }
}

function Test-ComponentAvailability {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$ComponentName
    )
    
    try {
        $command = Get-Command $ComponentName -ErrorAction SilentlyContinue
        return ($null -ne $command)
    }
    catch {
        return $false
    }
}

function Initialize-IntelligentPromptEngine {
    <#
    .SYNOPSIS
    Initialize the intelligent prompt engine and verify all components are working
    #>
    [CmdletBinding()]
    param()
    
    Write-AgentLog -Message "Initializing enhanced intelligent prompt engine" -Level "INFO" -Component "PromptEngineOrchestrator"
    
    try {
        $initResult = @{
            Success = $false
            ComponentsInitialized = @()
            ComponentsFailed = @()
            OverallHealth = "Unknown"
            Error = $null
        }
        
        # Test each component
        $components = @(
            @{ Name = "PromptConfiguration"; TestFunction = "Get-PromptEngineConfig" },
            @{ Name = "ResultAnalysisEngine"; TestFunction = "Invoke-CommandResultAnalysis" },
            @{ Name = "PromptTypeSelection"; TestFunction = "Invoke-PromptTypeSelection" },
            @{ Name = "PromptTemplateSystem"; TestFunction = "New-PromptTemplate" }
        )
        
        foreach ($component in $components) {
            try {
                $testCommand = Get-Command $component.TestFunction -ErrorAction SilentlyContinue
                if ($testCommand) {
                    $initResult.ComponentsInitialized += $component.Name
                    Write-AgentLog -Message "Component initialized: $($component.Name)" -Level "DEBUG" -Component "PromptEngineOrchestrator"
                }
                else {
                    $initResult.ComponentsFailed += $component.Name
                    Write-AgentLog -Message "Component failed to initialize: $($component.Name)" -Level "WARNING" -Component "PromptEngineOrchestrator"
                }
            }
            catch {
                $initResult.ComponentsFailed += $component.Name
                Write-AgentLog -Message "Component initialization error: $($component.Name) - $_" -Level "ERROR" -Component "PromptEngineOrchestrator"
            }
        }
        
        # Determine overall health
        $healthyCount = $initResult.ComponentsInitialized.Count
        $totalCount = $components.Count
        
        if ($healthyCount -eq $totalCount) {
            $initResult.OverallHealth = "Healthy"
            $initResult.Success = $true
        }
        elseif ($healthyCount -gt ($totalCount / 2)) {
            $initResult.OverallHealth = "Degraded"
            $initResult.Success = $true
        }
        else {
            $initResult.OverallHealth = "Critical"
            $initResult.Success = $false
            $initResult.Error = "Critical component failures prevent engine operation"
        }
        
        Write-AgentLog -Message "Intelligent prompt engine initialization complete: $($initResult.OverallHealth) ($healthyCount/$totalCount components)" -Level "INFO" -Component "PromptEngineOrchestrator"
        
        return $initResult
    }
    catch {
        Write-AgentLog -Message "Intelligent prompt engine initialization failed: $_" -Level "ERROR" -Component "PromptEngineOrchestrator"
        return @{
            Success = $false
            ComponentsInitialized = @()
            ComponentsFailed = @()
            OverallHealth = "Critical"
            Error = $_.ToString()
        }
    }
}

#endregion

#region Module Exports

# Export all orchestration functions
Export-ModuleMember -Function @(
    'Invoke-IntelligentPromptGeneration',
    'Get-PromptEngineStatus', 
    'Initialize-IntelligentPromptEngine'
)

# Re-export key component functions for direct access
Export-ModuleMember -Function @(
    'Get-PromptEngineConfig',
    'Invoke-CommandResultAnalysis',
    'Invoke-PromptTypeSelection',
    'New-PromptTemplate'
)

Write-AgentLog -Message "IntelligentPromptEngine-Refactored module loaded successfully with modular architecture" -Level "INFO" -Component "PromptEngineOrchestrator"

#endregion