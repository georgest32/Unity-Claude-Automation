# ConversationStateManager-Refactored.psm1
# Refactored orchestrator for ConversationStateManager module
# Imports and coordinates all modular components

# Component Imports
$componentsPath = Join-Path $PSScriptRoot "Core"
Import-Module (Join-Path $componentsPath "ConversationCore.psm1") -Force -Global
Import-Module (Join-Path $componentsPath "StateManagement.psm1") -Force
Import-Module (Join-Path $componentsPath "HistoryManagement.psm1") -Force
Import-Module (Join-Path $componentsPath "GoalManagement.psm1") -Force
Import-Module (Join-Path $componentsPath "RoleAwareManagement.psm1") -Force
Import-Module (Join-Path $componentsPath "PersistenceManagement.psm1") -Force

# Version information
$script:ModuleVersion = "2.0.0"
$script:RefactoredDate = "2025-08-26"

Write-StateLog "ConversationStateManager Refactored Module v$script:ModuleVersion loaded" -Level "INFO"
Write-StateLog "REFACTORED VERSION - Using modular component architecture" -Level "SUCCESS"

# Orchestration Functions

function Get-ConversationStateManagerComponents {
    <#
    .SYNOPSIS
    Returns information about loaded components
    
    .DESCRIPTION
    Provides details about the refactored modular architecture
    #>
    
    return @{
        Version = $script:ModuleVersion
        RefactoredDate = $script:RefactoredDate
        Components = @(
            @{ Name = "ConversationCore"; Description = "Core configuration and logging" }
            @{ Name = "StateManagement"; Description = "State machine management" }
            @{ Name = "HistoryManagement"; Description = "Conversation history tracking" }
            @{ Name = "GoalManagement"; Description = "Goal tracking and effectiveness" }
            @{ Name = "RoleAwareManagement"; Description = "Role-aware dialogue patterns" }
            @{ Name = "PersistenceManagement"; Description = "State and history persistence" }
        )
        Architecture = "Modular Component-Based"
        TotalFunctions = 22
    }
}

function Test-ConversationStateManagerHealth {
    <#
    .SYNOPSIS
    Tests health of all components
    
    .DESCRIPTION
    Verifies that all components are loaded and functioning
    #>
    
    Write-StateLog "Testing ConversationStateManager component health" -Level "DEBUG"
    
    $healthReport = @{
        Overall = $true
        Components = @{}
        Timestamp = Get-Date
    }
    
    # Test each component
    $components = @(
        @{ Name = "StateManagement"; TestCmd = { Get-Command Initialize-ConversationState -ErrorAction SilentlyContinue } }
        @{ Name = "HistoryManagement"; TestCmd = { Get-Command Add-ConversationHistoryItem -ErrorAction SilentlyContinue } }
        @{ Name = "GoalManagement"; TestCmd = { Get-Command Add-ConversationGoal -ErrorAction SilentlyContinue } }
        @{ Name = "RoleAwareManagement"; TestCmd = { Get-Command Add-RoleAwareHistoryItem -ErrorAction SilentlyContinue } }
        @{ Name = "PersistenceManagement"; TestCmd = { Get-Command Save-ConversationState -ErrorAction SilentlyContinue } }
    )
    
    foreach ($component in $components) {
        $result = & $component.TestCmd
        $healthReport.Components[$component.Name] = if ($result) { "Healthy" } else { "Failed" }
        
        if (-not $result) {
            $healthReport.Overall = $false
            Write-StateLog "Component health check failed: $($component.Name)" -Level "WARNING"
        }
    }
    
    # Test state initialization
    if ($null -eq $script:ConversationState) {
        $healthReport.StateInitialized = $false
        Write-StateLog "Conversation state not initialized" -Level "INFO"
    } else {
        $healthReport.StateInitialized = $true
    }
    
    return $healthReport
}

function Invoke-ConversationStateManagerDiagnostics {
    <#
    .SYNOPSIS
    Runs comprehensive diagnostics on the conversation state system
    
    .DESCRIPTION
    Performs detailed analysis and reporting of system status
    #>
    
    Write-StateLog "Running ConversationStateManager diagnostics" -Level "INFO"
    
    $diagnostics = @{
        Timestamp = Get-Date
        ComponentHealth = Test-ConversationStateManagerHealth
        StateInfo = if ($script:ConversationState) {
            @{
                CurrentState = $script:ConversationState.CurrentState
                SessionId = $script:ConversationState.SessionId
                TransitionCount = $script:ConversationState.TransitionCount
                ErrorCount = $script:ConversationState.ErrorCount
                SuccessCount = $script:ConversationState.SuccessCount
            }
        } else { "Not initialized" }
        HistoryInfo = @{
            ItemCount = $script:ConversationHistory.Count
            RoleAwareItemCount = $script:RoleAwareHistory.Count
            MaxHistorySize = $script:MaxHistorySize
            MaxRoleHistorySize = $script:MaxRoleHistorySize
        }
        GoalsInfo = @{
            TotalGoals = $script:ConversationGoals.Count
            ActiveGoals = ($script:ConversationGoals | Where-Object { $_.Status -eq "Active" }).Count
            CompletedGoals = ($script:ConversationGoals | Where-Object { $_.Status -eq "Completed" }).Count
        }
        EffectivenessInfo = if ($script:ConversationEffectiveness -and $script:ConversationEffectiveness.Scores) {
            @{
                OverallScore = $script:ConversationEffectiveness.Scores.Overall
                Trend = $script:ConversationEffectiveness.Scores.Trend
            }
        } else { "Not calculated" }
        PersistenceInfo = @{
            StateFileExists = Test-Path $script:StatePersistencePath
            HistoryFileExists = Test-Path $script:HistoryPersistencePath
            GoalsFileExists = Test-Path $script:GoalsPersistencePath
        }
    }
    
    Write-StateLog "Diagnostics complete" -Level "SUCCESS"
    
    return $diagnostics
}

function Initialize-CompleteConversationSystem {
    <#
    .SYNOPSIS
    Initializes the complete conversation management system
    
    .DESCRIPTION
    Sets up all components with default or specified configuration
    
    .PARAMETER SessionId
    Optional session ID to use
    
    .PARAMETER LoadPersisted
    Whether to load persisted data
    #>
    param(
        [string]$SessionId = "",
        [switch]$LoadPersisted
    )
    
    Write-StateLog "Initializing complete conversation system" -Level "INFO"
    
    try {
        # Initialize state
        $stateResult = Initialize-ConversationState -SessionId $SessionId -LoadPersisted:$LoadPersisted
        
        if (-not $stateResult.Success) {
            throw "Failed to initialize conversation state: $($stateResult.Error)"
        }
        
        # Load persisted data if requested
        if ($LoadPersisted) {
            # Load goals
            $goalsResult = Load-ConversationGoals
            if ($goalsResult.Success) {
                Write-StateLog "Loaded $($goalsResult.GoalCount) persisted goals" -Level "INFO"
            }
            
            # Initialize effectiveness tracking
            Update-ConversationEffectiveness
        }
        
        Write-StateLog "Complete conversation system initialized" -Level "SUCCESS"
        
        return @{
            Success = $true
            SessionId = $stateResult.SessionId
            LoadedPersisted = $LoadPersisted.IsPresent
            ComponentStatus = Test-ConversationStateManagerHealth
        }
    }
    catch {
        Write-StateLog "Failed to initialize complete conversation system: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-ConversationSummary {
    <#
    .SYNOPSIS
    Gets comprehensive conversation summary
    
    .DESCRIPTION
    Returns complete overview of conversation state and metrics
    #>
    
    Write-StateLog "Generating conversation summary" -Level "DEBUG"
    
    try {
        $summary = @{
            State = Get-ConversationState
            Metadata = Get-SessionMetadata
            Goals = Get-ConversationGoals -Status "All"
            History = @{
                Recent = (Get-ConversationHistory -Limit 5).History
                RoleAware = (Get-RoleAwareHistory -Limit 5 -IncludeAnalysis).Analysis
            }
            Effectiveness = if ($script:ConversationEffectiveness) {
                $script:ConversationEffectiveness
            } else { @{} }
            DialoguePatterns = if ($script:DialoguePatterns.Statistics) {
                $script:DialoguePatterns.Statistics
            } else { @{} }
        }
        
        return @{
            Success = $true
            Summary = $summary
        }
    }
    catch {
        Write-StateLog "Failed to generate conversation summary: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

# Export all public functions from components plus orchestration functions
Export-ModuleMember -Function @(
    # State Management
    'Initialize-ConversationState',
    'Set-ConversationState',
    'Get-ConversationState',
    'Get-ValidStateTransitions',
    'Reset-ConversationState',
    
    # History Management
    'Add-ConversationHistoryItem',
    'Get-ConversationHistory',
    'Get-ConversationContext',
    'Clear-ConversationHistory',
    'Get-SessionMetadata',
    
    # Goal Management
    'Add-ConversationGoal',
    'Update-ConversationGoal',
    'Get-ConversationGoals',
    'Calculate-GoalRelevance',
    
    # Role-Aware Management
    'Add-RoleAwareHistoryItem',
    'Get-RoleAwareHistory',
    'Update-DialoguePatterns',
    'Update-ConversationEffectiveness',
    
    # Persistence Management
    'Save-ConversationState',
    'Save-ConversationHistory',
    'Save-ConversationGoals',
    'Load-ConversationState',
    'Load-ConversationHistory',
    'Load-ConversationGoals',
    'Export-ConversationSession',
    'Import-ConversationSession',
    
    # Orchestration Functions
    'Get-ConversationStateManagerComponents',
    'Test-ConversationStateManagerHealth',
    'Invoke-ConversationStateManagerDiagnostics',
    'Initialize-CompleteConversationSystem',
    'Get-ConversationSummary'
)

Write-StateLog "ConversationStateManager module loaded successfully with 33 functions" -Level "SUCCESS"