#region DePA Algorithm Implementation Component
<#
.SYNOPSIS
    Unity Claude CPG - DePA Algorithm Implementation Component
    
.DESCRIPTION
    Implements the DePA (Dead Program Artifact) algorithm for line-level perplexity analysis
    to identify potentially dead or obsolete code using statistical language modeling and 
    entropy measurements.
    
    Key capabilities:
    - Multi-language perplexity calculation (PowerShell, JavaScript, TypeScript, Python, C#)
    - Context-aware entropy analysis with configurable window sizes
    - Token frequency analysis and probability distributions
    - Reference tracking to identify isolated code sections
    - Categorized scoring system (Normal, Suspicious, HighPerplexity, VeryHighPerplexity)
    
.VERSION
    2.0.0 - Refactored modular component
    
.DEPENDENCIES
    - Unity-Claude-CPG (Code Property Graph analysis)
    
.AUTHOR
    Unity-Claude-Automation Framework
#>

# Import required dependencies
$cpgModule = Join-Path (Split-Path $PSScriptRoot -Parent) "Unity-Claude-CPG.psd1"
if (Test-Path $cpgModule) {
    Import-Module $cpgModule -Force -ErrorAction SilentlyContinue
}

# Load CPG enums
$enumPath = Join-Path (Split-Path $PSScriptRoot -Parent) "Unity-Claude-CPG-Enums.ps1"
if (Test-Path $enumPath) {
    . $enumPath
}

#region DePA Algorithm Implementation

function Get-CodePerplexity {
    <#
    .SYNOPSIS
        Implements DePA (Dead Program Artifact) algorithm for line-level perplexity analysis
        
    .DESCRIPTION
        Calculates perplexity scores for code lines to identify potentially dead or obsolete code.
        Based on statistical language modeling and entropy measurements.
        
    .PARAMETER CodeContent
        The code content to analyze
        
    .PARAMETER Language
        Programming language of the code
        
    .PARAMETER WindowSize
        Context window size for perplexity calculation (default: 5 lines)
        
    .OUTPUTS
        System.Collections.Hashtable
        Contains perplexity analysis with scores, categories, and dead code candidates
        
    .EXAMPLE
        $perplexity = Get-CodePerplexity -CodeContent $code -Language "PowerShell"
        Write-Host "Dead code candidates: $($perplexity.DeadCodeCandidates.Count)"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$CodeContent,
        
        [Parameter(Mandatory)]
        [ValidateSet("PowerShell", "JavaScript", "TypeScript", "Python", "CSharp")]
        [string]$Language,
        
        [int]$WindowSize = 5
    )
    
    try {
        Write-Verbose "Calculating code perplexity for $Language code with window size $WindowSize"
        
        # Split code into lines
        $lines = $CodeContent -split "`n"
        $lineCount = $lines.Count
        
        # Initialize perplexity scores
        $perplexityScores = @{}
        
        # Language-specific token patterns
        $tokenPatterns = @{
            PowerShell = @{
                Keywords = @('function', 'param', 'if', 'else', 'foreach', 'while', 'try', 'catch', 'return')
                Operators = @('-eq', '-ne', '-gt', '-lt', '-and', '-or', '-not')
                Special = @('$_', '$?', '$^', '$$')
            }
            JavaScript = @{
                Keywords = @('function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'async', 'await')
                Operators = @('===', '!==', '&&', '||', '=>')
                Special = @('this', 'super', 'new')
            }
            Python = @{
                Keywords = @('def', 'class', 'if', 'else', 'elif', 'for', 'while', 'return', 'import', 'from')
                Operators = @('and', 'or', 'not', 'in', 'is')
                Special = @('self', '__init__', '__name__')
            }
            TypeScript = @{
                Keywords = @('function', 'const', 'let', 'interface', 'type', 'class', 'extends', 'implements')
                Operators = @('===', '!==', '&&', '||', '=>', '?.')
                Special = @('this', 'super', 'new', 'typeof')
            }
            CSharp = @{
                Keywords = @('class', 'interface', 'public', 'private', 'protected', 'static', 'void', 'return')
                Operators = @('==', '!=', '&&', '||', '??', '?.')
                Special = @('this', 'base', 'new', 'typeof')
            }
        }
        
        $patterns = $tokenPatterns[$Language]
        
        # Calculate perplexity for each line
        for ($i = 0; $i -lt $lineCount; $i++) {
            $line = $lines[$i]
            
            # Skip empty lines and comments
            if ([string]::IsNullOrWhiteSpace($line)) {
                $perplexityScores[$i] = @{
                    LineNumber = $i + 1
                    Score = 0
                    Category = "Empty"
                }
                continue
            }
            
            # Check for comment patterns
            $isComment = switch ($Language) {
                "PowerShell" { $line.Trim().StartsWith("#") }
                "JavaScript" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                "TypeScript" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                "Python" { $line.Trim().StartsWith("#") }
                "CSharp" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                default { $false }
            }
            
            if ($isComment) {
                $perplexityScores[$i] = @{
                    LineNumber = $i + 1
                    Score = 0.1
                    Category = "Comment"
                }
                continue
            }
            
            # Calculate context window
            $contextStart = [Math]::Max(0, $i - $WindowSize)
            $contextEnd = [Math]::Min($lineCount - 1, $i + $WindowSize)
            $context = $lines[$contextStart..$contextEnd] -join " "
            
            # Calculate token frequency
            $lineTokens = $line -split '\s+' | Where-Object { $_ -ne "" }
            $contextTokens = $context -split '\s+' | Where-Object { $_ -ne "" }
            
            # Calculate entropy-based perplexity
            $entropy = 0
            $tokenProbabilities = @{}
            
            foreach ($token in $lineTokens) {
                $frequency = @($contextTokens | Where-Object { $_ -eq $token }).Count
                $totalTokens = @($contextTokens).Count
                $probability = if ($totalTokens -gt 0) { 
                    $frequency / $totalTokens 
                } else { 
                    0.001 
                }
                
                if ($probability -gt 0) {
                    $entropy -= $probability * [Math]::Log($probability, 2)
                }
                
                $tokenProbabilities[$token] = $probability
            }
            
            # Calculate perplexity score (2^entropy)
            $perplexity = [Math]::Pow(2, $entropy)
            
            # Adjust for known patterns
            $adjustedScore = $perplexity
            
            # Lower score for lines with common keywords
            $keywordCount = @($patterns.Keywords | Where-Object { $line -match "\b$_\b" }).Count
            if ($keywordCount -gt 0) {
                $adjustedScore *= (1 - 0.1 * $keywordCount)
            }
            
            # Higher score for isolated code (no references in context)
            $hasReferences = $false
            foreach ($token in $lineTokens) {
                if ($token -match '^\$\w+$|^\w+\(\)$|^\w+\.\w+$') {
                    # Check if token appears elsewhere in context
                    $otherOccurrences = @($context -split '\s+' | Where-Object { $_ -eq $token -and $_ -ne $line }).Count
                    if ($otherOccurrences -eq 0) {
                        $adjustedScore *= 1.5
                    } else {
                        $hasReferences = $true
                    }
                }
            }
            
            # Categorize based on score
            $category = switch ($adjustedScore) {
                { $_ -lt 2 } { "Normal" }
                { $_ -ge 2 -and $_ -lt 5 } { "Suspicious" }
                { $_ -ge 5 -and $_ -lt 10 } { "HighPerplexity" }
                { $_ -ge 10 } { "VeryHighPerplexity" }
            }
            
            $perplexityScores[$i] = @{
                LineNumber = $i + 1
                Score = [Math]::Round($adjustedScore, 2)
                Category = $category
                HasReferences = $hasReferences
                Line = $line.Trim()
            }
        }
        
        # Return analysis results
        return @{
            Language = $Language
            TotalLines = $lineCount
            Scores = $perplexityScores
            Summary = @{
                Normal = @($perplexityScores.Values | Where-Object { $_.Category -eq "Normal" }).Count
                Suspicious = @($perplexityScores.Values | Where-Object { $_.Category -eq "Suspicious" }).Count
                HighPerplexity = @($perplexityScores.Values | Where-Object { $_.Category -eq "HighPerplexity" }).Count
                VeryHighPerplexity = @($perplexityScores.Values | Where-Object { $_.Category -eq "VeryHighPerplexity" }).Count
            }
            DeadCodeCandidates = $perplexityScores.Values | 
                Where-Object { $_.Category -in @("HighPerplexity", "VeryHighPerplexity") -and -not $_.HasReferences }
        }
    }
    catch {
        Write-Error "Failed to calculate code perplexity: $_"
        throw
    }
}

#endregion DePA Algorithm Implementation

# Export public functions
Export-ModuleMember -Function @(
    'Get-CodePerplexity'
)

#endregion DePA Algorithm Implementation Component