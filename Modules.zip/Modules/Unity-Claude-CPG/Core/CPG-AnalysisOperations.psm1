#Requires -Version 5.1
<#
.SYNOPSIS
    Analysis operations for Code Property Graph (CPG) implementation.

.DESCRIPTION
    Contains functions for analyzing CPG structures, including statistics,
    connectivity analysis, and graph metrics calculation.

.NOTES
    Part of Unity-Claude-CPG refactored architecture
    Originally from Unity-Claude-CPG.psm1 (lines 716-770)
    Refactoring Date: 2025-08-25
#>

# Import required data structures
using module .\CPG-DataStructures.psm1

function Get-CPGStatistics {
    <#
    .SYNOPSIS
    Computes comprehensive statistics for a CPG graph.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [switch]$IncludeNodeTypeBreakdown,
        [switch]$IncludeEdgeTypeBreakdown,
        [switch]$IncludeConnectivity
    )
    
    $stats = @{
        NodeCount = $Graph.Nodes.Count
        EdgeCount = $Graph.Edges.Count
        GraphId = $Graph.Id
        GraphName = $Graph.Name
        CreatedAt = $Graph.CreatedAt
        ModifiedAt = $Graph.ModifiedAt
        Version = $Graph.Version
    }
    
    if ($IncludeNodeTypeBreakdown) {
        $nodeTypes = @{}
        foreach ($node in $Graph.Nodes.Values) {
            $typeStr = $node.Type.ToString()
            if ($nodeTypes.ContainsKey($typeStr)) {
                $nodeTypes[$typeStr]++
            } else {
                $nodeTypes[$typeStr] = 1
            }
        }
        $stats.NodeTypeBreakdown = $nodeTypes
    }
    
    if ($IncludeEdgeTypeBreakdown) {
        $edgeTypes = @{}
        foreach ($edge in $Graph.Edges.Values) {
            $typeStr = $edge.Type.ToString()
            if ($edgeTypes.ContainsKey($typeStr)) {
                $edgeTypes[$typeStr]++
            } else {
                $edgeTypes[$typeStr] = 1
            }
        }
        $stats.EdgeTypeBreakdown = $edgeTypes
    }
    
    if ($IncludeConnectivity) {
        $connectivity = @{
            IsolatedNodes = 0
            ConnectedComponents = 0
            MaxDegree = 0
            AvgDegree = 0
        }
        
        $degrees = @()
        foreach ($nodeId in $Graph.Nodes.Keys) {
            $inDegree = $Graph.AdjacencyList[$nodeId].Incoming.Count
            $outDegree = $Graph.AdjacencyList[$nodeId].Outgoing.Count
            $totalDegree = $inDegree + $outDegree
            
            $degrees += $totalDegree
            
            if ($totalDegree -eq 0) {
                $connectivity.IsolatedNodes++
            }
            
            if ($totalDegree -gt $connectivity.MaxDegree) {
                $connectivity.MaxDegree = $totalDegree
            }
        }
        
        if ($degrees.Count -gt 0) {
            $connectivity.AvgDegree = [math]::Round(($degrees | Measure-Object -Sum).Sum / $degrees.Count, 2)
        }
        
        $stats.Connectivity = $connectivity
    }
    
    return $stats
}

function Test-CPGStronglyConnected {
    <#
    .SYNOPSIS
    Tests if the CPG graph is strongly connected using Tarjan's algorithm.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph
    )
    
    if ($Graph.Nodes.Count -eq 0) {
        return $true
    }
    
    # Simple connectivity test for now
    # A full Tarjan's algorithm implementation would be more complex
    $visited = @{}
    $startNode = $Graph.Nodes.Keys | Select-Object -First 1
    
    # DFS from first node
    $stack = @($startNode)
    while ($stack.Count -gt 0) {
        $currentId = $stack[-1]
        $stack = $stack[0..($stack.Count - 2)]
        
        if ($visited.ContainsKey($currentId)) {
            continue
        }
        
        $visited[$currentId] = $true
        
        foreach ($edgeId in $Graph.AdjacencyList[$currentId].Outgoing) {
            $edge = $Graph.Edges[$edgeId]
            if (-not $visited.ContainsKey($edge.TargetId)) {
                $stack += $edge.TargetId
            }
        }
    }
    
    # Check if all nodes were visited
    return $visited.Count -eq $Graph.Nodes.Count
}

function Get-CPGComplexityMetrics {
    <#
    .SYNOPSIS
    Calculates complexity metrics for the CPG graph.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph
    )
    
    $metrics = @{
        CyclomaticComplexity = 0
        Density = 0
        Modularity = 0
        ClusteringCoefficient = 0
    }
    
    # Calculate graph density
    $nodeCount = $Graph.Nodes.Count
    if ($nodeCount -gt 1) {
        $maxPossibleEdges = $nodeCount * ($nodeCount - 1)
        if ($maxPossibleEdges -gt 0) {
            $metrics.Density = [math]::Round($Graph.Edges.Count / $maxPossibleEdges, 4)
        }
    }
    
    # Calculate cyclomatic complexity (simplified)
    # V(G) = E - N + 2P where E=edges, N=nodes, P=connected components
    $metrics.CyclomaticComplexity = $Graph.Edges.Count - $Graph.Nodes.Count + 2
    
    return $metrics
}

function Find-CPGCycles {
    <#
    .SYNOPSIS
    Finds cycles in the CPG graph using depth-first search.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [int]$MaxCycles = 10
    )
    
    $visited = @{}
    $recursionStack = @{}
    $cycles = @()
    
    function Find-CyclesDFS($nodeId, $path) {
        if ($cycles.Count -ge $MaxCycles) {
            return
        }
        
        $visited[$nodeId] = $true
        $recursionStack[$nodeId] = $true
        
        foreach ($edgeId in $Graph.AdjacencyList[$nodeId].Outgoing) {
            $edge = $Graph.Edges[$edgeId]
            $targetId = $edge.TargetId
            
            if ($recursionStack.ContainsKey($targetId)) {
                # Found a cycle
                $cycleStart = $path.IndexOf($targetId)
                if ($cycleStart -ge 0) {
                    $cycle = $path[$cycleStart..($path.Count - 1)] + $targetId
                    $cycles += @{
                        Nodes = $cycle | ForEach-Object { $Graph.Nodes[$_] }
                        Length = $cycle.Count - 1
                    }
                }
            }
            elseif (-not $visited.ContainsKey($targetId)) {
                Find-CyclesDFS $targetId ($path + $targetId)
            }
        }
        
        $recursionStack.Remove($nodeId)
    }
    
    foreach ($nodeId in $Graph.Nodes.Keys) {
        if (-not $visited.ContainsKey($nodeId)) {
            Find-CyclesDFS $nodeId @($nodeId)
        }
    }
    
    return $cycles
}

Export-ModuleMember -Function @(
    'Get-CPGStatistics',
    'Test-CPGStronglyConnected',
    'Get-CPGComplexityMetrics',
    'Find-CPGCycles'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original file size: 1013 lines
# This component: Analysis and metrics operations