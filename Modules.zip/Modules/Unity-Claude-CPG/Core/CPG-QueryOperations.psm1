#Requires -Version 5.1
<#
.SYNOPSIS
    Query operations for Code Property Graph (CPG) implementation.

.DESCRIPTION
    Contains functions for querying and traversing CPG structures.
    Provides search, path finding, and neighbor discovery operations.

.NOTES
    Part of Unity-Claude-CPG refactored architecture
    Originally from Unity-Claude-CPG.psm1 (lines 498-715)
    Refactoring Date: 2025-08-25
#>

# Import required data structures
using module .\CPG-DataStructures.psm1

function Get-CPGNode {
    <#
    .SYNOPSIS
    Retrieves nodes from a CPG graph by various criteria.
    #>
    [CmdletBinding(DefaultParameterSetName = 'ById')]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(ParameterSetName = 'ById')]
        [string]$Id,
        
        [Parameter(ParameterSetName = 'ByName')]
        [string]$Name,
        
        [Parameter(ParameterSetName = 'ByType')]
        [CPGNodeType]$Type,
        
        [Parameter(ParameterSetName = 'ByFilter')]
        [scriptblock]$Filter,
        
        [switch]$First
    )
    
    $results = @()
    
    switch ($PSCmdlet.ParameterSetName) {
        'ById' {
            if ($Id) {
                if ($Graph.Nodes.ContainsKey($Id)) {
                    $results += $Graph.Nodes[$Id]
                }
            } else {
                $results = $Graph.Nodes.Values
            }
        }
        'ByName' {
            $results = $Graph.Nodes.Values | Where-Object { $_.Name -eq $Name }
        }
        'ByType' {
            $results = $Graph.Nodes.Values | Where-Object { $_.Type -eq $Type }
        }
        'ByFilter' {
            $results = $Graph.Nodes.Values | Where-Object $Filter
        }
    }
    
    if ($First -and $results.Count -gt 0) {
        return $results[0]
    }
    
    return $results
}

function Get-CPGEdge {
    <#
    .SYNOPSIS
    Retrieves edges from a CPG graph by various criteria.
    #>
    [CmdletBinding(DefaultParameterSetName = 'ById')]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(ParameterSetName = 'ById')]
        [string]$Id,
        
        [Parameter(ParameterSetName = 'ByNodes')]
        [string]$SourceId,
        
        [Parameter(ParameterSetName = 'ByNodes')]
        [string]$TargetId,
        
        [Parameter(ParameterSetName = 'ByType')]
        [CPGEdgeType]$Type,
        
        [Parameter(ParameterSetName = 'ByFilter')]
        [scriptblock]$Filter
    )
    
    $results = @()
    
    switch ($PSCmdlet.ParameterSetName) {
        'ById' {
            if ($Id) {
                if ($Graph.Edges.ContainsKey($Id)) {
                    $results += $Graph.Edges[$Id]
                }
            } else {
                $results = $Graph.Edges.Values
            }
        }
        'ByNodes' {
            $results = $Graph.Edges.Values | Where-Object {
                ($SourceId -and $_.SourceId -eq $SourceId) -and 
                ($TargetId -and $_.TargetId -eq $TargetId)
            }
        }
        'ByType' {
            $results = $Graph.Edges.Values | Where-Object { $_.Type -eq $Type }
        }
        'ByFilter' {
            $results = $Graph.Edges.Values | Where-Object $Filter
        }
    }
    
    return $results
}

function Get-CPGNeighbors {
    <#
    .SYNOPSIS
    Gets neighboring nodes of a specified node in the CPG graph.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(Mandatory)]
        [string]$NodeId,
        
        [ValidateSet('Outgoing', 'Incoming', 'Both')]
        [string]$Direction = 'Both',
        
        [CPGEdgeType[]]$EdgeTypes,
        [int]$MaxDepth = 1,
        [switch]$IncludeEdges
    )
    
    if (-not $Graph.AdjacencyList.ContainsKey($NodeId)) {
        return @()
    }
    
    $visited = @{}
    $queue = @(@{ NodeId = $NodeId; Depth = 0 })
    $results = @()
    
    while ($queue.Count -gt 0) {
        $current = $queue[0]
        $queue = $queue[1..($queue.Count - 1)]
        
        if ($visited.ContainsKey($current.NodeId) -or $current.Depth -gt $MaxDepth) {
            continue
        }
        
        $visited[$current.NodeId] = $true
        
        if ($current.Depth -gt 0) {
            $neighbor = @{
                Node = $Graph.Nodes[$current.NodeId]
                Depth = $current.Depth
            }
            
            if ($IncludeEdges) {
                $neighbor.Edges = @()
                # Find connecting edges
                foreach ($edgeId in $Graph.AdjacencyList[$current.NodeId].Incoming + $Graph.AdjacencyList[$current.NodeId].Outgoing) {
                    $edge = $Graph.Edges[$edgeId]
                    if (($edge.SourceId -eq $NodeId) -or ($edge.TargetId -eq $NodeId)) {
                        if (-not $EdgeTypes -or ($edge.Type -in $EdgeTypes)) {
                            $neighbor.Edges += $edge
                        }
                    }
                }
            }
            
            $results += $neighbor
        }
        
        if ($current.Depth -lt $MaxDepth) {
            $adjacencies = @()
            
            if ($Direction -in @('Outgoing', 'Both')) {
                $adjacencies += $Graph.AdjacencyList[$current.NodeId].Outgoing
            }
            
            if ($Direction -in @('Incoming', 'Both')) {
                $adjacencies += $Graph.AdjacencyList[$current.NodeId].Incoming
            }
            
            foreach ($edgeId in $adjacencies) {
                $edge = $Graph.Edges[$edgeId]
                if ($EdgeTypes -and ($edge.Type -notin $EdgeTypes)) {
                    continue
                }
                
                $nextNodeId = if ($edge.SourceId -eq $current.NodeId) { $edge.TargetId } else { $edge.SourceId }
                
                if (-not $visited.ContainsKey($nextNodeId)) {
                    $queue += @{ NodeId = $nextNodeId; Depth = $current.Depth + 1 }
                }
            }
        }
    }
    
    return $results
}

function Find-CPGPath {
    <#
    .SYNOPSIS
    Finds paths between nodes in a CPG graph using breadth-first search.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(Mandatory)]
        [string]$StartNodeId,
        
        [Parameter(Mandatory)]
        [string]$EndNodeId,
        
        [CPGEdgeType[]]$EdgeTypes,
        [ValidateSet('Shortest', 'All')]
        [string]$PathType = 'Shortest',
        [int]$MaxDepth = 10
    )
    
    if (-not $Graph.Nodes.ContainsKey($StartNodeId)) {
        throw "Start node '$StartNodeId' not found in graph"
    }
    
    if (-not $Graph.Nodes.ContainsKey($EndNodeId)) {
        throw "End node '$EndNodeId' not found in graph"
    }
    
    if ($StartNodeId -eq $EndNodeId) {
        return @(@{
            Nodes = @($Graph.Nodes[$StartNodeId])
            Edges = @()
            Length = 0
        })
    }
    
    $queue = @(@{
        NodeId = $StartNodeId
        Path = @($StartNodeId)
        EdgePath = @()
        Depth = 0
    })
    
    $visited = @{}
    $allPaths = @()
    
    while ($queue.Count -gt 0) {
        $current = $queue[0]
        $queue = $queue[1..($queue.Count - 1)]
        
        if ($current.Depth -gt $MaxDepth) {
            continue
        }
        
        if ($PathType -eq 'Shortest' -and $visited.ContainsKey($current.NodeId)) {
            continue
        }
        
        $visited[$current.NodeId] = $true
        
        # Get outgoing edges
        foreach ($edgeId in $Graph.AdjacencyList[$current.NodeId].Outgoing) {
            $edge = $Graph.Edges[$edgeId]
            
            if ($EdgeTypes -and ($edge.Type -notin $EdgeTypes)) {
                continue
            }
            
            $nextNodeId = $edge.TargetId
            
            if ($nextNodeId -eq $EndNodeId) {
                # Found a path
                $path = @{
                    Nodes = @()
                    Edges = @()
                    Length = $current.Path.Count
                }
                
                foreach ($nodeId in ($current.Path + $nextNodeId)) {
                    $path.Nodes += $Graph.Nodes[$nodeId]
                }
                
                foreach ($edgeId in ($current.EdgePath + $edge.Id)) {
                    $path.Edges += $Graph.Edges[$edgeId]
                }
                
                $allPaths += $path
                
                if ($PathType -eq 'Shortest') {
                    return $allPaths
                }
            }
            elseif ($nextNodeId -notin $current.Path) {
                $newPath = $current.Path + $nextNodeId
                $newEdgePath = $current.EdgePath + $edge.Id
                
                $queue += @{
                    NodeId = $nextNodeId
                    Path = $newPath
                    EdgePath = $newEdgePath
                    Depth = $current.Depth + 1
                }
            }
        }
    }
    
    return $allPaths
}

Export-ModuleMember -Function @(
    'Get-CPGNode',
    'Get-CPGEdge', 
    'Get-CPGNeighbors',
    'Find-CPGPath'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original file size: 1013 lines
# This component: Query and traversal operations