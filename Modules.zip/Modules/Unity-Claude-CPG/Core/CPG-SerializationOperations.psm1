#Requires -Version 5.1
<#
.SYNOPSIS
    Serialization operations for Code Property Graph (CPG) implementation.

.DESCRIPTION
    Contains functions for importing and exporting CPG structures to/from 
    various formats including JSON, XML, and GraphML.

.NOTES
    Part of Unity-Claude-CPG refactored architecture
    Originally from Unity-Claude-CPG.psm1 (lines 771-893)
    Refactoring Date: 2025-08-25
#>

# Import required data structures
using module .\CPG-DataStructures.psm1

function Export-CPGraph {
    <#
    .SYNOPSIS
    Exports a CPG graph to various formats.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(Mandatory)]
        [string]$Path,
        
        [ValidateSet('JSON', 'XML', 'GraphML', 'DOT')]
        [string]$Format = 'JSON',
        
        [switch]$IncludeMetadata,
        [switch]$Compress
    )
    
    $exportData = @{
        GraphInfo = $Graph.ToHashtable()
        Nodes = @()
        Edges = @()
        ExportedAt = Get-Date
        Format = $Format
    }
    
    # Export nodes
    foreach ($node in $Graph.Nodes.Values) {
        $nodeData = $node.ToHashtable()
        if (-not $IncludeMetadata) {
            $nodeData.Remove('Metadata')
        }
        $exportData.Nodes += $nodeData
    }
    
    # Export edges
    foreach ($edge in $Graph.Edges.Values) {
        $edgeData = $edge.ToHashtable()
        if (-not $IncludeMetadata) {
            $edgeData.Remove('Metadata')
        }
        $exportData.Edges += $edgeData
    }
    
    # Convert to specified format
    switch ($Format) {
        'JSON' {
            $content = $exportData | ConvertTo-Json -Depth 10
        }
        'XML' {
            # Convert to XML format
            $content = Export-ToXML -Data $exportData
        }
        'GraphML' {
            # Convert to GraphML format
            $content = Export-ToGraphML -Graph $Graph -IncludeMetadata:$IncludeMetadata
        }
        'DOT' {
            # Convert to DOT format for Graphviz
            $content = Export-ToDOT -Graph $Graph
        }
    }
    
    # Write to file
    if ($Compress) {
        # TODO: Implement compression
        $content | Out-File -FilePath $Path -Encoding UTF8
    } else {
        $content | Out-File -FilePath $Path -Encoding UTF8
    }
    
    return @{
        Path = $Path
        Format = $Format
        NodeCount = $exportData.Nodes.Count
        EdgeCount = $exportData.Edges.Count
        ExportedAt = $exportData.ExportedAt
    }
}

function Import-CPGraph {
    <#
    .SYNOPSIS
    Imports a CPG graph from various formats.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Path,
        
        [ValidateSet('JSON', 'XML', 'GraphML')]
        [string]$Format = 'JSON',
        
        [string]$GraphName
    )
    
    if (-not (Test-Path $Path)) {
        throw "File not found: $Path"
    }
    
    $content = Get-Content -Path $Path -Raw
    
    # Parse content based on format
    switch ($Format) {
        'JSON' {
            $data = $content | ConvertFrom-Json
        }
        'XML' {
            $data = Import-FromXML -Content $content
        }
        'GraphML' {
            $data = Import-FromGraphML -Content $content
        }
    }
    
    # Create new graph
    $graph = [CPGraph]::new()
    if ($GraphName) {
        $graph.Name = $GraphName
    } elseif ($data.GraphInfo -and $data.GraphInfo.Name) {
        $graph.Name = $data.GraphInfo.Name
    }
    
    # Import nodes
    foreach ($nodeData in $data.Nodes) {
        $node = [CPGNode]::new()
        $node.Id = $nodeData.Id
        $node.Name = $nodeData.Name
        $node.Type = [CPGNodeType]$nodeData.Type
        $node.Properties = $nodeData.Properties
        $node.FilePath = $nodeData.FilePath
        $node.StartLine = $nodeData.StartLine
        $node.EndLine = $nodeData.EndLine
        $node.StartColumn = $nodeData.StartColumn
        $node.EndColumn = $nodeData.EndColumn
        $node.Language = $nodeData.Language
        $node.CreatedAt = $nodeData.CreatedAt
        $node.ModifiedAt = $nodeData.ModifiedAt
        $node.Metadata = $nodeData.Metadata
        
        $graph.Nodes[$node.Id] = $node
        $graph.AdjacencyList[$node.Id] = @{
            Outgoing = @()
            Incoming = @()
        }
    }
    
    # Import edges
    foreach ($edgeData in $data.Edges) {
        $edge = [CPGEdge]::new()
        $edge.Id = $edgeData.Id
        $edge.SourceId = $edgeData.SourceId
        $edge.TargetId = $edgeData.TargetId
        $edge.Type = [CPGEdgeType]$edgeData.Type
        $edge.Direction = [EdgeDirection]$edgeData.Direction
        $edge.Properties = $edgeData.Properties
        $edge.Weight = $edgeData.Weight
        $edge.CreatedAt = $edgeData.CreatedAt
        $edge.Metadata = $edgeData.Metadata
        
        $graph.Edges[$edge.Id] = $edge
        
        # Update adjacency list
        $graph.AdjacencyList[$edge.SourceId].Outgoing += $edge.Id
        $graph.AdjacencyList[$edge.TargetId].Incoming += $edge.Id
        
        if ($edge.Direction -eq [EdgeDirection]::Bidirectional) {
            $graph.AdjacencyList[$edge.TargetId].Outgoing += $edge.Id
            $graph.AdjacencyList[$edge.SourceId].Incoming += $edge.Id
        }
    }
    
    return $graph
}

function Export-ToGraphML {
    <#
    .SYNOPSIS
    Helper function to export graph to GraphML format.
    #>
    param(
        [CPGraph]$Graph,
        [switch]$IncludeMetadata
    )
    
    $xml = @"
<?xml version="1.0" encoding="UTF-8"?>
<graphml xmlns="http://graphml.graphdrawing.org/xmlns"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://graphml.graphdrawing.org/xmlns
         http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd">
  
  <!-- Key definitions -->
  <key id="name" for="node" attr.name="name" attr.type="string"/>
  <key id="type" for="node" attr.name="type" attr.type="string"/>
  <key id="filepath" for="node" attr.name="filepath" attr.type="string"/>
  <key id="edgetype" for="edge" attr.name="type" attr.type="string"/>
  <key id="weight" for="edge" attr.name="weight" attr.type="double"/>

  <graph id="$($Graph.Id)" edgedefault="directed">
"@
    
    # Add nodes
    foreach ($node in $Graph.Nodes.Values) {
        $xml += "`n    <node id=`"$($node.Id)`">"
        $xml += "`n      <data key=`"name`">$($node.Name)</data>"
        $xml += "`n      <data key=`"type`">$($node.Type)</data>"
        if ($node.FilePath) {
            $xml += "`n      <data key=`"filepath`">$($node.FilePath)</data>"
        }
        $xml += "`n    </node>"
    }
    
    # Add edges
    foreach ($edge in $Graph.Edges.Values) {
        $xml += "`n    <edge id=`"$($edge.Id)`" source=`"$($edge.SourceId)`" target=`"$($edge.TargetId)`">"
        $xml += "`n      <data key=`"edgetype`">$($edge.Type)</data>"
        $xml += "`n      <data key=`"weight`">$($edge.Weight)</data>"
        $xml += "`n    </edge>"
    }
    
    $xml += "`n  </graph>`n</graphml>"
    return $xml
}

function Export-ToDOT {
    <#
    .SYNOPSIS
    Helper function to export graph to DOT format.
    #>
    param(
        [CPGraph]$Graph
    )
    
    $dot = "digraph `"$($Graph.Name)`" {`n"
    $dot += "  rankdir=TB;`n"
    $dot += "  node [shape=box];`n`n"
    
    # Add nodes
    foreach ($node in $Graph.Nodes.Values) {
        $label = "$($node.Name)\n($($node.Type))"
        $dot += "  `"$($node.Id)`" [label=`"$label`"];`n"
    }
    
    $dot += "`n"
    
    # Add edges
    foreach ($edge in $Graph.Edges.Values) {
        $dot += "  `"$($edge.SourceId)`" -> `"$($edge.TargetId)`" [label=`"$($edge.Type)`"];`n"
    }
    
    $dot += "}"
    return $dot
}

Export-ModuleMember -Function @(
    'Export-CPGraph',
    'Import-CPGraph'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original file size: 1013 lines
# This component: Graph serialization and import/export operations