#region Graph Traversal for Unreachable Code Component
<#
.SYNOPSIS
    Unity Claude CPG - Graph Traversal for Unreachable Code Component
    
.DESCRIPTION
    Implements graph traversal algorithms to identify unreachable code sections using
    Code Property Graph analysis. Performs reachability analysis using breadth-first
    search to find functions, classes, and code blocks that are never called or referenced.
    
    Key capabilities:
    - Auto-detection of entry points (main functions, exported functions, public methods)
    - BFS-based reachability analysis across CPG nodes
    - Unreachable code identification with severity assessment
    - File-based grouping and statistical reporting
    - Parent-child relationship tracking for comprehensive analysis
    
.VERSION
    2.0.0 - Refactored modular component
    
.DEPENDENCIES
    - Unity-Claude-CPG (Code Property Graph analysis)
    
.AUTHOR
    Unity-Claude-Automation Framework
#>

# Import required dependencies
$cpgModule = Join-Path (Split-Path $PSScriptRoot -Parent) "Unity-Claude-CPG.psd1"
if (Test-Path $cpgModule) {
    Import-Module $cpgModule -Force -ErrorAction SilentlyContinue
}

# Load CPG enums
$enumPath = Join-Path (Split-Path $PSScriptRoot -Parent) "Unity-Claude-CPG-Enums.ps1"
if (Test-Path $enumPath) {
    . $enumPath
}

#region Graph Traversal for Unreachable Code

function Find-UnreachableCode {
    <#
    .SYNOPSIS
        Finds unreachable code using CPG graph traversal
        
    .DESCRIPTION
        Analyzes the Code Property Graph to identify functions, classes, and code blocks
        that are never called or referenced using breadth-first search reachability analysis.
        
    .PARAMETER Graph
        The CPG graph to analyze
        
    .PARAMETER EntryPoints
        Array of entry point node IDs (e.g., main functions, exported functions)
        
    .OUTPUTS
        System.Collections.Hashtable
        Contains unreachable code analysis with statistics and file groupings
        
    .EXAMPLE
        $unreachable = Find-UnreachableCode -Graph $cpgGraph -EntryPoints @("main", "Start-Application")
        Write-Host "Found $($unreachable.UnreachableCode.Count) unreachable code sections"
        
    .EXAMPLE
        $unreachable = Find-UnreachableCode -Graph $cpgGraph
        $unreachable.ByFile | ForEach-Object { 
            Write-Host "File $($_.File) has $($_.Count) unreachable items"
        }
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [string[]]$EntryPoints = @()
    )
    
    try {
        Write-Verbose "Finding unreachable code in graph with $($Graph.Nodes.Count) nodes"
        
        # If no entry points specified, find them automatically
        if ($EntryPoints.Count -eq 0) {
            Write-Verbose "Auto-detecting entry points"
            
            # Find potential entry points
            $EntryPoints = @()
            
            # Main functions
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Name -match "^(main|Main|Start|Initialize)" } |
                Select-Object -ExpandProperty Id
            
            # Exported functions (PowerShell modules)
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Properties.IsExported -eq $true } |
                Select-Object -ExpandProperty Id
            
            # Public methods (classes)
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Method -and $_.Properties.Visibility -eq "Public" } |
                Select-Object -ExpandProperty Id
            
            # Event handlers
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Name -match "(_Click|_Load|_Changed|Handler)$" } |
                Select-Object -ExpandProperty Id
            
            # Module-level code
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Module } |
                Select-Object -ExpandProperty Id
        }
        
        Write-Verbose "Found $($EntryPoints.Count) entry points"
        
        # Perform reachability analysis using BFS
        $reachable = @{}
        $queue = New-Object System.Collections.Queue
        
        # Initialize with entry points
        foreach ($entryPoint in $EntryPoints) {
            if ($Graph.Nodes.ContainsKey($entryPoint)) {
                $queue.Enqueue($entryPoint)
                $reachable[$entryPoint] = $true
            }
        }
        
        # Traverse graph
        while ($queue.Count -gt 0) {
            $currentId = $queue.Dequeue()
            
            # Find all outgoing edges
            $outgoingEdges = $Graph.Edges.Values | Where-Object { $_.Source -eq $currentId }
            
            foreach ($edge in $outgoingEdges) {
                if (-not $reachable.ContainsKey($edge.Target)) {
                    $reachable[$edge.Target] = $true
                    $queue.Enqueue($edge.Target)
                    
                    # Also mark parent nodes as reachable (e.g., class if method is reachable)
                    $targetNode = $Graph.Nodes[$edge.Target]
                    if ($targetNode -and $targetNode.Properties.ParentId) {
                        if (-not $reachable.ContainsKey($targetNode.Properties.ParentId)) {
                            $reachable[$targetNode.Properties.ParentId] = $true
                            $queue.Enqueue($targetNode.Properties.ParentId)
                        }
                    }
                }
            }
        }
        
        Write-Verbose "Found $($reachable.Count) reachable nodes"
        
        # Identify unreachable nodes
        $unreachableNodes = @()
        foreach ($node in $Graph.Nodes.Values) {
            # Only consider function/method/class nodes
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method, [CPGNodeType]::Class)) {
                if (-not $reachable.ContainsKey($node.Id)) {
                    $unreachableNodes += @{
                        Id = $node.Id
                        Name = $node.Name
                        Type = $node.Type
                        File = $node.Properties.FilePath
                        Line = $node.Properties.LineNumber
                        Severity = if ($node.Type -eq [CPGNodeType]::Class) { "High" } 
                                  elseif ($node.Properties.Size -gt 50) { "High" }
                                  else { "Medium" }
                    }
                }
            }
        }
        
        # Calculate statistics
        $totalNodesCount = @($Graph.Nodes.Values).Count
        $reachableCount = @($reachable.Keys).Count
        
        $stats = @{
            TotalNodes = $totalNodesCount
            ReachableNodes = $reachableCount
            UnreachableNodes = @($unreachableNodes).Count
            Coverage = if ($totalNodesCount -gt 0) { 
                [Math]::Round(([double]$reachableCount / [double]$totalNodesCount) * 100, 2)
            } else { 0 }
        }
        
        # Group by file
        $byFile = $unreachableNodes | Group-Object -Property { $_.File } | 
            ForEach-Object {
                @{
                    File = $_.Name
                    Count = $_.Count
                    Items = $_.Group
                }
            }
        
        # Ensure arrays are returned
        return @{
            UnreachableCode = @($unreachableNodes)
            Statistics = $stats
            ByFile = @($byFile)
            EntryPoints = @($EntryPoints)
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to find unreachable code: $_"
        throw
    }
}

#endregion Graph Traversal for Unreachable Code

# Export public functions
Export-ModuleMember -Function @(
    'Find-UnreachableCode'
)

#endregion Graph Traversal for Unreachable Code Component