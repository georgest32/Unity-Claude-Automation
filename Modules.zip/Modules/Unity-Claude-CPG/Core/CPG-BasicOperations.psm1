#Requires -Version 5.1
<#
.SYNOPSIS
    Basic graph operations for Code Property Graph (CPG) implementation.

.DESCRIPTION
    Contains functions for creating and manipulating CPG nodes, edges, and graphs.
    Provides the core CRUD operations for the CPG system.

.NOTES
    Part of Unity-Claude-CPG refactored architecture
    Originally from Unity-Claude-CPG.psm1 (lines 337-497)
    Refactoring Date: 2025-08-25
#>

# Import required data structures
using module .\CPG-DataStructures.psm1

function New-CPGNode {
    <#
    .SYNOPSIS
    Creates a new CPG node with the specified name and type.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name,
        
        [Parameter(Mandatory)]
        [CPGNodeType]$Type,
        
        [hashtable]$Properties = @{},
        [string]$FilePath,
        [int]$StartLine = 0,
        [int]$EndLine = 0,
        [int]$StartColumn = 0,
        [int]$EndColumn = 0,
        [string]$Language = 'PowerShell',
        [hashtable]$Metadata = @{}
    )
    
    $node = [CPGNode]::new($Name, $Type)
    $node.Properties = $Properties
    $node.FilePath = $FilePath
    $node.StartLine = $StartLine
    $node.EndLine = $EndLine
    $node.StartColumn = $StartColumn
    $node.EndColumn = $EndColumn
    $node.Language = $Language
    $node.Metadata = $Metadata
    
    return $node
}

function New-CPGEdge {
    <#
    .SYNOPSIS
    Creates a new CPG edge between two nodes.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SourceId,
        
        [Parameter(Mandatory)]
        [string]$TargetId,
        
        [Parameter(Mandatory)]
        [CPGEdgeType]$Type,
        
        [EdgeDirection]$Direction = [EdgeDirection]::Forward,
        [hashtable]$Properties = @{},
        [double]$Weight = 1.0,
        [hashtable]$Metadata = @{}
    )
    
    $edge = [CPGEdge]::new($SourceId, $TargetId, $Type)
    $edge.Direction = $Direction
    $edge.Properties = $Properties
    $edge.Weight = $Weight
    $edge.Metadata = $Metadata
    
    return $edge
}

function New-CPGraph {
    <#
    .SYNOPSIS
    Creates a new CPG graph instance.
    #>
    [CmdletBinding()]
    param(
        [string]$Name = "Graph-$([guid]::NewGuid().ToString().Substring(0,8))",
        [hashtable]$Metadata = @{}
    )
    
    $graph = [CPGraph]::new($Name)
    $graph.Metadata = $Metadata
    
    return $graph
}

function Add-CPGNode {
    <#
    .SYNOPSIS
    Adds a node to the specified CPG graph.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(Mandatory)]
        [CPGNode]$Node
    )
    
    if ($Graph.Nodes.ContainsKey($Node.Id)) {
        Write-Warning "Node with ID '$($Node.Id)' already exists in graph '$($Graph.Name)'"
        return $false
    }
    
    $Graph.Nodes[$Node.Id] = $Node
    $Graph.AdjacencyList[$Node.Id] = @{
        Outgoing = @()
        Incoming = @()
    }
    $Graph.UpdateModifiedTime()
    
    return $true
}

function Add-CPGEdge {
    <#
    .SYNOPSIS
    Adds an edge to the specified CPG graph.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [CPGraph]$Graph,
        
        [Parameter(Mandatory)]
        [CPGEdge]$Edge
    )
    
    # Validate source and target nodes exist
    if (-not $Graph.Nodes.ContainsKey($Edge.SourceId)) {
        throw "Source node '$($Edge.SourceId)' does not exist in graph"
    }
    
    if (-not $Graph.Nodes.ContainsKey($Edge.TargetId)) {
        throw "Target node '$($Edge.TargetId)' does not exist in graph"
    }
    
    if ($Graph.Edges.ContainsKey($Edge.Id)) {
        Write-Warning "Edge with ID '$($Edge.Id)' already exists in graph '$($Graph.Name)'"
        return $false
    }
    
    $Graph.Edges[$Edge.Id] = $Edge
    
    # Update adjacency list
    $Graph.AdjacencyList[$Edge.SourceId].Outgoing += $Edge.Id
    $Graph.AdjacencyList[$Edge.TargetId].Incoming += $Edge.Id
    
    if ($Edge.Direction -eq [EdgeDirection]::Bidirectional) {
        $Graph.AdjacencyList[$Edge.TargetId].Outgoing += $Edge.Id
        $Graph.AdjacencyList[$Edge.SourceId].Incoming += $Edge.Id
    }
    
    $Graph.UpdateModifiedTime()
    return $true
}

Export-ModuleMember -Function @(
    'New-CPGNode',
    'New-CPGEdge',
    'New-CPGraph',
    'Add-CPGNode',
    'Add-CPGEdge'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original file size: 1013 lines  
# This component: Basic graph operations (node/edge/graph creation and addition)