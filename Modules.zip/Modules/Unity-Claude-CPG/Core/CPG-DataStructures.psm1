#Requires -Version 5.1
<#
.SYNOPSIS
    Core data structures for Code Property Graph (CPG) implementation.

.DESCRIPTION
    Contains enumerations and class definitions for CPG nodes, edges, and graphs.
    This module provides the foundational data types for the CPG system.

.NOTES
    Part of Unity-Claude-CPG refactored architecture
    Originally from Unity-Claude-CPG.psm1 (lines 32-245)
    Refactoring Date: 2025-08-25
#>

# Module-level variables for thread-safe graph storage
$script:CPGStorage = [hashtable]::Synchronized(@{})
$script:NodeIndex = [hashtable]::Synchronized(@{})
$script:EdgeIndex = [hashtable]::Synchronized(@{})
$script:GraphMetadata = [hashtable]::Synchronized(@{})
$script:CPGLock = [System.Threading.ReaderWriterLock]::new()

# Node type enumeration
enum CPGNodeType {
    Module
    Function
    Class
    Method
    Variable
    Parameter
    File
    Property
    Field
    Namespace
    Interface
    Enum
    Constant
    Label
    Comment
    Unknown
}

# Edge type enumeration
enum CPGEdgeType {
    Calls           # Function/method calls
    Uses            # Variable usage
    Imports         # Module imports
    Extends         # Class inheritance
    Implements      # Interface implementation
    DependsOn       # General dependency
    References      # Object references
    Assigns         # Variable assignment
    Returns         # Return values
    Throws          # Exception throwing
    Catches         # Exception handling
    Contains        # Containment relationship
    Follows         # Control flow
    DataFlow        # Data flow
    Overrides       # Method overriding
}

# Edge direction enumeration
enum EdgeDirection {
    Forward
    Backward
    Bidirectional
}

class CPGNode {
    [string]$Id
    [string]$Name
    [CPGNodeType]$Type
    [hashtable]$Properties
    [string]$FilePath
    [int]$StartLine
    [int]$EndLine
    [int]$StartColumn
    [int]$EndColumn
    [string]$Language
    [datetime]$CreatedAt
    [datetime]$ModifiedAt
    [hashtable]$Metadata
    
    CPGNode() {
        $this.Id = [guid]::NewGuid().ToString()
        $this.Properties = @{}
        $this.Metadata = @{}
        $this.CreatedAt = Get-Date
        $this.ModifiedAt = Get-Date
    }
    
    CPGNode([string]$name, [CPGNodeType]$type) {
        $this.Id = [guid]::NewGuid().ToString()
        $this.Name = $name
        $this.Type = $type
        $this.Properties = @{}
        $this.Metadata = @{}
        $this.CreatedAt = Get-Date
        $this.ModifiedAt = Get-Date
    }
    
    [string] ToString() {
        return "$($this.Type)::$($this.Name)"
    }
    
    [hashtable] ToHashtable() {
        return @{
            Id = $this.Id
            Name = $this.Name
            Type = $this.Type.ToString()
            Properties = $this.Properties
            FilePath = $this.FilePath
            StartLine = $this.StartLine
            EndLine = $this.EndLine
            StartColumn = $this.StartColumn
            EndColumn = $this.EndColumn
            Language = $this.Language
            CreatedAt = $this.CreatedAt
            ModifiedAt = $this.ModifiedAt
            Metadata = $this.Metadata
        }
    }
}

class CPGEdge {
    [string]$Id
    [string]$SourceId
    [string]$TargetId
    [CPGEdgeType]$Type
    [EdgeDirection]$Direction
    [hashtable]$Properties
    [double]$Weight
    [datetime]$CreatedAt
    [hashtable]$Metadata
    
    CPGEdge() {
        $this.Id = [guid]::NewGuid().ToString()
        $this.Properties = @{}
        $this.Metadata = @{}
        $this.Weight = 1.0
        $this.Direction = [EdgeDirection]::Forward
        $this.CreatedAt = Get-Date
    }
    
    CPGEdge([string]$sourceId, [string]$targetId, [CPGEdgeType]$type) {
        $this.Id = [guid]::NewGuid().ToString()
        $this.SourceId = $sourceId
        $this.TargetId = $targetId
        $this.Type = $type
        $this.Properties = @{}
        $this.Metadata = @{}
        $this.Weight = 1.0
        $this.Direction = [EdgeDirection]::Forward
        $this.CreatedAt = Get-Date
    }
    
    [string] ToString() {
        return "$($this.SourceId) -[$($this.Type)]-> $($this.TargetId)"
    }
    
    [hashtable] ToHashtable() {
        return @{
            Id = $this.Id
            SourceId = $this.SourceId
            TargetId = $this.TargetId
            Type = $this.Type.ToString()
            Direction = $this.Direction.ToString()
            Properties = $this.Properties
            Weight = $this.Weight
            CreatedAt = $this.CreatedAt
            Metadata = $this.Metadata
        }
    }
}

class CPGraph {
    [string]$Id
    [string]$Name
    [hashtable]$Nodes
    [hashtable]$Edges
    [hashtable]$AdjacencyList
    [hashtable]$Metadata
    [datetime]$CreatedAt
    [datetime]$ModifiedAt
    [int]$Version
    
    CPGraph() {
        $this.Id = [guid]::NewGuid().ToString()
        $this.Nodes = [hashtable]::Synchronized(@{})
        $this.Edges = [hashtable]::Synchronized(@{})
        $this.AdjacencyList = [hashtable]::Synchronized(@{})
        $this.Metadata = [hashtable]::Synchronized(@{})
        $this.CreatedAt = Get-Date
        $this.ModifiedAt = Get-Date
        $this.Version = 1
    }
    
    CPGraph([string]$name) {
        $this.Id = [guid]::NewGuid().ToString()
        $this.Name = $name
        $this.Nodes = [hashtable]::Synchronized(@{})
        $this.Edges = [hashtable]::Synchronized(@{})
        $this.AdjacencyList = [hashtable]::Synchronized(@{})
        $this.Metadata = [hashtable]::Synchronized(@{})
        $this.CreatedAt = Get-Date
        $this.ModifiedAt = Get-Date
        $this.Version = 1
    }
    
    [void] UpdateModifiedTime() {
        $this.ModifiedAt = Get-Date
        $this.Version++
    }
    
    [string] ToString() {
        return "CPGraph '$($this.Name)' (Nodes: $($this.Nodes.Count), Edges: $($this.Edges.Count))"
    }
    
    [hashtable] ToHashtable() {
        return @{
            Id = $this.Id
            Name = $this.Name
            NodesCount = $this.Nodes.Count
            EdgesCount = $this.Edges.Count
            CreatedAt = $this.CreatedAt
            ModifiedAt = $this.ModifiedAt
            Version = $this.Version
            Metadata = $this.Metadata
        }
    }
}

# Export data structures
Export-ModuleMember -Variable @(
    'CPGStorage',
    'NodeIndex', 
    'EdgeIndex',
    'GraphMetadata',
    'CPGLock'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original file size: 1013 lines
# This component: Core data structures and classes