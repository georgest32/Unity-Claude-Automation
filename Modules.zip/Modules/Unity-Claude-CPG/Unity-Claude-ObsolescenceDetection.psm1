# Unity-Claude-ObsolescenceDetection.psm1
# Obsolescence detection and dead code analysis for Unity-Claude CPG

#Requires -Version 5.1

# Import required modules
$cpgModule = Join-Path $PSScriptRoot "Unity-Claude-CPG.psm1"
if (Test-Path $cpgModule) {
    Import-Module $cpgModule -Force
}

# Load enums
$enumPath = Join-Path $PSScriptRoot "Unity-Claude-CPG-Enums.ps1"
if (Test-Path $enumPath) {
    . $enumPath
}

#region DePA Algorithm Implementation

function Get-CodePerplexity {
    <#
    .SYNOPSIS
    Implements DePA (Dead Program Artifact) algorithm for line-level perplexity analysis
    
    .DESCRIPTION
    Calculates perplexity scores for code lines to identify potentially dead or obsolete code.
    Based on statistical language modeling and entropy measurements.
    
    .PARAMETER CodeContent
    The code content to analyze
    
    .PARAMETER Language
    Programming language of the code
    
    .PARAMETER WindowSize
    Context window size for perplexity calculation (default: 5 lines)
    
    .EXAMPLE
    $perplexity = Get-CodePerplexity -CodeContent $code -Language "PowerShell"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$CodeContent,
        
        [Parameter(Mandatory)]
        [ValidateSet("PowerShell", "JavaScript", "TypeScript", "Python", "CSharp")]
        [string]$Language,
        
        [int]$WindowSize = 5
    )
    
    try {
        Write-Verbose "Calculating code perplexity for $Language code"
        
        # Split code into lines
        $lines = $CodeContent -split "`n"
        $lineCount = $lines.Count
        
        # Initialize perplexity scores
        $perplexityScores = @{}
        
        # Language-specific token patterns
        $tokenPatterns = @{
            PowerShell = @{
                Keywords = @('function', 'param', 'if', 'else', 'foreach', 'while', 'try', 'catch', 'return')
                Operators = @('-eq', '-ne', '-gt', '-lt', '-and', '-or', '-not')
                Special = @('$_', '$?', '$^', '$$')
            }
            JavaScript = @{
                Keywords = @('function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'async', 'await')
                Operators = @('===', '!==', '&&', '||', '=>')
                Special = @('this', 'super', 'new')
            }
            Python = @{
                Keywords = @('def', 'class', 'if', 'else', 'elif', 'for', 'while', 'return', 'import', 'from')
                Operators = @('and', 'or', 'not', 'in', 'is')
                Special = @('self', '__init__', '__name__')
            }
            TypeScript = @{
                Keywords = @('function', 'const', 'let', 'interface', 'type', 'class', 'extends', 'implements')
                Operators = @('===', '!==', '&&', '||', '=>', '?.')
                Special = @('this', 'super', 'new', 'typeof')
            }
            CSharp = @{
                Keywords = @('class', 'interface', 'public', 'private', 'protected', 'static', 'void', 'return')
                Operators = @('==', '!=', '&&', '||', '??', '?.')
                Special = @('this', 'base', 'new', 'typeof')
            }
        }
        
        $patterns = $tokenPatterns[$Language]
        
        # Calculate perplexity for each line
        for ($i = 0; $i -lt $lineCount; $i++) {
            $line = $lines[$i]
            
            # Skip empty lines and comments
            if ([string]::IsNullOrWhiteSpace($line)) {
                $perplexityScores[$i] = @{
                    LineNumber = $i + 1
                    Score = 0
                    Category = "Empty"
                }
                continue
            }
            
            # Check for comment patterns
            $isComment = switch ($Language) {
                "PowerShell" { $line.Trim().StartsWith("#") }
                "JavaScript" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                "TypeScript" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                "Python" { $line.Trim().StartsWith("#") }
                "CSharp" { $line.Trim().StartsWith("//") -or $line.Trim().StartsWith("/*") }
                default { $false }
            }
            
            if ($isComment) {
                $perplexityScores[$i] = @{
                    LineNumber = $i + 1
                    Score = 0.1
                    Category = "Comment"
                }
                continue
            }
            
            # Calculate context window
            $contextStart = [Math]::Max(0, $i - $WindowSize)
            $contextEnd = [Math]::Min($lineCount - 1, $i + $WindowSize)
            $context = $lines[$contextStart..$contextEnd] -join " "
            
            # Calculate token frequency
            $lineTokens = $line -split '\s+' | Where-Object { $_ -ne "" }
            $contextTokens = $context -split '\s+' | Where-Object { $_ -ne "" }
            
            # Calculate entropy-based perplexity
            $entropy = 0
            $tokenProbabilities = @{}
            
            foreach ($token in $lineTokens) {
                $frequency = ($contextTokens | Where-Object { $_ -eq $token } | Measure-Object).Count
                $totalTokens = ($contextTokens | Measure-Object).Count
                $probability = if ($totalTokens -gt 0) { 
                    $frequency / $totalTokens 
                } else { 
                    0.001 
                }
                
                if ($probability -gt 0) {
                    $entropy -= $probability * [Math]::Log($probability, 2)
                }
                
                $tokenProbabilities[$token] = $probability
            }
            
            # Calculate perplexity score (2^entropy)
            $perplexity = [Math]::Pow(2, $entropy)
            
            # Adjust for known patterns
            $adjustedScore = $perplexity
            
            # Lower score for lines with common keywords
            $keywordCount = ($patterns.Keywords | Where-Object { $line -match "\b$_\b" } | Measure-Object).Count
            if ($keywordCount -gt 0) {
                $adjustedScore *= (1 - 0.1 * $keywordCount)
            }
            
            # Higher score for isolated code (no references in context)
            $hasReferences = $false
            foreach ($token in $lineTokens) {
                if ($token -match '^\$\w+$|^\w+\(\)$|^\w+\.\w+$') {
                    # Check if token appears elsewhere in context
                    $otherOccurrences = ($context -split '\s+' | Where-Object { $_ -eq $token -and $_ -ne $line } | Measure-Object).Count
                    if ($otherOccurrences -eq 0) {
                        $adjustedScore *= 1.5
                    } else {
                        $hasReferences = $true
                    }
                }
            }
            
            # Categorize based on score
            $category = switch ($adjustedScore) {
                { $_ -lt 2 } { "Normal" }
                { $_ -ge 2 -and $_ -lt 5 } { "Suspicious" }
                { $_ -ge 5 -and $_ -lt 10 } { "HighPerplexity" }
                { $_ -ge 10 } { "VeryHighPerplexity" }
            }
            
            $perplexityScores[$i] = @{
                LineNumber = $i + 1
                Score = [Math]::Round($adjustedScore, 2)
                Category = $category
                HasReferences = $hasReferences
                Line = $line.Trim()
            }
        }
        
        # Return analysis results
        return @{
            Language = $Language
            TotalLines = $lineCount
            Scores = $perplexityScores
            Summary = @{
                Normal = ($perplexityScores.Values | Where-Object { $_.Category -eq "Normal" }).Count
                Suspicious = ($perplexityScores.Values | Where-Object { $_.Category -eq "Suspicious" }).Count
                HighPerplexity = ($perplexityScores.Values | Where-Object { $_.Category -eq "HighPerplexity" }).Count
                VeryHighPerplexity = ($perplexityScores.Values | Where-Object { $_.Category -eq "VeryHighPerplexity" }).Count
            }
            DeadCodeCandidates = $perplexityScores.Values | 
                Where-Object { $_.Category -in @("HighPerplexity", "VeryHighPerplexity") -and -not $_.HasReferences }
        }
    }
    catch {
        Write-Error "Failed to calculate code perplexity: $_"
        throw
    }
}

#endregion

#region Graph Traversal for Unreachable Code

function Find-UnreachableCode {
    <#
    .SYNOPSIS
    Finds unreachable code using CPG graph traversal
    
    .DESCRIPTION
    Analyzes the Code Property Graph to identify functions, classes, and code blocks
    that are never called or referenced.
    
    .PARAMETER Graph
    The CPG graph to analyze
    
    .PARAMETER EntryPoints
    Array of entry point node IDs (e.g., main functions, exported functions)
    
    .EXAMPLE
    $unreachable = Find-UnreachableCode -Graph $cpgGraph -EntryPoints @("main", "Start-Application")
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [string[]]$EntryPoints = @()
    )
    
    try {
        Write-Verbose "Finding unreachable code in graph with $($Graph.Nodes.Count) nodes"
        
        # If no entry points specified, find them automatically
        if ($EntryPoints.Count -eq 0) {
            Write-Verbose "Auto-detecting entry points"
            
            # Find potential entry points
            $EntryPoints = @()
            
            # Main functions
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Name -match "^(main|Main|Start|Initialize)" } |
                Select-Object -ExpandProperty Id
            
            # Exported functions (PowerShell modules)
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Properties.IsExported -eq $true } |
                Select-Object -ExpandProperty Id
            
            # Public methods (classes)
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Method -and $_.Properties.Visibility -eq "Public" } |
                Select-Object -ExpandProperty Id
            
            # Event handlers
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Function -and $_.Name -match "(_Click|_Load|_Changed|Handler)$" } |
                Select-Object -ExpandProperty Id
            
            # Module-level code
            $EntryPoints += $Graph.Nodes.Values | 
                Where-Object { $_.Type -eq [CPGNodeType]::Module } |
                Select-Object -ExpandProperty Id
        }
        
        Write-Verbose "Found $($EntryPoints.Count) entry points"
        
        # Perform reachability analysis using BFS
        $reachable = @{}
        $queue = New-Object System.Collections.Queue
        
        # Initialize with entry points
        foreach ($entryPoint in $EntryPoints) {
            if ($Graph.Nodes.ContainsKey($entryPoint)) {
                $queue.Enqueue($entryPoint)
                $reachable[$entryPoint] = $true
            }
        }
        
        # Traverse graph
        while ($queue.Count -gt 0) {
            $currentId = $queue.Dequeue()
            
            # Find all outgoing edges
            $outgoingEdges = $Graph.Edges.Values | Where-Object { $_.Source -eq $currentId }
            
            foreach ($edge in $outgoingEdges) {
                if (-not $reachable.ContainsKey($edge.Target)) {
                    $reachable[$edge.Target] = $true
                    $queue.Enqueue($edge.Target)
                    
                    # Also mark parent nodes as reachable (e.g., class if method is reachable)
                    $targetNode = $Graph.Nodes[$edge.Target]
                    if ($targetNode -and $targetNode.Properties.ParentId) {
                        if (-not $reachable.ContainsKey($targetNode.Properties.ParentId)) {
                            $reachable[$targetNode.Properties.ParentId] = $true
                            $queue.Enqueue($targetNode.Properties.ParentId)
                        }
                    }
                }
            }
        }
        
        Write-Verbose "Found $($reachable.Count) reachable nodes"
        
        # Identify unreachable nodes
        $unreachableNodes = @()
        foreach ($node in $Graph.Nodes.Values) {
            # Only consider function/method/class nodes
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method, [CPGNodeType]::Class)) {
                if (-not $reachable.ContainsKey($node.Id)) {
                    $unreachableNodes += @{
                        Id = $node.Id
                        Name = $node.Name
                        Type = $node.Type
                        File = $node.Properties.FilePath
                        Line = $node.Properties.LineNumber
                        Severity = if ($node.Type -eq [CPGNodeType]::Class) { "High" } 
                                  elseif ($node.Properties.Size -gt 50) { "High" }
                                  else { "Medium" }
                    }
                }
            }
        }
        
        # Calculate statistics
        $totalNodesCount = ($Graph.Nodes.Values | Measure-Object).Count
        $reachableCount = ($reachable | Measure-Object).Count
        
        $stats = @{
            TotalNodes = $totalNodesCount
            ReachableNodes = $reachableCount
            UnreachableNodes = ($unreachableNodes | Measure-Object).Count
            Coverage = [Math]::Round(([double]$reachableCount / [double]$totalNodesCount) * 100, 2)
        }
        
        # Group by file
        $byFile = $unreachableNodes | Group-Object -Property { $_.File } | 
            ForEach-Object {
                @{
                    File = $_.Name
                    Count = $_.Count
                    Items = $_.Group
                }
            }
        
        # Ensure arrays are returned
        return @{
            UnreachableCode = @($unreachableNodes)
            Statistics = $stats
            ByFile = @($byFile)
            EntryPoints = @($EntryPoints)
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to find unreachable code: $_"
        throw
    }
}

#endregion

#region Code Redundancy Detection

function Test-CodeRedundancy {
    <#
    .SYNOPSIS
    Tests for code redundancy using Levenshtein distance
    
    .DESCRIPTION
    Identifies duplicate or near-duplicate code blocks using string similarity metrics.
    
    .PARAMETER Graph
    The CPG graph to analyze
    
    .PARAMETER SimilarityThreshold
    Threshold for considering code similar (0.0 to 1.0, default: 0.85)
    
    .EXAMPLE
    $redundancy = Test-CodeRedundancy -Graph $cpgGraph -SimilarityThreshold 0.9
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [ValidateRange(0.0, 1.0)]
        [double]$SimilarityThreshold = 0.85
    )
    
    try {
        Write-Verbose "Testing code redundancy with threshold $SimilarityThreshold"
        
        # Helper function for Levenshtein distance - simplified to avoid array operation issues
        function Get-LevenshteinDistance {
            param(
                [string]$String1,
                [string]$String2
            )
            
            # Handle edge cases
            if ($String1 -eq $String2) { return 0 }
            if ([string]::IsNullOrEmpty($String1)) { return $String2.Length }
            if ([string]::IsNullOrEmpty($String2)) { return $String1.Length }
            
            # Convert to character arrays for safer indexing
            $chars1 = $String1.ToCharArray()
            $chars2 = $String2.ToCharArray()
            $len1 = $chars1.Count
            $len2 = $chars2.Count
            
            # Use hashtable-based approach to avoid matrix array issues
            $distances = @{}
            
            # Initialize distances
            for ($i = 0; $i -le $len1; $i++) {
                $distances["$i,0"] = $i
            }
            for ($j = 0; $j -le $len2; $j++) {
                $distances["0,$j"] = $j
            }
            
            # Calculate distances using explicit keys
            for ($i = 1; $i -le $len1; $i++) {
                for ($j = 1; $j -le $len2; $j++) {
                    $cost = if ($chars1[$i - 1] -eq $chars2[$j - 1]) { 0 } else { 1 }
                    
                    $deletion = $distances["$($i-1),$j"] + 1
                    $insertion = $distances["$i,$($j-1)"] + 1  
                    $substitution = $distances["$($i-1),$($j-1)"] + $cost
                    
                    $distances["$i,$j"] = [Math]::Min([Math]::Min($deletion, $insertion), $substitution)
                }
            }
            
            return $distances["$len1,$len2"]
        }
        
        # Helper function for similarity ratio
        function Get-SimilarityRatio {
            param(
                [string]$String1,
                [string]$String2
            )
            
            $distance = Get-LevenshteinDistance -String1 $String1 -String2 $String2
            $maxLen = [Math]::Max($String1.Length, $String2.Length)
            
            if ($maxLen -eq 0) { return 1.0 }
            
            # Ensure scalar types for arithmetic operations
            $distanceVal = [double]$distance
            $maxLenVal = [double]$maxLen
            
            return 1.0 - ($distanceVal / $maxLenVal)
        }
        
        # Extract code blocks from nodes
        $codeBlocks = @()
        foreach ($node in $Graph.Nodes.Values) {
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method) -and $node.Properties.Code) {
                $codeBlocks += @{
                    Id = $node.Id
                    Name = $node.Name
                    Type = $node.Type
                    File = $node.Properties.FilePath
                    Line = $node.Properties.LineNumber
                    Code = $node.Properties.Code
                    NormalizedCode = $node.Properties.Code -replace '\s+', ' ' -replace '^\s+|\s+$', ''
                }
            }
        }
        
        Write-Verbose "Analyzing $(($codeBlocks | Measure-Object).Count) code blocks for redundancy"
        
        # Find similar code blocks
        $duplicates = @()
        $processed = @{}
        
        $totalBlocks = ($codeBlocks | Measure-Object).Count
        for ($i = 0; $i -lt $totalBlocks; $i++) {
            $block1 = $codeBlocks[$i]
            
            if ($processed.ContainsKey($block1.Id)) { continue }
            
            $similarBlocks = @()
            
            for ($j = $i + 1; $j -lt $totalBlocks; $j++) {
                $block2 = $codeBlocks[$j]
                
                if ($processed.ContainsKey($block2.Id)) { continue }
                
                # Calculate similarity
                $similarity = Get-SimilarityRatio -String1 $block1.NormalizedCode -String2 $block2.NormalizedCode
                
                if ($similarity -ge $SimilarityThreshold) {
                    $similarBlocks += @{
                        Id = $block2.Id
                        Name = $block2.Name
                        File = $block2.File
                        Line = $block2.Line
                        Similarity = [Math]::Round($similarity, 3)
                    }
                    
                    $processed[$block2.Id] = $true
                }
            }
            
            if (($similarBlocks | Measure-Object).Count -gt 0) {
                $duplicates += @{
                    Primary = @{
                        Id = $block1.Id
                        Name = $block1.Name
                        File = $block1.File
                        Line = $block1.Line
                    }
                    Duplicates = $similarBlocks
                    Count = ($similarBlocks | Measure-Object).Count + 1
                    MaxSimilarity = ($similarBlocks | Measure-Object -Property Similarity -Maximum).Maximum
                }
                
                $processed[$block1.Id] = $true
            }
        }
        
        # Calculate redundancy statistics
        $stats = @{
            TotalBlocks = ($codeBlocks | Measure-Object).Count
            DuplicateGroups = ($duplicates | Measure-Object).Count
            TotalDuplicates = ($duplicates | ForEach-Object { $_.Count } | Measure-Object -Sum).Sum
            RedundancyRate = if (($codeBlocks | Measure-Object).Count -gt 0) {
                [Math]::Round((($processed.Keys | Measure-Object).Count / ($codeBlocks | Measure-Object).Count) * 100, 2)
            } else { 0 }
        }
        
        # Find exact duplicates
        $exactDuplicates = $duplicates | Where-Object { $_.MaxSimilarity -eq 1.0 }
        
        # Find near duplicates
        $nearDuplicates = $duplicates | Where-Object { $_.MaxSimilarity -lt 1.0 }
        
        # Ensure arrays are returned
        return @{
            Duplicates = @($duplicates)
            ExactDuplicates = @($exactDuplicates)
            NearDuplicates = @($nearDuplicates)
            Statistics = $stats
            SimilarityThreshold = $SimilarityThreshold
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to test code redundancy: $_"
        throw
    }
}

#endregion

#region Code Complexity Metrics

function Get-CodeComplexityMetrics {
    <#
    .SYNOPSIS
    Calculates various code complexity metrics
    
    .DESCRIPTION
    Computes cyclomatic complexity, cognitive complexity, and other metrics
    to identify overly complex code that may be obsolete or need refactoring.
    
    .PARAMETER Graph
    The CPG graph to analyze
    
    .PARAMETER IncludeHalstead
    Include Halstead complexity metrics
    
    .EXAMPLE
    $metrics = Get-CodeComplexityMetrics -Graph $cpgGraph -IncludeHalstead
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [switch]$IncludeHalstead
    )
    
    try {
        Write-Verbose "Calculating code complexity metrics for graph"
        
        $complexityResults = @()
        
        foreach ($node in $Graph.Nodes.Values) {
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method)) {
                $metrics = @{
                    Id = $node.Id
                    Name = $node.Name
                    Type = $node.Type
                    File = $node.Properties.FilePath
                    Line = $node.Properties.LineNumber
                }
                
                # Get code content
                $code = $node.Properties.Code
                if (-not $code) { continue }
                
                # Calculate Cyclomatic Complexity (CC)
                # CC = E - N + 2P where E = edges, N = nodes, P = connected components
                # Simplified: Count decision points + 1
                $decisionPoints = 0
                $decisionPatterns = @(
                    'if\s*\(',
                    'else\s+if\s*\(',
                    'else\s*\{',
                    'for\s*\(',
                    'foreach\s*\(',
                    'while\s*\(',
                    'do\s*\{',
                    'switch\s*\(',
                    'case\s+',
                    'catch\s*\(',
                    '\?\s*.*\s*:',  # Ternary operator
                    '&&',           # Logical AND
                    '\|\|'          # Logical OR
                )
                
                foreach ($pattern in $decisionPatterns) {
                    $matches = @([regex]::Matches($code, $pattern))
                    $decisionPoints += $matches.Count
                }
                
                $metrics.CyclomaticComplexity = $decisionPoints + 1
                
                # Calculate Cognitive Complexity
                # Considers nesting depth and complexity increments
                $cognitiveComplexity = 0
                $lines = $code -split "`n"
                $nestingLevel = 0
                
                foreach ($line in $lines) {
                    $trimmedLine = $line.Trim()
                    
                    # Increment for control flow
                    if ($trimmedLine -match '^\s*(if|for|foreach|while|switch)\s*\(') {
                        $cognitiveComplexity += 1 + $nestingLevel
                    }
                    
                    # Increment for else/elseif
                    if ($trimmedLine -match '^\s*(else|elseif|elif)\s*') {
                        $cognitiveComplexity += 1
                    }
                    
                    # Track nesting
                    $openBraces = @([regex]::Matches($line, '\{')).Count
                    $closeBraces = @([regex]::Matches($line, '\}')).Count
                    $nestingLevel += ($openBraces - $closeBraces)
                    $nestingLevel = [Math]::Max(0, $nestingLevel)
                }
                
                $metrics.CognitiveComplexity = $cognitiveComplexity
                
                # Lines of Code (LOC)
                $metrics.LinesOfCode = $lines.Count
                
                # Source Lines of Code (SLOC) - excluding comments and blank lines
                $sloc = ($lines | Where-Object { 
                    $_.Trim() -ne "" -and 
                    -not ($_.Trim().StartsWith("#")) -and
                    -not ($_.Trim().StartsWith("//"))
                }).Count
                $metrics.SourceLinesOfCode = $sloc
                
                # Calculate Halstead metrics if requested
                if ($IncludeHalstead) {
                    # Extract operators and operands
                    $operators = @([regex]::Matches($code, '[\+\-\*/=%<>!&\|]+|if|else|for|while|return|function|class|new'))
                    $operands = @([regex]::Matches($code, '\b[a-zA-Z_]\w*\b|\b\d+\b|"[^"]*"|''[^'']*'''))
                    
                    $n1 = ($operators | Select-Object -Unique Value | Measure-Object).Count  # Unique operators
                    $n2 = ($operands | Select-Object -Unique Value | Measure-Object).Count   # Unique operands
                    $N1 = ($operators | Measure-Object).Count                              # Total operators
                    $N2 = ($operands | Measure-Object).Count                               # Total operands
                    
                    $metrics.Halstead = @{
                        Vocabulary = $n1 + $n2
                        Length = $N1 + $N2
                        Volume = if (($n1 + $n2) -gt 0) { 
                            ($N1 + $N2) * [Math]::Log($n1 + $n2, 2) 
                        } else { 0 }
                        Difficulty = if ($n2 -gt 0) { 
                            ($n1 / 2) * ($N2 / $n2) 
                        } else { 0 }
                        Effort = 0  # Will be calculated below
                    }
                    
                    $metrics.Halstead.Effort = $metrics.Halstead.Volume * $metrics.Halstead.Difficulty
                }
                
                # Maintainability Index
                # MI = 171 - 5.2 * ln(V) - 0.23 * CC - 16.2 * ln(LOC)
                $volume = if ($IncludeHalstead -and $metrics.Halstead.Volume -gt 0) {
                    $metrics.Halstead.Volume
                } else {
                    $sloc * [Math]::Log($sloc + 1, 2)
                }
                
                $maintainabilityIndex = 171
                if ($volume -gt 0) { $maintainabilityIndex -= 5.2 * [Math]::Log($volume) }
                if ($metrics.CyclomaticComplexity -gt 0) { $maintainabilityIndex -= 0.23 * $metrics.CyclomaticComplexity }
                if ($sloc -gt 0) { $maintainabilityIndex -= 16.2 * [Math]::Log($sloc) }
                
                $metrics.MaintainabilityIndex = [Math]::Round([Math]::Max(0, [Math]::Min(100, $maintainabilityIndex)), 2)
                
                # Risk assessment based on complexity
                $riskLevel = if ($metrics.CyclomaticComplexity -gt 50 -or $metrics.CognitiveComplexity -gt 40) {
                    "VeryHigh"
                } elseif ($metrics.CyclomaticComplexity -gt 20 -or $metrics.CognitiveComplexity -gt 20) {
                    "High"
                } elseif ($metrics.CyclomaticComplexity -gt 10 -or $metrics.CognitiveComplexity -gt 10) {
                    "Medium"
                } else {
                    "Low"
                }
                
                $metrics.RiskLevel = $riskLevel
                
                # Obsolescence indicator
                # High complexity + low maintainability = likely obsolete
                $obsolescenceScore = 0
                if ($metrics.CyclomaticComplexity -gt 20) { $obsolescenceScore += 30 }
                if ($metrics.CognitiveComplexity -gt 20) { $obsolescenceScore += 20 }
                if ($metrics.MaintainabilityIndex -lt 50) { $obsolescenceScore += 30 }
                if ($sloc -gt 200) { $obsolescenceScore += 20 }
                
                $metrics.ObsolescenceScore = $obsolescenceScore
                $metrics.ObsolescenceRisk = switch ($obsolescenceScore) {
                    { $_ -ge 70 } { "High" }
                    { $_ -ge 40 } { "Medium" }
                    default { "Low" }
                }
                
                $complexityResults += $metrics
            }
        }
        
        # Calculate summary statistics
        $summary = @{
            TotalFunctions = $complexityResults.Count
            AverageCyclomaticComplexity = ($complexityResults | Measure-Object -Property CyclomaticComplexity -Average).Average
            AverageCognitiveComplexity = ($complexityResults | Measure-Object -Property CognitiveComplexity -Average).Average
            AverageMaintainabilityIndex = ($complexityResults | Measure-Object -Property MaintainabilityIndex -Average).Average
            HighRiskFunctions = ($complexityResults | Where-Object { $_.RiskLevel -in @("High", "VeryHigh") }).Count
            ObsolescenceCandidates = ($complexityResults | Where-Object { $_.ObsolescenceRisk -in @("High") }).Count
        }
        
        # Identify top complex functions
        $topComplex = $complexityResults | 
            Sort-Object -Property CyclomaticComplexity -Descending |
            Select-Object -First 10
        
        # Ensure arrays are returned
        return @{
            Metrics = @($complexityResults)
            Summary = $summary
            TopComplexFunctions = @($topComplex)
            HighRiskFunctions = @($complexityResults | Where-Object { $_.RiskLevel -in @("High", "VeryHigh") })
            ObsolescenceCandidates = @($complexityResults | Where-Object { $_.ObsolescenceRisk -eq "High" })
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to calculate complexity metrics: $_"
        throw
    }
}

#endregion

#endregion

#region Documentation Drift Detection

function Compare-CodeToDocumentation {
    <#
    .SYNOPSIS
    Compares code implementation with its documentation
    
    .DESCRIPTION
    Analyzes code against inline comments, help documentation, and external docs
    to identify drift between implementation and documentation.
    
    .PARAMETER Graph
    The CPG graph containing code nodes
    
    .PARAMETER DocumentationPath
    Optional path to external documentation files
    
    .PARAMETER IncludeInlineComments
    Include inline comment analysis
    
    .EXAMPLE
    $drift = Compare-CodeToDocumentation -Graph $cpgGraph -DocumentationPath ".\docs"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [string]$DocumentationPath,
        
        [switch]$IncludeInlineComments
    )
    
    try {
        Write-Verbose "Comparing code to documentation for $($Graph.Nodes.Count) nodes"
        
        $driftResults = @()
        
        foreach ($node in $Graph.Nodes.Values) {
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method, [CPGNodeType]::Class)) {
                $driftItem = @{
                    Id = $node.Id
                    Name = $node.Name
                    Type = $node.Type
                    File = $node.Properties.FilePath
                    Line = $node.Properties.LineNumber
                    Issues = @()
                }
                
                # Extract documentation from node
                $nodeDoc = @{
                    Synopsis = $null
                    Description = $null
                    Parameters = @{}
                    Returns = $null
                    Examples = @()
                }
                
                # Parse comment-based help (PowerShell)
                if ($node.Properties.CommentHelp) {
                    $help = $node.Properties.CommentHelp
                    
                    # Extract synopsis
                    if ($help -match '\.SYNOPSIS\s*\n\s*(.+?)(?=\n\s*\.|\n\s*#>|$)') {
                        $nodeDoc.Synopsis = $matches[1].Trim()
                    }
                    
                    # Extract description
                    if ($help -match '\.DESCRIPTION\s*\n\s*([\s\S]+?)(?=\n\s*\.|\n\s*#>|$)') {
                        $nodeDoc.Description = $matches[1].Trim()
                    }
                    
                    # Extract parameters
                    $paramMatches = [regex]::Matches($help, '\.PARAMETER\s+(\w+)\s*\n\s*(.+?)(?=\n\s*\.|\n\s*#>|$)')
                    foreach ($match in $paramMatches) {
                        $nodeDoc.Parameters[$match.Groups[1].Value] = $match.Groups[2].Value.Trim()
                    }
                    
                    # Extract return type
                    if ($help -match '\.OUTPUTS\s*\n\s*(.+?)(?=\n\s*\.|\n\s*#>|$)') {
                        $nodeDoc.Returns = $matches[1].Trim()
                    }
                }
                
                # Parse JSDoc comments (JavaScript/TypeScript)
                elseif ($node.Properties.JSDoc) {
                    $jsdoc = $node.Properties.JSDoc
                    
                    # Extract description
                    if ($jsdoc -match '^\s*\*\s*([^@].+?)(?=\n\s*\*\s*@|$)') {
                        $nodeDoc.Description = $matches[1].Trim()
                    }
                    
                    # Extract parameters
                    $paramMatches = [regex]::Matches($jsdoc, '@param\s*\{([^}]+)\}\s*(\w+)\s*-?\s*(.+?)(?=\n\s*\*\s*@|$)')
                    foreach ($match in $paramMatches) {
                        $nodeDoc.Parameters[$match.Groups[2].Value] = @{
                            Type = $match.Groups[1].Value
                            Description = $match.Groups[3].Value.Trim()
                        }
                    }
                    
                    # Extract return type
                    if ($jsdoc -match '@returns?\s*\{([^}]+)\}\s*(.+?)(?=\n\s*\*\s*@|$)') {
                        $nodeDoc.Returns = @{
                            Type = $matches[1]
                            Description = $matches[2].Trim()
                        }
                    }
                }
                
                # Parse Python docstrings
                elseif ($node.Properties.Docstring) {
                    $docstring = $node.Properties.Docstring
                    
                    # Extract description (first line or paragraph)
                    if ($docstring -match '^"""(.+?)(?:\n|""")') {
                        $nodeDoc.Description = $matches[1].Trim()
                    }
                    
                    # Extract parameters (Google/NumPy style)
                    if ($docstring -match 'Args:\s*\n([\s\S]+?)(?=\n\s*Returns?:|$)') {
                        $argsSection = $matches[1]
                        $paramMatches = [regex]::Matches($argsSection, '(\w+)\s*(?:\([^)]+\))?\s*:\s*(.+?)(?=\n\s*\w+\s*:|$)')
                        foreach ($match in $paramMatches) {
                            $nodeDoc.Parameters[$match.Groups[1].Value] = $match.Groups[2].Value.Trim()
                        }
                    }
                    
                    # Extract return type
                    if ($docstring -match 'Returns?:\s*\n\s*(.+?)(?=\n\s*\w+:|$)') {
                        $nodeDoc.Returns = $matches[1].Trim()
                    }
                }
                
                # Compare with actual implementation
                $actualParams = @()
                if ($node.Properties.Parameters) {
                    $actualParams = $node.Properties.Parameters
                }
                
                # Check for missing documentation
                if (-not $nodeDoc.Synopsis -and -not $nodeDoc.Description) {
                    $driftItem.Issues += @{
                        Type = "MissingDocumentation"
                        Severity = "High"
                        Message = "No documentation found for $($node.Type) '$($node.Name)'"
                    }
                }
                
                # Check parameter documentation
                foreach ($param in $actualParams) {
                    if (-not $nodeDoc.Parameters.ContainsKey($param.Name)) {
                        $driftItem.Issues += @{
                            Type = "UndocumentedParameter"
                            Severity = "Medium"
                            Message = "Parameter '$($param.Name)' is not documented"
                            Parameter = $param.Name
                        }
                    }
                }
                
                # Check for documented but non-existent parameters
                foreach ($docParam in $nodeDoc.Parameters.Keys) {
                    $exists = $actualParams | Where-Object { $_.Name -eq $docParam }
                    if (-not $exists) {
                        $driftItem.Issues += @{
                            Type = "ObsoleteParameter"
                            Severity = "High"
                            Message = "Documented parameter '$docParam' does not exist in code"
                            Parameter = $docParam
                        }
                    }
                }
                
                # Check return type documentation
                if ($node.Properties.ReturnType -and -not $nodeDoc.Returns) {
                    $driftItem.Issues += @{
                        Type = "MissingReturnDocumentation"
                        Severity = "Low"
                        Message = "Return type not documented"
                    }
                }
                
                # Check for stale examples
                if ($nodeDoc.Examples.Count -gt 0) {
                    foreach ($example in $nodeDoc.Examples) {
                        # Simple check: does the example reference the current function name?
                        if ($example -notmatch $node.Name) {
                            $driftItem.Issues += @{
                                Type = "StaleExample"
                                Severity = "Low"
                                Message = "Example may be outdated or incorrect"
                            }
                        }
                    }
                }
                
                if ($driftItem.Issues.Count -gt 0) {
                    $driftResults += $driftItem
                }
            }
        }
        
        # Check external documentation if path provided
        $externalDriftItems = @()
        if ($DocumentationPath -and (Test-Path $DocumentationPath)) {
            Write-Verbose "Checking external documentation at $DocumentationPath"
            
            $docFiles = Get-ChildItem -Path $DocumentationPath -Include "*.md", "*.txt", "*.rst" -Recurse
            
            foreach ($docFile in $docFiles) {
                $content = Get-Content $docFile.FullName -Raw
                
                # Look for code references in documentation
                $codeRefs = [regex]::Matches($content, '`([^`]+)`|```[^`]+```')
                
                foreach ($ref in $codeRefs) {
                    $codeSnippet = $ref.Value -replace '`', ''
                    
                    # Check if referenced functions exist
                    foreach ($node in $Graph.Nodes.Values) {
                        if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method) -and 
                            $codeSnippet -match "\b$($node.Name)\b") {
                            
                            # Verify signature matches
                            if ($node.Properties.Signature -and 
                                $codeSnippet -notmatch [regex]::Escape($node.Properties.Signature)) {
                                
                                $externalDriftItems += @{
                                    File = $docFile.Name
                                    Type = "OutdatedSignature"
                                    Function = $node.Name
                                    Message = "Documentation contains outdated function signature"
                                }
                            }
                        }
                    }
                }
            }
        }
        
        # Calculate statistics
        $totalNodes = ($Graph.Nodes.Values | Where-Object { 
            $_.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method, [CPGNodeType]::Class) 
        }).Count
        
        $stats = @{
            TotalCodeElements = $totalNodes
            ElementsWithIssues = $driftResults.Count
            TotalIssues = ($driftResults | ForEach-Object { $_.Issues.Count } | Measure-Object -Sum).Sum
            CoverageRate = if ($totalNodes -gt 0) {
                [Math]::Round((($totalNodes - $driftResults.Count) / $totalNodes) * 100, 2)
            } else { 0 }
            IssuesByType = $driftResults.Issues | Group-Object Type | ForEach-Object {
                @{ Type = $_.Name; Count = $_.Count }
            }
        }
        
        # Ensure arrays are returned
        return @{
            DriftItems = @($driftResults)
            ExternalDriftItems = @($externalDriftItems)
            Statistics = $stats
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to compare code to documentation: $_"
        throw
    }
}

function Find-UndocumentedFeatures {
    <#
    .SYNOPSIS
    Finds code features that lack documentation
    
    .DESCRIPTION
    Scans the CPG to identify public APIs, exported functions, and other features
    that should be documented but currently lack documentation.
    
    .PARAMETER Graph
    The CPG graph to analyze
    
    .PARAMETER MinimumVisibility
    Minimum visibility level to check (Public, Protected, Private)
    
    .EXAMPLE
    $undocumented = Find-UndocumentedFeatures -Graph $cpgGraph -MinimumVisibility "Public"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [ValidateSet("Public", "Protected", "Private")]
        [string]$MinimumVisibility = "Public"
    )
    
    try {
        Write-Verbose "Finding undocumented features in graph"
        
        $undocumentedFeatures = @()
        $visibilityLevels = @{
            "Public" = 3
            "Protected" = 2
            "Private" = 1
        }
        
        $minLevel = $visibilityLevels[$MinimumVisibility]
        
        foreach ($node in $Graph.Nodes.Values) {
            $shouldDocument = $false
            $reason = ""
            
            # Determine if node should be documented
            switch ($node.Type) {
                ([CPGNodeType]::Function) {
                    # Check if exported or public
                    if ($node.Properties.IsExported -eq $true) {
                        $shouldDocument = $true
                        $reason = "Exported function"
                    }
                    elseif ($node.Properties.Visibility -and 
                            $visibilityLevels[$node.Properties.Visibility] -ge $minLevel) {
                        $shouldDocument = $true
                        $reason = "Public function"
                    }
                }
                
                ([CPGNodeType]::Method) {
                    # Check visibility
                    if ($node.Properties.Visibility -and 
                        $visibilityLevels[$node.Properties.Visibility] -ge $minLevel) {
                        $shouldDocument = $true
                        $reason = "$($node.Properties.Visibility) method"
                    }
                }
                
                ([CPGNodeType]::Class) {
                    # Classes should always be documented if public
                    if (-not $node.Properties.Visibility -or 
                        $visibilityLevels[$node.Properties.Visibility] -ge $minLevel) {
                        $shouldDocument = $true
                        $reason = "Class definition"
                    }
                }
                
                ([CPGNodeType]::Module) {
                    # Modules should always be documented
                    $shouldDocument = $true
                    $reason = "Module"
                }
            }
            
            if ($shouldDocument) {
                # Check for documentation
                $hasDocumentation = $false
                
                if ($node.Properties.CommentHelp -or 
                    $node.Properties.JSDoc -or 
                    $node.Properties.Docstring -or
                    $node.Properties.XMLDoc) {
                    
                    # Check if documentation is meaningful (not just empty template)
                    $doc = $node.Properties.CommentHelp ?? 
                           $node.Properties.JSDoc ?? 
                           $node.Properties.Docstring ?? 
                           $node.Properties.XMLDoc
                    
                    if ($doc -and $doc.Length -gt 20 -and 
                        $doc -notmatch '^\s*<#\s*#>\s*$' -and
                        $doc -notmatch '^\s*/\*\s*\*/\s*$') {
                        $hasDocumentation = $true
                    }
                }
                
                if (-not $hasDocumentation) {
                    $undocumentedFeatures += @{
                        Id = $node.Id
                        Name = $node.Name
                        Type = $node.Type
                        File = $node.Properties.FilePath
                        Line = $node.Properties.LineNumber
                        Reason = $reason
                        Visibility = $node.Properties.Visibility ?? "Public"
                        Parameters = $node.Properties.Parameters
                        Complexity = if ($node.Properties.CyclomaticComplexity) {
                            $node.Properties.CyclomaticComplexity
                        } else { 0 }
                        Priority = switch ($reason) {
                            "Exported function" { "High" }
                            "Public method" { "High" }
                            "Public function" { "High" }
                            "Class definition" { "High" }
                            "Module" { "Critical" }
                            default { "Medium" }
                        }
                    }
                }
            }
        }
        
        # Group by priority and file
        $byPriority = $undocumentedFeatures | Group-Object Priority
        $byFile = $undocumentedFeatures | Group-Object { $_.File }
        
        # Calculate coverage statistics
        $totalPublicElements = ($Graph.Nodes.Values | Where-Object {
            $_.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method, [CPGNodeType]::Class) -and
            ($_.Properties.IsExported -eq $true -or 
             $_.Properties.Visibility -eq "Public" -or
             -not $_.Properties.Visibility)
        }).Count
        
        $stats = @{
            TotalPublicElements = $totalPublicElements
            UndocumentedCount = $undocumentedFeatures.Count
            DocumentationCoverage = if ($totalPublicElements -gt 0) {
                [Math]::Round((($totalPublicElements - $undocumentedFeatures.Count) / $totalPublicElements) * 100, 2)
            } else { 100 }
            CriticalCount = ($undocumentedFeatures | Where-Object { $_.Priority -eq "Critical" }).Count
            HighPriorityCount = ($undocumentedFeatures | Where-Object { $_.Priority -eq "High" }).Count
        }
        
        # Ensure arrays are returned
        return @{
            UndocumentedFeatures = @($undocumentedFeatures)
            ByPriority = @($byPriority | ForEach-Object {
                @{
                    Priority = $_.Name
                    Count = $_.Count
                    Items = @($_.Group)
                }
            })
            ByFile = @($byFile | ForEach-Object {
                @{
                    File = $_.Name
                    Count = $_.Count
                    Items = @($_.Group)
                }
            })
            Statistics = $stats
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to find undocumented features: $_"
        throw
    }
}

function Test-DocumentationAccuracy {
    <#
    .SYNOPSIS
    Tests the accuracy of existing documentation
    
    .DESCRIPTION
    Validates code examples, parameter descriptions, and return types
    in documentation against actual implementation.
    
    .PARAMETER Graph
    The CPG graph containing code
    
    .PARAMETER DocumentationPath
    Path to documentation files to test
    
    .PARAMETER TestExamples
    Actually execute code examples to verify they work
    
    .EXAMPLE
    $accuracy = Test-DocumentationAccuracy -Graph $cpgGraph -DocumentationPath ".\docs"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [string]$DocumentationPath,
        
        [switch]$TestExamples
    )
    
    try {
        Write-Verbose "Testing documentation accuracy"
        
        $accuracyResults = @()
        $testedItems = 0
        $passedItems = 0
        
        foreach ($node in $Graph.Nodes.Values) {
            if ($node.Type -in @([CPGNodeType]::Function, [CPGNodeType]::Method)) {
                $testResult = @{
                    Id = $node.Id
                    Name = $node.Name
                    File = $node.Properties.FilePath
                    Tests = @()
                    Passed = $true
                }
                
                # Get documentation
                $doc = $node.Properties.CommentHelp ?? 
                       $node.Properties.JSDoc ?? 
                       $node.Properties.Docstring
                
                if ($doc) {
                    $testedItems++
                    
                    # Test 1: Parameter count matches
                    $docParams = @()
                    if ($doc -match '\.PARAMETER|@param|Args:') {
                        $paramMatches = [regex]::Matches($doc, '(?:\.PARAMETER|@param)\s+(\w+)')
                        $docParams = $paramMatches | ForEach-Object { $_.Groups[1].Value }
                    }
                    
                    $actualParams = if ($node.Properties.Parameters) {
                        $node.Properties.Parameters | ForEach-Object { $_.Name }
                    } else { @() }
                    
                    $paramTest = @{
                        Test = "ParameterCount"
                        Expected = $actualParams.Count
                        Actual = $docParams.Count
                        Passed = $actualParams.Count -eq $docParams.Count
                    }
                    
                    $testResult.Tests += $paramTest
                    if (-not $paramTest.Passed) { $testResult.Passed = $false }
                    
                    # Test 2: Parameter names match
                    foreach ($docParam in $docParams) {
                        $paramNameTest = @{
                            Test = "ParameterName"
                            Parameter = $docParam
                            Exists = $actualParams -contains $docParam
                            Passed = $actualParams -contains $docParam
                        }
                        
                        $testResult.Tests += $paramNameTest
                        if (-not $paramNameTest.Passed) { $testResult.Passed = $false }
                    }
                    
                    # Test 3: Return type accuracy
                    if ($doc -match '\.OUTPUTS\s+(\[?[\w.]+\]?)' -or 
                        $doc -match '@returns?\s*\{([^}]+)\}') {
                        
                        $docReturnType = $matches[1]
                        $actualReturnType = $node.Properties.ReturnType
                        
                        if ($actualReturnType) {
                            $returnTest = @{
                                Test = "ReturnType"
                                Expected = $actualReturnType
                                Documented = $docReturnType
                                Passed = $docReturnType -eq $actualReturnType -or
                                        $docReturnType -match [regex]::Escape($actualReturnType)
                            }
                            
                            $testResult.Tests += $returnTest
                            if (-not $returnTest.Passed) { $testResult.Passed = $false }
                        }
                    }
                    
                    # Test 4: Example validity
                    if ($TestExamples -and $doc -match '\.EXAMPLE\s*\n\s*(.+?)(?=\n\s*\.|\n\s*#>|$)') {
                        $example = $matches[1].Trim()
                        
                        # Check if example contains the function name
                        $exampleTest = @{
                            Test = "ExampleValidity"
                            Example = $example
                            ContainsFunctionName = $example -match $node.Name
                            Passed = $example -match $node.Name
                        }
                        
                        # Try to parse the example for basic syntax
                        try {
                            $ast = [System.Management.Automation.Language.Parser]::ParseInput(
                                $example, 
                                [ref]$null, 
                                [ref]$null
                            )
                            $exampleTest.SyntaxValid = $true
                        }
                        catch {
                            $exampleTest.SyntaxValid = $false
                            $exampleTest.Passed = $false
                        }
                        
                        $testResult.Tests += $exampleTest
                        if (-not $exampleTest.Passed) { $testResult.Passed = $false }
                    }
                    
                    if ($testResult.Passed) { $passedItems++ }
                    $accuracyResults += $testResult
                }
            }
        }
        
        # Test external documentation files
        $externalTests = @()
        if ($DocumentationPath -and (Test-Path $DocumentationPath)) {
            Write-Verbose "Testing external documentation at $DocumentationPath"
            
            $docFiles = Get-ChildItem -Path $DocumentationPath -Include "*.md", "*.txt" -Recurse
            
            foreach ($docFile in $docFiles) {
                $content = Get-Content $docFile.FullName -Raw
                
                # Extract code blocks
                $codeBlocks = [regex]::Matches($content, '```(?:powershell|javascript|python|csharp)?\s*\n([\s\S]+?)\n```')
                
                foreach ($block in $codeBlocks) {
                    $code = $block.Groups[1].Value
                    $testedItems++
                    
                    $blockTest = @{
                        File = $docFile.Name
                        Code = $code.Substring(0, [Math]::Min(100, $code.Length))
                        Tests = @()
                        Passed = $true
                    }
                    
                    # Test for function references
                    foreach ($node in $Graph.Nodes.Values) {
                        if ($node.Type -eq [CPGNodeType]::Function -and $code -match $node.Name) {
                            # Check if parameters match
                            if ($node.Properties.Parameters) {
                                foreach ($param in $node.Properties.Parameters) {
                                    if ($code -notmatch "-$($param.Name)") {
                                        $blockTest.Tests += @{
                                            Test = "MissingParameter"
                                            Function = $node.Name
                                            Parameter = $param.Name
                                            Passed = $false
                                        }
                                        $blockTest.Passed = $false
                                    }
                                }
                            }
                        }
                    }
                    
                    if ($blockTest.Passed) { $passedItems++ }
                    $externalTests += $blockTest
                }
            }
        }
        
        # Calculate accuracy score
        $accuracyScore = if ($testedItems -gt 0) {
            [Math]::Round(($passedItems / $testedItems) * 100, 2)
        } else { 0 }
        
        # Identify common issues
        $allTests = $accuracyResults.Tests + ($externalTests | ForEach-Object { $_.Tests })
        $failedTests = $allTests | Where-Object { -not $_.Passed }
        $issueTypes = $failedTests | Group-Object Test
        
        # Ensure arrays are returned
        return @{
            AccuracyResults = @($accuracyResults)
            ExternalTests = @($externalTests)
            Statistics = @{
                TestedItems = $testedItems
                PassedItems = $passedItems
                AccuracyScore = $accuracyScore
                CommonIssues = @($issueTypes | ForEach-Object {
                    @{
                        Type = $_.Name
                        Count = $_.Count
                    }
                })
            }
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to test documentation accuracy: $_"
        throw
    }
}

function Update-DocumentationSuggestions {
    <#
    .SYNOPSIS
    Generates suggestions for updating documentation
    
    .DESCRIPTION
    Creates documentation templates and suggestions based on code analysis
    and identified documentation issues.
    
    .PARAMETER Graph
    The CPG graph containing code
    
    .PARAMETER DriftAnalysis
    Results from Compare-CodeToDocumentation
    
    .PARAMETER UndocumentedFeatures
    Results from Find-UndocumentedFeatures
    
    .PARAMETER OutputPath
    Path to save documentation suggestions
    
    .EXAMPLE
    $suggestions = Update-DocumentationSuggestions -Graph $cpgGraph -DriftAnalysis $drift -UndocumentedFeatures $undoc
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Graph,
        
        [hashtable]$DriftAnalysis,
        
        [hashtable]$UndocumentedFeatures,
        
        [string]$OutputPath
    )
    
    try {
        Write-Verbose "Generating documentation update suggestions"
        
        $suggestions = @{
            Templates = @()
            Updates = @()
            NewDocumentation = @()
            Priority = @{
                Critical = @()
                High = @()
                Medium = @()
                Low = @()
            }
        }
        
        # Generate templates for undocumented features
        if ($UndocumentedFeatures -and $UndocumentedFeatures.UndocumentedFeatures) {
            foreach ($feature in $UndocumentedFeatures.UndocumentedFeatures) {
                $template = ""
                
                # PowerShell function template
                if ($feature.Type -eq [CPGNodeType]::Function) {
                    $template = @"
<#
.SYNOPSIS
Brief description of what $($feature.Name) does

.DESCRIPTION
Detailed description of the function's purpose and behavior

"@
                    
                    # Add parameters
                    if ($feature.Parameters) {
                        foreach ($param in $feature.Parameters) {
                            $template += @"

.PARAMETER $($param.Name)
Description of the $($param.Name) parameter
"@
                        }
                    }
                    
                    $template += @"

.EXAMPLE
$($feature.Name) -ExampleParam "value"
Description of what this example does

.OUTPUTS
[Type] Description of what the function returns
#>
"@
                }
                
                # JavaScript/TypeScript JSDoc template
                elseif ($feature.Type -eq [CPGNodeType]::Method -and $feature.File -match '\.(js|ts)$') {
                    $template = @"
/**
 * Brief description of $($feature.Name)
 * 
 * Detailed description of the method's purpose
 * 
"@
                    
                    if ($feature.Parameters) {
                        foreach ($param in $feature.Parameters) {
                            $template += @"
 * @param {type} $($param.Name) - Description of parameter
"@
                        }
                    }
                    
                    $template += @"
 * @returns {type} Description of return value
 * @example
 * // Example usage
 * $($feature.Name)(args);
 */
"@
                }
                
                # Python docstring template
                elseif ($feature.Type -eq [CPGNodeType]::Method -and $feature.File -match '\.py$') {
                    $template = @'
"""
Brief description of method
    
Detailed description of purpose and behavior
    
Args:
'@
                    
                    if ($feature.Parameters) {
                        foreach ($param in $feature.Parameters) {
                            $template += @"
    $($param.Name): Description of parameter
"@
                        }
                    }
                    
                    $template += @'
    
Returns:
    Description of return value
    
Example:
    >>> result = method(args)
"""
'@
                }
                
                $suggestion = @{
                    Feature = $feature.Name
                    Type = $feature.Type
                    File = $feature.File
                    Line = $feature.Line
                    Template = $template
                    Priority = $feature.Priority
                    Action = "Add Documentation"
                }
                
                $suggestions.Templates += $suggestion
                
                # Add to priority queue
                switch ($feature.Priority) {
                    "Critical" { $suggestions.Priority.Critical += $suggestion }
                    "High" { $suggestions.Priority.High += $suggestion }
                    "Medium" { $suggestions.Priority.Medium += $suggestion }
                    "Low" { $suggestions.Priority.Low += $suggestion }
                }
            }
        }
        
        # Generate update suggestions for drift items
        if ($DriftAnalysis -and $DriftAnalysis.DriftItems) {
            foreach ($driftItem in $DriftAnalysis.DriftItems) {
                foreach ($issue in $driftItem.Issues) {
                    $updateSuggestion = @{
                        Feature = $driftItem.Name
                        File = $driftItem.File
                        Line = $driftItem.Line
                        IssueType = $issue.Type
                        Action = switch ($issue.Type) {
                            "MissingDocumentation" { "Add complete documentation" }
                            "UndocumentedParameter" { "Document parameter: $($issue.Parameter)" }
                            "ObsoleteParameter" { "Remove documentation for non-existent parameter: $($issue.Parameter)" }
                            "MissingReturnDocumentation" { "Add return type documentation" }
                            "StaleExample" { "Update example to reflect current implementation" }
                            "OutdatedSignature" { "Update function signature in documentation" }
                            default { "Review and update documentation" }
                        }
                        Priority = $issue.Severity
                        Details = $issue.Message
                    }
                    
                    $suggestions.Updates += $updateSuggestion
                    
                    # Add to priority queue
                    switch ($issue.Severity) {
                        "Critical" { $suggestions.Priority.Critical += $updateSuggestion }
                        "High" { $suggestions.Priority.High += $updateSuggestion }
                        "Medium" { $suggestions.Priority.Medium += $updateSuggestion }
                        "Low" { $suggestions.Priority.Low += $updateSuggestion }
                    }
                }
            }
        }
        
        # Generate new documentation suggestions
        # Find clusters of related undocumented features
        if ($UndocumentedFeatures -and $UndocumentedFeatures.ByFile) {
            foreach ($fileGroup in $UndocumentedFeatures.ByFile) {
                if ($fileGroup.Count -gt 3) {
                    $newDoc = @{
                        Type = "ModuleDocumentation"
                        File = $fileGroup.File
                        FeatureCount = $fileGroup.Count
                        Features = $fileGroup.Items | Select-Object -ExpandProperty Name
                        Suggestion = "Create comprehensive module documentation for $($fileGroup.File)"
                        Priority = "High"
                        Template = @"
# Module: $(Split-Path $fileGroup.File -Leaf)

## Overview
Description of module purpose and functionality

## Functions

$(($fileGroup.Items | ForEach-Object { "### $($_.Name)`n`nDescription of function`n" }) -join "`n")

## Examples

### Example 1: Basic Usage
```powershell
# Example code
```

## Dependencies
- List dependencies

## Notes
Additional information
"@
                    }
                    
                    $suggestions.NewDocumentation += $newDoc
                    $suggestions.Priority.High += $newDoc
                }
            }
        }
        
        # Calculate effort estimates
        $effortEstimate = @{
            TotalItems = $suggestions.Templates.Count + $suggestions.Updates.Count + $suggestions.NewDocumentation.Count
            EstimatedHours = 0
        }
        
        # Estimate time per item type
        $effortEstimate.EstimatedHours += $suggestions.Templates.Count * 0.25  # 15 min per template
        $effortEstimate.EstimatedHours += ($suggestions.Updates | Where-Object { $_.Priority -eq "High" }).Count * 0.5
        $effortEstimate.EstimatedHours += ($suggestions.Updates | Where-Object { $_.Priority -eq "Medium" }).Count * 0.25
        $effortEstimate.EstimatedHours += ($suggestions.Updates | Where-Object { $_.Priority -eq "Low" }).Count * 0.1
        $effortEstimate.EstimatedHours += $suggestions.NewDocumentation.Count * 2  # 2 hours per new doc
        
        $effortEstimate.EstimatedHours = [Math]::Round($effortEstimate.EstimatedHours, 1)
        
        # Save suggestions if output path provided
        if ($OutputPath) {
            if (-not (Test-Path $OutputPath)) {
                New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
            }
            
            # Save templates
            $templateFile = Join-Path $OutputPath "documentation-templates.md"
            $templateContent = "# Documentation Templates`n`n"
            
            foreach ($template in $suggestions.Templates) {
                $templateContent += "## $($template.Feature)`n"
                $templateContent += "File: $($template.File) (Line $($template.Line))`n"
                $templateContent += "Priority: $($template.Priority)`n`n"
                $templateContent += "``````powershell`n$($template.Template)`n```````n`n"
            }
            
            $templateContent | Out-File -FilePath $templateFile -Encoding UTF8
            Write-Verbose "Saved templates to $templateFile"
            
            # Save update suggestions
            $updateFile = Join-Path $OutputPath "documentation-updates.json"
            $suggestions | ConvertTo-Json -Depth 10 | Out-File -FilePath $updateFile -Encoding UTF8
            Write-Verbose "Saved update suggestions to $updateFile"
        }
        
        # Ensure arrays are returned
        return @{
            Suggestions = $suggestions
            EffortEstimate = $effortEstimate
            Summary = @{
                TemplatesGenerated = $suggestions.Templates.Count
                UpdatesNeeded = $suggestions.Updates.Count
                NewDocumentationNeeded = $suggestions.NewDocumentation.Count
                CriticalItems = $suggestions.Priority.Critical.Count
                HighPriorityItems = $suggestions.Priority.High.Count
            }
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }
    }
    catch {
        Write-Error "Failed to generate documentation suggestions: $_"
        throw
    }
}

#endregion

# Export module functions
Export-ModuleMember -Function @(
    'Get-CodePerplexity',
    'Find-UnreachableCode',
    'Test-CodeRedundancy',
    'Get-CodeComplexityMetrics',
    'Compare-CodeToDocumentation',
    'Find-UndocumentedFeatures',
    'Test-DocumentationAccuracy',
    'Update-DocumentationSuggestions'
)
# SIG # Begin signature block
# MIIFzgYJKoZIhvcNAQcCoIIFvzCCBbsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBxzLLFO0YrLVxm
# eUO02PQk5k7h7tJhbXg7D0RZVHbqUKCCAzAwggMsMIICFKADAgECAhB1HRbZIqgr
# lUTwkh3hnGtFMA0GCSqGSIb3DQEBCwUAMC4xLDAqBgNVBAMMI1VuaXR5LUNsYXVk
# ZS1BdXRvbWF0aW9uLURldmVsb3BtZW50MB4XDTI1MDgyMDIxMTUxN1oXDTI2MDgy
# MDIxMzUxN1owLjEsMCoGA1UEAwwjVW5pdHktQ2xhdWRlLUF1dG9tYXRpb24tRGV2
# ZWxvcG1lbnQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCx4feqKdUQ
# 6GufY4umNzlM1Pi8aHUGR8HlfhIWFjsrRAxCxhieRlWbHe0Hw+pVBeX76X57e5Pu
# 4Kxxzu+MxMry0NJYf3yOLRTfhYskHBcLraXUCtrMwqnhPKvul6Sx6Lu8vilk605W
# ADJNifl3WFuexVCYJJM9G2mfuYIDN+rZ5zmpn0qCXum49bm629h+HyJ205Zrn9aB
# hIrA4i/JlrAh1kosWnCo62psl7ixbNVqFqwWEt+gAqSeIo4ChwkOQl7GHmk78Q5I
# oRneY4JTVlKzhdZEYhJGFXeoZml/5jcmUcox4UNYrKdokE7z8ZTmyowBOUNS+sHI
# G1TY5DZSb8vdAgMBAAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr
# BgEFBQcDAzAdBgNVHQ4EFgQUfDms7LrGVboHjmwlSyIjYD/JLQwwDQYJKoZIhvcN
# AQELBQADggEBABRMsfT7DzKy+aFi4HDg0MpxmbjQxOH1lzUzanaECRiyA0sn7+sA
# /4jvis1+qC5NjDGkLKOTCuDzIXnBWLCCBugukXbIO7g392ANqKdHjBHw1WlLvMVk
# 4WSmY096lzpvDd3jJApr/Alcp4KmRGNLnQ3vv+F9Uj58Uo1qjs85vt6fl9xe5lo3
# rFahNHL4ngjgyF8emNm7FItJeNtVe08PhFn0caOX0FTzXrZxGGO6Ov8tzf91j/qK
# QdBifG7Fx3FF7DifNqoBBo55a7q0anz30k8p+V0zllrLkgGXfOzXmA1L37Qmt3QB
# FCdJVigjQMuHcrJsWd8rg857Og0un91tfZIxggH0MIIB8AIBATBCMC4xLDAqBgNV
# BAMMI1VuaXR5LUNsYXVkZS1BdXRvbWF0aW9uLURldmVsb3BtZW50AhB1HRbZIqgr
# lUTwkh3hnGtFMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAIoAKA
# AKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIAXB2C6ldkRPkiLZ8NxUTJC2
# PZw2g97J67gu2vAeUCDhMA0GCSqGSIb3DQEBAQUABIIBAJBFbaPMJ8n2IjM1BGgg
# sIXYMIvnadzyEOSNTrEu3XQTXw24/VAqi+5j1Ls8ujwjtxii4MxE347uhYxhF+Xs
# LBx3ZYdIZb6O60OktNI7+FRHRwElUbNeLXT2r99Dc9p9lb5rl05np3KRPiccF9zU
# 33ZQliyozB589jl+4vxMBuM8o/+JgBEP5TtLzlpA4L1dXUN132UvUUFrwP6OlxPI
# GINy6Xjb4k8svZor5JAsNVN0xwCw1ZW6o80tzNSPpxyt82KU1KhqhMd1vURLhjx0
# kC8xWVI1JfE2MFpE0i6rT34d9rPUrM88Se2kCJL4PW+jSrAOXIDM1tWYp3pELoiB
# KRs=
# SIG # End signature block
