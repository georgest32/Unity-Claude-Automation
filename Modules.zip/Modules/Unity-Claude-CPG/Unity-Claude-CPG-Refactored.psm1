#Requires -Version 5.1
<#
.SYNOPSIS
    Code Property Graph (CPG) module for relationship mapping and code analysis.
    
.DESCRIPTION  
    REFACTORED VERSION: This module has been refactored into modular components
    for better maintainability and organization.
    
    Implements a Code Property Graph structure that merges AST, CFG, and PDG
    for comprehensive code analysis, relationship mapping, and obsolescence detection.
    Based on Joern architecture with PowerShell-specific optimizations.

.NOTES
    Version: 1.1.0 (Refactored)
    Author: Unity-Claude Automation System
    Date: 2025-08-25
    
    REFACTORING MARKER: This module was refactored on 2025-08-25
    Original file size: 1013 lines
    New architecture: 6 focused components in Core/ subdirectory
    
    Component Structure:
    - CPG-DataStructures.psm1: Core classes and enums
    - CPG-BasicOperations.psm1: Node/edge/graph creation
    - CPG-QueryOperations.psm1: Search and traversal
    - CPG-AnalysisOperations.psm1: Statistics and metrics  
    - CPG-SerializationOperations.psm1: Import/export
    - Plus AST conversion from existing Unity-Claude-CPG-ASTConverter.psm1
#>

# === REFACTORING DEBUG LOG ===
Write-Host "✅ LOADING REFACTORED VERSION: Unity-Claude-CPG-Refactored.psm1 with 6 modular components" -ForegroundColor Green
Write-Host "📦 Components: DataStructures, BasicOperations, QueryOperations, AnalysisOperations, SerializationOperations + ASTConverter" -ForegroundColor Cyan

# Import all component modules
$CorePath = Join-Path $PSScriptRoot "Core"

# Import data structures first (required by other components)
$dataStructuresPath = Join-Path $CorePath "CPG-DataStructures.psm1"
if (Test-Path $dataStructuresPath) {
    Import-Module $dataStructuresPath -Force -Global
} else {
    Write-Error "Core component CPG-DataStructures.psm1 not found at: $dataStructuresPath"
}

# Import all other components
$components = @(
    "CPG-BasicOperations.psm1",
    "CPG-QueryOperations.psm1", 
    "CPG-AnalysisOperations.psm1",
    "CPG-SerializationOperations.psm1"
)

foreach ($component in $components) {
    $componentPath = Join-Path $CorePath $component
    if (Test-Path $componentPath) {
        Import-Module $componentPath -Force -Global
        Write-Verbose "Imported CPG component: $component"
    } else {
        Write-Error "Core component $component not found at: $componentPath"
    }
}

# Import AST converter (existing functionality)
$astConverterPath = Join-Path $PSScriptRoot "Unity-Claude-CPG-ASTConverter.psm1"
if (Test-Path $astConverterPath) {
    Import-Module $astConverterPath -Force -Global
    Write-Verbose "Imported AST converter component"
} else {
    Write-Warning "AST converter not found at: $astConverterPath"
}

# Add the ConvertTo-CPGFromScriptBlock function (preserved from original)
function ConvertTo-CPGFromScriptBlock {
    <#
    .SYNOPSIS
    Converts a PowerShell ScriptBlock to CPG format for analysis.
    
    .DESCRIPTION
    Parses a PowerShell ScriptBlock into an AST and converts it to CPG format for analysis.
    Provides a synthetic file path for in-memory code snippets.
    
    .PARAMETER ScriptBlock
    The PowerShell ScriptBlock to convert
    
    .PARAMETER GraphName
    Name for the generated graph (optional)
    
    .PARAMETER IncludeDataFlow
    Include data flow edges in the graph
    
    .PARAMETER IncludeControlFlow
    Include control flow edges in the graph
    
    .PARAMETER PseudoPath
    Optional friendly pseudo path for the root file node
    
    .EXAMPLE
    $graph = ConvertTo-CPGFromScriptBlock -ScriptBlock { function Test { Write-Host "Hello" } }
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock] $ScriptBlock,

        [string] $GraphName,
        [switch] $IncludeDataFlow,
        [switch] $IncludeControlFlow,

        # Optional friendly pseudo path for the root file node
        [string] $PseudoPath
    )

    # Parse the ScriptBlock to an AST
    $tokens = $null            # ✅ declare a real variable for tokens
    $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseInput(
        $ScriptBlock.ToString(),
        [ref]$tokens,           # ✅ pass a ref to a variable
        [ref]$parseErrors
    )

    if ($parseErrors -and $parseErrors.Count -gt 0) {
        throw ("ScriptBlock parse failed:`n" + ($parseErrors | ForEach-Object { $_.Message } | Out-String))
    }
    if (-not $ast) { throw "Parser returned null AST." }

    if (-not $PseudoPath) {
        $timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss_ffff')
        $PseudoPath = "InMemory:$timestamp.ps1"
    }

    Write-Verbose "[CPG] Parsed scriptblock to AST; PseudoPath='$PseudoPath'"

    # Invoke the converter function directly (now available through nested module)
    $graph = Convert-ASTtoCPG `
        -AST $ast `
        -FilePath $PseudoPath `
        -GraphName $GraphName `
        -IncludeDataFlow:$IncludeDataFlow `
        -IncludeControlFlow:$IncludeControlFlow
    
    if (-not $graph) { throw "Convert-ASTtoCPG returned null graph." }
    return $graph
}

# Export all public functions from components
Export-ModuleMember -Function @(
    # Core graph API (from BasicOperations)
    'New-CPGraph','New-CPGNode','Add-CPGNode','New-CPGEdge','Add-CPGEdge',
    
    # Query operations
    'Get-CPGNode','Get-CPGEdge','Get-CPGNeighbors','Find-CPGPath',
    
    # Analysis operations  
    'Get-CPGStatistics','Test-CPGStronglyConnected','Get-CPGComplexityMetrics','Find-CPGCycles',
    
    # Serialization operations
    'Export-CPGraph','Import-CPGraph',

    # AST conversion operations
    'Convert-ASTtoCPG','ConvertTo-CPGFromFile','ConvertTo-CPGFromScriptBlock'
)

Write-Verbose "Unity-Claude-CPG refactored module loaded successfully"
Write-Verbose "Components: DataStructures, BasicOperations, QueryOperations, AnalysisOperations, SerializationOperations, ASTConverter"

# REFACTORING MARKER: This module was refactored from Unity-Claude-CPG.psm1 on 2025-08-25
# Original monolithic file: 1013 lines
# New modular architecture: 6 focused components + main orchestrator
# Maintainability improvement: ~85% reduction in file complexity per component