#Requires -Version 5.1
<#
.SYNOPSIS
    Module integration and dependency management for Unity-Claude-MasterOrchestrator.

.DESCRIPTION
    Handles module loading, dependency resolution, integration points identification,
    and module availability testing for the master orchestrator system.

.NOTES
    Part of Unity-Claude-MasterOrchestrator refactored architecture
    Originally from Unity-Claude-MasterOrchestrator.psm1 (lines 120-378)
    Refactoring Date: 2025-08-25
#>

# Import the core orchestrator for logging and configuration
Import-Module "$PSScriptRoot\OrchestratorCore.psm1" -Force

function Test-ModuleAvailability {
    <#
    .SYNOPSIS
    Tests if a PowerShell module is available and can be loaded.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModuleName
    )
    
    try {
        $module = Get-Module -Name $ModuleName -ErrorAction SilentlyContinue
        if (-not $module) {
            # Define potential module paths for legacy modules
            $basePath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation\Modules"
            $potentialPaths = @(
                # Direct module folder with manifest
                "$basePath\$ModuleName\$ModuleName.psd1"
                # Direct psm1 file in Modules root
                "$basePath\$ModuleName.psm1"
                # Execution folder
                "$basePath\Execution\$ModuleName.psd1"
                "$basePath\Execution\$ModuleName.psm1"
                # Nested in AutonomousAgent folder structure
                "$basePath\Unity-Claude-AutonomousAgent\$ModuleName.psm1"
                # Nested in sub-folders
                "$basePath\Unity-Claude-AutonomousAgent\Core\$ModuleName.psm1"
                "$basePath\Unity-Claude-AutonomousAgent\Execution\$ModuleName.psm1"
                "$basePath\Unity-Claude-AutonomousAgent\Integration\$ModuleName.psm1"
                "$basePath\Unity-Claude-AutonomousAgent\Monitoring\$ModuleName.psm1"
                "$basePath\Unity-Claude-AutonomousAgent\Parsing\$ModuleName.psm1"
            )
            
            # Try each potential path
            foreach ($path in $potentialPaths) {
                if (Test-Path $path) {
                    Write-OrchestratorLog -Message "Found module '$ModuleName' at: $path" -Level "DEBUG"
                    try {
                        Import-Module $path -Force -ErrorAction Stop
                        $module = Get-Module -Name $ModuleName -ErrorAction SilentlyContinue
                        if ($module) {
                            Write-OrchestratorLog -Message "Successfully loaded module '$ModuleName' from: $path" -Level "DEBUG"
                            break
                        }
                    } catch {
                        Write-OrchestratorLog -Message "Failed to load module '$ModuleName' from $path : $_" -Level "DEBUG"
                        continue
                    }
                }
            }
            
            # Final fallback - try importing by name
            if (-not $module) {
                try {
                    Import-Module $ModuleName -Force -ErrorAction SilentlyContinue
                    $module = Get-Module -Name $ModuleName -ErrorAction SilentlyContinue
                } catch {
                    # Silently continue
                }
            }
        }
        
        if ($module) {
            Write-OrchestratorLog -Message "Module '$ModuleName' is available with $($module.ExportedCommands.Count) functions" -Level "DEBUG"
            return $true
        } else {
            Write-OrchestratorLog -Message "Module '$ModuleName' not available" -Level "WARN"
            return $false
        }
    }
    catch {
        Write-OrchestratorLog -Message "Error checking module '$ModuleName': $_" -Level "ERROR"
        return $false
    }
}

function Initialize-ModuleIntegration {
    <#
    .SYNOPSIS
    Initializes the unified module integration system.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$Force
    )
    
    Write-OrchestratorLog -Message "Initializing unified module integration" -Level "INFO"
    
    $initializationResult = @{
        Success = $true
        LoadedModules = @()
        FailedModules = @()
        IntegrationMap = @{}
        Timestamp = Get-Date
    }
    
    try {
        # Get current orchestrator state
        $state = Get-OrchestratorState
        $architecture = Get-ModuleArchitecture
        
        # Clear existing integration state if forcing
        if ($Force) {
            $state.IntegratedModules.Clear()
            Write-OrchestratorLog -Message "Cleared existing module integration state" -Level "DEBUG"
        }
        
        # Load modules in dependency order based on 2025 research patterns
        $moduleLoadOrder = @()
        $moduleLoadOrder += $architecture.CoreModules
        $moduleLoadOrder += $architecture.IntegrationModules  
        $moduleLoadOrder += $architecture.AgentModules
        $moduleLoadOrder += $architecture.ExecutionModules
        $moduleLoadOrder += $architecture.CommunicationModules
        $moduleLoadOrder += $architecture.ProcessingModules
        
        Write-OrchestratorLog -Message "Loading $($moduleLoadOrder.Count) modules in sequential order" -Level "INFO"
        
        foreach ($moduleName in $moduleLoadOrder) {
            try {
                $moduleInfo = Initialize-SingleModule -ModuleName $moduleName
                
                if ($moduleInfo.Success) {
                    $initializationResult.LoadedModules += $moduleName
                    $initializationResult.IntegrationMap[$moduleName] = $moduleInfo
                    Write-OrchestratorLog -Message "Successfully integrated module: $moduleName" -Level "DEBUG"
                } else {
                    $initializationResult.FailedModules += @{
                        ModuleName = $moduleName
                        Error = $moduleInfo.Error
                    }
                    Write-OrchestratorLog -Message "Failed to integrate module '$moduleName': $($moduleInfo.Error)" -Level "WARN"
                }
            }
            catch {
                $initializationResult.FailedModules += @{
                    ModuleName = $moduleName
                    Error = $_.Exception.Message
                }
                Write-OrchestratorLog -Message "Exception integrating module '$moduleName': $_" -Level "ERROR"
            }
        }
        
        # Validate critical modules are loaded
        $criticalModules = @('Unity-Claude-ResponseMonitor', 'Unity-Claude-DecisionEngine', 'Unity-Claude-Safety')
        $criticalModulesLoaded = 0
        
        foreach ($criticalModule in $criticalModules) {
            if ($initializationResult.LoadedModules -contains $criticalModule) {
                $criticalModulesLoaded++
            }
        }
        
        if ($criticalModulesLoaded -lt 2) {
            $initializationResult.Success = $false
            Write-OrchestratorLog -Message "Insufficient critical modules loaded ($criticalModulesLoaded/3)" -Level "ERROR"
        }
        
        Write-OrchestratorLog -Message "Module integration completed: $($initializationResult.LoadedModules.Count) loaded, $($initializationResult.FailedModules.Count) failed" -Level "INFO"
        
        return $initializationResult
    }
    catch {
        Write-OrchestratorLog -Message "Critical error in module integration: $_" -Level "ERROR"
        $initializationResult.Success = $false
        $initializationResult.Error = $_.Exception.Message
        return $initializationResult
    }
}

function Initialize-SingleModule {
    <#
    .SYNOPSIS
    Initializes a single module and collects its integration information.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModuleName
    )
    
    Write-OrchestratorLog -Message "Initializing module: $ModuleName" -Level "DEBUG"
    
    try {
        # Check if module is available and load it
        $isAvailable = Test-ModuleAvailability -ModuleName $ModuleName
        
        if (-not $isAvailable) {
            return @{
                Success = $false
                ModuleName = $ModuleName
                Error = "Module not available or failed to load"
                Functions = @()
            }
        }
        
        # Get module information
        $module = Get-Module -Name $ModuleName
        $moduleInfo = @{
            Success = $true
            ModuleName = $ModuleName
            Version = $module.Version.ToString()
            Functions = @()
            IntegrationPoints = @()
            InitializationTime = Get-Date
        }
        
        # Collect exported functions
        if ($module.ExportedCommands) {
            $moduleInfo.Functions = $module.ExportedCommands.Keys | Sort-Object
        }
        
        # Identify integration points based on function names
        $moduleInfo.IntegrationPoints = Get-ModuleIntegrationPoints -ModuleName $ModuleName -Functions $moduleInfo.Functions
        
        Write-OrchestratorLog -Message "Module '$ModuleName' initialized with $($moduleInfo.Functions.Count) functions" -Level "DEBUG"
        
        return $moduleInfo
    }
    catch {
        Write-OrchestratorLog -Message "Error initializing module '$ModuleName': $_" -Level "ERROR"
        return @{
            Success = $false
            ModuleName = $ModuleName
            Error = $_.Exception.Message
            Functions = @()
        }
    }
}

function Get-ModuleIntegrationPoints {
    <#
    .SYNOPSIS
    Analyzes module functions to identify integration points.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModuleName,
        
        [Parameter(Mandatory = $true)]
        [array]$Functions
    )
    
    $integrationPoints = @()
    
    # Define integration patterns based on function names
    $integrationPatterns = @{
        "EventHandlers" = @("*-Event", "*-Handler", "On*", "Handle*")
        "StateManagement" = @("Get-*State", "Set-*State", "*-State", "*-Status")
        "Configuration" = @("Get-*Config", "Set-*Config", "*-Configuration")
        "Processing" = @("Invoke-*", "Process-*", "Execute-*")
        "Monitoring" = @("Start-*", "Stop-*", "Monitor-*", "Watch-*")
        "Analysis" = @("Analyze-*", "Parse-*", "Extract-*", "Classify-*")
        "Testing" = @("Test-*", "Validate-*", "Check-*")
    }
    
    foreach ($function in $Functions) {
        foreach ($patternType in $integrationPatterns.Keys) {
            $patterns = $integrationPatterns[$patternType]
            foreach ($pattern in $patterns) {
                if ($function -like $pattern) {
                    $integrationPoints += @{
                        Type = $patternType
                        Function = $function
                        Pattern = $pattern
                    }
                    break
                }
            }
        }
    }
    
    return $integrationPoints
}

Export-ModuleMember -Function @(
    'Test-ModuleAvailability',
    'Initialize-ModuleIntegration',
    'Initialize-SingleModule',
    'Get-ModuleIntegrationPoints'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-MasterOrchestrator.psm1 on 2025-08-25
# Original file size: 1276 lines
# This component: Module integration and dependency management (lines 120-378)