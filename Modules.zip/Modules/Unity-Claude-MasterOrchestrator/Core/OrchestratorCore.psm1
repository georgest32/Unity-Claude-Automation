#Requires -Version 5.1
<#
.SYNOPSIS
    Core configuration and logging functionality for Unity-Claude-MasterOrchestrator.

.DESCRIPTION
    Contains core configuration management, logging functions, and basic utilities
    for the master orchestrator system.

.NOTES
    Part of Unity-Claude-MasterOrchestrator refactored architecture
    Originally from Unity-Claude-MasterOrchestrator.psm1 (lines 1-120)
    Refactoring Date: 2025-08-25
#>

# Module-level variables
$script:OrchestratorConfig = @{
    EnableDebugLogging = $true
    EnableAutonomousMode = $false
    SequentialProcessing = $true
    EventDrivenMode = $true
    MaxConcurrentOperations = 3
    OperationTimeoutMs = 30000
    SafetyValidationEnabled = $true
    LearningIntegrationEnabled = $true
    ConversationRounds = 0
    MaxConversationRounds = 10
}

$script:LogPath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation\unity_claude_automation.log"

# Orchestration state management
$script:IntegratedModules = @{}
$script:ActiveOperations = @{}
$script:EventQueue = [System.Collections.Queue]::new()
$script:OperationHistory = [System.Collections.Generic.List[hashtable]]::new()
$script:FeedbackLoopActive = $false

# Define the unified module architecture based on research findings
$script:ModuleArchitecture = @{
    # Core Foundation Modules
    CoreModules = @(
        'Unity-Claude-Core'
        'Unity-Claude-Errors'
        'Unity-Claude-Learning'
        'Unity-Claude-Safety'
    )
    
    # Day 17 New Integration Modules
    IntegrationModules = @(
        'Unity-Claude-ResponseMonitor'
        'Unity-Claude-DecisionEngine'
    )
    
    # Existing Autonomous Agent Modules
    AgentModules = @(
        'Unity-Claude-AutonomousStateTracker-Enhanced'
        'ConversationStateManager'
        'ContextOptimization'
        'IntelligentPromptEngine'
    )
    
    # Command Execution Modules
    ExecutionModules = @(
        'Unity-Claude-FixEngine'
        'SafeCommandExecution'
        'Unity-TestAutomation'
    )
    
    # Communication Modules
    CommunicationModules = @(
        'Unity-Claude-IPC-Bidirectional'
        'CLIAutomation'
    )
    
    # Processing Modules  
    ProcessingModules = @(
        'ResponseParsing'
        'Classification'
        'ContextExtraction'
    )
}

function Write-OrchestratorLog {
    <#
    .SYNOPSIS
    Writes log messages for the orchestrator system.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter()]
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG")]
        [string]$Level = "INFO"
    )
    
    if (-not $script:OrchestratorConfig.EnableDebugLogging -and $Level -eq "DEBUG") {
        return
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] [MasterOrchestrator] $Message"
    
    try {
        Add-Content -Path $script:LogPath -Value $logEntry -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {
        # Silently continue if logging fails
    }
    
    if ($Level -eq "ERROR") {
        Write-Error $Message
    } elseif ($Level -eq "WARN") {
        Write-Warning $Message
    } elseif ($script:OrchestratorConfig.EnableDebugLogging -or $Level -eq "INFO") {
        Write-Host $logEntry -ForegroundColor $(
            switch ($Level) {
                "ERROR" { "Red" }
                "WARN" { "Yellow" }
                "INFO" { "Green" }
                "DEBUG" { "Cyan" }
                default { "White" }
            }
        )
    }
}

function Get-OrchestratorConfig {
    <#
    .SYNOPSIS
    Gets the current orchestrator configuration.
    #>
    return $script:OrchestratorConfig.Clone()
}

function Set-OrchestratorConfig {
    <#
    .SYNOPSIS
    Updates orchestrator configuration settings.
    #>
    [CmdletBinding()]
    param(
        [hashtable]$Config
    )
    
    foreach ($key in $Config.Keys) {
        if ($script:OrchestratorConfig.ContainsKey($key)) {
            $script:OrchestratorConfig[$key] = $Config[$key]
            Write-OrchestratorLog "Updated config: $key = $($Config[$key])" -Level "DEBUG"
        }
    }
}

function Get-ModuleArchitecture {
    <#
    .SYNOPSIS
    Returns the defined module architecture.
    #>
    return $script:ModuleArchitecture
}

function Get-OrchestratorState {
    <#
    .SYNOPSIS
    Gets the current orchestrator state information.
    #>
    return @{
        Config = $script:OrchestratorConfig
        IntegratedModules = $script:IntegratedModules.Keys
        ActiveOperations = $script:ActiveOperations.Keys
        EventQueueSize = $script:EventQueue.Count
        OperationHistoryCount = $script:OperationHistory.Count
        FeedbackLoopActive = $script:FeedbackLoopActive
        LogPath = $script:LogPath
    }
}

Export-ModuleMember -Function @(
    'Write-OrchestratorLog',
    'Get-OrchestratorConfig',
    'Set-OrchestratorConfig', 
    'Get-ModuleArchitecture',
    'Get-OrchestratorState'
) -Variable @(
    'OrchestratorConfig',
    'LogPath',
    'IntegratedModules',
    'ActiveOperations', 
    'EventQueue',
    'OperationHistory',
    'FeedbackLoopActive',
    'ModuleArchitecture'
)

# REFACTORING MARKER: This module was refactored from Unity-Claude-MasterOrchestrator.psm1 on 2025-08-25
# Original file size: 1276 lines
# This component: Core configuration, logging, and state management