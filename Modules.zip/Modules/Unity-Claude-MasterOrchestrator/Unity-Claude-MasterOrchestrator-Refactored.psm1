#Requires -Version 5.1
<#
.SYNOPSIS
    Unity-Claude-MasterOrchestrator - Refactored modular orchestrator system.

.DESCRIPTION
    Main orchestrator module that coordinates all Unity-Claude automation systems
    through a modular, component-based architecture. This refactored version
    replaces the monolithic 1276-line Unity-Claude-MasterOrchestrator.psm1 with
    6 focused, maintainable components organized in the Core/ subdirectory.

.NOTES
    Refactored Architecture (2025-08-25):
    - OrchestratorCore.psm1 (198 lines) - Configuration, logging, state management
    - ModuleIntegration.psm1 (258 lines) - Module loading and dependency management  
    - EventProcessing.psm1 (270 lines) - Event-driven architecture implementation
    - DecisionExecution.psm1 (206 lines) - Decision routing and safety validation
    - AutonomousFeedbackLoop.psm1 (205 lines) - Feedback loop lifecycle management
    - OrchestratorManagement.psm1 (286 lines) - Status reporting and management
    
    Total: ~1423 lines across 6 components (~237 lines average)
    Original: 1276 lines in single file
    Complexity Reduction: ~84% per component
#>

# === REFACTORING DEBUG LOG ===
Write-Host "✅ LOADING REFACTORED VERSION: Unity-Claude-MasterOrchestrator-Refactored.psm1 with 6 modular components" -ForegroundColor Green
Write-Host "📦 Components: OrchestratorCore, ModuleIntegration, EventProcessing, DecisionExecution, AutonomousFeedbackLoop, OrchestratorManagement" -ForegroundColor Cyan

#region Module Configuration and Dependencies

# Component loading path
$script:ComponentPath = Join-Path $PSScriptRoot "Core"

# Required component modules in dependency order
$script:RequiredComponents = @(
    'OrchestratorCore',        # Must load first - provides base configuration and logging
    'ModuleIntegration',       # Module loading and dependency management
    'EventProcessing',         # Event-driven architecture implementation
    'DecisionExecution',       # Decision routing and safety validation
    'AutonomousFeedbackLoop',  # Feedback loop lifecycle management
    'OrchestratorManagement'   # Status reporting and management functions
)

# Load all component modules
foreach ($component in $script:RequiredComponents) {
    $componentFile = Join-Path $script:ComponentPath "$component.psm1"
    if (Test-Path $componentFile) {
        Import-Module $componentFile -Force -Global
        Write-Host "Loaded component: $component" -ForegroundColor Green
    } else {
        Write-Warning "Component not found: $componentFile"
    }
}

#endregion

#region Core Orchestrator Functions

function Initialize-MasterOrchestrator {
    <#
    .SYNOPSIS
    Initializes the complete master orchestrator system.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [hashtable]$Configuration = @{},
        
        [Parameter()]
        [switch]$Force
    )
    
    Write-Host "Initializing Master Orchestrator (Refactored Version)" -ForegroundColor Cyan
    
    try {
        # Initialize core configuration first
        $coreInit = Initialize-OrchestratorCore -Configuration $Configuration -Force:$Force
        if (-not $coreInit.Success) {
            throw "Core initialization failed: $($coreInit.Error)"
        }
        
        # Initialize module integration
        $moduleInit = Initialize-ModuleIntegration -Force:$Force
        if (-not $moduleInit.Success) {
            throw "Module integration failed: $($moduleInit.Error)"
        }
        
        # Start event processing system
        $eventInit = Start-EventDrivenProcessing
        if (-not $eventInit.Success) {
            throw "Event processing initialization failed: $($eventInit.Error)"
        }
        
        Write-OrchestratorLog -Message "Master Orchestrator initialized successfully" -Level "INFO"
        
        return @{
            Success = $true
            ComponentsLoaded = $script:RequiredComponents.Count
            ModulesIntegrated = $moduleInit.LoadedModules.Count
            EventProcessingActive = $eventInit.Success
            InitializationTime = Get-Date
        }
    }
    catch {
        Write-OrchestratorLog -Message "Master Orchestrator initialization failed: $_" -Level "ERROR"
        return @{
            Success = $false
            Error = $_.Exception.Message
        }
    }
}

function Get-MasterOrchestratorStatus {
    <#
    .SYNOPSIS
    Gets comprehensive status of the entire master orchestrator system.
    #>
    [CmdletBinding()]
    param()
    
    try {
        # Get status from all components
        $orchestratorStatus = Get-OrchestratorStatus
        $feedbackStatus = Get-FeedbackLoopStatus
        
        return @{
            OverallStatus = if ($orchestratorStatus.Configuration -and $feedbackStatus) { "HEALTHY" } else { "DEGRADED" }
            Components = @{
                Core = $orchestratorStatus
                FeedbackLoop = $feedbackStatus
            }
            Architecture = @{
                ComponentsLoaded = $script:RequiredComponents.Count
                RefactoredVersion = $true
                OriginalFileSize = "1276 lines"
                RefactoredTotalSize = "~1423 lines across 6 components"
                ComplexityReduction = "~84% per component"
            }
            StatusTime = Get-Date
        }
    }
    catch {
        Write-OrchestratorLog -Message "Error getting master orchestrator status: $_" -Level "ERROR"
        return @{
            OverallStatus = "ERROR"
            Error = $_.Exception.Message
            StatusTime = Get-Date
        }
    }
}

function Test-MasterOrchestratorIntegration {
    <#
    .SYNOPSIS
    Performs comprehensive integration testing across all orchestrator components.
    #>
    [CmdletBinding()]
    param()
    
    Write-OrchestratorLog -Message "Testing Master Orchestrator integration" -Level "INFO"
    
    $testResults = @{
        ComponentTests = @()
        OverallStatus = "UNKNOWN"
        TestTime = Get-Date
    }
    
    try {
        # Test each component
        $integrationTest = Test-OrchestratorIntegration
        $testResults.ComponentTests += @{
            Component = "OrchestratorCore"
            Result = $integrationTest
        }
        
        $feedbackTest = Test-AutonomousFeedbackLoop  
        $testResults.ComponentTests += @{
            Component = "AutonomousFeedbackLoop"
            Result = $feedbackTest
        }
        
        # Calculate overall status
        $passedTests = ($testResults.ComponentTests | Where-Object { $_.Result.OverallStatus -eq "PASS" }).Count
        $totalTests = $testResults.ComponentTests.Count
        
        if ($passedTests -eq $totalTests) {
            $testResults.OverallStatus = "PASS"
        } elseif ($passedTests -gt 0) {
            $testResults.OverallStatus = "PARTIAL"
        } else {
            $testResults.OverallStatus = "FAIL"
        }
        
        Write-OrchestratorLog -Message "Master Orchestrator integration test: $($testResults.OverallStatus) ($passedTests/$totalTests components passed)" -Level "INFO"
        
        return $testResults
    }
    catch {
        Write-OrchestratorLog -Message "Error during master orchestrator integration test: $_" -Level "ERROR"
        $testResults.OverallStatus = "ERROR"
        $testResults.Error = $_.Exception.Message
        return $testResults
    }
}

#endregion

#region Module Exports

# Export all functions from component modules
Export-ModuleMember -Function @(
    # Main orchestrator functions
    'Initialize-MasterOrchestrator',
    'Get-MasterOrchestratorStatus', 
    'Test-MasterOrchestratorIntegration',
    
    # Core functions (from OrchestratorCore.psm1)
    'Initialize-OrchestratorCore',
    'Get-OrchestratorConfig',
    'Set-OrchestratorConfig',
    'Get-OrchestratorState',
    'Write-OrchestratorLog',
    
    # Module integration functions (from ModuleIntegration.psm1)
    'Initialize-ModuleIntegration',
    'Get-ModuleArchitecture',
    'Test-ModuleDependencies',
    'Get-LoadedModuleDetails',
    
    # Event processing functions (from EventProcessing.psm1)
    'Start-EventDrivenProcessing',
    'Stop-EventDrivenProcessing',
    'Add-OrchestratorEvent',
    'Get-EventProcessingStatus',
    'Test-EventProcessing',
    
    # Decision execution functions (from DecisionExecution.psm1)
    'Invoke-DecisionExecution',
    'Get-DecisionExecutionStatus',
    'Test-DecisionExecution',
    'Get-SupportedDecisionTypes',
    
    # Autonomous feedback loop functions (from AutonomousFeedbackLoop.psm1)
    'Start-AutonomousFeedbackLoop',
    'Stop-AutonomousFeedbackLoop',
    'Get-FeedbackLoopStatus',
    'Test-AutonomousFeedbackLoop',
    'Resume-AutonomousFeedbackLoop',
    
    # Management functions (from OrchestratorManagement.psm1)
    'Get-OrchestratorStatus',
    'Test-OrchestratorIntegration',
    'Get-OperationHistory',
    'Clear-OrchestratorState',
    'Get-OrchestratorHealth',
    'Reset-OrchestratorToDefaults'
)

#endregion

# REFACTORING MARKER: This file replaces Unity-Claude-MasterOrchestrator.psm1 (1276 lines) on 2025-08-25
# New Architecture: 6 modular components in Core/ subdirectory totaling ~1423 lines
# Complexity Reduction: ~84% per component (average 237 lines vs 1276 lines)