
function Initialize-SystemStatusMonitoring {
    [CmdletBinding()]
    param(
        [string]$ProjectPath = "C:\UnityProjects\Sound-and-Shoal\Unity-Claude-Automation",
        
        [switch]$EnableCommunication = $false,  # Default to false to prevent crashes
        
        [switch]$EnableFileWatcher = $false     # Default to false to prevent crashes
    )
    
    Write-SystemStatusLog "Initializing Day 18 System Status Monitoring..." -Level 'INFO'
    
    try {
        # Update system info with current data
        $script:SystemStatusData.SystemInfo.HostName = $env:COMPUTERNAME
        $script:SystemStatusData.SystemInfo.SystemUptime = Get-SystemUptime
        
        # Initialize subsystems with critical modules
        foreach ($subsystemName in $script:CriticalSubsystems.Keys) {
            $subsystemInfo = $script:CriticalSubsystems[$subsystemName]
            
            $script:SystemStatusData.Subsystems[$subsystemName] = @{
                ProcessId = $null
                Status = "Unknown"
                LastHeartbeat = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')
                HealthScore = 0.0
                Performance = @{
                    CpuPercent = 0.0
                    MemoryMB = 0.0
                    ResponseTimeMs = 0.0
                }
                ModuleInfo = @{
                    Version = "1.0.0"
                    Path = $subsystemInfo.Path
                    ExportedFunctions = @()
                }
            }
            
            # Set up dependencies
            $script:SystemStatusData.Dependencies[$subsystemName] = $subsystemInfo.Dependencies
        }
        
        # Initialize communication features if enabled (Hour 2.5 Enhanced)
        if ($EnableCommunication) {
            Write-SystemStatusLog "Initializing Hour 2.5 Cross-Subsystem Communication Protocol..." -Level 'INFO'
            
            # Initialize cross-module engine events first
            $engineEventResult = Initialize-CrossModuleEvents
            if ($engineEventResult) {
                Write-SystemStatusLog "Cross-module engine events initialized" -Level 'OK'
            }
            
            # Try to initialize named pipe server with research-validated patterns
            $namedPipeResult = Initialize-NamedPipeServer -PipeName $script:SystemStatusConfig.NamedPipeName -TimeoutSeconds 30
            if ($namedPipeResult) {
                Write-SystemStatusLog "Research-validated named pipe communication enabled" -Level 'OK'
            } else {
                Write-SystemStatusLog "Using JSON fallback communication (research-validated patterns)" -Level 'WARN'
            }
            
            # Start background message processor
            $processorResult = Start-MessageProcessor
            if ($processorResult) {
                Write-SystemStatusLog "Background message processor started" -Level 'OK'
            }
            
            # Register default message handlers
            Register-MessageHandler -MessageType "HeartbeatRequest" -Handler {
                param($Message)
                Write-SystemStatusLog "Processing heartbeat request from: $($Message.source)" -Level 'DEBUG'
                
                # Send heartbeat response
                $responseMessage = New-SystemStatusMessage -MessageType "StatusUpdate" -Source "Unity-Claude-SystemStatus" -Target $Message.source
                $responseMessage.payload = @{
                    status = "Healthy"
                    timestamp = (Get-Date).psobject.BaseObject
                    respondingTo = $Message.correlationId
                    healthScore = 1.0
                }
                Send-SystemStatusMessage -Message $responseMessage | Out-Null
            }
            
            Register-MessageHandler -MessageType "HealthCheck" -Handler {
                param($Message)
                Write-SystemStatusLog "Processing health check request from: $($Message.source)" -Level 'DEBUG'
                
                # Perform comprehensive health check
                $healthResults = Test-AllSubsystemHeartbeats
                
                $responseMessage = New-SystemStatusMessage -MessageType "StatusUpdate" -Source "Unity-Claude-SystemStatus" -Target $Message.source
                $responseMessage.payload = @{
                    healthCheckResults = $healthResults
                    timestamp = (Get-Date).psobject.BaseObject
                    respondingTo = $Message.correlationId
                }
                Send-SystemStatusMessage -Message $responseMessage | Out-Null
            }
            
            # Start file watcher for real-time updates if enabled
            if ($EnableFileWatcher) {
                $fileWatcherResult = Start-SystemStatusFileWatcher
                if ($fileWatcherResult) {
                    Write-SystemStatusLog "Real-time file monitoring enabled with debouncing" -Level 'OK'
                } else {
                    Write-SystemStatusLog "File monitoring disabled due to initialization error" -Level 'WARN'
                }
            }
        }
        
        # Write initial system status
        $writeResult = Write-SystemStatus -StatusData $script:SystemStatusData
        if ($writeResult) {
            Write-SystemStatusLog "System status monitoring initialized successfully" -Level 'OK'
            return $true
        } else {
            Write-SystemStatusLog "Failed to write initial system status" -Level 'ERROR'
            return $false
        }
        
    } catch {
        Write-SystemStatusLog "Error initializing system status monitoring: $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

# SIG # Begin signature block
# MIIFqQYJKoZIhvcNAQcCoIIFmjCCBZYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUNPvtID5q2OwwG5Vw0P3+rLpG
# TgqgggMwMIIDLDCCAhSgAwIBAgIQdR0W2SKoK5VE8JId4ZxrRTANBgkqhkiG9w0B
# AQsFADAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0b21hdGlvbi1EZXZlbG9w
# bWVudDAeFw0yNTA4MjAyMTE1MTdaFw0yNjA4MjAyMTM1MTdaMC4xLDAqBgNVBAMM
# I1VuaXR5LUNsYXVkZS1BdXRvbWF0aW9uLURldmVsb3BtZW50MIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAseH3qinVEOhrn2OLpjc5TNT4vGh1BkfB5X4S
# FhY7K0QMQsYYnkZVmx3tB8PqVQXl++l+e3uT7uCscc7vjMTK8tDSWH98ji0U34WL
# JBwXC62l1ArazMKp4Tyr7peksei7vL4pZOtOVgAyTYn5d1hbnsVQmCSTPRtpn7mC
# Azfq2ec5qZ9Kgl7puPW5utvYfh8idtOWa5/WgYSKwOIvyZawIdZKLFpwqOtqbJe4
# sWzVahasFhLfoAKkniKOAocJDkJexh5pO/EOSKEZ3mOCU1ZSs4XWRGISRhV3qGZp
# f+Y3JlHKMeFDWKynaJBO8/GU5sqMATlDUvrByBtU2OQ2Um/L3QIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHw5
# rOy6xlW6B45sJUsiI2A/yS0MMA0GCSqGSIb3DQEBCwUAA4IBAQAUTLH0+w8ysvmh
# YuBw4NDKcZm40MTh9Zc1M2p2hAkYsgNLJ+/rAP+I74rNfqguTYwxpCyjkwrg8yF5
# wViwggboLpF2yDu4N/dgDainR4wR8NVpS7zFZOFkpmNPepc6bw3d4yQKa/wJXKeC
# pkRjS50N77/hfVI+fFKNao7POb7en5fcXuZaN6xWoTRy+J4I4MhfHpjZuxSLSXjb
# VXtPD4RZ9HGjl9BU8162cRhjujr/Lc3/dY/6ikHQYnxuxcdxRew4nzaqAQaOeWu6
# tGp899JPKfldM5Zay5IBl3zs15gNS9+0Jrd0ARQnSVYoI0DLh3KybFnfK4POezoN
# Lp/dbX2SMYIB4zCCAd8CAQEwQjAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0
# b21hdGlvbi1EZXZlbG9wbWVudAIQdR0W2SKoK5VE8JId4ZxrRTAJBgUrDgMCGgUA
# oHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0B
# CQQxFgQUEp0fkrwUCmbHxRYaeQv9jCqWeq4wDQYJKoZIhvcNAQEBBQAEggEAEu5C
# RbyB11tf95XlnSDz1IxoWkuoFZ/uK2Fv3n+VNwhFsTgDhaw/tShYXCj8gj3/7khX
# 42JgryFkk5Shn3eP0i5yZvrx8mzNRX5bmZ916s3VspSsYbXXqG0MCxombMrhYk8+
# tKWHa7aR7YRnMhmZwk41UE1e6NQGaTGH53Doa1Wk4X5eVDffmoItHkX1L0bz+WsE
# fBHmTV2WY8GL5/TBK+B+AaxUWSdLmxSDF4BILZ1xO/Nlghy4T17WaiJCdmAHN1Bs
# Z6llANVXRsdk3mX3RERWrjNSupqBVBu5bdM4z416W0lqSb8Lm6QMY24Y8GJEs4TO
# obzwRiE4bA/PJQGMqA==
# SIG # End signature block
