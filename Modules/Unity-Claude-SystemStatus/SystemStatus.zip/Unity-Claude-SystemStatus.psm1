# Auto-generated modular refactor of Unity-Claude-SystemStatus
$script:ModuleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# Load all function files
Get-ChildItem -Path $ModuleRoot -Recurse -Filter *.ps1 | ForEach-Object { . $_.FullName }

# Initialize configuration after loading all functions
if (Get-Command Initialize-SystemStatusConfig -ErrorAction SilentlyContinue) {
    Initialize-SystemStatusConfig
}

Export-ModuleMember -Function ConvertTo-HashTable, Get-AlertHistory, Get-CriticalSubsystems, Get-ProcessPerformanceCounters, Get-RegisteredSubsystems, Get-ServiceDependencyGraph, Get-SubsystemProcessId, Get-SystemUptime, Get-TopologicalSort, Initialize-CrossModuleEvents, Initialize-NamedPipeServer, Initialize-SubsystemRunspaces, Initialize-SystemStatusConfig, Initialize-SystemStatusMonitoring, Invoke-CircuitBreakerCheck, Invoke-EscalationProcedure, Invoke-MessageHandler, Measure-CommunicationPerformance, New-SubsystemMutex, New-SystemStatusMessage, Read-SystemStatus, Receive-SystemStatusMessage, Register-MessageHandler, Register-Subsystem, Remove-SubsystemMutex, Restart-ServiceWithDependencies, Send-EngineEvent, Send-HealthAlert, Send-HealthCheckRequest, Send-Heartbeat, Send-HeartbeatRequest, Send-SystemStatusMessage, Start-AutonomousAgentSafe, Start-MessageProcessor, Start-ServiceRecoveryAction, Start-SubsystemSession, Start-SystemStatusFileWatcher, Stop-MessageProcessor, Stop-NamedPipeServer, Stop-SubsystemRunspaces, Stop-SystemStatusFileWatcher, Stop-SystemStatusMonitoring, Test-AllSubsystemHeartbeats, Test-AutonomousAgentStatus, Test-CriticalSubsystemHealth, Test-HeartbeatResponse, Test-ProcessHealth, Test-ProcessPerformanceHealth, Test-ServiceResponsiveness, Test-SubsystemMutex, Test-SystemStatusSchema, Unregister-Subsystem, Update-SubsystemProcessInfo, Write-SystemStatus, Write-SystemStatusLog
