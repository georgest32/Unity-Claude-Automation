
function Get-TopologicalSort {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [hashtable]$DependencyGraph
    )
    
    Write-SystemStatusLog "Performing topological sort on dependency graph with $($DependencyGraph.Keys.Count) nodes" -Level 'DEBUG'
    
    [System.Collections.ArrayList]$result = @()
    $visited = @{}
    $visiting = @{}
    
    function Visit-Node($node) {
        Write-SystemStatusLog "Visiting node: $node" -Level 'TRACE'
        
        if ($visiting[$node]) { 
            $errorMsg = "Circular dependency detected involving node: $node"
            Write-SystemStatusLog $errorMsg -Level 'ERROR'
            throw $errorMsg 
        }
        if ($visited[$node]) { 
            Write-SystemStatusLog "Node already visited: $node" -Level 'TRACE'
            return 
        }
        
        $visiting[$node] = $true
        
        # Process dependencies if they exist
        if ($DependencyGraph.ContainsKey($node) -and $DependencyGraph[$node]) {
            foreach ($dependency in $DependencyGraph[$node]) {
                if ($dependency) {  # Only process non-null dependencies
                    Visit-Node $dependency
                }
            }
        }
        
        $visiting[$node] = $false
        $visited[$node] = $true
        [void]$result.Add($node)
        
        Write-SystemStatusLog "Node processed and added to result: $node" -Level 'TRACE'
    }
    
    try {
        foreach ($node in $DependencyGraph.Keys) {
            if (-not $visited[$node]) { 
                Visit-Node $node 
            }
        }
        
        Write-SystemStatusLog "Topological sort completed. Result order: $($result -join ', ')" -Level 'INFO'
        return @($result)
    }
    catch {
        Write-SystemStatusLog "Error in topological sort - $($_.Exception.Message)" -Level 'ERROR'
        return @()
    }
}

# SIG # Begin signature block
# MIIFqQYJKoZIhvcNAQcCoIIFmjCCBZYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUscIkxFe24A5xgWPr33zVAYRA
# RE6gggMwMIIDLDCCAhSgAwIBAgIQdR0W2SKoK5VE8JId4ZxrRTANBgkqhkiG9w0B
# AQsFADAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0b21hdGlvbi1EZXZlbG9w
# bWVudDAeFw0yNTA4MjAyMTE1MTdaFw0yNjA4MjAyMTM1MTdaMC4xLDAqBgNVBAMM
# I1VuaXR5LUNsYXVkZS1BdXRvbWF0aW9uLURldmVsb3BtZW50MIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAseH3qinVEOhrn2OLpjc5TNT4vGh1BkfB5X4S
# FhY7K0QMQsYYnkZVmx3tB8PqVQXl++l+e3uT7uCscc7vjMTK8tDSWH98ji0U34WL
# JBwXC62l1ArazMKp4Tyr7peksei7vL4pZOtOVgAyTYn5d1hbnsVQmCSTPRtpn7mC
# Azfq2ec5qZ9Kgl7puPW5utvYfh8idtOWa5/WgYSKwOIvyZawIdZKLFpwqOtqbJe4
# sWzVahasFhLfoAKkniKOAocJDkJexh5pO/EOSKEZ3mOCU1ZSs4XWRGISRhV3qGZp
# f+Y3JlHKMeFDWKynaJBO8/GU5sqMATlDUvrByBtU2OQ2Um/L3QIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHw5
# rOy6xlW6B45sJUsiI2A/yS0MMA0GCSqGSIb3DQEBCwUAA4IBAQAUTLH0+w8ysvmh
# YuBw4NDKcZm40MTh9Zc1M2p2hAkYsgNLJ+/rAP+I74rNfqguTYwxpCyjkwrg8yF5
# wViwggboLpF2yDu4N/dgDainR4wR8NVpS7zFZOFkpmNPepc6bw3d4yQKa/wJXKeC
# pkRjS50N77/hfVI+fFKNao7POb7en5fcXuZaN6xWoTRy+J4I4MhfHpjZuxSLSXjb
# VXtPD4RZ9HGjl9BU8162cRhjujr/Lc3/dY/6ikHQYnxuxcdxRew4nzaqAQaOeWu6
# tGp899JPKfldM5Zay5IBl3zs15gNS9+0Jrd0ARQnSVYoI0DLh3KybFnfK4POezoN
# Lp/dbX2SMYIB4zCCAd8CAQEwQjAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0
# b21hdGlvbi1EZXZlbG9wbWVudAIQdR0W2SKoK5VE8JId4ZxrRTAJBgUrDgMCGgUA
# oHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0B
# CQQxFgQUsdRuliMHMRvGbKB7FSa20Tvk4GMwDQYJKoZIhvcNAQEBBQAEggEAX6ec
# 7CK5237jbcyV65efb9dPqHwlmUmUK2eUH3esgl4RMdq0PiDJDht8F/LZ8Ylcelk9
# +4yjhbXO28emWmKYBGi4O0V7MfyLJ73OtouKZRbOKX4RwhtUO/vX+AuWn1wzLpaT
# Ku+HhJs+xzskadCWfA2c4ArBOT1fAEWgTks6cToINxvJVMGaCQj/e8QAtbomPPoF
# yuuRuSToKADcSdiVYJLyu+GvWen//i6olfr+0sPx6Wors9ZfnIcU+wbIYcXSm/Kk
# bEHtJ7GpHKJK3oV0i4KgF05hTYgWWWUrZN3awPUcdoQny+KurFIvK92Rq8RbPXqJ
# Sn9LVC+glE2xZi4yuA==
# SIG # End signature block
