
function Invoke-CircuitBreakerCheck {
    <#
    .SYNOPSIS
    Implements circuit breaker pattern for subsystem failure detection
    
    .DESCRIPTION
    Enterprise circuit breaker implementation with three states (Closed/Open/Half-Open):
    - State-based failure tracking and threshold management
    - Per-subsystem circuit breaker instances (research-validated pattern)
    - Integrates with existing system status monitoring
    
    .PARAMETER SubsystemName
    Name of the subsystem to check circuit breaker for
    
    .PARAMETER TestResult
    Health test result to process through circuit breaker
    
    .EXAMPLE
    Invoke-CircuitBreakerCheck -SubsystemName "Unity-Claude-Core" -TestResult $healthResult
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$SubsystemName,
        
        [Parameter(Mandatory=$true)]
        [object]$TestResult
    )
    
    Write-SystemStatusLog "Processing circuit breaker check for subsystem: $SubsystemName" -Level 'DEBUG'
    
    try {
        # Initialize circuit breaker state storage if not exists
        if (-not $script:CircuitBreakerState) {
            $script:CircuitBreakerState = @{}
        }
        
        # Initialize circuit breaker for this subsystem if not exists
        if (-not $script:CircuitBreakerState.ContainsKey($SubsystemName)) {
            $script:CircuitBreakerState[$SubsystemName] = @{
                State = "Closed"  # Closed, Open, Half-Open
                FailureCount = 0
                LastFailureTime = $null
                LastSuccessTime = Get-Date
                StateChangeTime = Get-Date
                FailureThreshold = 3  # Research-validated threshold
                TimeoutSeconds = 60   # SCOM 2025 standard timeout
                TestRequestsInHalfOpen = 0
                MaxTestRequests = 1   # Single test request in half-open
            }
            Write-SystemStatusLog "Initialized circuit breaker for $SubsystemName" -Level 'DEBUG'
        }
        
        $circuitBreaker = $script:CircuitBreakerState[$SubsystemName]
        $currentTime = Get-Date
        
        # Process test result based on current circuit breaker state
        switch ($circuitBreaker.State) {
            "Closed" {
                if ($TestResult.OverallHealthy -or ($TestResult -is [bool] -and $TestResult)) {
                    # Success - reset failure count
                    $circuitBreaker.FailureCount = 0
                    $circuitBreaker.LastSuccessTime = $currentTime
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - Success in Closed state" -Level 'DEBUG'
                } else {
                    # Failure - increment count
                    $circuitBreaker.FailureCount++
                    $circuitBreaker.LastFailureTime = $currentTime
                    
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - Failure $($circuitBreaker.FailureCount)/$($circuitBreaker.FailureThreshold)" -Level 'WARN'
                    
                    # Check if threshold exceeded
                    if ($circuitBreaker.FailureCount -ge $circuitBreaker.FailureThreshold) {
                        $circuitBreaker.State = "Open"
                        $circuitBreaker.StateChangeTime = $currentTime
                        Write-SystemStatusLog "Circuit breaker $SubsystemName - OPENED due to failure threshold" -Level 'ERROR'
                        
                        # Send alert for circuit breaker opening
                        Send-HealthAlert -AlertLevel "Critical" -SubsystemName $SubsystemName -Message "Circuit breaker opened - $($circuitBreaker.FailureCount) consecutive failures"
                    }
                }
            }
            
            "Open" {
                # Check if timeout period has passed
                $timeInOpen = ($currentTime - $circuitBreaker.StateChangeTime).TotalSeconds
                
                if ($timeInOpen -ge $circuitBreaker.TimeoutSeconds) {
                    # Move to Half-Open state for testing
                    $circuitBreaker.State = "Half-Open"
                    $circuitBreaker.StateChangeTime = $currentTime
                    $circuitBreaker.TestRequestsInHalfOpen = 0
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - Moving to Half-Open for testing" -Level 'INFO'
                } else {
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - Remaining in Open state ($([math]::Round($circuitBreaker.TimeoutSeconds - $timeInOpen, 1))s remaining)" -Level 'DEBUG'
                }
            }
            
            "Half-Open" {
                $circuitBreaker.TestRequestsInHalfOpen++
                
                if ($TestResult.OverallHealthy -or ($TestResult -is [bool] -and $TestResult)) {
                    # Success - return to Closed state
                    $circuitBreaker.State = "Closed"
                    $circuitBreaker.FailureCount = 0
                    $circuitBreaker.LastSuccessTime = $currentTime
                    $circuitBreaker.StateChangeTime = $currentTime
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - CLOSED after successful test" -Level 'INFO'
                    
                    # Send alert for circuit breaker recovery
                    Send-HealthAlert -AlertLevel "Info" -SubsystemName $SubsystemName -Message "Circuit breaker closed - subsystem recovered"
                } else {
                    # Failure - return to Open state
                    $circuitBreaker.State = "Open"
                    $circuitBreaker.FailureCount++
                    $circuitBreaker.LastFailureTime = $currentTime
                    $circuitBreaker.StateChangeTime = $currentTime
                    Write-SystemStatusLog "Circuit breaker $SubsystemName - Returned to Open after test failure" -Level 'ERROR'
                }
            }
        }
        
        # Return circuit breaker status
        $circuitBreakerStatus = @{
            SubsystemName = $SubsystemName
            State = $circuitBreaker.State
            FailureCount = $circuitBreaker.FailureCount
            LastFailureTime = $circuitBreaker.LastFailureTime
            LastSuccessTime = $circuitBreaker.LastSuccessTime
            StateChangeTime = $circuitBreaker.StateChangeTime
            IsHealthy = ($circuitBreaker.State -eq "Closed")
            AllowRequests = ($circuitBreaker.State -ne "Open")
        }
        
        return $circuitBreakerStatus
        
    } catch {
        Write-SystemStatusLog "Error in circuit breaker check for $SubsystemName`: $($_.Exception.Message)" -Level 'ERROR'
        throw
    }
}

# SIG # Begin signature block
# MIIFqQYJKoZIhvcNAQcCoIIFmjCCBZYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU42mKP01oa+iDF1gRT8lFE2Ea
# KHOgggMwMIIDLDCCAhSgAwIBAgIQdR0W2SKoK5VE8JId4ZxrRTANBgkqhkiG9w0B
# AQsFADAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0b21hdGlvbi1EZXZlbG9w
# bWVudDAeFw0yNTA4MjAyMTE1MTdaFw0yNjA4MjAyMTM1MTdaMC4xLDAqBgNVBAMM
# I1VuaXR5LUNsYXVkZS1BdXRvbWF0aW9uLURldmVsb3BtZW50MIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAseH3qinVEOhrn2OLpjc5TNT4vGh1BkfB5X4S
# FhY7K0QMQsYYnkZVmx3tB8PqVQXl++l+e3uT7uCscc7vjMTK8tDSWH98ji0U34WL
# JBwXC62l1ArazMKp4Tyr7peksei7vL4pZOtOVgAyTYn5d1hbnsVQmCSTPRtpn7mC
# Azfq2ec5qZ9Kgl7puPW5utvYfh8idtOWa5/WgYSKwOIvyZawIdZKLFpwqOtqbJe4
# sWzVahasFhLfoAKkniKOAocJDkJexh5pO/EOSKEZ3mOCU1ZSs4XWRGISRhV3qGZp
# f+Y3JlHKMeFDWKynaJBO8/GU5sqMATlDUvrByBtU2OQ2Um/L3QIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFHw5
# rOy6xlW6B45sJUsiI2A/yS0MMA0GCSqGSIb3DQEBCwUAA4IBAQAUTLH0+w8ysvmh
# YuBw4NDKcZm40MTh9Zc1M2p2hAkYsgNLJ+/rAP+I74rNfqguTYwxpCyjkwrg8yF5
# wViwggboLpF2yDu4N/dgDainR4wR8NVpS7zFZOFkpmNPepc6bw3d4yQKa/wJXKeC
# pkRjS50N77/hfVI+fFKNao7POb7en5fcXuZaN6xWoTRy+J4I4MhfHpjZuxSLSXjb
# VXtPD4RZ9HGjl9BU8162cRhjujr/Lc3/dY/6ikHQYnxuxcdxRew4nzaqAQaOeWu6
# tGp899JPKfldM5Zay5IBl3zs15gNS9+0Jrd0ARQnSVYoI0DLh3KybFnfK4POezoN
# Lp/dbX2SMYIB4zCCAd8CAQEwQjAuMSwwKgYDVQQDDCNVbml0eS1DbGF1ZGUtQXV0
# b21hdGlvbi1EZXZlbG9wbWVudAIQdR0W2SKoK5VE8JId4ZxrRTAJBgUrDgMCGgUA
# oHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0B
# CQQxFgQUTgr2hTTpDGexBvxQiktU2H2J+14wDQYJKoZIhvcNAQEBBQAEggEAi346
# sAAoli5IPNstJjO1CYfWWTMgWMAGbMgt5VGDc8woyzrQJeLXJhfFM0KqD9m0B2CS
# wnLKcbo4szbcxQkcb7d/gmxCi7/Y7iwmsHaW+SdCDb4Lp91yRtAp3/ogILVnmHk0
# nemKoLi2nEap0jKpvJyjtY3/dfDH9TGjLTCc67DxGQLOe9qs3lGv5ItKxlNItpW2
# Wzdpeknto/ZurLI2VlOrhaa58mXBz5jBDqxiqkjADwiP5/n6v1b/hyswPQusry+T
# BX/twAzRlPYyCIyQUlmVW2nZa+yq38SpR5B8nlPTzhx8rXBJ+tzCVCsLBGLJMsUL
# HhJsN8pwF6S4uMaoNA==
# SIG # End signature block
